// /* tslint:disable:no-unused-variable */
import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormBuilder, FormArray, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { InsuranceHeadingPanelComponent } from './common/insurance-heading-panel/insurance-heading-panel.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { BaseFormComponent } from './base-form.component';
import { MatDialog } from '@angular/material';
import { TransactionalService } from '../services/transactional.service';
import { StateService } from '../services/state.service';
import { StringConstantPipe } from '../pipe/string-constant.pipe';
import { InsuranceSpinnerService } from '../services/insurance-spinner.service';
import { MatSnackBarComponent } from './common/banner/banner.component';
import { ProgressSpinnerDialogComponent } from './common/modal/modal.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BasicInputComponent } from '../../form-insurance-components/input/basic-input/input.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';

@Component({
  selector: 'app-test-comp',
  template: `
        <div id="app">
        <app-basic-input [field]=_field [group]=testFormGroup
        (inputFocusInEvent)="onFocus($event, _field)"
        (inputFocusOutEvent)="onFocusOut($event, _field)"></app-basic-input>
        </div>
    `,
})

export class TestBaseFormComponent extends BaseFormComponent {
  public form: FormGroup;
  public testFormGroup = new FormGroup(
    { 'application_address1': new FormControl('') }
  );
  public _field = {
    'question_reference_id': 1,
    'sequence_number': 1,
    'label': 'Address line 1',
    'name': 'application_address1',
    'type': 'textbasic',
    'value': '',
    'visible_by_default': 1,
    'validations': [{
      'name': 'required',
      'pattern': '',
      'message': 'This field is required',
    }],
  };
  constructor(public transService: TransactionalService, public fb: FormBuilder,
    public stateService: StateService, public matDialogService: MatDialog, public insuranceSpinner: InsuranceSpinnerService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
  }
}

describe('Insurance Base Form Component', () => {
  let component: TestBaseFormComponent;
  let fixture: ComponentFixture<TestBaseFormComponent>;
  let nativeElement: Element;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [
        MatSnackBarComponent,
        TransactionalService,
        StateService,
        MatDialog,
        ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestBaseFormComponent,
        InsuranceHeadingPanelComponent,
        StringConstantPipe,
        ProgressSpinnerDialogComponent,
      ],
    })
      .compileComponents().then(() => {
        fixture = TestBed.createComponent(TestBaseFormComponent);
        component = fixture.componentInstance;
        nativeElement = fixture.nativeElement;
        fixture.detectChanges();
      });
    // .overrideModule(BrowserAnimationsModule, { set: { entryComponents: [ProgressSpinnerDialogComponent] } }).compileComponents();
  }));

  it('getFieldError() when there is no error on field', () => {
    expect(component.getFieldError('name')).toBeNull();
  });

  it('getFieldError() when there is error on field', () => {
    component.stateService.fieldError['name'] = 'Please enter valid values';
    expect(component.getFieldError('name')).toEqual('Please enter valid values');
  });

  it('onFocus()', () => {
    component.stateService.fieldError['application_address1'] = 'Please enter valid values';
    const _ele = document.getElementById('application_address1');
    _ele.dispatchEvent(new Event('focus'));
    // fakeAsync(() => {
    fixture.detectChanges();
    expect(component.stateService.fieldError['application_address1']).toBeUndefined();
    // });
  });

  it('onFocusOut()', () => {
    const _ele: any = document.getElementById('application_address1');
    _ele.value = 'Test';
    _ele.dispatchEvent(new Event('focusout'));
    // fakeAsync(() => {
    fixture.detectChanges();
    expect(component.stateService.fieldError['application_address1']).toBeUndefined();
    // });
  });

  it('getDate() past date', () => {
    const past_date = new Date(Date.now() - 15 * 24 * 60 * 60 * 1000);
    expect(component.getDate('pastDate', 15).getDate()).toEqual(past_date.getDate());
  });

  it('getDate() future date', () => {
    const future_date = new Date(Date.now() + 15 * 24 * 60 * 60 * 1000);
    expect(component.getDate('futureDate', 15).getDate()).toEqual(future_date.getDate());
  });

  it('getDate() todays date', () => {
    const today_date = new Date();
    expect(component.getDate('todaysDate').getDate()).toEqual(today_date.getDate());
  });

  it('applyFormValues()', () => {
    const _formVal = {
      'application_address1': 'Test',
    };
    component.applyFormValues(component.testFormGroup, _formVal);
    fixture.detectChanges();
    const _ele: any = document.getElementById('application_address1');
    fixture.detectChanges();
    expect(_ele.value).toEqual('Test');
  });

  it('removeFieldError()', () => {
    component.stateService.fieldError['application_address1'] = 'Please enter valid values';
    component.removeFieldError('application_address1');
    expect(component.stateService.fieldError['application_address1']).toBeUndefined();
  });

  it('isValid() when Field is Valid', () => {
    const _ele: any = document.getElementById('application_address1');
    const _errors = component.testFormGroup.get('application_address1').errors;
    component.isValid(_ele, 'Test', _errors);
    expect(component.getFieldError('application_address1')).toBeNull();
  });

});

