import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { InsurancePaymentMethodComponent } from './insurance-payment-method.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';

@Component({
  selector: 'app-test-insurance-payment-method',
  template: `
  <app-insurance-payment-method [paymentLabelObject]='["Single Annual Pay - ", "$480 ", "/ year", "yearly"]'>
  </app-insurance-payment-method>
  `,
})

class TestInsurancePaymentMethodComponent {
}

describe('Insurance Payment Method Component', () => {
  let component: InsurancePaymentMethodComponent;
  let fixture: ComponentFixture<TestInsurancePaymentMethodComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestInsurancePaymentMethodComponent,
        InsurancePaymentMethodComponent,
        StepsComponent,
        SummaryPanelComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsurancePaymentMethodComponent);
    component = fixture.debugElement.children[0].componentInstance as InsurancePaymentMethodComponent;
    fixture.detectChanges();
  });

  /* it('should create', () => {
    expect(component).toBeTruthy();
  }); */
});
