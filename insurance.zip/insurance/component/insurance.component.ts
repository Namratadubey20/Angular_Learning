import {
  Component, OnInit, OnDestroy, ViewEncapsulation, Output
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TransactionalService } from '../services/transactional.service';
import { BaseFormComponent } from './base-form.component';
import { StateService } from '../services/state.service';
import { MatDialog } from '@angular/material';
import { InsuranceSpinnerService } from './../services/insurance-spinner.service';

@Component({
  selector: 'app-insurance',
  templateUrl: './insurance.component.html',
  styleUrls: ['./insurance.component.scss'],
})

export class InsuranceComponent extends BaseFormComponent implements OnInit, OnDestroy {
  constructor(public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog,
    public insuranceSpinner: InsuranceSpinnerService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
  }

  ngOnInit() {
    this.insuranceSpinner.show();
    // this.spinners.push(this.showSpinner(this.matDialogService));
  }

  ngOnDestroy() {
    this.insuranceSpinner.hide();
  }
}
