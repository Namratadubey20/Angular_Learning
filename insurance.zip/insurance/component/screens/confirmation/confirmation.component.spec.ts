import { TestBed, async, fakeAsync, getTestBed, ComponentFixture, inject } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { ConfirmationComponent } from './confirmation.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { PurchaseSummaryPanelComponent } from '../../common/purchase-summary-panel/purchase-summary-panel.component';
import { StringConstantPipe } from 'src/app/insurance/pipe/string-constant.pipe';
import { GetLabelPipe } from 'src/app/insurance/pipe/get-label.pipe';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { Router, ActivatedRoute } from '@angular/router';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { of, throwError } from 'rxjs';
import { TransactionalService } from 'src/app/insurance/services/transactional.service';
import { StateService } from '../../../services/state.service';
import { BehaviorSubject } from 'rxjs';
import { MockDialog, MockInsuranceStaticService, MockStateService, MockTransactionalService, questionList } from '../../../../common/mock';

@Component({
  selector: 'app-test-insurance-confirmation',
  template: '<app-insurance-confirmation></app-insurance-confirmation>',
})

class TestInsuranceConfirmationComponent {
}
class MockRouteBlankComponent {
}
describe('Insurance Confirmation Component', () => {
  let component: ConfirmationComponent;
  let fixture: ComponentFixture<TestInsuranceConfirmationComponent>;
  let router: Router;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  let dataLayer: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'dashboard', component: MockRouteBlankComponent },
          { path: 'insurance/insuranceDetails', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [
        MatSnackBarComponent,
        ServiceHandler,
        GoogleTagManagerService,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        { provide: StateService, useValue: MockStateService },
      ],
      declarations: [
        TestInsuranceConfirmationComponent,
        ConfirmationComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        InsuranceHeadingPanelComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceConfirmationComponent);
    router = TestBed.get(Router);
    component = fixture.debugElement.children[0].componentInstance as ConfirmationComponent;
    component.stateService.isConfirmationPageLoad = new BehaviorSubject<Boolean>(false);
    window.dataLayer = dataLayer = [];
    fixture.detectChanges();
  });

  it('should create', inject([InsuranceStaticService], (insuranceService: InsuranceStaticService) => {
    spyOn(insuranceService, 'getApplicationData').and.callFake(() => {
      return of({
        'data': {
          'data': {
            'status': 'Completed',
            'data': {
              'paymentMethod': { 'paymentChannelCode': { 'defaultDisplayText': 'Visa' } },
              'productNo': 6389,
            },
          },
        },
      });
    });
    expect(component).toBeTruthy();
  }));

  it('should navigate back to dashbord home isFTRHomeFn', () => {
    const routerstub1: Router = TestBed.get(Router);
    const navigateSpy1 = spyOn(routerstub1, 'navigate').and.returnValue(['/dashboard']);
    component.isFTRHomeFn('');
    expect(navigateSpy1).toHaveBeenCalledWith(['/dashboard']);
  });

  it('should navigate back to dashbord home navigateHome', () => {
    const routerstub2: Router = TestBed.get(Router);
    const navigateSpy2 = spyOn(routerstub2, 'navigate').and.returnValue(['/dashboard']);
    component.navigateHome();
    expect(navigateSpy2).toHaveBeenCalledWith(['/dashboard']);
  });

  it('should navigate to navigateDashboardFn', inject([TransactionalService], (transService: TransactionalService) => {
    spyOn(transService, 'isLoggedIn').and.returnValue(true);
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateDashboardFn('');
    expect(navigateSpy).toHaveBeenCalledWith(['/dashboard']);
  }));

  it('should return decryptPayload data',
    inject([InsuranceStaticService], (insuranceService: InsuranceStaticService) => {
      spyOn(insuranceService, 'getInsuranceProductSuccessDeclineMessage').and.callFake(() => {
        return of({
          'data':
            '<span class="semi-bold">Congratulations,</span> {{name}}! You have successfully purchased your Professional Liability Policy.',
        });
      });
      component.getInsuranceProductSuccessDeclineMessage('policy_success_message', 'insurance_rakesh');
      expect(component).toBeTruthy();
    }));

  it('should call download', () => {
    component.confirmData['documnet'] = [{
      'id': 12049,
      'createdBy': 'insurance_rakesh',
      'createdAt': '2020-10-06T10:10:27.845+0000',
      'updatedBy': 'insurance_rakesh',
      'updatedAt': '2020-10-06T10:10:27.845+0000',
      'fileTypeName': 'applicationFile',
      'parentObjectTypeName': 'Application',
      'parentObjectId': 14578,
      'productId': 6389,
      'fileTypeDescription': 'Application',
      'name': 'ColonialApplication_14578_20201006_0610.pdf',
    }];
    component.downloadFile('applicationFile', '');
    expect(component).toBeTruthy();
  });

  it('should call download', inject([StateService], (stateService: StateService) => {
    component.confirmData['documnet'] = [{
      'id': 12049,
      'createdBy': 'insurance_rakesh',
      'createdAt': '2020-10-06T10:10:27.845+0000',
      'updatedBy': 'insurance_rakesh',
      'updatedAt': '2020-10-06T10:10:27.845+0000',
      'fileTypeName': 'applicationFile',
      'parentObjectTypeName': 'Application',
      'parentObjectId': 14578,
      'productId': 6389,
      'fileTypeDescription': 'Application',
      'name': 'ColonialApplication_14578_20201006_0610.pdf',
    }];
    component.stateService.insuranceDetails = {
      'applicationId': '123',
      'agreeToAutoRenewal': 'false',
      'questionAnswers': {
        'dynamicQuestions': {}, 'paymentMethod': {}, 'premiumCalculation': {},
        'deliveryMethod': {}, 'termsAndConditions': {}, 'agreeToRenewPolicy': '',
        'amount': '', 'deductible': '',
      },
      'isSetBusinessNameChecked': true,
    };
    component.stateService.insuranceDetails.questionAnswers['applicationFile'] = true;
    component.printFn('');
    expect(component).toBeTruthy();
  }));
});
