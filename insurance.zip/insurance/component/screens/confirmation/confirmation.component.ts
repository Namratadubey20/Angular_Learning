import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { TransactionalService } from '../../../services/transactional.service';
import { StateService } from '../../../services/state.service';
import { StringConstants } from '../../../constants/string-constants';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { BaseFormComponent } from '../../base-form.component';
import { MatDialog } from '@angular/material';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { InsuranceSpinnerService } from 'src/app/insurance/services/insurance-spinner.service';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { UrlConstant } from 'src/app/insurance/constants/url-constant';
import { UtilMethodsService } from 'src/app/insurance/services/util-method.service';
import { environment } from 'src/environments/environment';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-insurance-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss'],
})
export class ConfirmationComponent extends BaseFormComponent implements OnInit, OnDestroy, AfterViewInit {

  appConfig;
  constructor(private router: Router, public transService: TransactionalService, public stateService: StateService,
    public stringConstant: StringConstants, public fb: FormBuilder, public matDialogService: MatDialog,
    public insuranceStaticService: InsuranceStaticService, public insuranceSpinner: InsuranceSpinnerService,
    public snackBar: MatSnackBarComponent, private urlConstant: UrlConstant,
    private gtmService: GoogleTagManagerService,
    public appConfigService: AppConfigService,
    public securityService: SecurityService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }
  public confirmData = {};
  public serverURL = window.location.origin + '/' + environment.downloadURI;
  public applicationDownloadLink = this.serverURL;
  public insurancePolicyDownloadLink = this.serverURL;
  ngOnInit() { // me.stateService.insuranceDetails.applicationId
    const me = this;
    me.insuranceSpinner.show();
    const applicName = me.stateService.insuranceDetails.questionAnswers[me.comparativeConstants.staticQuestionNames.application_firstName]
      + ' '
      + me.stateService.insuranceDetails.questionAnswers[me.comparativeConstants.staticQuestionNames.application_lastName];
    me.confirmData = me.insuranceStaticService.getConfirmResponseFormJson().data;
    delete me.confirmData['applicant'];
    if (!me.stateService.isDeclined && !UtilMethodsService.isEmpty(me.confirmData)) {
      // below api call will give us productId = "data.productNo" in get application api response 18535
      me.insuranceStaticService.getApplicationData(me.stateService.insuranceDetails.applicationId).subscribe((data) => {
        // console.log('insurance applicant  data-->', data);
        // GTM DLV when route on complete page
        const applicationStatus = data ? data.status : '';
        let gtmApplicationStatus: string;
        if (applicationStatus === 'Completed') {
          gtmApplicationStatus = 'Completed';
        } else if (applicationStatus === 'Declined') {
          gtmApplicationStatus = 'Declined';
        } else {
          gtmApplicationStatus = 'pending';
        }
        const paymentPlanType = data['data'].paymentMethod ?
          (data['data'].paymentMethod.paymentChannelCode ?
            data['data'].paymentMethod.paymentChannelCode.defaultDisplayText : '') : '';
        let insurancePremiumType = this.stateService.insuranceDetails.questionAnswers['premiumOption'];
        if (insurancePremiumType === 'monthlyPay') {
          insurancePremiumType = 'month';
        } else {
          insurancePremiumType = 'year';
        }
        this.insuranceAppCompleteGtmEvent('insurance-app-complete', this.stateService.insuranceSelected[0], '',
          'new', this.stateService.insuranceDetails ? this.stateService.insuranceDetails['applicationId'] : '',
          this.stateService.insuranceDetails['premiumAmount'],
          insurancePremiumType, paymentPlanType, gtmApplicationStatus);
        me.confirmData['applicant'] = data;
        if (!UtilMethodsService.isEmpty(data.data.productNo)) {
          me.getPreceedingDataForPolicyConfirmation(applicName);
        }
        console.log('insurance confirm data-->', me.confirmData);
        me.insuranceSpinner.hide();
      }, (error) => {
        const errMsg = me.snackBarErrorMsg(error);
        me.showBanner(me.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        me.insuranceSpinner.hide();
      });
    } else {
      me.getInsuranceProductSuccessDeclineMessage('policy_deccline_message', applicName);
      me.insuranceSpinner.hide();
    }
  }

  ngAfterViewInit() {
    this.insuranceSpinner.hide();
    this.insuranceSpinner.showFooter();
    this.insuranceSpinner.hide();
  }

  getPreceedingDataForPolicyConfirmation(applicName) {
    const _total_calls = 2;
    let _counter = 0;
    const me = this;

    me.insuranceStaticService.getInsuranceProduct(me.confirmData['applicant'].data.productNo).subscribe((productData) => {
      me.confirmData['product'] = productData;
      if (++_counter === _total_calls) {
        me.getInsuranceProductSuccessDeclineMessage('policy_success_message', applicName);
      }
    }, (error) => {
      // errorMessage += error.message;
      const errMsg = me.snackBarErrorMsg(error);
      me.showBanner(me.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      me.insuranceSpinner.hide();
    });


    me.insuranceStaticService.getInsuranceProductDocument(me.confirmData['applicant'].data.productNo).subscribe((productDocument) => {
      me.stateService.insuranceDetails['disablePrintOption'] = {};
      me.confirmData['documnet'] = productDocument;
      me.confirmData['documnet'].forEach(fileObj => {
        if (fileObj.fileTypeName === 'applicationFile') {
          me.applicationDownloadLink += fileObj.id;
        }
        if (fileObj.fileTypeName === 'insurancePolicyFile') {
          me.insurancePolicyDownloadLink += fileObj.id;
        }
        if (++_counter === _total_calls) {
          me.getInsuranceProductSuccessDeclineMessage('policy_success_message', applicName);
        }
        me.stateService.insuranceDetails['disablePrintOption'][fileObj.fileTypeName] = true;
      }, (error) => {
        // errorMessage += error.message;
        const errMsg = me.snackBarErrorMsg(error);
        me.showBanner(me.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        me.insuranceSpinner.hide();
      });
    });


  }

  getInsuranceProductSuccessDeclineMessage(_policyMessage, _applicantName) {
    const me = this;
    me.insuranceStaticService.getInsuranceProductSuccessDeclineMessage(_policyMessage).subscribe((policySuccessDecline) => {
      me.insuranceSpinner.hide();
      me.confirmData['policySuccessDecline'] = policySuccessDecline.data.replace('{{name}}', '</span><span>' + _applicantName);
      if (!me.stateService.isDeclined) {
        me.stateService.isConfirmationPageLoad.next(true);
      }
    }, (error) => {
      // errorMessage += error.message;
      me.insuranceSpinner.hide();
      const errMsg = me.snackBarErrorMsg(error);
      me.showBanner(me.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      me.insuranceSpinner.hide();
    });
  }

  navigateDashboardFn(event) {
    if (this.transService.isLoggedIn()) {
      const originState = sessionStorage.getItem('originState');
      sessionStorage.removeItem('applicationId');
      if (originState === 'rails') {
        if (this.confirmData['applicant']) {
          this.navigateToRails(this.confirmData['applicant'].id, this.confirmData['applicant'].status);
        } else {
          this.navigateToRails(this.stateService.insuranceDetails.applicationId, 'Declined');
        }
      } else {
        this.router.navigate(['/dashboard']);
      }
    } else {
      window.location.href = 'https://www.colonialsurety.com/';
    }
  }

  navigateToRails(id, status) {
    this.securityService.getAccessToken().then(response => {
      sessionStorage.removeItem('originState');
      console.log(this.securityService.requestURL(`?sutoken=${response}&applicationId=${id}&applicationStatus=${status}`));
      let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
      if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
        railsUrl = this.appConfig.colonial_erisa_TPA_url;
      }
      window.open(`${railsUrl}?sutoken=${response}&applicationId=${id}&applicationStatus=${status}`, '_self');
    });
  }

  isFTRHomeFn(event) {
    const originState = sessionStorage.getItem('originState');
    sessionStorage.removeItem('applicationId');
    if (originState === 'rails') {
      this.navigateToRails(this.confirmData['applicant'].id, this.confirmData['applicant'].status);
    } else {
      this.router.navigate(['/dashboard']);
    }
  }

  navigateHome() {
    const originState = sessionStorage.getItem('originState');
    sessionStorage.removeItem('applicationId');
    if (originState === 'rails') {
      this.navigateToRails(this.confirmData['applicant'].id, this.confirmData['applicant'].status);
    } else {
      this.router.navigate(['/dashboard']);
    }
  }

  printFn(event) {
    const me = this;
    // let missingFiles = '';
    console.log('insurance print clicked-->', event, '--', me.stateService.insuranceDetails.questionAnswers);
    me.confirmData['documnet'].forEach(fileObj => {
      if (me.stateService.insuranceDetails.questionAnswers[fileObj.fileTypeName]) {
        delete me.stateService.insuranceDetails.questionAnswers[fileObj.fileTypeName];
        console.log('print doc url-->', me.serverURL + fileObj.id);
        window.open(me.serverURL + fileObj.id, '_blank');
      } /* else {
        for (const printFileOption in me.comparativeConstants.CONFIRM_PRINT) {
          if (me.stateService.insuranceDetails.questionAnswers[printFileOption]) {
            if we remove delete call, selection will remain and user can again click and check for any error if
            delete me.stateService.insuranceDetails.questionAnswers[printFileOption];
            missingFiles += printFileOption;
          }
        }
      } */
    });
  }

  downloadFile(fileTypeName, event) {
    const me = this;
    let fileId = 0;
    let fileName = '';
    me.confirmData['documnet'].forEach(fileObj => {
      if (fileObj.fileTypeName === fileTypeName) {
        fileId = fileObj.id;
        fileName = fileObj.name;
      }
    });
    if (fileId !== 0) {
      /* me.insuranceStaticService.downloadFile(fileId).subscribe((fileContent) => {
        console.log('insurance document fileContent -->', fileContent);
      }); */
      const aLink = document.getElementById(me.stateService.insuranceDetails.applicationId);
      if (aLink) {
        aLink.remove();
      }
      let link;
      link = document.createElement('a');
      link.setAttribute('id', me.stateService.insuranceDetails.applicationId);
      link.download = fileName;
      link.href = me.serverURL + fileId;
      console.log('print doc url-->', me.serverURL + fileId);
      link.click();
    } else {
      me.showBanner(me.snackBar, this.stringConstant.File_DWLD_UNAVAILABLE, BaseFormComponent.ERROR_BAR);
    }
  }

  ngOnDestroy() {
    this.stateService.isDeclined = false;
    this.insuranceSpinner.hide();
  }

  insuranceAppCompleteGtmEvent(event, insuranceType, userType, insuranceClass, applicationID,
    insurancePremium, insurancePremiumType, paymentType, status) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`,
      `${insuranceClass}`,
      `${applicationID}`,
      `${insurancePremium}`,
      `${insurancePremiumType}`,
      `${paymentType}`,
      `${status}`
    );
  }

}
