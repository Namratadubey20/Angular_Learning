// /* tslint:disable:no-unused-variable */
import { TestBed, async, fakeAsync, getTestBed, ComponentFixture, inject } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { InsuranceSearchComponent } from './search.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { ProgressSpinnerDialogComponent } from '../../common/modal/modal.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppConfigService } from 'src/app/app-config-service';
import { Router } from '@angular/router';
import { StateService } from 'src/app/insurance/services/state.service';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { of, Observable, throwError } from 'rxjs';
import { TransactionalService } from 'src/app/insurance/services/transactional.service';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';

@Component({
  selector: 'app-test-search',
  template: '<app-insurance-search></app-insurance-search>',
})

class TestInsuranceSearchComponent {
}

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {

}

declare global {
  interface Window {
    dataLayer: any;
  }
}

describe('Insurance Get Quotes Component', () => {
  let component: InsuranceSearchComponent;
  let fixture: ComponentFixture<TestInsuranceSearchComponent>;
  let router: Router;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  let dataLayer: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'dashboard', component: MockRouteBlankComponent },
          { path: 'insurance/insuranceDetails', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [
        MatSnackBarComponent,
        ServiceHandler,
        GoogleTagManagerService,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestInsuranceSearchComponent,
        MockRouteBlankComponent,
        InsuranceHeadingPanelComponent,
        InsuranceSearchComponent,
        StringConstantPipe,
        ProgressSpinnerDialogComponent,
      ],
    })
      .overrideModule(BrowserAnimationsModule, { set: { entryComponents: [ProgressSpinnerDialogComponent] } }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceSearchComponent);
    router = TestBed.get(Router);
    component = fixture.debugElement.children[0].componentInstance as InsuranceSearchComponent;
    window.dataLayer = dataLayer = [];
    spyOn(component, 'checkIfPageValidForNavigation').and.returnValue(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


});
