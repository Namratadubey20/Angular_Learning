import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { FormBuilder } from '@angular/forms';
import { TransactionalService } from '../../../services/transactional.service';
import { BaseFormComponent } from '../../base-form.component';
import { StateService } from '../../../services/state.service';
import { GetQuoteModel } from '../../../models/get-quote.model';
import { MatDialog } from '@angular/material';
import { Subscription } from 'rxjs';
import { PreloadService } from '../../../services/preload.service';
import { Router, UrlSegment } from '@angular/router';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { StringConstantPipe } from 'src/app/insurance/pipe/string-constant.pipe';
import { StringConstants } from '../../../constants/string-constants';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { UtilMethodsService } from 'src/app/insurance/services/util-method.service';
import { InsuranceSpinnerService } from 'src/app/insurance/services/insurance-spinner.service';
import { ProductConfigService } from '../../../services/product-config.service';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-insurance-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  providers: [
    StringConstantPipe, ProductConfigPipe],
})
export class InsuranceSearchComponent extends BaseFormComponent implements OnInit, OnDestroy, AfterViewInit {
  // comparativeConstants: ComparativeConstants;
  // userRole: UserImpl = null;
  appConfig;
  protected subscriptions: Array<Subscription> = [];
  constructor(public insuranceStaticService: InsuranceStaticService, public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public productConfig: ProductConfigService,
    public productConfigPipe: ProductConfigPipe,
    public matDialogService: MatDialog, private router: Router,
    public snackBar: MatSnackBarComponent,
    public stringConstantPipe: StringConstantPipe,
    public preloadService: PreloadService, public stringConstant: StringConstants,
    public insuranceSpinner: InsuranceSpinnerService,
    private gtmService: GoogleTagManagerService,
    public appConfigService: AppConfigService,
    public securityService: SecurityService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    // this.ComparativeConstants = ComparativeConstants;
    // this.matDialog = MatDialog;
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }


  searchApplicantID(id) {
    if (id.value.length > 0) {
      alert(id.value);
    this.subscriptions.push(this.insuranceStaticService.getApplicationData(id.value).subscribe((data) => {
        const applicantData = data;
        const isIbondProduct = false;
        if (data && data.productType) {
          const isInsuranceProduct = ComparativeConstants.INSURANCE_CODE_ARRAY.indexOf(data.productType.name) > -1 ? true : false;

          let url = '';
          if (isIbondProduct) {
            url = `ibond/application/${data.productTypeCode}/${data.id}`;
          } else if (isInsuranceProduct) {
            url = `/insurance/evaluator?applicationId=${data.id}`;
          }
          if (url) {
          window.open(url, '_blank');
          }
        } else {
          this.showBanner(this.snackBar, this.stringConstant.APPLICANTID_NOTFOUND, BaseFormComponent.ERROR_BAR);
        }

      },
      (error) => {
        const errMsg = !UtilMethodsService.isEmpty(error.error) && error.error.responseDesc || `Application ID doesn't exist`;
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }));
    }
  }

}
