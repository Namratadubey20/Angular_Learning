import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed, tick, fakeAsync, inject } from '@angular/core/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../../../../app-config-service';
import { ServiceHandler } from '../../../../common/utils/service-handler.service';
import { ProductConfigPipe } from '../../../../insurance/pipe/product-config.pipe';
import { MockInsuranceStaticService } from '../../../../common/mock';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { InsuranceStaticService } from '../../../../insurance/services/insurance-static-service';
import { MaterialModule } from '../../../../material.module';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { PurchaseSummaryPanelComponent } from '../../common/purchase-summary-panel/purchase-summary-panel.component';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { InsuranceAgreementComponent } from './agreement.component';
import { of, throwError } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StateService } from 'src/app/insurance/services/state.service';
import { MockStateService } from '../../../../common/mock';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { TransactionalService } from 'src/app/insurance/services/transactional.service';


@Component({
  selector: 'app-test-insurance-agreement',
  template: '<app-insurance-agreement></app-insurance-agreement>',
})

class TestInsuranceAgreementComponent { }

describe('Insurance Agreement Component', () => {
  let component: InsuranceAgreementComponent;
  let fixture: ComponentFixture<TestInsuranceAgreementComponent>;
  let router: Router;
  let activatedRoute: ActivatedRoute;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  let dataLayer: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [
        MatSnackBarComponent,
        ServiceHandler,
        GoogleTagManagerService,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        { provide: InsuranceStaticService, useClass: MockInsuranceStaticService },
        { provide: StateService, useValue: MockStateService },
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: {
              _value: {
                applicationId: '12345',
                isAnonymousUser: true,
              },
            },
          },
        },
      ],
      declarations: [
        TestInsuranceAgreementComponent,
        InsuranceAgreementComponent,
        InsuranceHeadingPanelComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceAgreementComponent);
    router = TestBed.get(Router);
    activatedRoute = TestBed.get(ActivatedRoute);
    component = fixture.debugElement.children[0].componentInstance as InsuranceAgreementComponent;
    window.dataLayer = dataLayer = [];
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  /* it('should create', () => {
     expect(component).toBeTruthy();
   });

   it('should set pageLoaded after view init and get total required fields', () => {
     spyOn(component, 'getTotalRequiredFieldsForSection').and.returnValue('');
     component.ngAfterViewInit();
     expect(component.getTotalRequiredFieldsForSection).toHaveBeenCalled();
   });

   it('should return API response error when getAgreementTerms called',
     inject([StateService, InsuranceStaticService], (stateService: StateService,
       insuranceService: InsuranceStaticService) => {
       const showBanner = spyOn(component, 'showBanner').and.returnValue('');
       const getAgreementTerms = spyOn(insuranceService, 'getAgreementTerms').and.
         returnValue(throwError({ status: 404, error: { message: '' } }));
       const data = {
         'fields': [{
           'question_reference_id': 1,
           'sequence_number': 1,
           'label': '',
           'name': 'aggrementTermsYes',
           'type': 'checkbox',
           'value': '',
           'visible_by_default': 1,
           'options': [
             {
               'id': 1,
               'code': 'yes',
               'label': '',
             },
           ],
         },
         {
           'question_reference_id': 1,
           'sequence_number': 1,
           'label': '',
           'name': 'aggrementYes',
           'type': 'checkbox',
           'value': '',
           'visible_by_default': 1,
           'options': [
             {
               'id': 1,
               'code': 'yes',
               'label': 'Yes, I have read & agree with the terms and conditions of this agreement.*',
             },
           ],
         },
         {
           'id': 68,
           'name': 'readAndAgreeToTerms',
           'label': 'Yes, I have read & agree with the terms and conditions of this agreement.*',
           'type': 'singlecheckbox',
           'validations': [
             {
               'name': 'required',
               'message': 'This field is required',
             },
           ],
         },
         {
           'id': 64,
           'name': 'acknowledgeFraudWarning',
           'label': 'Yes, I have read & I agree',
           'type': 'singlecheckbox',
           'parentObject': 'data.termsAndConditions',
           'validations': [
             {
               'name': 'required',
               'message': 'This field is required',
             },
           ],
         },
         {
           'id': 63,
           'name': 'acknowledgeTerms',
           'label': 'Yes, I acknowledge the above.',
           'type': 'singlecheckbox',
           'parentObject': 'data.termsAndConditions',
           'validations': [
             {
               'name': 'required',
               'message': 'This field is required',
             },
           ],
         },
         {
           'id': 91,
           'name': 'reviewAgentApplication',
           'label': 'I have reviewed the attached application to ensure that all the information is correct.',
           'type': 'singlecheckbox',
           'parentObject': 'data.termsAndConditions',
           'validations': [
             {
               'name': 'required',
               'message': 'This field is required',
             },
           ],
         },
         {
           'id': 98,
           'name': 'agreeToRenewPolicy',
           'label': '-',
           'type': 'radio',
           'parentObject': 'data',
           'validations': [
             {
               'name': 'required',
               'message': 'This field is required',
             },
           ],
           'options': [
             {
               'id': 68,
               'name': 'yes',
               // tslint:disable-next-line: max-line-length
               'label': 'YES, I want to sign up for automatic renewal to ensure that there will not be a
                lapse in coverage. I, {APPLICANT_NAME} understand that Colonial will automatically renew
                upon the expiration date unless otherwise cancelled by Colonial. Prior to expiration,
                I will be offered the opportunity to change or elect not to renew the policy. I,
                {APPLICANT_NAME}, authorize Colonial to automatically charge the credit card account I
                have provided for all renewal policy premium. I represent that I am the owner and/or authorized signer of the account.',
             },
             {
               'id': 69,
               'name': 'no',
               'label': 'NO, I do not want to sign up for automatic renewal to ensure that there will not be a lapse in coverage.',
             },
           ],
         },
         {
           'question_reference_id': 1,
           'sequence_number': 1,
           'label': 'Signature Email',
           'name': 'emailSignature',
           'type': 'textbasic',
           'visible_by_default': 1,
           'placeholder': 'example@email.com',
           'validations': [
             {
               'name': 'required',
               'message': 'This field is required',
             },
             {
               'name': 'pattern',
               // tslint:disable-next-line:quotemark
               // tslint:disable-next-line: max-line-length
               'value': '^([A-Z|a-z|0-9](\.|_|\-|\+|\&){0,1})+[A-Z|a-z|0-9]\@([A-Z|a-z|0-9](\-){0,1})+
               [A-Z|a-z|0-9]((\.){0,1}[A-Z|a-z|0-9]){2,3}\.[a-z]{2,3}$',
               'message': 'E-Signature must match applicant email',
             },
           ],
         }],
       };
       component.ngOnInit();
       expect(getAgreementTerms).toHaveBeenCalled();
       // component.assignPatternToSignature(data.fields);
       spyOn(component, 'assignPatternToSignature');
       component.assignPatternToSignature(data);
       expect(component.assignPatternToSignature).toHaveBeenCalledWith(data);
       expect(showBanner).toHaveBeenCalled();
     }));

   it('should navigate to insurance/yourquotes', async () => {
     const navigateSpy = spyOn(router, 'navigate');
     const event = '';
     component.stateService.SECTIONS[component.parentSectionName]['istouched'] = true;
     component.stateService.SECTIONS[component.parentSectionName]['errors'] = 0;
     component.navigateForwardFn(event);
     fixture.detectChanges();
     fixture.whenStable().then(() => {
       expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insurancePayment'],
         { queryParams: { 'fromUrl': '/insurance/agreement' } });
     });
     expect(component.stateService.editedQuesDetails).toEqual({});
   });

   it('should navigate to insurance/yourquotes', async () => {
     const navigateSpy = spyOn(router, 'navigate');
     const event = true;
     component.navigateBackwardFn(event);
     fixture.detectChanges();
     // fixture.whenStable().then(() => {
     expect(navigateSpy).toHaveBeenCalledWith(['/insurance/yourquotes']);
     // });
   });

   it(`should logout after saving data`, fakeAsync(() => {
     const spy = spyOn(router, 'navigateByUrl');
     const payloadData = component.transService.encryptPayload();
     const pageRef = 'productInformation';
     component.saveApplication(payloadData, pageRef);
     tick(6000);
     const url = spy.calls.first().args[0];
     fixture.detectChanges();
     expect(url).toBe('/secure/logout');
   }));

   it('should navigate to home', inject([StateService, TransactionalService], (stateService: StateService,
     transactionalService: TransactionalService) => {
     const checkLoginAndRedirect = spyOn(transactionalService, 'checkLoginAndRedirect').and.returnValue('');
     component.navigateHome();
     expect(checkLoginAndRedirect).toHaveBeenCalled();
   }));

   it(`should allow user to update application`, inject([InsuranceStaticService], (insuranceService: InsuranceStaticService) => {
     const navigateSpy = spyOn(router, 'navigate');
     const payloadData = component.transService.encryptPayload();
     const pageRef = 'productInformation';
     component.updateApplication(payloadData, pageRef);
     fixture.detectChanges();
     fixture.whenStable().then(() => {
       expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insurancePayment'],
         { queryParams: { 'fromUrl': '/insurance/agreement' } });
       expect(component.stateService.isDeclined).toEqual(false);
     });
     expect(component).toBeTruthy();
   }));

   it('should return API response error when updateApplication called',
     inject([StateService, InsuranceStaticService], (stateService: StateService,
       insuranceService: InsuranceStaticService) => {
       const payloadData = component.transService.encryptPayload();
       const pageRef = 'productInformation';
       const showBanner = spyOn(component, 'showBanner').and.returnValue('');
       const updateApplication = spyOn(insuranceService, 'updateApplication').and.
         returnValue(throwError({ status: 404, error: { message: '' } }));
       component.updateApplication(payloadData, pageRef);
       expect(updateApplication).toHaveBeenCalled();
       expect(showBanner).toHaveBeenCalled();
     }));

   it(`should genrate application id`, async () => {
     const payloadData = component.transService.encryptPayload();
     const pageRef = 'productInformation';
     component.generateApplicationID(payloadData, pageRef);
     fixture.detectChanges();
     fixture.whenStable().then(() => {
       expect(component.stateService.insuranceDetails.applicationId).toEqual('20501');
       expect(component.stateService.isDeclined).toEqual(true);
     });
     expect(component).toBeTruthy();
   });

   it('should handle radio event', () => {
     const eventObj = 'yes';
     const field = {
       'id': 98,
       'name': 'agreeToRenewPolicy',
       'label': '-',
       'type': 'radio',
       'parentObject': 'data',
       'validations': [
         {
           'name': 'required',
           'message': 'This field is required',
         },
       ],
       'options': [
         {
           'id': 68,
           'name': 'yes',
           // tslint:disable-next-line: max-line-length
           'label': 'YES, I want to sign up for automatic renewal to ensure that there will not be a lapse in coverage.
           I, {APPLICANT_NAME} understand that Colonial will automatically renew upon the expiration date unless
           otherwise cancelled by Colonial. Prior to expiration, I will be offered the opportunity to change or
           elect not to renew the policy. I, {APPLICANT_NAME}, authorize Colonial to automatically charge the credit
           card account I have provided for all renewal policy premium. I represent that I am the owner and/or
           authorized signer of the account.',
         },
         {
           'id': 69,
           'name': 'no',
           'label': 'NO, I do not want to sign up for automatic renewal to ensure that there will not be a lapse in coverage.',
         },
       ],
     };
     component.handleRadio(eventObj, field);
   });*/

});
