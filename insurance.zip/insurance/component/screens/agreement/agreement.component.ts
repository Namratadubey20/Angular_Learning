import { Component, OnInit, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { TransactionalService } from '../../../services/transactional.service';
import { BaseFormComponent } from '../../base-form.component';
import { StateService } from '../../../services/state.service';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { StringConstants } from '../../../constants/string-constants';
import { AgreementModel } from '../../../models/agreement.model';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { InsuranceSpinnerService } from 'src/app/insurance/services/insurance-spinner.service';
import { UtilMethodsService } from 'src/app/insurance/services/util-method.service';
import { ComparativeConstants } from 'src/app/insurance/constants/comparative-constants';
import { ProductConfigService } from 'src/app/insurance/services/product-config.service';
import { DialogComponent } from 'src/app/form-insurance-components/dialog/dialog.component';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-insurance-agreement',
  templateUrl: './agreement.component.html',
  styleUrls: ['./agreement.component.scss'],
})
export class InsuranceAgreementComponent extends BaseFormComponent implements OnInit, AfterViewInit {
  appConfig;
  constructor(public insuranceStaticService: InsuranceStaticService, public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog, private router: Router,
    // tslint:disable-next-line:max-line-length
    public stringConstant: StringConstants, public productConfig: ProductConfigService, public snackBar: MatSnackBarComponent, public insuranceSpinner: InsuranceSpinnerService, public dialog: MatDialog,
    private _changeDetectionRef: ChangeDetectorRef, private activatedRoute: ActivatedRoute,
    private gtmService: GoogleTagManagerService,
    public appConfigService: AppConfigService,
    public securityService: SecurityService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.parentSectionName = 'agreement';
    this.sectionName = 'agreement';
    this.modelName = AgreementModel;
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }
  public formatted_date;
  public tncData = '';
  public fnwData = '';
  showSignBy = false;
  ngOnInit() {
    const me = this;
    this.formatted_date = this.transService.formatDateTo(this.getDate('todaysDate'), 'MMMDDYYYY');
    this.stateService.insuranceDetails.questionAnswers['agreementDate'] = new Date().toISOString();
    // UtilMethodsService.formatDateToString(this.getDate('todaysDate'));

    this.insuranceStaticService.getAgreementTerms().subscribe(
      (data) => {
        me.tncData = data.tnc;
        if (data.fraudAndWarning) {
          me.fnwData = data.fraudAndWarning;
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        this.insuranceSpinner.hide();
      }, () => {
        this.insuranceSpinner.hide();
      }
    );
    this.setSubSectionForValidation(this.parentSectionName, this.sectionName);
    this.getQuoteJson = this.insuranceStaticService.getAgreementFormJson();
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.setQuestionNameToStack(this.getQuoteJson.data[i]);
    }
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.loadInitialFields(this.getQuoteJson.data[i].fields);
    }
    // this.assignPatternToSignature(this.questionJSONDatafields);
    // For auto renewal to display applicant name
    for (let i = 0; i < this.questionJSONDatafields.length; i++) {
      if (this.questionJSONDatafields[i]['name'] === 'agreeToRenewPolicy') {
        // tslint:disable-next-line: max-line-length
        const autoRenewalApplicantName = (this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_firstName]).concat(' ')
          .concat(this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_lastName]);
        // tslint:disable-next-line: max-line-length
        const replaceRenewalApplicantName = this.questionJSONDatafields[i]['options'][0]['label'].replace(/{APPLICANT_NAME}/g, autoRenewalApplicantName);
        this.questionJSONDatafields[i]['options'][0]['label'] = replaceRenewalApplicantName;
        // tslint:disable-next-line: max-line-length
        if (this.stateService.insuranceDetails['questionAnswers'].agreeToRenewPolicy === '' || this.stateService.insuranceDetails['questionAnswers'].agreeToRenewPolicy === null) {
          this.stateService.insuranceDetails['questionAnswers'].agreeToRenewPolicy = 'yes';
        }
      }
    }

    this.form = this.createControlwithNewJson(this.questionJSONDatafields);
    this.insuranceSpinner.hide();

    const _value = this.activatedRoute.queryParams['_value'];
    if (_value && _value['action'] === 'save' && Boolean(JSON.parse(_value['isAnonymousUser'])) === true) {
      // before call save for later we need to create applicationId for Anonymous user
      // We have login ID as Anonymous user is now loggedIn user
      const _payloadData = this.transService.encryptPayload(true);
      if (_payloadData && !this.stateService.insuranceDetails['applicationId']
        && this.transService.isUserLogIn()) {
        this.generateApplicationID(_payloadData, this.parentSectionName);
      }
    }
    // GTM DLV when route on agreement page
    let insurancePremiumType = this.stateService.insuranceDetails.questionAnswers['premiumOption'];
    if (insurancePremiumType === 'monthlyPay') {
      insurancePremiumType = 'month';
    } else {
      insurancePremiumType = 'year';
    }
    this.insuranceAppAgreementGtmEvent('insurance-app-agreement', this.stateService.insuranceSelected[0], '',
      'new', this.stateService.insuranceDetails ? this.stateService.insuranceDetails['applicationId'] : '',
      this.stateService.insuranceDetails['premiumAmount'],
      insurancePremiumType);
    sessionStorage.setItem('applicationId', this.stateService.insuranceDetails['applicationId']);
  }

  assignPatternToSignature(jsonData) {
    jsonData.filter(item => {
      if (item['name'] === 'emailSignature') {
        item['validations'].filter(valid => {
          if (valid['name'] === 'pattern') {
            valid['value'] = this.stateService.insuranceDetails['questionAnswers']['applicantEmail'];
          }
        });
      }
    });
  }
  ngAfterViewInit() {
    // this.stateService.insuranceDetails.questionAnswers['emailSignature'] =
    //   this.stateService.insuranceDetails.questionAnswers['applicantEmail'];
    // this.applyFormValues(this.form, this.stateService.insuranceDetails.questionAnswers);
    this.getTotalRequiredFieldsForSection();
    this.highlightInvalidFields(this.form);
    if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['emailSignature'])
      && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['applicantEmail'])
      && (this.stateService.insuranceDetails.questionAnswers['emailSignature'].toLowerCase().trim()
        === this.stateService.insuranceDetails.questionAnswers['applicantEmail'].toLowerCase().trim())) {
      this.showSignBy = true;
    } else {
      this.showSignBy = false;
    }
    this._changeDetectionRef.detectChanges();
  }

  handlCheckBoxChange(eventObj: any, field: any) {
    super.handlCheckBoxChange(eventObj, field);
    if (eventObj.checked) {
      this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = eventObj.checked;
      delete this.stateService.fieldError[eventObj.fieldName.name];
    } else {
      delete this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name];
    }
    this.validatePage(false, [], null);
  }

  handleRadio(eventObj: any, field: any) {
    if (eventObj.value === 'yes') {
      this.stateService.insuranceDetails['agreeToAutoRenewal'] = 'true';
    } else {
      this.stateService.insuranceDetails['agreeToAutoRenewal'] = 'false';
    }
    this.stateService.insuranceDetails['questionAnswers'].agreeToRenewPolicy = eventObj.value;
  }

  navigateBackwardFn(event) {
    this.insuranceSpinner.show();
    this.router.navigate(['/insurance/yourquotes']);
  }

  navigateForwardFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    if (this.stateService.SECTIONS[this.parentSectionName]['istouched'] === true &&
      // tslint:disable-next-line:triple-equals
      this.stateService.SECTIONS[this.parentSectionName]['errors'] == 0) {
      this.stateService.editedQuesDetails = {};
      this.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_CONTINUE;
      // commenting decline page code as DB team making it as mandatory for now
      // if (this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants.staticQuestionNames.readAndAgreeToTerms]) {
      if (!this.transService.isUserLogIn()) {
        // if anonymous user , allow user to jump on Payment page post login
        // login auth guard help here to move anonymous user to login page
        this.router.navigate(['/insurance/insurancePayment'], { queryParams: { 'fromUrl': '/insurance/agreement' } });
      } else {
        // loggedIn user needs to call update API on agreement page when clicks continue and move to payment page
        // if user loggedIn login auth guard allows user to jump on payment page
        const _payloadData = this.transService.encryptPayload();
        if (_payloadData) {
          this.updateApplication(_payloadData, this.parentSectionName);
        }
      }
      // }
      // else {
      //   this.stateService.isDeclined = true;
      //   this.router.navigate(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/agreement' } });
      //   // this.showBanner(this.snackBar, this.stringConstant.CONFIRMATION_DECLINE, BaseFormComponent.ERROR_BAR, 15);
      // }
    } else {
      if (this.stateService.insuranceDetails.questionAnswers['emailSignature']
        !== this.stateService.insuranceDetails.questionAnswers['applicantEmail']) {
        this.showPageError(this.snackBar, false);
      } else {
        this.openWarningDialog();
      }
    }
  }
  openWarningDialog() {
    const dialogRef = this.dialog.open(DialogComponent, {
      data: {
        isContinueButton: false,
        isCancelButton: false,
        iswarningMessage: false,
      },
      width: '550px', position: { top: '100px' },
    });
  }

  updateApplication(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    this.insuranceStaticService.updateApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        this.router.navigate(['/insurance/insurancePayment'], { queryParams: { 'fromUrl': '/insurance/agreement' } });
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        this.insuranceSpinner.hide();
      }, () => {
        this.insuranceSpinner.hide();
      }
    );
  }

  navigateHome() {
    this.transService.checkLoginAndRedirect(this.parentSectionName);
  }

  isSaveForLaterFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    this.stateService.editedQuesDetails = {};
    this.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_SAVE_FOR_LATER;
    const _payloadData = this.transService.encryptPayload(true);
    if (this.transService.isUserLogIn()) {
      // login user save for later
      if (_payloadData) {
        this.saveApplication(_payloadData, this.parentSectionName);
      }
    } else {
      // Anonymous user
      const navigationExtras: NavigationExtras = {
        queryParams: {
          action: 'save',
          returnUrl: '/insurance/agreement',
        },
      };
      this.stateService.SECTIONS['getQuote']['status'] = 'complete';
      this.stateService.SECTIONS['productInformation']['status'] = 'complete';
      this.stateService.SECTIONS['yourQuote']['status'] = 'complete';
      this.router.navigate(['/insurance/create-user'], navigationExtras);
    }
  }

  saveApplication(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    // tslint:disable-next-line: max-line-length
    this.insuranceStaticService.saveApplication(_payloadData, _pageReference).subscribe(
      async (data) => {
        const originState = sessionStorage.getItem('originState');
        sessionStorage.removeItem('applicationId');
        this.insuranceSpinner.hide();
        // this.showBanner(this.snackBar, 'Record Saved Successfully', BaseFormComponent.ERROR_BAR);
        if (!UtilMethodsService.isEmpty(this.activatedRoute.queryParams['_value']['isAnonymousUser']) &&
          Boolean(JSON.parse(this.activatedRoute.queryParams['_value']['isAnonymousUser'])) === true) {
          this.showBanner(this.snackBar, this.stringConstant.APPLICATION_SAVED, BaseFormComponent.SUCCESS_BAR);
          this.activatedRoute.queryParams['_value'] = {};
          this.setDelay(() => {
            this.router.navigateByUrl('/secure/logout');
          }, 5000);
          return;
        }
        console.log('agreement save for later-->', data.id, data.status);
        if (originState === 'rails') {
          this.navigateToRails(data.id, data.status);
        } else {
          await this.router.navigateByUrl('/secure/logout');
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  navigateToRails(id, status) {
    this.securityService.getAccessToken().then(response => {
      sessionStorage.removeItem('originState');
      console.log(this.securityService.requestURL(`?sutoken=${response}`));
      let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
      if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
        railsUrl = this.appConfig.colonial_erisa_TPA_url;
      }
      window.open(`${railsUrl}?sutoken=${response}&applicationId=${id}&applicationStatus=${status}`, '_self');
    });
  }

  onFocusOut(event: any, field: any) {
    super.onFocusOut(event, field);
    if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['emailSignature'])
      && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['applicantEmail'])
      && (this.stateService.insuranceDetails.questionAnswers['emailSignature'].toLowerCase().trim()
        === this.stateService.insuranceDetails.questionAnswers['applicantEmail'].toLowerCase().trim())) {
      this.showSignBy = true;
    } else {
      this.showSignBy = false;
    }
  }

  generateApplicationID(_payloadData, _pageReference) {
    this.insuranceStaticService.createApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        if (data.data && data.data.knockedOut) {
          this.stateService.isDeclined = true;
          this.router.navigate(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
          return;
        }
        this.stateService.insuranceDetails['applicationId'] = data.id;
        if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['applicationId'])) {
          this.isSaveForLaterFn(null);
        }
        this.insuranceSpinner.show();
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  insuranceAppAgreementGtmEvent(event, insuranceType, userType, insuranceClass, applicationID, insurancePremium, insurancePremiumType) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`,
      `${insuranceClass}`,
      `${applicationID}`,
      `${insurancePremium}`,
      `${insurancePremiumType}`
    );
  }

}
