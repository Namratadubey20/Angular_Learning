import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { TransactionalService } from '../../../services/transactional.service';
import { BaseFormComponent } from '../../base-form.component';
import { StateService } from '../../../services/state.service';
import { YourQuoteModel } from '../../../models/your-quote.model';
import { Router, NavigationExtras, ActivatedRoute, NavigationEnd } from '@angular/router';
import { StringConstants } from '../../../constants/string-constants';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { UtilMethodsService } from '../../../services/util-method.service';
import { ProductConfigService } from '../../../services/product-config.service';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { EmailPopupComponent } from '../../common/email-popup/email-popup.component';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';
import { Observable, Subscription, interval } from 'rxjs';
import { ConfirmDialogComponent } from 'src/app/form-insurance-components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-insurance-your-quotes',
  templateUrl: './your-quotes.component.html',
  styleUrls: ['./your-quotes.component.scss'],
  providers: [
    StringConstantPipe, ProductConfigPipe],
})
export class InsuranceYourQuotesComponent extends BaseFormComponent implements OnInit, AfterViewInit, OnDestroy {
  public annualPay = 0;
  public monthlyPay = 0;
  animationCounter = 0;
  animationFlag = false;
  appConfig;
  originState;
  monthlyAmountCalulated;
  private updateSubscription: Subscription;
  // tslint:disable-next-line:max-line-length
  constructor(public insuranceStaticService: InsuranceStaticService,
    public productConfigPipe: ProductConfigPipe, public stringConstantPipe: StringConstantPipe, public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog, private router: Router,
    public productConfig: ProductConfigService, public stringConstant: StringConstants, public snackBar: MatSnackBarComponent,
    public insuranceSpinner: InsuranceSpinnerService, private activatedRoute: ActivatedRoute, public dialog: MatDialog,
    private gtmService: GoogleTagManagerService,
    public appConfigService: AppConfigService,
    public securityService: SecurityService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.parentSectionName = 'yourQuote';
    this.sectionName = 'productPremium';
    this.modelName = YourQuoteModel;
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
    this.originState = sessionStorage.getItem('originState');
  }

  ngOnInit() {
    const me = this;
    // FRN-9 start
    this.getQuoteJson = this.insuranceStaticService.getYourQuotesFormJson();
    this.getInsuranceLimit(this.stateService.insuranceDetails.questionAnswers['profession']);
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.loadInitialFields(this.getQuoteJson.data[i].fields);
    }
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.setQuestionNameToStack(this.getQuoteJson.data[i]);
    }
    // Fix for FTR-4036
    this.limiInsuranceManageOption();
    if (this.stateService.insuranceDetails.questionAnswers.deductible !== null
      && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers.deductible)) {
      this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.YOUR_DEDUCTIBLE]
        = '' + this.stateService.insuranceDetails.questionAnswers.deductible;
    }
    if (this.stateService.insuranceDetails.questionAnswers.amount !== null
      && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers.amount)) {
      this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.YOUR_AGGREGATE]
        = '' + this.stateService.insuranceDetails.questionAnswers.amount;
      if (this.stateService.insuranceDetails['insuranceLimit']
        && this.stateService.insuranceDetails['insuranceLimit'].length > 0) {
        if (this.stateService.insuranceDetails['insuranceLimit'].findIndex(
          lmt => lmt.name === this.stateService.insuranceDetails.questionAnswers.amount) === -1) {
          this.stateService.insuranceDetails.questionAnswers['premiumOption'] = null;
          delete this.stateService.insuranceDetails['premiumAmount'];
          this.stateService.insuranceDetails.questionAnswers.amount = null;
          this.stateService.insuranceDetails.questionAnswers.deductible = null;
        }
      }
    }
    this.form = this.createControlwithNewJson(this.questionJSONDatafields);
    // FRN-9 end

    me.setSubSectionForValidation(me.parentSectionName, me.sectionName);
    const _value = this.activatedRoute.queryParams['_value'];
    if (_value && _value['action'] === 'save' && Boolean(JSON.parse(_value['isAnonymousUser'])) === true) {
      // before call save for later we need to create applicationId for Anonymous user
      // We have login ID as Anonymous user is now loggedIn user
      const _payloadData = this.transService.encryptPayload(true);
      if (_payloadData && !this.stateService.insuranceDetails['applicationId']
        && this.transService.isUserLogIn()) {
        this.generateApplicationID(_payloadData, this.parentSectionName);
      }
    }
    if (this.stringConstantPipe.transform(this.stringConstant.DEFAULT_PAYMENT_METHOD)) {
      this.setProductPaymentMode(this.stringConstantPipe.transform(this.stringConstant.DEFAULT_PAYMENT_METHOD));
    }
    sessionStorage.setItem('applicationId', this.stateService.insuranceDetails['applicationId']);
    if ((this.stateService.insuranceSelected[0] === 'cyber' &&
      (this.stateService.insuranceDetails.questionAnswers['amount'] !== null
        && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['amount'])))
      || (this.stateService.insuranceSelected[0] !== 'cyber' &&
        (this.stateService.insuranceDetails.questionAnswers['amount'] !== null
          && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['amount']))
        && (this.stateService.insuranceDetails.questionAnswers['deductible'] !== null
          && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['deductible'])))) {
      // call premium calc
      const _payloadData = this.transService.encryptPayload();
      if (!UtilMethodsService.isEmpty(this.stateService.quoteId)) {
        _payloadData['quoteId'] = this.stateService.quoteId;
      }
      this.computePremium(_payloadData, 'onInit');
    }
    // UI load Before value set issue , so refreshed the screen
    this.updateSubscription = interval(50).subscribe(
      (val) => {
        if (this.stateService.insuranceDetails['premiumAmount']) {
          this.annualPay = this.stateService.insuranceDetails['premiumAmount'];
          this.monthlyPay = Math.round(this.annualPay / 12);
        }
      });
  }

  ngAfterViewInit() {
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      this.isCustomPageValidationRequired = true;
    }
    this.getTotalRequiredFieldsForSection();
    this.highlightInvalidFields(this.form);
  }

  getInsuranceLimit(_profession) {
    // if condtion will execute only for pnl insurnace product
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_LIMIT_ALLOW_PRODUCT)) {
      this.insuranceStaticService.getInsuranceLimit(_profession).subscribe((_limit) => {
        // this.stateService.insuranceDetails['insuranceLimit'] = _limit['list'];
        for (let i = 0; i < this.getQuoteJson.data.length; i++) {
          this.getQuoteJson.data[i].fields.forEach(amt => {
            if (amt.name === 'amount') {
              amt.options = _limit['list'];
            }
          });
        }
      });
    }
  }

  limiInsuranceManageOption() {
    let limitOption = '';
    const limitOptionObj = {
      id: 62,
      label: '$50,000',
      name: '50000',
    };

    if (this.stateService.insuranceSelected[0] === ComparativeConstants.EPLI_PRODUCT_CODE) {
      if (this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state] === 'NY') {
        limitOption = this.componentStaticQuestionStack['amount'].options.find(opt => opt.name === '50000');
        if (limitOption) {
          // tslint:disable-next-line:max-line-length
          this.componentStaticQuestionStack['amount']['options'].splice(this.componentStaticQuestionStack['amount']['options'].indexOf(limitOption), 1);
        }
      } else {
        limitOption = this.componentStaticQuestionStack['amount']['options'].find(opt => opt.name === '50000');
        if (!limitOption) {
          this.componentStaticQuestionStack['amount']['options'].insert(0, limitOptionObj);
        }
      }
    }
    // this.stateService.insuranceDetails.insuranceLimit use this object to compare and check amount selected, if value
    // exist in amount than pre-populate else reset amount value
  }

  validatePageForNavigation() {
    const isValidated = this.checkIfPageValidForNavigation();
    console.log('isValidated >> ', isValidated);
  }

  navigateBackwardFn(event) {
    if ((this.stateService.insuranceSelected[0] === 'cyber' &&
      (this.stateService.insuranceDetails.questionAnswers['amount'] !== null
        && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['amount'])))
      || (this.stateService.insuranceSelected[0] !== 'cyber' &&
        (this.stateService.insuranceDetails.questionAnswers['amount'] !== null
          && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['amount']))
        && (this.stateService.insuranceDetails.questionAnswers['deductible'] !== null
          && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['deductible'])))) {
      // call popup for confirmation
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        width: '750px', position: { top: '100px' },
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.router.navigate(['/insurance/insuranceDetails']);
          console.log('navigate to back true');
        } else {
          // stay in same page
          console.log('stay in same page false');
        }
      });
    } else {
      this.router.navigate(['/insurance/insuranceDetails']);
    }
  }

  navigateHome() {
    this.transService.checkLoginAndRedirect(this.parentSectionName);
  }

  isSaveForLaterFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    this.stateService.editedQuesDetails = {};
    this.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_SAVE_FOR_LATER;
    const _payloadData = this.transService.encryptPayload(true);
    if (this.transService.isUserLogIn()) {
      // login user save for later
      if (_payloadData) {
        this.saveApplication(_payloadData, this.parentSectionName);
      }
    } else {
      // Anonymous user
      const navigationExtras: NavigationExtras = {
        queryParams: {
          action: 'save',
          returnUrl: '/insurance/yourquotes',
        },
      };
      this.stateService.SECTIONS['getQuote']['status'] = 'complete';
      this.stateService.SECTIONS['productInformation']['status'] = 'complete';
      this.router.navigate(['/insurance/create-user'], navigationExtras);
    }
  }

  isSendToClientFn(event) {
    const applicationId = this.stateService.insuranceDetails['applicationId'];
    this.insuranceSpinner.show();
    this.insuranceStaticService.sendToclientMailDetails(applicationId).subscribe(res => {
      this.insuranceSpinner.hide();
      const dialogRef = this.dialog.open(EmailPopupComponent, {
        data: res,
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          const _payloadData = this.transService.encryptPayload(true);
          if (_payloadData) {
            this.saveApplication(_payloadData, this.parentSectionName);
          }
        }
      });
    }, (error: any) => {
      const errMsg = this.snackBarErrorMsg(error);
      this.insuranceSpinner.hide();
      this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
    });

  }

  onSelectChange(event, field, productType?) {
    super.onSelectChange(event, field);
    this.aggregateChange({ 'data': event, 'field': field, 'productType': productType });
  }

  aggregateChange(event) {
    console.log('your quote aggregate/deductible change-->', event);
    this.insuranceSpinner.show();
    let showErr = true;
    const me = this;
    me.stateService.editedQuesDetails = {};
    const _payloadData = this.transService.encryptPayload();
    if (!UtilMethodsService.isEmpty(this.stateService.quoteId)) {
      _payloadData['quoteId'] = this.stateService.quoteId;
    }
    if (me.stateService.insuranceSelected[0] !== 'cyber' &&
      (this.stateService.insuranceDetails.questionAnswers['amount'] !== null
        && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['amount']))
      && (this.stateService.insuranceDetails.questionAnswers['deductible'] !== null
        && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['deductible']))) {
      if (me.stateService.insuranceSelected[0] === 'pnl') {
        me.computePremium(_payloadData, '');
      }
      if (me.stateService.insuranceSelected[0] === 'epli') {
        if (me.stateService.SECTIONS[me.parentSectionName]['istouched'] === true
          && me.stateService.SECTIONS[me.parentSectionName]['errors'] === 0) {
          showErr = false;
          me.computePremium(_payloadData, '');
        } else {
          if (showErr) {
            this.insuranceSpinner.hide();
            this.showPageError(this.snackBar, true);
          }
        }
      }
    } else if (me.stateService.insuranceSelected[0] === 'cyber' &&
      (this.stateService.insuranceDetails.questionAnswers['amount'] !== null
        && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['amount']))) {
      me.computePremium(_payloadData, '');
    } else {
      this.insuranceSpinner.hide();
    }
    if (this.stringConstantPipe.transform(this.stringConstant.DEFAULT_PAYMENT_METHOD)) {
      // tslint:disable-next-line:max-line-length
      this.stateService.insuranceDetails.questionAnswers['premiumOption'] = this.stringConstantPipe.transform(this.stringConstant.DEFAULT_PAYMENT_METHOD);
    }
    this.validatePage(false, null, null);
  }

  computePremium(_payloadData, callingSrc) {
    const me = this;
    const oldPremium = me.stateService.insuranceDetails['premiumAmount'];
    me.insuranceStaticService.premiumCalculator(_payloadData, me.parentSectionName).subscribe(data => {
      if (data) {
        me.animationCounter++;
        me.stateService.insuranceDetails['animationCounter'] = me.animationCounter;
        if (me.animationCounter > 1) {
          me.animationFlag = true;
        }
        // FRN-688
        if (UtilMethodsService.isEmpty(callingSrc)) { // calling from ngOnInIt
          if (me.stateService.insuranceSelected[0] !== 'cyber') {
            if (!UtilMethodsService.isEmpty(oldPremium) && (oldPremium !== data.premium)) {
              this.stateService.insuranceDetails.questionAnswers['premiumOption'] = null;
              this.stateService.SECTIONS['yourQuote']['status'] = 'inProgress';
            }
          }
        } else {
          if (me.stateService.insuranceSelected[0] !== 'cyber') {
            if (!UtilMethodsService.isEmpty(oldPremium) && (oldPremium !== data.premium)) {
              this.stateService.insuranceDetails.questionAnswers['premiumOption'] = null;
              this.stateService.SECTIONS['yourQuote']['status'] = 'inProgress';
            }
          }
        }

        me.annualPay = data.premium;
        me.monthlyPay = Math.round(me.annualPay / 12);
        me.stateService.insuranceDetails['premiumAmount'] = data.premium;
        this.monthlyAmountCalulated = '$' + Math.round(this.stateService.insuranceDetails['premiumAmount'] / 12) * 2
          + ' ' + this.stringConstant.YOUR_QUOTE_INSTALLMENTS_HELP_TEXT;
      }
    }, (error: any) => {
      const errMsg = this.snackBarErrorMsg(error);
      this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      this.stateService.insuranceDetails.questionAnswers['premiumOption'] = null;
      me.annualPay = 0;
      me.monthlyPay = 0;
      me.stateService.insuranceDetails['premiumAmount'] = 0;
      this.insuranceSpinner.hide();
    }, () => {
      this.insuranceSpinner.hide();
    });
  }

  setProductPaymentMode(paymentMode: any) {
    this.stateService.insuranceDetails.questionAnswers['premiumOption'] = paymentMode;
    this.stateService.editedQuesDetails = {};
    // this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['istouched'] = true;
    this.validatePage(false, [], null);
  }

  navigateForwardFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      this.isCustomPageValidationRequired = true;
      this.modelName = YourQuoteModel;
      this.validatePage(false, [], null);
    }
    if (this.stateService.SECTIONS[this.parentSectionName]['istouched'] === true &&
      // tslint:disable-next-line:triple-equals
      this.stateService.SECTIONS[this.parentSectionName]['errors'] == 0) {
      // this.router.navigate(['/insurance/agreement']);
      // GTM DLV when clicked quote button
      let insurancePremiumType = this.stateService.insuranceDetails.questionAnswers['premiumOption'];
      if (insurancePremiumType === 'monthlyPay') {
        insurancePremiumType = 'month';
      } else {
        insurancePremiumType = 'year';
      }
      this.insuranceAppQuoteGtmEvent('insurance-app-quote', this.stateService.insuranceSelected[0], '',
        'new', this.stateService.insuranceDetails ? this.stateService.insuranceDetails['applicationId'] : '',
        this.stateService.insuranceDetails['premiumAmount'],
        insurancePremiumType);
      this.stateService.editedQuesDetails = {};
      this.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_CONTINUE;
      if (!this.transService.isUserLogIn()) {
        // if anonymous user , allow user to jump on agreement
        this.router.navigate(['/insurance/agreement']);
      } else {
        const _payloadData = this.transService.encryptPayload();
        if (_payloadData) {
          this.updateApplication(_payloadData, this.parentSectionName);
        }
      }
    } else {
      this.showPageError(this.snackBar, false);
    }
  }

  updateApplication(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    // tslint:disable-next-line: max-line-length
    this.insuranceStaticService.updateApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        this.router.navigate(['/insurance/agreement']);
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        this.insuranceSpinner.hide();
      }, () => {
        this.insuranceSpinner.hide();
      }
    );
  }

  saveApplication(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    // tslint:disable-next-line: max-line-length
    this.insuranceStaticService.saveApplication(_payloadData, _pageReference).subscribe(
      async (data) => {
        sessionStorage.removeItem('applicationId');
        this.insuranceSpinner.hide();
        if (this.transService.isAgent()) {
          this.router.navigateByUrl('/dashboard');
          return;
        }
        if (!UtilMethodsService.isEmpty(this.activatedRoute.queryParams['_value']['isAnonymousUser']) &&
          Boolean(JSON.parse(this.activatedRoute.queryParams['_value']['isAnonymousUser'])) === true) {
          this.showBanner(this.snackBar, this.stringConstant.APPLICATION_SAVED, BaseFormComponent.SUCCESS_BAR);
          this.activatedRoute.queryParams['_value'] = {};
          this.setDelay(() => {
            this.router.navigateByUrl('/secure/logout');
          }, 5000);
          return;
        }
        if (this.originState === 'rails') {
          this.navigateToRails(data.id, data.status);
        } else {
          await this.router.navigateByUrl('/secure/logout');
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  navigateToRails(id, status) {
    this.securityService.getAccessToken().then(response => {
      sessionStorage.removeItem('originState');
      console.log(this.securityService.requestURL(`?sutoken=${response}`));
      let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
      if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
        railsUrl = this.appConfig.colonial_erisa_TPA_url;
      }
      window.open(`${railsUrl}?sutoken=${response}&applicationId=${id}&applicationStatus=${status}`, '_self');
    });
  }

  generateApplicationID(_payloadData, _pageReference) {
    this.insuranceStaticService.createApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        if (data.data && data.data.knockedOut) {
          this.stateService.isDeclined = true;
          this.router.navigate(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
          return;
        }
        this.stateService.insuranceDetails['applicationId'] = data.id;
        if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['applicationId'])) {
          this.isSaveForLaterFn(null);
        }
        this.insuranceSpinner.show();
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  insuranceAppQuoteGtmEvent(event, insuranceType, userType, insuranceClass, applicationID, insurancePremium, insurancePremiumType) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`,
      `${insuranceClass}`,
      `${applicationID}`,
      `${insurancePremium}`,
      `${insurancePremiumType}`
    );
  }

  ngOnDestroy() {
    this.updateSubscription.unsubscribe();
  }


}
