import { TestBed, async, ComponentFixture, inject, tick, fakeAsync } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { InsuranceYourQuotesComponent } from './your-quotes.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component } from '@angular/core';
import { InsurancePaymentMethodComponent } from '../../shared/insurance-payment-method/insurance-payment-method.component';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { InsuranceYourProductDetailsComponent } from './your-product-details/your-product-details.component';
import { PurchaseSummaryPanelComponent } from '../../common/purchase-summary-panel/purchase-summary-panel.component';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { Router, ActivatedRoute } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StateService } from '../../../services/state.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { of } from 'rxjs';
import { ProductConfigPipe } from 'src/app/insurance/pipe/product-config.pipe';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { TransactionalService } from '../../../services/transactional.service';
import { MatDialog } from '@angular/material';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { EmailPopupComponent } from '../../common/email-popup/email-popup.component';
import { MockInsuranceStaticService } from '../../../../common/mock';


@Component({
  selector: 'app-test-insurance-your-quotes',
  template: '<app-insurance-your-quotes></app-insurance-your-quotes>',
})

class TestInsuranceYourQuptesComponent {
}

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {
}


describe('Insurance Your Quotes Component', () => {
  let component: InsuranceYourQuotesComponent;
  let fixture: ComponentFixture<TestInsuranceYourQuptesComponent>;
  let router: Router;
  let activatedRoute: ActivatedRoute;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  const dialogMock = {
    close: () => { },
  };
  let dataLayer: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'insurance/insuranceDetails', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [
        MatSnackBarComponent, ServiceHandler, GoogleTagManagerService, MatDialog,
        {
          provide: MatDialogRef,
          useValue: dialogMock,
        },
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        { provide: InsuranceStaticService, useClass: MockInsuranceStaticService },
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: {
              _value: {
                applicationId: '12345',
                isAnonymousUser: true,
              },
            },
          },
        },
      ],
      declarations: [
        TestInsuranceYourQuptesComponent,
        MockRouteBlankComponent,
        InsuranceYourQuotesComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        InsuranceHeadingPanelComponent,
        InsurancePaymentMethodComponent,
        InsuranceYourProductDetailsComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
        EmailPopupComponent,
      ],
    }).overrideModule(BrowserModule, { set: { entryComponents: [EmailPopupComponent] } })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceYourQuptesComponent);
    router = TestBed.get(Router);
    activatedRoute = TestBed.get(ActivatedRoute);
    component = fixture.debugElement.children[0].componentInstance as InsuranceYourQuotesComponent;
    window.dataLayer = dataLayer = [];
    spyOn(component, 'getTotalRequiredFieldsForSection').and.returnValue('');
    spyOn(component, 'checkIfPageValidForNavigation').and.returnValue(true);
    fixture.detectChanges();
  });

  /* it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check if page is valid for navigation', () => {
    component.validatePageForNavigation();
    expect(component.checkIfPageValidForNavigation).toHaveBeenCalled();
  });

  it('should navigate back to insuranceDetails', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateBackwardFn('');
    expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceDetails']);
  });

  it('should navigate forward to agreement screen', inject([StateService, InsuranceStaticService, TransactionalService],
    (stateService: StateService, insuranceService: InsuranceStaticService, transService: TransactionalService) => {
      const navigateSpy = spyOn(router, 'navigate');
      stateService.SECTIONS['yourQuote']['istouched'] = true;
      stateService.SECTIONS['yourQuote']['errors'] = 0;
      const isUserLogIn = spyOn(transService, 'isUserLogIn').and.returnValue(false);
      const payloadData = component.transService.encryptPayload();
      const pageRef = 'yourQuote';
      component.navigateForwardFn('');
      expect(isUserLogIn).toHaveBeenCalled();
      expect(navigateSpy).toHaveBeenCalledWith(['/insurance/agreement']);
      component.updateApplication(payloadData, pageRef);
    }));

  it('should return showPageError', inject([StateService], (stateService: StateService) => {
    stateService.SECTIONS['yourQuote']['istouched'] = false;
    expect(component.navigateForwardFn('')).toBeUndefined();
  }));

  it('should aggregate change', () => {
    expect(component.aggregateChange('')).toBeUndefined();
  });

  it('should call isSaveForLaterFn', () => {
    expect(component.isSaveForLaterFn('')).toBeUndefined();
  });

  it('should set product payment', () => {
    expect(component.setProductPaymentMode('Single Annual Pay')).toBeUndefined();
  });

  it('should show loading indicator if the page is not loaded', inject([InsuranceStaticService],
    (insuranceStaticService: InsuranceStaticService) => {
      const spinnerSpy = spyOn(TestBed.get(InsuranceSpinnerService), 'show');
      component.insuranceStaticService.sendToclientMailDetails('1111');
      component.transService.encryptPayload(true);
      component.isSendToClientFn('');
      expect(spinnerSpy).toHaveBeenCalled();
    }));

  it(`should genrate application id`, async () => {
    const payloadData = component.transService.encryptPayload();
    const pageRef = 'productInformation';
    component.generateApplicationID(payloadData, pageRef);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.stateService.insuranceDetails.applicationId).toEqual('20501');
    });
  });

  it('should logout after saving data', fakeAsync(() => {
    const spy = spyOn(router, 'navigateByUrl');
    const payloadData = component.transService.encryptPayload();
    const pageRef = 'productInformation';
    component.saveApplication(payloadData, pageRef);
    tick(6000);
    const url = spy.calls.first().args[0];
    fixture.detectChanges();
    expect(url).toBe('/secure/logout');
  })); */

});
