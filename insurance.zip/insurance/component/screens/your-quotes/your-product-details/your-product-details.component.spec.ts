import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { InsuranceYourProductDetailsComponent } from './your-product-details.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StringConstantPipe } from '../../../../pipe/string-constant.pipe';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';
import { ProductConfigPipe } from 'src/app/insurance/pipe/product-config.pipe';

@Component({
  selector: 'app-test-insurance-professional-liability',
  template: '<app-insurance-product-coverage-pay [data]=data [payAmount]=payAmount></app-insurance-product-coverage-pay>',
})

class TestInsuranceYourProductDetailsComponent {
  public data = ['pnl'];
  public payAmount = 421;
}

describe('Insurance Professional Liability Component', () => {
  let component: InsuranceYourProductDetailsComponent;
  let fixture: ComponentFixture<TestInsuranceYourProductDetailsComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestInsuranceYourProductDetailsComponent,
        InsuranceYourProductDetailsComponent,
        StringConstantPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceYourProductDetailsComponent);
    component = fixture.debugElement.children[0].componentInstance as InsuranceYourProductDetailsComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
