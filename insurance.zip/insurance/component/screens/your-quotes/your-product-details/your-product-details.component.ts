import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { InsuranceStaticService } from '../../../../services/insurance-static-service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { TransactionalService } from '../../../../services/transactional.service';
import { BaseFormComponent } from '../../../base-form.component';
import { StateService } from '../../../../services/state.service';
import { StringConstants } from '../../../../constants/string-constants';
import { YourQuoteModel } from '../../../../models/your-quote.model';
import { UtilMethodsService } from '../../../../services/util-method.service';
import { InsuranceSpinnerService } from '../../../../services/insurance-spinner.service';
import { ComparativeConstants } from '../../../../constants/comparative-constants';
import { ProductConfigService } from 'src/app/insurance/services/product-config.service';
import { ProductConfigPipe } from 'src/app/insurance/pipe/product-config.pipe';
import { StringConstantPipe } from 'src/app/insurance/pipe/string-constant.pipe';
import { EvaluateExpressionPipe } from 'src/app/insurance/pipe/evaluate-expression.pipe';
import { animation } from '@angular/animations';
@Component({
  selector: 'app-insurance-product-coverage-pay',
  templateUrl: './your-product-details.component.html',
  styleUrls: ['./your-product-details.component.scss'],
  providers: [
    ProductConfigPipe, StringConstantPipe, EvaluateExpressionPipe],
})
export class InsuranceYourProductDetailsComponent extends BaseFormComponent implements OnInit {
  constructor(public insuranceStaticService: InsuranceStaticService, public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog,
    public stringConstant: StringConstants, public productConfig: ProductConfigService, public insuranceSpinner: InsuranceSpinnerService,
    public productConfigPipe: ProductConfigPipe, public stringConstantPipe: StringConstantPipe,
    public evaluateExpressionPipe: EvaluateExpressionPipe) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
  }

  @Input() data: any;
  @Input() payAmount: number;
  @Output() aggregateChange = new EventEmitter();
  @Output() deductibleChange = new EventEmitter();
  ngOnInit() {
  }

  limiInsuranceManageOption() {
    let limitOption = '';
    const limitOptionObj = {
      id: 62,
      label: '$50,000',
      name: '50000',
    };

    if (this.stateService.insuranceSelected[0] === ComparativeConstants.EPLI_PRODUCT_CODE) {
      if (this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state] === 'NY') {
        limitOption = this.componentStaticQuestionStack['amount'].options.find(opt => opt.name === '50000');
        if (limitOption) {
          // tslint:disable-next-line:max-line-length
          this.componentStaticQuestionStack['amount']['options'].splice(this.componentStaticQuestionStack['amount']['options'].indexOf(limitOption), 1);
        }
      } else {
        limitOption = this.componentStaticQuestionStack['amount']['options'].find(opt => opt.name === '50000');
        if (!limitOption) {
          this.componentStaticQuestionStack['amount']['options'].insert(0, limitOptionObj);
        }
      }
    }

  }

  getInsuranceLimit(_profession) {
    // if condtion will execute only for pnl insurnace product
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_LIMIT_ALLOW_PRODUCT)) {
      this.insuranceStaticService.getInsuranceLimit(_profession).subscribe((_limit) => {
        // this.stateService.insuranceDetails['insuranceLimit'] = _limit['list'];
        for (let i = 0; i < this.getQuoteJson.data.length; i++) {
          this.getQuoteJson.data[i].fields.forEach(amt => {
            if (amt.name === 'amount') {
              amt.options = _limit['list'];
            }
          });
        }
      });
    }
  }

  /* onSelectChange(event, field, productType?) {
    super.onSelectChange(event, field);
    this.aggregateChange.emit({ 'data': event, 'field': field, 'productType': productType });
    let yourKey;
    let koKey;
    if (field.name === ComparativeConstants.YOUR_AGGREGATE) {
      koKey = this.data.toString().toUpperCase() + '_' + ComparativeConstants.AGGREGATE;
      yourKey = ComparativeConstants.YOUR_AGGREGATE;
    } else {
      koKey = this.data.toString().toUpperCase() + '_' + ComparativeConstants.DEDUCTIBLE;
      yourKey = ComparativeConstants.YOUR_DEDUCTIBLE;
    }
    Object.keys(this.stateService.insuranceDetails.questionAnswers.dynamicQuestions).forEach(dq => {
      if (dq.indexOf(koKey) > -1) {
        this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[dq]
          = this.stateService.insuranceDetails.questionAnswers[yourKey];
      }
    });
  } */

}
