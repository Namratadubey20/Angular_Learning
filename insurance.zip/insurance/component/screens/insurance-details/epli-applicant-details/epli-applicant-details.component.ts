import { AfterViewInit, Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ComparativeConstants } from '../../../../constants/comparative-constants';
import { StringConstants } from '../../../../constants/string-constants';
import { InsuranceDetailsModel } from '../../../../models/insurance-details.model';
import { DirectiveValidationService } from '../../../../services/directive-validation.service';
import { InsuranceStaticService } from '../../../../services/insurance-static-service';
import { StateService } from '../../../../services/state.service';
import { TransactionalService } from '../../../../services/transactional.service';
import { UtilMethodsService } from '../../../../services/util-method.service';
import { BaseFormComponent } from '../../../base-form.component';
import { ProductConfigService } from '../../../../services/product-config.service';
import { InsuranceSpinnerService } from '../../../../services/insurance-spinner.service';
import { ProductConfigPipe } from '../../../../pipe/product-config.pipe';
import { MatSnackBarComponent } from '../../../common/banner/banner.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-epli-applicant-details',
  templateUrl: 'epli-applicant-details.component.html',
  providers: [ProductConfigPipe],
  styleUrls: ['./epli-applicant-details.component.scss'],

})
export class EPLIApplicantDetailComponent extends BaseFormComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() getQuoteJson;
  getQuoteStaticJson: any;
  productSpecificQuestions = [];
  @Input() queSectionName: any;
  // @Input() sectionName: any;
  parentSectionName = 'productInformation';
  sectionName = 'applicantDetails';
  // filtered: any[];
  quesListForSection = [{}];
  knockoutpanel2QueSet: any;
  bufferKnockoutPanel2QueSet: any;
  @Output() professionChangeEvent = new EventEmitter<string>();


  constructor(public insuranceStaticService: InsuranceStaticService, public transService: TransactionalService,
    public productConfigPipe: ProductConfigPipe, public productConfig: ProductConfigService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog, public stringConstant: StringConstants,
    public insuranceSpinner: InsuranceSpinnerService, public snackBar: MatSnackBarComponent, private router: Router) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.modelName = InsuranceDetailsModel;
    this.parentSectionName = 'productInformation';
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;

  }

  ngOnInit() {


    this.getQuoteStaticJson = UtilMethodsService.copyObject(this.insuranceStaticService.getInsuranceDetailFormJson());
    // this.setSubSectionForValidation(this.parentSectionName, this.sectionName);
    // this.publishQuestionForForm();
    console.log('getQuoteJson', this.getQuoteStaticJson);
    this.getProductSpecificQuestions(this.getQuoteStaticJson, this.resetGetQuoteJson);
    // for (let i = 0; i < this.getQuoteJson.data.length; i++) {
    //   this.setQuestionNameToStack(this.getQuoteJson.data[i]);
    // }
    this.stateService.preloadData.state = UtilMethodsService.copyObject(this.stateService.preloadData.allowedStates);
    // for (let i = 0; i < this.getQuoteJson.data.length; i++) {
    //   this.loadInitialFields(this.getQuoteJson.data[i].fields);
    // }
    // this.form = this.createControlwithNewJson(this.questionJSONDatafields);





    console.log('--> ', this.getQuoteJson);
    this.knockoutpanel2QueSet = UtilMethodsService.copyObject(this.getQuoteJson);
    this.associatedProduct = this.sectionName;
    this.sectionName = this.sectionName;
    this.filterQuestionSectionSpecific();
    this.loadFormWithJson(this.knockoutpanel2QueSet);
    if (this.knockoutpanel2QueSet) {
      this.bufferKnockoutPanel2QueSet = UtilMethodsService.copyObject(this.knockoutpanel2QueSet);
    }
  }

  getProductSpecificQuestions(getQuoteJson, callback) {
    this.stateService.insuranceSelected.forEach((prod) => {
      getQuoteJson.data[0].fields.forEach((element) => {

        if (element.allowedproduct && element.allowedproduct.includes(prod)) {
          const isObjPresent = this.productSpecificQuestions.find(_obj => _obj.name === element.name);
          if (!isObjPresent) {
            this.productSpecificQuestions.push(element);
          }
        }
      });
    });
    callback(getQuoteJson, this.productSpecificQuestions);
    this.getQuoteJson.questions = this.getQuoteJson.questions.concat(getQuoteJson.data[0].fields);

  }


  resetGetQuoteJson(getQuoteJson, productSpecificQuestions) {
    getQuoteJson.data[0].fields = productSpecificQuestions;

  }
  filterQuestionSectionSpecific() {
    this.quesListForSection = this.knockoutpanel2QueSet.questions.filter((que: any) => {
      return (que.sectionName && this.queSectionName.includes(que.sectionName)) || !que.sectionName;
    });

    if (this.quesListForSection.length > 0) {
      this.knockoutpanel2QueSet.questions = this.quesListForSection;
    }
  }

  // ngAfterViewInit() {
  //   if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
  //     this.isCustomPageValidationRequired = true;
  //   }
  //   this.getTotalRequiredFieldsForSection();
  //   this.highlightInvalidFields(this.form);
  // }

  loadFormWithJson(getQuoteJson) {
    getQuoteJson.fields = getQuoteJson.questions;
    this.setQuestionNameToStack(getQuoteJson);
    this.loadInitialFields(getQuoteJson.fields);
    this.form = this.createControlwithNewJson(this.questionJSONDatafields);
    // FRN-13 profession should always disable
    if (!UtilMethodsService.isEmpty(this.form) && this.form.controls['profession']) {
      this.form.controls['profession'].disable();
    }
    if (this.transService.isClientAssociatedWithAgent() || this.transService.isAgent()) {
      this.transService.setControlState(this.insuranceSpinner, this.form);
      // by default state and city will disable on 2nd page
      this.disableFormControls(this.stateService.insuranceDetails['isPrepopulateUserDetails'], this.form, true);
    } else {
      // disbale only state city last parmeter true disables only state n city
      this.disableFormControls(this.stateService.insuranceDetails['isPrepopulateUserDetails'], this.form, true);
    }
    if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
      this.insuranceStaticService.getClientInfoOnType('P', this.transService.getPersonalId()).subscribe((res => {
        if (res.insurancePolicyPurchased || res.policyPurchasedOnCompanyName) {
          this.form.controls['applicantName'].disable();
        }
      }));
      /* for Direct Client */
    } else {
      if (this.transService.isUserLogIn()) {
        this.insuranceStaticService.getClientInfoOnType('P', this.stateService.userID).subscribe((res => {
          if (res.insurancePolicyPurchased || res.policyPurchasedOnCompanyName) {
            this.form.controls['applicantName'].disable();
          }
        }));
      }
    }
    // this.disableFormControls(this.stateService.insuranceDetails['isPrepopulateUserDetails'], this.form, true);
    // this.setSubSectionForValidation(this.parentSectionName, this.stateService.insuranceSelected[0]);

  }


  // onFocusOut(event: any, field: any) {
  //   super.onFocusOut(event, field);
  // }

  onFocus(event: any, field: any) {
    super.onFocus(event, field);
  }

  public subscribeControl(group, field) {
    const me = this;
    me.valueChangeSubscribe = group.get(field.name).valueChanges
      // .debounceTime(500)
      .subscribe((answerEvent) => {
        this.stateService.isApplicationReadyToAction = false;
        if (!UtilMethodsService.isEmpty(answerEvent)) {
          if (field.sectionName) {
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = answerEvent;
          } else {
            me.stateService.insuranceDetails.questionAnswers[field.name] = answerEvent;
          }
          me.stateService.screenMapObject[field.name] = answerEvent;
          if (field.type === 'date') {
            // me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] =
            //   UtilMethodsService.formatDateToString(answerEvent);
            if (field.sectionName) {
              me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name]
                = UtilMethodsService.formatDateToString(answerEvent);
            } else {
              me.stateService.insuranceDetails.questionAnswers[field.name] = UtilMethodsService.formatDateToString(answerEvent);
            }
          }
          if (field.type === 'textcurrency') {
            const formattedValue = DirectiveValidationService.formatMoney(answerEvent);
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = formattedValue.replace(/,/ig, '');
          }
          if (field.name === ComparativeConstants.EPLI_FILE_UPLOAD_PARENT_KEY) {
            delete me.stateService.insuranceDetails.questionAnswers['attachDetails'];
          }
          if (field.name === 'state') {
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = answerEvent;
          }
        } else {
          if (field.sectionName) {
            delete me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name];
          } else {
            delete me.stateService.insuranceDetails.questionAnswers[field.name];
          }
          if (field.name === 'state') {
            delete me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name];
          }

        }

        if (me.parentSectionName && me.sectionName) {
          const evaluateDC = function() {
            me.evaluateDisplayCriteriaForQuestions();
          };
          const validatePageMethod = function() {
            me.validatePage(false, [], null);
          };
          const executeEvalDC = this.transService.debounce(evaluateDC, 500);
          const executeDebounceMethod = this.transService.debounce(validatePageMethod, 1000);
          executeEvalDC();
          executeDebounceMethod();
        }
      });
  }

  ngAfterViewInit() {
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      this.isCustomPageValidationRequired = true;
    }
    this.getTotalRequiredFieldsForSection();
    this.highlightInvalidFields(this.form);

    // form validation when user click continue on insurance details page
    // and all accordion get open
    this.subscriptions.push(this.stateService.isPageVaildate.subscribe((_isPageValidRequired) => {
      if (_isPageValidRequired) {
        if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
          this.isCustomPageValidationRequired = true;
        }
        this.getTotalRequiredFieldsForSection();
        this.highlightInvalidFields(this.form);
      }
    }));
  }

  populateGooglePlaceValues(event) {
    console.log('google place--', event);
    // tslint:disable-next-line:max-line-length
    this.setGooglePlaceValues(event, [ComparativeConstants.staticQuestionNames.application_address1, ComparativeConstants.staticQuestionNames.application_address2, ComparativeConstants.staticQuestionNames.application_city, ComparativeConstants.staticQuestionNames.application_state, ComparativeConstants.staticQuestionNames.application_zipCode], this.snackBar, this.stringConstant, true, this.router, this.matDialogService);
    /* if (this.productConfigPipe.transform(this.productConfig.refreshKOQuestion)) {
      this.resetKnockOutQuestions(this.professionChangeEvent);
    } commented for FRN-773*/
    this.validatePage(false, null, null);
  }
  onFocusOut(event: any, field: any) {
    super.onFocusOut(event, field);
    if (this.form.controls[field.name].value && this.transService.isFieldTypeInput(field.type)) {
      this.form.controls[field.name].setValue(this.form.controls[field.name].value.trim());
    }
    if (field.name === ComparativeConstants.staticQuestionNames.application_zipCode) {
      // tslint:disable-next-line:max-line-length
      const me = this;
      // tslint:disable-next-line:max-line-length
      console.log('zipCode--', this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode]);
      // tslint:disable-next-line:max-line-length
      if (this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode]) {
        // tslint:disable-next-line:max-line-length
        this.getZipCodeFromAddress(this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode]);
        if (this.parentSectionName && this.sectionName) {
          const evaluateDC = function() {
            me.evaluateDisplayCriteriaForQuestions();
          };
          const validatePageMethod = function() {
            me.validatePage(false, [], null);
          };
          const executeEvalDC = me.transService.debounce(evaluateDC, 500);
          const executeDebounceMethod = me.transService.debounce(validatePageMethod, 1000);
          executeEvalDC();
          executeDebounceMethod();
        }
      }
    }
    // if (field.name === ComparativeConstants.staticQuestionNames.application_firstName ||
    //   field.name === ComparativeConstants.staticQuestionNames.application_lastName) {
    //   this.setApplicantBusinessName('');
    // }
    if (field.name === ComparativeConstants.staticQuestionNames.application_businessName) {
      // if business name is changed just uncheck the box
      // have to check for previous value and current value if not match then reset
      const businessName = (this.form.controls[ComparativeConstants.staticQuestionNames.application_firstName].value).concat(' ')
        .concat(this.form.controls[ComparativeConstants.staticQuestionNames.application_lastName].value);
      if (!UtilMethodsService.isEmpty(this.form.controls[field.name].value)
        && !UtilMethodsService.isEmpty(businessName)
        && this.form.controls[field.name].value.toUpperCase() !== businessName.toUpperCase()) {
        // this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.setApplicantName] = false;
      }
    }
  }
  getZipCodeFromAddress(zipCode): void {
    this.insuranceSpinner.show();
    const me = this;
    me.insuranceStaticService.getZipCodeFromAddress(zipCode).subscribe((response) => {
      this.insuranceSpinner.hide();
      console.log(response);
      if (this.stateService.preloadData.sanctionStates.includes(response.state)) {
        // tslint:disable-next-line:max-line-length
        this.showBanner(this.snackBar, this.stringConstant.SANCTIONSTATE_SEL_MESSAGE.concat(response.state), BaseFormComponent.ERROR_BAR);
        this.form.controls[ComparativeConstants.staticQuestionNames.application_zipCode].reset();
        delete this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode];
      } else {
        // tslint:disable-next-line:max-line-length
        const formattedResponse = UtilMethodsService.filterEmptyValueFromObject(UtilMethodsService.copyObject(response));
        if (formattedResponse.city) {
          me.setGooglePlaceValues({ [ComparativeConstants.staticQuestionNames.application_city]: formattedResponse.city },
            [ComparativeConstants.staticQuestionNames.application_city], this.snackBar, this.stringConstant, false);
        }
        if (formattedResponse.state) {
          me.setGooglePlaceValues({ [ComparativeConstants.staticQuestionNames.application_state]: formattedResponse.state },
            [ComparativeConstants.staticQuestionNames.application_state], this.snackBar, this.stringConstant,
            true, this.router, this.matDialogService, formattedResponse.state);
        }
        if (!formattedResponse.city || !formattedResponse.state) {
          this.showBanner(this.snackBar, response.invalidZipCodeMessage, BaseFormComponent.ERROR_BAR);
          this.form.controls[ComparativeConstants.staticQuestionNames.application_zipCode].reset();
          delete this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode];
        }
        if (formattedResponse.state) {
          if (this.productConfigPipe.transform(this.productConfig.refreshKOQuestion)) {
            this.resetKnockOutQuestions(this.professionChangeEvent);
          }
          this.validatePage(false, null, null);
        }
      }
    },
      (error: any) => {
        this.insuranceSpinner.hide();
        const errMsg = this.snackBarErrorMsg(error);
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        this.form.controls[ComparativeConstants.staticQuestionNames.application_zipCode].reset();
        delete this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode];
      });
  }

  onSelectWithSearchChange(event: any, field: any) {
    super.onSelectWithSearchChange(event, field);
    if (field.name === ComparativeConstants.staticQuestionNames.application_state) {
      this.form.controls[ComparativeConstants.staticQuestionNames.application_zipCode].reset();
      if (this.productConfigPipe.transform(this.productConfig.refreshKOQuestion)) {
        this.resetKnockOutQuestions(this.professionChangeEvent);
      }
      this.validatePage(false, null, null);
      delete this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode];
    } else if (field.name === ComparativeConstants.staticQuestionNames.application_profession) {
      if (this.productConfigPipe.transform(this.productConfig.refreshKOQuestion)
        && this.stateService.insuranceSelected[0] !== ComparativeConstants.EPLI_PRODUCT_CODE) {
        this.resetKnockOutQuestions(this.professionChangeEvent);
      }
      this.validatePage(false, null, null);
    }
  }


  handlCheckBoxChange(eventObj: any) {
    super.handlCheckBoxChange(eventObj);
    // if (eventObj.fieldName.name === ComparativeConstants.staticQuestionNames.setApplicantName) {
    //   this.setApplicantBusinessName(eventObj);
    // }
  }

  // setApplicantBusinessName(eventObj: any) {
  //   if (eventObj) {
  //     if (eventObj.checked) {
  //       // if agent and client associate with agent
  //       if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = true;
  //         this.chechboxToggleSetClientDetails(true);
  //       } else {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = true;
  //       }
  //     } else {
  //       // if agent and client associate with agent
  //       if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = false;
  //         this.chechboxToggleSetClientDetails(false);
  //       } else {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = false;
  //         this.form.controls[ComparativeConstants.staticQuestionNames.application_businessName].reset();
  //       }
  //     }
  //   } else {
  //     // if first name or last name changes , business name should be blank,uncheck the box
  //     // check first name last name is match with business name if not reset
  //     const businessName = (this.form.controls[ComparativeConstants.staticQuestionNames.application_firstName].value).concat(' ')
  //       .concat(this.form.controls[ComparativeConstants.staticQuestionNames.application_lastName].value);
  //     if (!UtilMethodsService.isEmpty
  // (this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName])
  //       && !UtilMethodsService.isEmpty(businessName)
  //       && this.stateService.insuranceDetails
  //         .questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName].toUpperCase()
  //       !== businessName.toUpperCase() &&
  //       this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.setApplicantName] === true
  //     ) {
  //       this.form.controls[ComparativeConstants.staticQuestionNames.application_businessName].reset();
  //       this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.setApplicantName] = false;
  //     }
  //   }
  //   // if normal client then set business name this way
  //   if (!this.transService.isAgent()) {
  //     if (!UtilMethodsService.isEmpty(eventObj.fieldName.name)
  //       && this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name]) { this.setBusinessName(); }
  //     // tslint:disable-next-line:no-unused-expression
  //   }
  // }


  // setApplicantBusinessName(eventObj: any) {
  //   if (eventObj) {
  //     if (eventObj.checked) {
  //       // if agent and client associate with agent
  //       if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = true;
  //         this.chechboxToggleSetClientDetails(true);
  //       } else {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = true;
  //       }
  //     } else {
  //       // if agent and client associate with agent
  //       if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = false;
  //         this.chechboxToggleSetClientDetails(false);
  //       } else {
  //         this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name] = false;
  //         this.form.controls[ComparativeConstants.staticQuestionNames.application_businessName].reset();
  //       }
  //     }
  //   } else {
  //     // if first name or last name changes , business name should be blank,uncheck the box
  //     // check first name last name is match with business name if not reset
  //     const businessName = (this.form.controls[ComparativeConstants.staticQuestionNames.application_firstName].value).concat(' ')
  //       .concat(this.form.controls[ComparativeConstants.staticQuestionNames.application_lastName].value);
  //     if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers
  // [ComparativeConstants.staticQuestionNames.application_businessName])
  //       && !UtilMethodsService.isEmpty(businessName)
  //       && this.stateService.insuranceDetails
  //         .questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName].toUpperCase()
  //       !== businessName.toUpperCase() &&
  //       this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.setApplicantName] === true
  //     ) {
  //       this.form.controls[ComparativeConstants.staticQuestionNames.application_businessName].reset();
  //       // this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.setApplicantName] = false;
  //     }
  //   }
  //   // if normal client then set business name this way
  //   if (!this.transService.isAgent()) {
  //     if (!UtilMethodsService.isEmpty(eventObj.fieldName.name)
  //       && this.stateService.insuranceDetails.questionAnswers[eventObj.fieldName.name]) { this.setBusinessName(); }
  //     // tslint:disable-next-line:no-unused-expression
  //   }
  // }

  // chechboxToggleSetClientDetails(_isCheckBoxCheked) {
  //   this.stateService.clientType = _isCheckBoxCheked ? 'P' : 'C';
  //   let id: number;
  //   if (this.stateService.clientType === 'C') {
  //     if (!UtilMethodsService.isEmpty(this.stateService.clientDetailsPayload.person.companyOfficePersons)) {
  //       id = this.stateService.clientDetailsPayload.person.companyOfficePersons[0].companyOffice.id;
  //       this.stateService.insuranceDetails['isNewCompany'] = false;
  //     } else {
  //       if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
  //         // 2nd page agent/client create company if not exist
  //         this.form.controls['applicantName'].setValue(null);
  //         this.form.controls['applicantName'].enable();
  //         this.stateService.insuranceDetails['isNewCompany'] = true;
  //         return;
  //       }
  //     }
  //   } else {
  //     id = this.stateService.clientDetailsPayload.person.id;
  //   }

  //   this.insuranceStaticService.getClientInfoOnType(this.stateService.clientType, id)
  //     .subscribe((_clientDetails) => {
  //       if (_clientDetails.policyPurchasedOnCompanyName) {
  //         this.stateService.ispolicyPurchasedOnCompanyName = true;
  //       } else {
  //         this.stateService.ispolicyPurchasedOnCompanyName = false;
  //       }
  //       // tslint:disable-next-line: max-line-length
  //       this.transService.prePopulateUserDetails
  // (this.insuranceSpinner, id, this.stateService.clientType, false, this.form, _clientDetails.companyPresentForPerson, _isCheckBoxCheked);
  //     }, (err) => {
  //       console.log('error', err);
  //     });
  // }
  // setBusinessName() {
  //   if (this.form.controls
  //     && !UtilMethodsService.isEmpty(this.form.controls[ComparativeConstants.staticQuestionNames.application_firstName])
  //     && !UtilMethodsService.isEmpty(this.form.controls[ComparativeConstants.staticQuestionNames.application_lastName])
  //     && (!UtilMethodsService.isEmpty(this.form.controls[ComparativeConstants.staticQuestionNames.application_firstName].value)
  //       || !UtilMethodsService.isEmpty(this.form.controls[ComparativeConstants.staticQuestionNames.application_lastName].value))
  //   ) {
  //     const valuetoSet = (this.form.controls[ComparativeConstants.staticQuestionNames.application_firstName].value).concat(' ')
  //       .concat(this.form.controls[ComparativeConstants.staticQuestionNames.application_lastName].value);
  //     this.form.controls[ComparativeConstants.staticQuestionNames.application_businessName].patchValue(valuetoSet);
  //     this.form.controls[ComparativeConstants.staticQuestionNames.application_businessName].updateValueAndValidity();
  //     delete this.stateService.fieldError[ComparativeConstants.staticQuestionNames.application_businessName];
  //   }
  // }


  onInputChange(event: any, field: any) {
    super.onInputChange(event, field);
    if (field.name === ComparativeConstants.staticQuestionNames.application_city) {
      this.form.controls[ComparativeConstants.staticQuestionNames.application_zipCode].reset();
      delete this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode];
    }
  }

  ngOnDestroy() {
    this.unsubscribe();
  }
}
