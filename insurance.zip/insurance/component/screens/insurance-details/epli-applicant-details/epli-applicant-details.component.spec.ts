import { TestBed, async, fakeAsync, getTestBed, ComponentFixture, tick, inject } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators, FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { EPLIApplicantDetailComponent } from './epli-applicant-details.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';
import { InsuranceStaticService } from '../../../../services/insurance-static-service';
import { MockInsuranceStaticService } from '../../../../../common/mock';
import { MatSnackBarComponent } from '../../../common/banner/banner.component';
import { StringConstantPipe } from '../../../../pipe/string-constant.pipe';
import { ProductConfigPipe } from '../../../../pipe/product-config.pipe';
import { TransactionalService } from '../../../../services/transactional.service';
import { StateService } from '../../../../services/state.service';
import { EvaluateExpressionPipe } from '../../../../pipe/evaluate-expression.pipe';

const stateEvntObj = {
  'fieldName': {
    'question_reference_id': 1,
    'sequence_number': 1,
    'label': '',
    'name': 'application_state',
    'type': 'selectwithsearch',
    'value': '',
    'visible_by_default': 1,
    'validations': [],
    'options': [
      {
        'id': 101,
        'code': 'Use First/Last name as applicant name',
        'label': 'Use First/Last name as applicant name',
      },
    ],
  },
  'selectedVal': [
  ],
};

const cityEvntObj = {
  'question_reference_id': 1,
  'sequence_number': 1,
  'label': 'City',
  'name': 'application_city',
  'type': 'textbasic',
  'value': '',
  'visible_by_default': 1,
  'validations': [
    {
      'name': 'required',
      'message': 'This field is required',
    },
    {
      'name': 'pattern',
      'pattern': {},
      'message': 'This field is required',
    },
  ],
};

const appZipCode = {
  'question_reference_id': 1,
  'sequence_number': 1,
  'label': 'Zip Code',
  'name': 'application_zipCode',
  'type': 'textnumber',
  'value': '',
  'visible_by_default': 1,
  'placeholder': 'Enter ZipCode',
  'validations': [
    {
      'name': 'required',
      'message': 'This field is required',
    },
    {
      'name': 'pattern',
      'pattern': {},
      'message': 'This field is required',
    },
  ],
};
const appAdd1 = {
  'question_reference_id': 1,
  'sequence_number': 1,
  'label': 'Zip Code',
  'name': 'application_address1',
  'type': 'textbasic',
  'value': '',
  'visible_by_default': 1,
  'placeholder': 'Enter ZipCode',
  'validations': [
    {
      'name': 'required',
      'message': 'This field is required',
    },
    {
      'name': 'pattern',
      'pattern': {},
      'message': 'This field is required',
    },
  ],
};


@Component({
  selector: 'app-test-epli-applicant-details',
  // tslint:disable-next-line:max-line-length
  template: '<app-epli-applicant-details [queSectionName]= quesSectionName [getQuoteJson]=getQuoteJson></app-epli-applicant-details>',
})

class TestInsuranceEPLIApplicantDetailsComponent {
  public parentSectionName = 'productInformation';
  public sectionName = 'applicantDetails';
  public quesSectionName = ['organizationalinformation'];
  public getQuoteJson = {
    'questions': [
      {
        'id': 55337,
        'name': 'EPLI_businessOrganization',
        'label': 'Business Organization',
        'type': 'select',
        'sectionName': 'organizationalinformation',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 56,
            'name': 'corporation',
            'label': 'Corporation',
          },
          {
            'id': 57,
            'name': 'partnership',
            'label': 'Partnership',
          },
          {
            'id': 58,
            'name': 'llc',
            'label': 'LLC',
          },
          {
            'id': 59,
            'name': 'other',
            'label': 'Other',
          },
        ],
      },
      {
        'id': 55338,
        'name': 'EPLI_other',
        'label': 'Other',
        'type': 'textbasic',
        'sectionName': 'organizationalinformation',
        'displayCriteria': '({EPLI_businessOrganization} ==  \'other\')',
      },
    ],
  };
  constructor() { }
}

describe('Insurance EPLI Applicant Details Component', () => {
  let component: EPLIApplicantDetailComponent;
  let fixture: ComponentFixture<TestInsuranceEPLIApplicantDetailsComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [ServiceHandler,
        StateService,
        InsuranceStaticService,
        TransactionalService,
        { provide: InsuranceStaticService, useClass: MockInsuranceStaticService },
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        MatSnackBarComponent,
      ],
      declarations: [
        TestInsuranceEPLIApplicantDetailsComponent,
        EPLIApplicantDetailComponent,
        EvaluateExpressionPipe,
        ProductConfigPipe,
        StringConstantPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceEPLIApplicantDetailsComponent);
    component = fixture.debugElement.children[0].componentInstance as EPLIApplicantDetailComponent;
    spyOn(component, 'getTotalRequiredFieldsForSection').and.returnValue('');
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /* it('should set applicant business name as firstName and lastName when user checks the checkbox',
    inject([StateService], (stateService: StateService) => {
      const _group: FormGroup = new FormGroup({});
      const _fb: FormBuilder = new FormBuilder();
      const control1 = _fb.control([], []);
      const control2 = _fb.control([], []);
      const control3 = _fb.control([], []);
      const control4 = _fb.control([], []);
      _group.addControl(appNameCB.fieldName.name, control1);
      _group.addControl(fname.name, control2);
      _group.addControl(lname.name, control3);
      _group.addControl(appName.name, control4);
      component.form = _group;
      component.form.controls[fname.name].setValue('xyz');
      component.form.controls[lname.name].setValue('abc');
      fixture.detectChanges();
      stateService.insuranceDetails.questionAnswers['firstName'] = 'xyz';
      stateService.insuranceDetails.questionAnswers['lastName'] = 'abc';
      appNameCB['checked'] = true;
      component.handlCheckBoxChange(appNameCB);
      fixture.detectChanges();
      // tslint:disable-next-line:no-unused-expression
      expect(component.form.controls[appName.name].value).toBe('xyz abc');
    }));

  it('should reset applicant/business name when user uncheck checkbox of set applicant/business name', () => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    const control5 = _fb.control([], []);
    const control6 = _fb.control([], []);
    const control7 = _fb.control([], []);
    const control8 = _fb.control([], []);
    _group.addControl(appNameCB.fieldName.name, control5);
    _group.addControl(fname.name, control6);
    _group.addControl(lname.name, control7);
    _group.addControl(appName.name, control8);
    component.form = _group;
    appNameCB['checked'] = false;
    component.handlCheckBoxChange(appNameCB);
    // tslint:disable-next-line:no-unused-expression
    expect(component.form.controls[appName.name].value).toBeNull();
  }); */

  it(' should call onSelectWithSearchChange',
    inject([StateService], (stateService: StateService) => {
      const _group: FormGroup = new FormGroup({});
      const _fb: FormBuilder = new FormBuilder();
      const control9 = _fb.control([], []);
      const control10 = _fb.control([], []);

      _group.addControl(stateEvntObj.fieldName.name, control9);
      _group.addControl(appZipCode.name, control10);

      component.form = _group;
      component.parentSectionName = 'productInformation';
      component.sectionName = 'applicantDetails';
      component.form.controls[appZipCode.name].setValue('12121');
      component.onSelectWithSearchChange(stateEvntObj, stateEvntObj.fieldName);
      // tslint:disable-next-line:no-unused-expression
      expect(stateService.insuranceDetails.questionAnswers[appZipCode.name]).toBeUndefined();
    }));

  /* it('should called onFocus', () => {
    const _event = {
      'id': 15902,
      'name': 'PNL_estimatedGrossSalesInNextTwelveMonths_DE_directMarketing',
      'label': 'What are your business??s estimated gross sales during the next 12 months?',
      'type': 'textnumber',
      'validations': [
        {
          'name': 'required',
          'value': 'true',
          'message': 'Field is Required',
        },
        {
          'name': 'pattern',
          'pattern': {},
          'message': 'Field is Required',
        },
      ],
    };
    component.onFocusOut(_event, _event);
    component.onFocus(_event, _event);
  }); */

  // it('should call on focusout of zipcode', () => {
  //   const _group: FormGroup = new FormGroup({});
  //   const _fb: FormBuilder = new FormBuilder();
  //   component.parentSectionName = 'productInformation';
  //   component.sectionName = 'applicantDetails';

  //   const control11 = _fb.control([], []);
  //   _group.addControl(appZipCode.name, control11);

  //   component.form = _group;
  //   const response = {
  //     city: 'City',
  //     state: 'California',
  //   };
  //   component.form.controls[appZipCode.name].setValue(' 12121');
  //   component.onFocusOut(appZipCode, appZipCode);
  //   component.getZipCodeFromAddress('12121');
  //   expect(component.form.controls[appZipCode.name].value).toEqual('12121');
  // });

  it('populateGooglePlaceValues', inject([StateService], (stateService: StateService) => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    component.parentSectionName = 'productInformation';
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation(component.parentSectionName, component.sectionName);
    const control12 = _fb.control([], []);
    _group.addControl(appAdd1.name, control12);

    component.form = _group;
    console.log('IN SPEC >>> ', stateService.SECTIONS);
    stateService.exitingAddress['street1'] = 'abc street';
    stateService.exitingAddress['zipCode'] = '12345';
    stateService.exitingAddress['city'] = 'pune';
    component.populateGooglePlaceValues(appAdd1);
  }));

  it('getZipCodeFromAddress() get States on based of zip', inject([StateService], (stateService: StateService) => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    const control13 = _fb.control([], []);

    _group.addControl('zipCode', control13);
    component.form = _group;
    component.getZipCodeFromAddress('08817');
    expect(stateService.insuranceDetails.questionAnswers['city']).toBe('Edison');
  }));

  it('getZipCodeFromAddress() invalid zip', inject([StateService], (stateService: StateService) => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    const control14 = _fb.control([], []);

    _group.addControl('zipCode', control14);
    component.form = _group;
    component.getZipCodeFromAddress('12345');
    expect(stateService.insuranceDetails.questionAnswers['city']).toBeUndefined();
  }));

  it('getZipCodeFromAddress() Sanctioned State', inject([StateService], (stateService: StateService) => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    const control15 = _fb.control([], []);

    _group.addControl('zipCode', control15);
    component.form = _group;
    stateService.preloadData.sanctionStates = ['NY'];
    component.getZipCodeFromAddress('44444');
    expect(stateService.insuranceDetails.questionAnswers['zipCode']).toBeUndefined();
  }));

  it('On Focus out function', inject([StateService], (stateService: StateService) => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    const control15 = _fb.control([], []);
    const control16 = _fb.control([], []);

    _group.addControl(stateEvntObj.fieldName.name, control15);
    _group.addControl(appZipCode.name, control16);
    component.form = _group;
    component.parentSectionName = 'productInformation';
    component.sectionName = 'applicantDetails';
    component.form.controls[appZipCode.name].setValue('12121');
    component.onFocusOut(stateEvntObj, stateEvntObj.fieldName);
    expect(stateService.insuranceDetails.questionAnswers[appZipCode.name]).toBeUndefined();
  }));

  it('On Focus function', () => {
    component.onFocus(stateEvntObj, stateEvntObj.fieldName);
  });

  it('On CheckBox Change function', () => {
    component.handlCheckBoxChange(stateEvntObj);
  });

  it('On Input change function', inject([StateService], (stateService: StateService) => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    const control15 = _fb.control([], []);
    const control16 = _fb.control([], []);

    _group.addControl(stateEvntObj.fieldName.name, control15);
    _group.addControl(cityEvntObj.name, control16);
    component.form = _group;
    component.parentSectionName = 'productInformation';
    component.sectionName = 'applicantDetails';
    component.form.controls[cityEvntObj.name].setValue('Pune');
    component.onInputChange(stateEvntObj, stateEvntObj.fieldName);
    expect(stateService.insuranceDetails.questionAnswers[appZipCode.name]).toBeUndefined();
  }));
});
