import { AfterViewInit, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ComparativeConstants } from '../../../../constants/comparative-constants';
import { StringConstants } from '../../../../constants/string-constants';
import { InsuranceDetailsModel } from '../../../../models/insurance-details.model';
import { DirectiveValidationService } from '../../../../services/directive-validation.service';
import { InsuranceStaticService } from '../../../../services/insurance-static-service';
import { StateService } from '../../../../services/state.service';
import { TransactionalService } from '../../../../services/transactional.service';
import { UtilMethodsService } from '../../../../services/util-method.service';
import { BaseFormComponent } from '../../../base-form.component';
import { ProductConfigService } from '../../../../services/product-config.service';
import { InsuranceSpinnerService } from '../../../../services/insurance-spinner.service';
import { ProductConfigPipe } from '../../../../pipe/product-config.pipe';

@Component({
  selector: 'app-knockout-panel-3-question',
  templateUrl: './knockout-panel-3-question.component.html',
  providers: [ProductConfigPipe],
  styleUrls: ['./knockout-panel-3-question.component.scss'],
})
export class KOPanel3QuestionComponent extends BaseFormComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() getQuoteJson;
  @Input() queSectionName: any;
  @Input() sectionName: any;
  // filtered: any[];
  quesListForSection = [{}];
  knockoutpanel3QueSet: any;
  bufferKnockoutPanel2QueSet: any;


  constructor(public insuranceStaticService: InsuranceStaticService, public transService: TransactionalService,
    public productConfigPipe: ProductConfigPipe, public productConfig: ProductConfigService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog, public stringConstant: StringConstants,
    public insuranceSpinner: InsuranceSpinnerService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.modelName = InsuranceDetailsModel;
    this.parentSectionName = 'productInformation';
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;
  }

  ngOnInit() {
    console.log('--> ', this.getQuoteJson);
    this.knockoutpanel3QueSet = UtilMethodsService.copyObject(this.getQuoteJson);
    this.associatedProduct = this.sectionName;
    this.sectionName = this.sectionName;
    this.filterQuestionSectionSpecific();
    this.loadFormWithJson(this.knockoutpanel3QueSet);
    if (this.knockoutpanel3QueSet) {
      this.bufferKnockoutPanel2QueSet = UtilMethodsService.copyObject(this.knockoutpanel3QueSet);
    }
  }

  filterQuestionSectionSpecific() {
    this.quesListForSection = this.knockoutpanel3QueSet.questions.filter((que: any) => {
      return (que.sectionName && this.queSectionName.includes(que.sectionName));
    });

    if (this.quesListForSection.length > 0) {
      this.knockoutpanel3QueSet.questions = this.quesListForSection;
    }
  }

  ngAfterViewInit() {
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      this.isCustomPageValidationRequired = true;
    }
    this.getTotalRequiredFieldsForSection();
    this.highlightInvalidFields(this.form);

    // form validation when user click continue on insurance details page
    // and all accordion get open
    this.subscriptions.push(this.stateService.isPageVaildate.subscribe((_isPageValidRequired) => {
      if (_isPageValidRequired) {
        if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
          this.isCustomPageValidationRequired = true;
        }
        this.getTotalRequiredFieldsForSection();
        this.highlightInvalidFields(this.form);
      }
    }));
  }

  loadFormWithJson(getQuoteJson) {
    getQuoteJson.fields = getQuoteJson.questions;
    this.setQuestionNameToStack(getQuoteJson);
    this.loadInitialFields(getQuoteJson.fields);
    this.form = this.createControlwithNewJson(this.questionJSONDatafields);
    // this.setSubSectionForValidation(this.parentSectionName, this.stateService.insuranceSelected[0]);

  }


  onFocusOut(event: any, field: any) {
    super.onFocusOut(event, field);
  }



  onFocus(event: any, field: any) {
    super.onFocus(event, field);
  }

  public subscribeControl(group: any, field: any) {
    const me = this;
    me.valueChangeSubscribe = group.get(field.name).valueChanges
      // .debounceTime(500)
      .subscribe((answerEvent) => {
        this.stateService.isApplicationReadyToAction = false;
        if (!UtilMethodsService.isEmpty(answerEvent)) {
          me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = answerEvent;
          me.stateService.screenMapObject[field.name] = answerEvent;
          if (field.type === 'date') {
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] =
              UtilMethodsService.formatDateToString(answerEvent);
            me.stateService.screenMapObject[field.name] =
              UtilMethodsService.formatDateToString(answerEvent);
          }
          if (field.type === 'checkbox' && Array.isArray(answerEvent)) {
            // filtered out NaN values if present in array
            const FilteredAnswerEvent = answerEvent.filter((value) => !Number.isNaN(value));
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = FilteredAnswerEvent.join();
            me.stateService.screenMapObject[field.name] = FilteredAnswerEvent.join();
          }
          if (field.type === 'textcurrency') {
            const formattedValue = DirectiveValidationService.formatMoney(answerEvent);
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = formattedValue.replace(/,/ig, '');
            me.stateService.screenMapObject[field.name] = formattedValue.replace(/,/ig, '');
          }
          if (field.name === ComparativeConstants.EPLI_FILE_UPLOAD_PARENT_KEY) {
            delete me.stateService.insuranceDetails.questionAnswers['attachDetails'];
            delete this.stateService.screenMapObject['attachDetails'];
          }
        } else {
          delete me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name];
          delete me.stateService.screenMapObject[field.name];
        }

        if (me.parentSectionName && me.sectionName) {
          const evaluateDC = function() {
            me.evaluateDisplayCriteriaForQuestions();
          };
          const validatePageMethod = function() {
            me.validatePage(false, [], null);
          };
          const executeEvalDC = this.transService.debounce(evaluateDC, 500);
          const executeDebounceMethod = this.transService.debounce(validatePageMethod, 1000);
          executeEvalDC();
          executeDebounceMethod();
        }
      });
  }

  handlCheckBoxChange(eventObj: any, field: any) {
    super.handlCheckBoxChange(eventObj, field);
    if (eventObj.checked) {
      this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[eventObj.fieldName.name] = true;
      delete this.stateService.fieldError[eventObj.fieldName.name];
    } else {
      delete this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[eventObj.fieldName.name];
    }
    this.validatePage(false, [], null);
  }

  ngOnDestroy() {
    this.unsubscribe();
  }
}
