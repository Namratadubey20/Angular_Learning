import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from 'src/app/app-config-service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { FormInsuranceComponentModule } from '../../../../../form-insurance-components/form-insurance-components.module';
import { EvaluateExpressionPipe } from '../../../../pipe/evaluate-expression.pipe';
import { MaterialModule } from '../../../../../material.module';
import { KOPanel3QuestionComponent } from './knockout-panel-3-question.component';


@Component({
  selector: 'app-test-insurance-knockout-question',
  // tslint:disable-next-line:max-line-length
  template: '<app-knockout-panel-3-question [queSectionName]= quesSectionName [getQuoteJson]=getQuoteJson [sectionName]= sectionName></app-knockout-panel-3-question>',
})

class TestInsuranceKnockoutQuestionComponent {
  // tslint:disable-next-line:max-line-length
  public sectionName = 'EPLI_panel3';
  // tslint:disable-next-line:max-line-length
  public quesSectionName = ['mainSection', 'CYBER_InfoSecurityPrivacyControls', 'CYBER_websiteContentControls', 'CYBER_priorClaimsCircumstances'];
  public getQuoteJson = {
    'questions': [
      {
        'id': 31643,
        'name': 'PNL_complyLaws_DE_directMarketing',
        'label': 'Does your business comply with applicable federal, state, and local laws and regulations?',
        'type': 'radio',
        'required': true,
        'options': [
          {
            'id': 20,
            'name': 'yes',
            'label': 'Yes',
          },
          {
            'id': 21,
            'name': 'no',
            'label': 'No',
          },
        ],
        'validations': [
          {
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
        ],
      },
      {
        'id': 11291,
        'name': 'PNL_deductibleToPurchase_DE_directMarketing',
        'label': 'What deductible do you wish to purchase?',
        'type': 'select',
        'required': true,
        'options': [
          {
            'id': 39,
            'name': 'fivehundred',
            'label': '$500',
          },
          {
            'id': 40,
            'name': 'twentyfivehundred',
            'label': '$2500',
          },
          {
            'id': 41,
            'name': 'fivethousand',
            'label': '$5000',
          },
        ],
      },
      {
        'id': 15902,
        'name': 'PNL_estimatedGrossSalesInNextTwelveMonths_DE_directMarketing',
        'label': 'What are your business??s estimated gross sales during the next 12 months?',
        'type': 'textbasic',
        'required': true,
        'options': [],
        'validations': [
          {
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
        ],
      },
      {
        'id': 5461,
        'name': 'PNL_insuranceLimitToPurchase_DE_directMarketing',
        'label': 'What limit of insurance do you wish to purchase?',
        'type': 'select',
        'required': true,
        'options': [
          {
            'id': 34,
            'name': 'twofifty',
            'label': '250,000',
          },
          {
            'id': 35,
            'name': 'fivehundred',
            'label': '500,000',
          },
          {
            'id': 36,
            'name': 'onethousand',
            'label': '1,000,000',
          },
          {
            'id': 37,
            'name': 'twothousand',
            'label': '2,000,000',
          },
          {
            'id': 38,
            'name': 'threethousand',
            'label': '3,000,000',
          },
        ],
      },
      {
        'id': 32120,
        'name': 'PNL_noInfringementIP_DE_directMarketing',
        // tslint:disable-next-line:max-line-length
        'label': 'Do your contracts state that to the best of your knowledge any materials or intellectual property created are original and do not infringe upon the intellectual property rights of others?',
        'type': 'radio',
        'required': true,
        'options': [
          {
            'id': 22,
            'name': 'yes',
            'label': 'Yes',
          },
          {
            'id': 23,
            'name': 'no',
            'label': 'No',
          },
          {
            'id': 24,
            'name': 'notapplicable',
            'label': 'Not Applicable',
          },
        ],
      },
      {
        'id': 41554,
        'name': 'PNL_processForScreeningMaterial_DE_directMarketing',
        // tslint:disable-next-line:max-line-length
        'label': 'Do you have a process in place to screen materials for any potential violation of another party??s copyrights, trademarks or other intellectual property rights?',
        'type': 'radio',
        'required': true,
        'options': [
          {
            'id': 22,
            'name': 'yes',
            'label': 'Yes',
          },
          {
            'id': 23,
            'name': 'no',
            'label': 'No',
          },
          {
            'id': 24,
            'name': 'notapplicable',
            'label': 'Not Applicable',
          },
        ],
      },
      {
        'id': 40865,
        'name': 'PNL_processForScreeningMaterialForPotentialSlander_DE_directMarketing',
        'label': 'Do you have a process in place to screen materials for potential libel, slander or advertising injury?',
        'type': 'radio',
        'required': true,
        'options': [
          {
            'id': 22,
            'name': 'yes',
            'label': 'Yes',
          },
          {
            'id': 23,
            'name': 'no',
            'label': 'No',
          },
          {
            'id': 24,
            'name': 'notapplicable',
            'label': 'Not Applicable',
          },
        ],
      },
      {
        'id': 29894,
        'name': 'PNL_promoteEntertainment_DE_directMarketing',
        // tslint:disable-next-line:max-line-length
        'label': 'Does your business promote media, artists or entertainers on behalf of or for any entertainment, publishing, music, internet or media company?',
        'type': 'radio',
        'required': true,
        'options': [
          {
            'id': 20,
            'name': 'yes',
            'label': 'Yes',
          },
          {
            'id': 21,
            'name': 'no',
            'label': 'No',
          },
        ],
      },
      {
        'id': 34081,
        'name': 'PNL_stateOwnershipRightForIP_DE_directMarketing',
        // tslint:disable-next-line:max-line-length
        'label': 'Do your contracts clearly state the ownership rights, licensing, and use of any materials or intellectual property created for or during an engagement?',
        'type': 'radio',
        'required': true,
        'options': [
          {
            'id': 22,
            'name': 'yes',
            'label': 'Yes',
          },
          {
            'id': 23,
            'name': 'no',
            'label': 'No',
          },
          {
            'id': 24,
            'name': 'notapplicable',
            'label': 'Not Applicable',
          },
        ],
      },
      {
        'id': 47758,
        'name': 'PNL_whenBusinessBegan_DE_directMarketing',
        'label': 'Approximately when did your business begin?',
        'type': 'date',
        'required': true,
        'options': [],
      },
      {
        'id': 23269,
        'name': 'PNL_whenWouldCoverageStart_DE_directMarketing',
        'label': 'If you purchase a policy, when would you like your coverage to start?',
        'type': 'date',
        'required': true,
        'options': [],
      },
    ],
  };
  constructor() { }
}

describe('Insurance Knockout panel1 Question Component', () => {
  let component: KOPanel3QuestionComponent;
  let fixture: ComponentFixture<TestInsuranceKnockoutQuestionComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestInsuranceKnockoutQuestionComponent,
        KOPanel3QuestionComponent,
        EvaluateExpressionPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceKnockoutQuestionComponent);
    component = fixture.debugElement.children[0].componentInstance as KOPanel3QuestionComponent;
    spyOn(component, 'getTotalRequiredFieldsForSection').and.returnValue('');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should called onfocusout', () => {
    const _event = {
      'id': 15902,
      'name': 'PNL_estimatedGrossSalesInNextTwelveMonths_DE_directMarketing',
      'label': 'What are your business??s estimated gross sales during the next 12 months?',
      'type': 'textnumber',
      'validations': [
        {
          'name': 'required',
          'value': 'true',
          'message': 'Field is Required',
        },
        {
          'name': 'pattern',
          'pattern': {},
          'message': 'Field is Required',
        },
      ],
    };
    component.onFocusOut(_event, _event);
    component.onFocus(_event, _event);
  });
});
