import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, fakeAsync, tick, inject } from '@angular/core/testing';
import { EmailPopupComponent } from '../../common/email-popup/email-popup.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router, ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from 'src/app/app-config-service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { StateService } from 'src/app/insurance/services/state.service';
import { TransactionalService } from 'src/app/insurance/services/transactional.service';
import { MockDialog, MockInsuranceStaticService, MockStateService, MockTransactionalService, questionList } from '../../../../common/mock';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { EvaluateExpressionPipe } from '../../../../insurance/pipe/evaluate-expression.pipe';
import { MaterialModule } from '../../../../material.module';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { ProductConfigService } from '../../../services/product-config.service';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { PurchaseSummaryPanelComponent } from '../../common/purchase-summary-panel/purchase-summary-panel.component';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { ApplicantDetailsComponent } from './applicant-details/applicant-details.component';
import { InsuranceDetailsComponent } from './insurance-details.component';
import { KOPanel1QuestionComponent } from './knockout-questions/knockout-panel-1-question.component';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { SecurityService } from 'src/app/security/security.service';
import { ChangeDetectionStrategy } from '@angular/core';

const appName = {
  'question_reference_id': 1,
  'sequence_number': 1,
  'label': 'Applicant/Business Name',
  'name': 'applicantName',
  'type': 'textbasic',
  'value': '',
  'allowedproduct': ['pnl', 'cyber', 'epli'],
  'visible_by_default': 1,
  'placeholder': 'Your Business Name',
  'validations': [{
    'name': 'required',
    // tslint:disable-next-line:quotemark
    'value': "^[a-zA-Z0-9 '-]*$",
    'message': 'This field is required',
  },
  {
    'name': 'maxlength',
    'value': 450,
    'message': '',
  }],
};

@Component({
  selector: 'app-test-insurance-details',
  template: '<app-insurance-details></app-insurance-details>',
  changeDetection: ChangeDetectionStrategy.OnPush,
})

class TestInsuranceDetailsComponent {
}

describe('Insurance Details Component', () => {
  let component: InsuranceDetailsComponent;
  let fixture: ComponentFixture<TestInsuranceDetailsComponent>;
  let router: Router;
  let activatedRoute: ActivatedRoute;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  let dataLayer: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        BrowserAnimationsModule,
        FormInsuranceComponentModule,
      ],
      providers: [
        MatSnackBarComponent,
        ProductConfigService,
        ServiceHandler,
        StringConstantPipe,
        SecurityService,
        GoogleTagManagerService,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        // InsuranceStaticService,
        { provide: InsuranceStaticService, useClass: MockInsuranceStaticService },
        { provide: TransactionalService, useClass: MockTransactionalService },
        { provide: StateService, useValue: MockStateService },
        { provide: MatDialog, useValue: MockDialog },
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: {
              _value: {
                applicationId: '12345',
                isAnonymousUser: true,
              },
            },
          },
        },
      ],
      declarations: [
        TestInsuranceDetailsComponent,
        InsuranceHeadingPanelComponent,
        InsuranceDetailsComponent,
        ApplicantDetailsComponent,
        StringConstantPipe,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        KOPanel1QuestionComponent,
        GetLabelPipe,
        ProductConfigPipe,
        EvaluateExpressionPipe,
        EmailPopupComponent,
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA,
        NO_ERRORS_SCHEMA,
      ],
    }).overrideModule(BrowserModule, { set: { entryComponents: [EmailPopupComponent] } })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceDetailsComponent);
    router = TestBed.get(Router);
    activatedRoute = TestBed.get(ActivatedRoute);
    component = fixture.debugElement.children[0].componentInstance as InsuranceDetailsComponent;
    window.dataLayer = dataLayer = [];
    spyOn(component, 'getTotalRequiredFieldsForSection').and.returnValue('');
    spyOn(component, 'checkIfPageValidForNavigation').and.returnValue(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to insurance/yourquotes through PremiumCalculator',
    inject([StateService, InsuranceStaticService, TransactionalService],
      (stateService: StateService, insuranceService: InsuranceStaticService, transService: TransactionalService) => {
        const navigateSpy = spyOn(router, 'navigate');
        stateService.SECTIONS['productInformation']['istouched'] = true;
        stateService.SECTIONS['productInformation']['errors'] = 0;
        const isUserLogIn = spyOn(transService, 'isUserLogIn').and.returnValue(false);
        const payloadData = component.transService.encryptPayload();
        payloadData.data.dynamicQuestions.splice(0, 2);
        console.log('payloadData.data.dynamicQuestions check', payloadData.data.dynamicQuestions);
        component.parentSectionName = 'productInformation';
        stateService.userID = 171003;
        component.navigateForwardFn('');
        // expect(isUserLogIn).toHaveBeenCalled();
        component.updateApplication(payloadData, component.parentSectionName);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          // if (component.stateService.isDeclined === false) {
          // expect(navigateSpy).toHaveBeenCalledWith(['/insurance/yourquotes'],
          //   { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });

          // } else {
          //   expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceConfirmation'],
          //     { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });

          // }
        });
      }));

  it('should update Application',
    inject([StateService, InsuranceStaticService, TransactionalService],
      (stateService: StateService, transService: TransactionalService) => {
        const navigateSpy = spyOn(router, 'navigate');
        stateService.SECTIONS['productInformation']['istouched'] = true;
        stateService.SECTIONS['productInformation']['errors'] = 0;
        const payloadData = component.transService.encryptPayload();
        payloadData.data.dynamicQuestions.splice(0, 2);
        console.log('payloadData.data.dynamicQuestions check', payloadData.data.dynamicQuestions);
        component.parentSectionName = 'productInformation';
        // component.transService.isAgentTemp = true;
        // const isAgent = spyOn(transService, 'isAgent').and.returnValue(true);
        component.stateService.originState = 'rails';
        component.navigateForwardFn('');
        // expect(isAgent).toHaveBeenCalled();
        // tslint:disable-next-line:max-line-length
        // expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
        component.updateApplication(payloadData, component.parentSectionName);
      }));


  it('should update business name', async () => {
    const userID = 176038;
    component.updateBusinessName(userID);
  });

  it('should navigate to insurance/getquotes', async () => {
    const navigateSpy = spyOn(router, 'navigate');
    const event = true;
    component.navigateBackwardFn(event);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(navigateSpy).toHaveBeenCalledWith(['/insurance/getquotes']);
    });
  });

  // tslint:disable-next-line:max-line-length
  it('should allow anonymous user to jump on your quote after premium calculate set premimum amount from responseexcute anonimus flow', async () => {
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation('productInformation', 'applicantDetails');
    const navigateSpy = spyOn(router, 'navigate');
    const payloadData = component.transService.encryptPayload();
    payloadData.data.dynamicQuestions.splice(0, 2);
    console.log('payloadData.data.dynamicQuestions check', payloadData.data.dynamicQuestions);
    const pageRef = 'productInformation';
    component.premiumCalculator(payloadData, pageRef);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // if (component.stateService.isDeclined === false) {
      expect(navigateSpy).toHaveBeenCalledWith(['/insurance/yourquotes'],
        { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });

      // } else {
      //   expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceConfirmation'],
      //     { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });

      // }
    });
  });

  it('should allow user to update application', async () => {
    const navigateSpy = spyOn(router, 'navigate');
    const payloadData = component.transService.encryptPayload();
    payloadData.data.dynamicQuestions.splice(0, 2);
    console.log('payloadData.data.dynamicQuestions check', payloadData.data.dynamicQuestions);
    const pageRef = 'productInformation';
    component.updateApplication(payloadData, pageRef);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      if (component.stateService.isDeclined === false) {
        expect(navigateSpy).toHaveBeenCalledWith(['/insurance/yourquotes'],
          { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });

      } else {
        expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceConfirmation'],
          { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });

      }
    });
  });

  it('should genrate application id', async () => {
    const _group: FormGroup = new FormGroup({});
    const _fb: FormBuilder = new FormBuilder();
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation('productInformation', 'applicantDetails');
    const control12 = _fb.control([], []);
    _group.addControl(appName.name, control12);
    component.form = _group;
    const payloadData = component.transService.encryptPayload();
    payloadData.data.dynamicQuestions.splice(0, 2);
    console.log('payloadData.data.dynamicQuestions check', payloadData.data.dynamicQuestions);
    const pageRef = 'productInformation';
    component.generateApplicationID(payloadData, pageRef);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.stateService.insuranceDetails.applicationId).toEqual('20501');
    });
  });

  it('should Send application form to client ', async () => {
    component.stateService.insuranceDetails['applicationId'] = '20501';
    component.isSendToClientFn('');
  });

  it('should limit Insurance Manage Option with Limit 50000 and State New York ', async () => {
    component.stateService.insuranceDetails.questionAnswers['state'] = 'NY';
    component.getQuoteJson.questions = [{
      'question_reference_id': 1,
      'sequence_number': 0,
      'label': '',
      'name': 'EPLI_insuranceLimitToPurchase',
      'type': 'selectbox',
      'value': '',
      'visible_by_default': 1,
      'options': [
        {
          'id': 20,
          'name': '50000',
          'label': '50000',
        },
      ],
    }];
    component.limiInsuranceManageOption();
  });

  /* it('should limit Insurance Manage Option limit 100000 and State other than New York', async () => {
    component.stateService.insuranceDetails.questionAnswers['state'] = 'AL';
    component.getQuoteJson.questions = [{
      'question_reference_id': 1,
      'sequence_number': 0,
      'label': '',
      'name': 'EPLI_insuranceLimitToPurchase',
      'type': 'selectbox',
      'value': '',
      'visible_by_default': 1,
      'options': [
        {
          'id': 20,
          'name': '100000',
          'label': '100000',
        },
      ],
    }];
    component.limiInsuranceManageOption();
  }); */

  it('should Get, delete, reset KO questions', async () => {
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation('productInformation', 'applicantDetails');
    component.productConfig.refreshKOQuestion = {
      allowed_products: ['pnl', 'epli'],
    };
    component.stateService.insuranceDetails.questionAnswers['state'] = 'AL';
    component.getKnockOutQuestionJson();
  });

  it('should delete KO questions', async () => {
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation('productInformation', 'applicantDetails');
    component.deleteknockOutQuestionSubSection();
  });

  it('should reset KO questions', async () => {
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation('productInformation', 'applicantDetails');
    component.resetknockOutQuestionSubSection();
  });

  it('should remove KO questions', async () => {
    const data = {
      'questions': [{
        'question_reference_id': 1,
        'sequence_number': 0,
        'label': '',
        'name': 'EPLI_insuranceLimitToPurchase',
        'type': 'selectbox',
        'value': '',
        'visible_by_default': 1,
        'options': [
          {
            'id': 20,
            'name': '50000',
            'label': '50000',
          },
        ],
      }],
    };
    component.stateService.fieldError.hasOwnProperty('EPLI_insuranceLimitToPurchase');
    component.removeKOFieldError(data);
  });

  it('should open required panel', async () => {
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation('productInformation', 'applicantDetails');
    component.stateService.insuranceDetails.questionAnswers['bondClassification'] = 'epli';
    component.stateService.SECTIONS['productInformation']['pnl']['errors'] = 1;
    component.openRequiredPanel();
  });

  it(`should logout after saving data`, fakeAsync(() => {
    component.sectionName = 'applicantDetails';
    component.setSubSectionForValidation('productInformation', 'applicantDetails');
    const spy = spyOn(router, 'navigateByUrl');
    const payloadData = component.transService.encryptPayload();
    payloadData.data.dynamicQuestions.splice(0, 2);
    console.log('payloadData.data.dynamicQuestions check', payloadData.data.dynamicQuestions);
    const pageRef = 'productInformation';
    component.saveApplication(payloadData, pageRef);
    tick(6000);
    const url = spy.calls.first().args[0];
    fixture.detectChanges();
    expect(url).toBe('/secure/logout');
  }));

  it('should save the application for later and logout', inject([TransactionalService],
    (transService: TransactionalService) => {
      component.sectionName = 'applicantDetails';
      component.setSubSectionForValidation('productInformation', 'applicantDetails');
      const navigateSpy = spyOn(router, 'navigateByUrl');
      const data = {};
      const isAgent = spyOn(transService, 'isAgent').and.returnValue(true);
      const isUserLogIn = spyOn(transService, 'isUserLogIn').and.returnValue(true);
      const pageRef = 'productInformation';
      component.stateService.insuranceDetails.questionAnswers['buttonReference'] = 'continue';

      component.isSaveForLaterFn('');
      expect(isAgent).toHaveBeenCalled();

      fixture.detectChanges();
      expect(component).toBeTruthy();
    }));

  it('should send client profile to company', inject([TransactionalService],
    (transService: TransactionalService) => {
      component.sectionName = 'applicantDetails';
      component.setSubSectionForValidation('productInformation', 'applicantDetails');
      const isAgent = spyOn(transService, 'isAgent').and.returnValue(true);
      component.stateService.clientType = 'C';
      component.setClientProfileToCompany('C');
      expect(isAgent).toHaveBeenCalled();
    }));

  /* it('should navigate to home', inject([TransactionalService], (transService: TransactionalService) => {
    component.parentSectionName = 'productInformation';
    const checkLoginAndRedirect = spyOn(transService, 'checkLoginAndRedirect').and.returnValue('');
    component.navigateHome();
    expect(checkLoginAndRedirect).toHaveBeenCalled();
  })); */

});
