import { AfterViewInit, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';

import { StringConstants } from '../../../../constants/string-constants';
import { InsuranceDetailsModel } from '../../../../models/insurance-details.model';
import { ComparativeConstants } from '../../../../constants/comparative-constants';
import { DirectiveValidationService } from '../../../../services/directive-validation.service';
import { InsuranceStaticService } from '../../../../services/insurance-static-service';
import { StateService } from '../../../../services/state.service';
import { TransactionalService } from '../../../../services/transactional.service';
import { UtilMethodsService } from '../../../../services/util-method.service';
import { BaseFormComponent } from '../../../base-form.component';
import { Validation } from 'src/app/insurance/services/validation';
import { ProductConfigService } from '../../../../services/product-config.service';
import { InsuranceSpinnerService } from '../../../../services/insurance-spinner.service';
import { ProductConfigPipe } from '../../../../pipe/product-config.pipe';

@Component({
  selector: 'app-knockout-panel-1-question',
  templateUrl: './knockout-panel-1-question.component.html',
  providers: [ProductConfigPipe],
  styleUrls: ['./knockout-panel-1-question.component.scss'],
})
export class KOPanel1QuestionComponent extends BaseFormComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() getQuoteJson;
  @Input() queSectionName: any;
  @Input() sectionName: any;
  // gridQuestions: any;
  quesListForSection = [{}];
  knockoutpanel1QueSet: any;
  // gridChildQuestions: any;
  // filteredChildQuestions: any;
  bufferKnockoutPanel1QueSet: any;

  constructor(public insuranceStaticService: InsuranceStaticService,
    public productConfigPipe: ProductConfigPipe, public productConfig: ProductConfigService,
    public directiveValidationService: DirectiveValidationService, public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog, public stringConstant: StringConstants,
    public insuranceSpinner: InsuranceSpinnerService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.modelName = InsuranceDetailsModel;
    this.parentSectionName = 'productInformation';
    // this.sectionName = 'applicantDetails';
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;
  }

  ngOnInit() {
    // this.getQuoteJson = this.getQuoteJson;
    console.log('--> ', this.getQuoteJson);
    this.getQuoteJson.questions.forEach(_koQuestion => {
      if (_koQuestion['name'] === this.comparativeConstants.PNL_INSURANCE_LIMIT_TO_PURCHASE_QUESTION) {
        _koQuestion['options'] = this.stateService.insuranceDetails['insuranceLimit'];
        return;
      }
    });
    this.knockoutpanel1QueSet = UtilMethodsService.copyObject(this.getQuoteJson);
    this.associatedProduct = this.sectionName;
    // this.sectionName = this.;
    // this.removeGridQuestions();
    this.filterQuestionSectionSpecific();


    this.loadFormWithJson(this.knockoutpanel1QueSet);
    if (this.knockoutpanel1QueSet) {
      this.bufferKnockoutPanel1QueSet = UtilMethodsService.copyObject(this.knockoutpanel1QueSet);
    }
  }

  // removeGridQuestions() {
  //   this.gridQue = this.knockoutpanel1QueSet.questions.filter((que) => {
  //     return (que.sectionName && que.sectionName === this.sectionName) && que.type === 'grid';
  //   });
  //   if (this.gridQue[0]) {
  //     const gridQuestionParentName = this.gridQue[0]['name'];
  //     this.gridChildQuestions = this.knockoutpanel1QueSet.questions.filter((que) => {
  //       return (que.sectionName && que.sectionName === this.sectionName) && que.name.indexOf(gridQuestionParentName) === 0;
  //     });
  //     console.log(this.gridChildQuestions);
  //     this.gridQue[0]['child'] = this.gridChildQuestions;
  //     //this.gridQue = [this.gridQue[0], ...this.gridChildQuestions];

  //     this.filteredChildQuestions = this.knockoutpanel1QueSet.questions.filter(b => {
  //       const indexFound = this.gridChildQuestions.findIndex(a => this.compareName(a, b));
  //       return indexFound === -1;
  //     });

  //     this.filtered = this.filteredChildQuestions.filter((que) => {
  //       return (que.sectionName && que.sectionName === this.sectionName) && que.type !== 'grid';
  //     });

  //     if (this.filtered.length > 0) {
  //       this.knockoutpanel1QueSet.questions = this.filtered;
  //     }
  //   }

  // }

  filterQuestionSectionSpecific() {
    this.quesListForSection = this.knockoutpanel1QueSet.questions.filter((que) => {
      return (que.sectionName && this.queSectionName.includes(que.sectionName));
    });
    if (this.quesListForSection.length > 0) {
      this.knockoutpanel1QueSet.questions = this.quesListForSection;
    }

  }

  // compareName = (obj1, obj2) => {
  //   return (obj1.name === obj2.name);
  // }



  ngAfterViewInit() {
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      this.isCustomPageValidationRequired = true;
    }
    this.getTotalRequiredFieldsForSection();
    this.highlightInvalidFields(this.form);

    // form validation when user click continue on insurance details page
    // and all accordion get open
    this.subscriptions.push(this.stateService.isPageVaildate.subscribe((_isPageValidRequired) => {
      if (_isPageValidRequired) {
        if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
          this.isCustomPageValidationRequired = true;
        }
        this.getTotalRequiredFieldsForSection();
        this.highlightInvalidFields(this.form);
      }
    }));
  }

  loadFormWithJson(getQuoteJson) {
    getQuoteJson.fields = getQuoteJson.questions;
    this.setQuestionNameToStack(getQuoteJson);
    this.loadInitialFields(getQuoteJson.fields);

    // FRN-6 UI - Remove Fields from Product Information Page
    // Added isHidden flag to fields for questions from ComparativeConstants.TOTAL_FIELDS_HIDE_FLAG
    this.questionJSONDatafields.forEach((ele) => {
      if (ComparativeConstants.TOTAL_FIELDS_HIDE_FLAG.includes(ele['name'])) {
        ele['isHidden'] = true;
      }
    });

    this.form = this.createControlwithNewJson(this.questionJSONDatafields);
    this.disableControl(this.form.controls);
  }


  onFocusOut(event: any, field: any) {
    super.onFocusOut(event, field);
    let questionSet;
    for (const key in ComparativeConstants.READONLYQUESTIONS) {
      if (ComparativeConstants.READONLYQUESTIONS.hasOwnProperty(key)) {
        const _questionArr = ComparativeConstants.READONLYQUESTIONS[key];
        if (_questionArr.includes(field.name)) {
          questionSet = _questionArr;
          this.calculateValueOfTotal(questionSet, key, field.type);
          return;
          // return;
        }


        // this.calculate(key, this.stringConstant.READONLYQUESTIONS[key]);
      }
    }
  }

  onSelectWithSearchChange(event, field) {
    super.onSelectWithSearchChange(event, field);
  }

  onFocus(event, field) {
    super.onFocus(event, field);
  }


  calculateValueOfTotal(questionArray, key: any, fieldType: String) {
    let valueToSet;
    const _this = this;
    const answeredQuestions = questionArray.filter(element => {
      return this.form.controls[element] && this.form.controls[element].value != null
        && this.form.controls[element].value !== '';
    });
    if (answeredQuestions.length > 1) {
      let quesOne, quesTwo;
      valueToSet = answeredQuestions.reduce(function(accumulator, currentValue) {
        if (fieldType === 'textcurrency') {
          quesOne = _this.form.controls[accumulator] ? _this.form.controls[accumulator].value : accumulator;
          quesOne = DirectiveValidationService.formatMoney(quesOne).replace(/,/ig, '');
          quesTwo = _this.form.controls[currentValue].value;
          quesTwo = DirectiveValidationService.formatMoney(quesTwo).replace(/,/ig, '');
          return parseFloat(quesOne) + parseFloat(quesTwo);
        } else {
          quesOne = _this.form.controls[accumulator] ? _this.form.controls[accumulator].value : accumulator;
          quesTwo = _this.form.controls[currentValue].value;
          return parseFloat(quesOne) + parseFloat(quesTwo);
        }
      });

      // delete this.stateService.fieldError[key];
      if (fieldType === 'textcurrency') {
        _this.form.controls[key].setValue(DirectiveValidationService.formatMoney(valueToSet));
        // if (valueToSet > 100000000.00) {
        //   this.stateService.fieldError[key] = ComparativeConstants.REVENUE_ERROR;
        //   this.form.get([key]).setErrors({
        //     revenueErr: { message: ComparativeConstants.REVENUE_ERROR },
        //   });
        //   _this.form.controls[key].reset();
        //   delete this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[key];

        // } else {
        //   delete this.stateService.fieldError[key];
        //   this.form.get([key]).setErrors(null);
        //   _this.form.controls[key].setValue(DirectiveValidationService.formatMoney(valueToSet));
        // }
      } else {
        _this.form.controls[key].setValue(valueToSet);
        const element = this.knockoutpanel1QueSet['questions'].find(question => question.name === key);
        if (element) {
          this.isValid(element, valueToSet, []);
        }
      }

    } else if (answeredQuestions.length === 1) {
      valueToSet = this.form.controls[answeredQuestions[0]].value;
      _this.form.controls[key].setValue(DirectiveValidationService.formatMoney(valueToSet));
      // delete _this.stateService.fieldError[key];
      if (fieldType === 'textcurrency') {
        _this.form.controls[key].setValue(DirectiveValidationService.formatMoney(valueToSet));
        // if (valueToSet > 100000000.00) {
        //   this.stateService.fieldError[key] = ComparativeConstants.REVENUE_ERROR;
        //   this.form.get([key]).setErrors({
        //     revenueErr: { message: ComparativeConstants.REVENUE_ERROR },
        //   });
        //   _this.form.controls[key].reset();
        //   delete this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[key];
        // } else {
        //   delete this.stateService.fieldError[key];
        //   this.form.get([key]).setErrors(null);
        //   _this.form.controls[key].setValue(DirectiveValidationService.formatMoney(valueToSet));
        // }
      } else {
        _this.form.controls[key].setValue(valueToSet);
        const element = this.knockoutpanel1QueSet['questions'].find(question => question.name === key);
        if (element) {
          this.isValid(element, valueToSet, []);
        }
      }

    } else {
      _this.form.controls[key].reset();
    }
    this.validatePage(false, [], null);
  }

  public subscribeControl(group, field) {
    const me = this;
    me.valueChangeSubscribe = group.get(field.name).valueChanges
      // .debounceTime(500)
      .subscribe((answerEvent) => {
        this.stateService.isApplicationReadyToAction = false;
        if (!UtilMethodsService.isEmpty(answerEvent)) {
          me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = answerEvent;
          me.stateService.screenMapObject[field.name] = answerEvent;
          if (field.type === 'date') {
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] =
              UtilMethodsService.formatDateToString(answerEvent);
            me.stateService.screenMapObject[field.name] =
              UtilMethodsService.formatDateToString(answerEvent);
          }
          if (field.type === 'checkbox' && Array.isArray(answerEvent)) {
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] =
              answerEvent.join();
            me.stateService.screenMapObject[field.name] = answerEvent.join();
          }
          if (field.type === 'textcurrency') {
            const formattedValue = DirectiveValidationService.formatMoney(answerEvent);
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = formattedValue.replace(/,/ig, '');
            me.stateService.screenMapObject[field.name] = formattedValue.replace(/,/ig, '');
          }
          if (field.name === ComparativeConstants.EPLI_FILE_UPLOAD_PARENT_KEY) {
            delete me.stateService.insuranceDetails.questionAnswers['attachDetails'];
            delete this.stateService.screenMapObject['attachDetails'];
          }
        } else {
          delete me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name];
          delete me.stateService.screenMapObject[field.name];
        }

        if (me.parentSectionName && me.sectionName) {
          const evaluateDC = function() {
            me.evaluateDisplayCriteriaForQuestions();
          };
          const validatePageMethod = function() {
            me.validatePage(false, [], null);
          };
          const executeEvalDC = this.transService.debounce(evaluateDC, 500);
          const executeDebounceMethod = this.transService.debounce(validatePageMethod, 1000);
          executeEvalDC();
          executeDebounceMethod();
        }
      });
  }

  handlCheckBoxChange(eventObj: any, field: any) {
    super.handlCheckBoxChange(eventObj, field);
    if (eventObj.checked) {
      this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[eventObj.fieldName.name] = true;
      delete this.stateService.fieldError[eventObj.fieldName.name];
    } else {
      delete this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[eventObj.fieldName.name];
    }
    this.validatePage(false, [], null);
  }

  ngOnDestroy() {
    this.unsubscribe();
  }
}
