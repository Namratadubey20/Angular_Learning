import { Component, OnInit, AfterViewInit, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { TransactionalService } from '../../../services/transactional.service';
import { BaseFormComponent } from '../../base-form.component';
import { StateService } from '../../../services/state.service';
import { MatAccordion, MatDialog } from '@angular/material';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { TempAPIMockData } from '../../../services/temp-apimock.service';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { StringConstants } from '../../../constants/string-constants';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { InsuranceDetailsModel } from '../../../models/insurance-details.model';
import { UtilMethodsService } from '../../../services/util-method.service';
import { ProductConfigService } from '../../../services/product-config.service';
import { StringConstantPipe } from 'src/app/insurance/pipe/string-constant.pipe';
import { EvaluateExpressionPipe } from 'src/app/insurance/pipe/evaluate-expression.pipe';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { EmailPopupComponent } from '../../common/email-popup/email-popup.component';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-insurance-details',
  templateUrl: './insurance-details.component.html',
  styleUrls: ['./insurance-details.component.scss'],
  providers: [
    ProductConfigPipe, StringConstantPipe, EvaluateExpressionPipe],
})
export class InsuranceDetailsComponent extends BaseFormComponent implements OnInit, AfterViewInit, OnDestroy {
  private changeQuoteJsonEvent: EventEmitter<boolean> = new EventEmitter();
  activePanel: String = '';
  profileStatusSet = null;
  localJson: any;
  appConfig;
  @ViewChild(MatAccordion) _accordion: MatAccordion;
  // tslint:disable-next-line:max-line-length
  constructor(public insuranceStaticService: InsuranceStaticService, public productConfigPipe: ProductConfigPipe, public snackBar: MatSnackBarComponent,
    public stringConstantPipe: StringConstantPipe,
    public evaluateExpressionPipe: EvaluateExpressionPipe,
    public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog, private router: Router,
    // tslint:disable-next-line:max-line-length
    public stringConstant: StringConstants, public insuranceSpinner: InsuranceSpinnerService, public productConfig: ProductConfigService,
    private activatedRoute: ActivatedRoute, public dialog: MatDialog,
    private gtmService: GoogleTagManagerService,
    public appConfigService: AppConfigService,
    public securityService: SecurityService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.parentSectionName = 'productInformation';
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });

    // To store old address if user make stateProfessionChnage request on insurance details page
    // but User cancel or close dialog pop up that case old values get render
    this.stateService.exitingAddress = {
      // state = this.stateService.insuranceDetails.questionAnswers['state';
      city: this.stateService.insuranceDetails.questionAnswers['city'],
      street1: this.stateService.insuranceDetails.questionAnswers['street1'],
      // street2: this.stateService.insuranceDetails.questionAnswers['street2'],
      zipCode: this.stateService.insuranceDetails.questionAnswers['zipCode'],
    };
  }

  ngOnInit() {
    this._accordion.openAll();
    // this.activePanel = this.stringConstantPipe.transform(ComparativeConstants.defaultPanelName);
    this.getInsuranceLimit(this.stateService.insuranceDetails.questionAnswers['profession']);
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      this.isCustomPageValidationRequired = true;
    }
    this.getKnockOutQuestionJson();
    // this.getQuoteJson = this.insuranceStaticService.getInsuranceSectionFormJson();
    this.setSubSectionForValidation(this.parentSectionName, 'applicantDetails');
    // this.getQuoteJson.data.forEach(element => {
    //   this.setSubSectionForValidation(this.parentSectionName, element.product);
    // });
    // this.anonymousUserSaveForLater(this.activatedRoute.queryParams['_value']);
    const _value = this.activatedRoute.queryParams['_value'];
    if (_value && _value['action'] === 'save' && Boolean(JSON.parse(_value['isAnonymousUser'])) === true) {
      // before call save for later we need to create applicationId for Anonymous user
      // We have login ID as Anonymous user is now loggedIn user
      const _payloadData = this.transService.encryptPayload(true);
      if (_payloadData && !this.stateService.insuranceDetails['applicationId']
        && this.transService.isUserLogIn()) {
        this.generateApplicationID(_payloadData, this.parentSectionName);
      }
    }
    this.insuranceSpinner.hide();
    // GTM DLV when route on Product Information page
    this.insuranceAppStartGtmEvent('insurance-app-start', this.stateService.insuranceSelected[0], '',
      'new', this.stateService.insuranceDetails ? this.stateService.insuranceDetails['applicationId'] : '');
    sessionStorage.setItem('applicationId', this.stateService.insuranceDetails['applicationId']);
    if (this.transService.isClientAssociatedWithAgent() && !this.transService.isPolicyAssociatedWithAgent()) {
      const personId = this.transService.getPersonalId();
      this.insuranceStaticService.getCompanyInfo(personId).subscribe((res => {
        if (res.length !== 0) {
          this.stateService.companyInfo = res;
          if (res[0].name) {
            this.stateService.insuranceDetails.questionAnswers['applicantName'] = res[0].name;
          }
        }
      }));
    }
  }

  ngAfterViewInit() {
    this.insuranceSpinner.showFooter();
    // tslint:disable-next-line:max-line-length
    if (this.stateService.originState === 'rails' && this.stateService.SECTIONS[this.parentSectionName]['applicantDetails']['istouched'] === true && this.stateService.SECTIONS[this.parentSectionName]['applicantDetails']['errors'] === 0) {
      // this.activePanel = 'knockOutPanel';
    }
  }

  navigateBackwardFn(event) {
    this.insuranceSpinner.show();
    this.router.navigate(['/insurance/getquotes']);
  }

  getKnockOutQuestionJson($event?) {
    // tslint:disable-next-line: no-unused-expression
    this.insuranceSpinner.show();
    this.insuranceStaticService.getInsuranceSectionFormJson().subscribe(data => {
      if (data) {
        this.getQuoteJson = data;
        if (data && data.questions && data.questions.length > 0) {
          if (this.productConfigPipe.transform(this.productConfig.refreshKOQuestion)) {
            // this.stateService.insuranceDetails.questionAnswers.dynamicQuestions = {};
            this.deleteknockOutQuestionSubSection();
            this.resetknockOutQuestionSubSection();
            this.removeKOFieldError(data);
            if (this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state]
              && this.stateService.insuranceSelected[0] === ComparativeConstants.EPLI_PRODUCT_CODE) {
              this.limiInsuranceManageOption();
            }
          }
        } else {
          delete this.stateService.SECTIONS[this.comparativeConstants.PRODUCT_INFORMATION][this.stateService.insuranceSelected[0]];
        }
        this.isSubSectionValidOnLoad(data.questions, this.evaluateExpressionPipe);
        // tslint:disable-next-line: max-line-length
        this.checkIfPageValidForNavigation(this.parentSectionName);
        this.insuranceSpinner.hide();
      }
    }, (error: any) => {
      const errMsg = this.snackBarErrorMsg(error);
      this.insuranceSpinner.hide();
      this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
    });
  }

  removeKOFieldError(data: any) {
    data.questions.forEach((question: any) => {
      if (this.stateService.fieldError.hasOwnProperty(question.name)) {
        delete this.stateService.fieldError[question.name];
      }
    });
  }

  resetknockOutQuestionSubSection() {
    const subSectionNames = Object.keys(ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE);
    if (subSectionNames) {
      subSectionNames.forEach((key) => {
        this.setSubSectionForValidation(this.parentSectionName,
          this.stringConstantPipe.transform(ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE[key]));
      });
    }
  }

  deleteknockOutQuestionSubSection() {
    const subSectionNames = Object.keys(ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE);
    if (subSectionNames) {
      subSectionNames.forEach((key) => {
        const name = this.stringConstantPipe.transform(ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE[key]);
        delete this.stateService.SECTIONS[this.comparativeConstants.PRODUCT_INFORMATION][name];
        console.log(this.stateService.SECTIONS);
      });
    }
  }

  isSubSectionValidOnLoad(questions, evaluationExpPipe) {
    const panelKey = Object.keys(ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE);
    if (panelKey) {
      panelKey.forEach((key) => {
        const subSectionName = this.stringConstantPipe.transform(ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE[key]);
        const queSectionName = this.stringConstantPipe.transform(ComparativeConstants.QUESTION_SECTION_NAME[key]);
        // console.log("SUBSECTION IS", subSectionName, "------------ QUESTION-SECTIONNAME", queSectionName);
        if (subSectionName) {
          const SectionWiseQueList = questions.filter((que: any) => {
            return (que.sectionName && queSectionName.includes(que.sectionName));
          });
          const isSectionValidOnLoad = InsuranceDetailsModel.validSectionOnload(SectionWiseQueList.length > 0 ? SectionWiseQueList
            : questions,
            this.stateService, subSectionName, evaluationExpPipe);
          if (isSectionValidOnLoad) {
            // tslint:disable-next-line: max-line-length
            this.stateService.SECTIONS[this.parentSectionName][subSectionName] = UtilMethodsService.copyObject(this.comparativeConstants.SUB_SECTION_COMPLETE_STATUS);
            // this.stateService.SECTIONS[this.parentSectionName]['status'] = 'complete';
          } else {
            // tslint:disable-next-line: max-line-length
            this.stateService.SECTIONS[this.parentSectionName][subSectionName] = UtilMethodsService.copyObject(this.comparativeConstants.SUB_SECTION_INCOMPLETE_STATUS);
          }
        }

      });

    }

  }

  panelClick(panelName) {
    window.scrollTo(0, 0);
    this.activePanel = panelName;
    this.insuranceSpinner.show();
    if (this.stateService.originState === 'rails' && this.activePanel === 'knockOutPanel') {
      setTimeout(() => {
        this.insuranceSpinner.hide();
      }, 0);
    }
  }

  panelAfterExpand() {
    this.insuranceSpinner.hide();
  }

  navigateForwardFn(event) {
    const me = this;
    me._accordion.openAll();
    me.stateService.isPageVaildate.next(true);
    if (!me.stateService.isApplicationReadyToAction) {
      return;
    }

    if (me.productConfigPipe.transform(me.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      me.isCustomPageValidationRequired = true;
      me.modelName = InsuranceDetailsModel;
      me.validatePage(false, [], null);
    }
    if (me.stateService.SECTIONS[me.parentSectionName]['istouched'] === true &&
      // tslint:disable-next-line:triple-equals
      me.stateService.SECTIONS[me.parentSectionName]['errors'] == 0) {
      me.stateService.editedQuesDetails = {};
      me.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_CONTINUE;
      if (!me.transService.isUserLogIn()) {
        // if anonymous user , allow user to jump on your quote after premium calculate , set premimum amount from response
        /* const _payloadData = me.transService.encryptPayload();
        if (_payloadData) {
          me.premiumCalculator(_payloadData, me.parentSectionName);
        } -- commented for FRN-9 */
        this.router.navigate(['/insurance/yourquotes'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
      } else {
        // if loggedIn user, just update API call, set premimum amount from update API response
        // check if agent or clientAssiciatedToAgent if so call update client details call
        // after updateClientData method update Application will call
        if (me.transService.isAgent() || me.transService.isClientAssociatedWithAgent()) {
          me.profileStatusSet = me.stateService.getPorfileSetStatus
            .debounceTime(1000)
            .subscribe((stat) => {
              if (!UtilMethodsService.isEmpty(me.profileStatusSet)) {
                me.profileStatusSet.unsubscribe();
              }
              console.log('>>>>> stat ', stat);
              if (stat === true) {
                if (me.transService.isClientAssociatedWithAgent() && me.transService.isCompanyPresentForClient()) {
                  me.stateService.clientType = 'C';
                  me.stateService.insuranceDetails['isNewCompany'] = false;
                }

                me.updateClientData('fwdfunc', () => {
                  const _payloadData = me.transService.encryptPayload();
                  if (_payloadData) {
                    // user profile getting updated using updateClientData API
                    // Company already getting created and updated using updateClientData method
                    // no need to use updateBusinessName method its creating duplicate company record
                    // if (me.transService.isClientAssociatedWithAgent() && !me.transService.isPolicyAssociatedWithAgent()) {
                    //     me.updateBusinessName(me.stateService.clientID);
                    // }
                    me.updateApplication(_payloadData, me.parentSectionName);
                  }
                });
              }
            });

          // moving setClientProfileToCompany fn below as its getting/setting old client details before update client details
          setTimeout(() => {
            me.setClientProfileToCompany('C');
          }, 1000);

        } else {
          // if ((me.transService.isAgent() || me.transService.isClientAssociatedWithAgent())) {
          //   me.setClientProfileToCompany('C');
          // }
          // normal client execution flow
          // first need to update business /company name before call to update call on continue
          // if company exist then only put API work else post API will create new company
          if (UtilMethodsService.isEmpty(this.stateService.userID)) {
            this.stateService.userID = this.transService.getPersonalId();
          }
          me.updateBusinessName(me.stateService.userID, () => {
            const _payloadData = me.transService.encryptPayload();
            if (_payloadData) {
              me.updateApplication(_payloadData, me.parentSectionName);
            }
          });
        }
      }
      me.insuranceSpinner.show();
    } else {
      // this.activePanel = null;
      this.showPageError(this.snackBar, true);
      setTimeout(() => {
        this.openRequiredPanel();
      }, 1000);
    }
  }

  openRequiredPanel() {
    let objArrOfPanels;
    if (this.stateService.insuranceDetails.questionAnswers['bondClassification'] === 'epli') {
      objArrOfPanels = ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE;
    } else {
      objArrOfPanels = { ...ComparativeConstants.PANEL1_NAMES_PRODUCTWISE, ...ComparativeConstants.SUBSECTION_NAMES_PRODUCTWISE };
    }

    const panelKey = Object.keys(objArrOfPanels);
    const InvalidPanelsArr = [];
    const UntouchedPanelsArr = [];

    if (panelKey) {
      panelKey.forEach((key, index) => {
        const subSectionName = this.stringConstantPipe.transform(objArrOfPanels[key]);
        if (subSectionName) {
          if (this.stateService.SECTIONS[this.parentSectionName][subSectionName]['istouched']) {
            if (this.stateService.SECTIONS[this.parentSectionName][subSectionName]['errors'] !== 0) {
              if (this.stateService.insuranceDetails.questionAnswers['bondClassification'] === 'epli') {
                if (key === 'EPLI_ACCORDIAN_PANEL1_SECTION') {
                  InvalidPanelsArr[0] = ComparativeConstants.insuranceDetailsPanelNames[index + 1];
                } else {
                  InvalidPanelsArr.push(ComparativeConstants.insuranceDetailsPanelNames[index + 1]);
                }
              } else {
                InvalidPanelsArr.push(ComparativeConstants.insuranceDetailsPanelNames[index]);
              }
            } else {
              console.log('invalid fields are 0 >> InvalidPanelsArr >> ', InvalidPanelsArr);
            }
          } else {
            if (this.stateService.insuranceDetails.questionAnswers['bondClassification'] === 'epli') {
              if (key === 'EPLI_ACCORDIAN_PANEL1_SECTION') {
                UntouchedPanelsArr[0] = ComparativeConstants.insuranceDetailsPanelNames[index + 1];
              } else {
                UntouchedPanelsArr.push(ComparativeConstants.insuranceDetailsPanelNames[index + 1]);
              }
            } else {
              UntouchedPanelsArr.push(ComparativeConstants.insuranceDetailsPanelNames[index]);
            }
          }
        }
      });
    }
    if (UntouchedPanelsArr.length !== 0 && InvalidPanelsArr.length !== 0) {
      this.activePanel = InvalidPanelsArr[0];
    } else if (UntouchedPanelsArr.length === 0 && InvalidPanelsArr.length !== 0) {
      this.activePanel = InvalidPanelsArr[0];
    } else if (UntouchedPanelsArr.length !== 0 && InvalidPanelsArr.length === 0) {
      this.activePanel = UntouchedPanelsArr[0];
    } else {
      this.activePanel = UntouchedPanelsArr[0];
    }
  }

  premiumCalculator(_payloadData, _pageReference) {
    // this.stateService.insuranceDetails.questionAnswers['premiumOption'] = null;
    if (!UtilMethodsService.isEmpty(this.stateService.quoteId)) {
      _payloadData['quoteId'] = this.stateService.quoteId;
    }
    this.insuranceStaticService.premiumCalculator(_payloadData, _pageReference).subscribe((data) => {
      this.insuranceSpinner.hide();
      this.stateService.insuranceDetails['premiumAmount'] = data.premium;
      this.router.navigate(['/insurance/yourquotes'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
    }, (error) => {
      const errMsg = this.snackBarErrorMsg(error);
      this.insuranceSpinner.hide();
      this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
    });
  }

  updateApplication(_payloadData, _pageReference) {
    // this.stateService.insuranceDetails.questionAnswers['premiumOption'] = null;
    this.insuranceStaticService.updateApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        this.insuranceSpinner.hide();
        if (data.data && data.data.knockedOut) {
          this.stateService.isDeclined = true;
          if (this.stateService.originState === 'rails') {
            this.navigateToRails(data.id, data.status);
          } else {
            this.router.navigate(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
          }
        } else {
          // tslint:disable-next-line:max-line-length
          this.stateService.insuranceDetails['premiumAmount'] = data.premium;
          // tslint:disable-next-line:max-line-length
          // this.showBanner(this.snackBar, (this.stringConstant.PREMIUM_CALC_MESG + ' $' + data.premium), BaseFormComponent.INFORMATION_BAR);
          this.stateService.isDeclined = false;
          // UI load before value set issue
          // if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['premiumAmount'])) {
          this.router.navigate(['/insurance/yourquotes'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
          // }
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  saveApplication(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    // tslint:disable-next-line: max-line-length
    this.insuranceStaticService.saveApplication(_payloadData, _pageReference).subscribe(
      async (data) => {
        const originState = sessionStorage.getItem('originState');
        sessionStorage.removeItem('applicationId');
        this.insuranceSpinner.hide();
        if (this.transService.isAgent()) {
          if (originState === 'rails') {
            this.navigateToRails(data.id, data.status);
          } else {
            this.router.navigateByUrl('/dashboard');
          }
          return;
        }
        if (!UtilMethodsService.isEmpty(this.activatedRoute.queryParams['_value']) &&
          Boolean(JSON.parse(this.activatedRoute.queryParams['_value']['isAnonymousUser'])) === true) {
          this.showBanner(this.snackBar, this.stringConstant.APPLICATION_SAVED, BaseFormComponent.SUCCESS_BAR);
          this.activatedRoute.queryParams['_value'] = {};
          this.setDelay(() => {
            this.router.navigateByUrl('/secure/logout');
          }, 5000);
          return;
        }
        if (originState === 'rails') {
          this.navigateToRails(data.id, data.status);
        } else {
          await this.router.navigateByUrl('/secure/logout');
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  navigateToRails(id, status) {
    this.securityService.getAccessToken().then(response => {
      sessionStorage.removeItem('originState');
      console.log(this.securityService.requestURL(`?sutoken=${response}`));
      let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
      if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
        railsUrl = this.appConfig.colonial_erisa_TPA_url;
      }
      this.insuranceSpinner.show();
      window.open(`${railsUrl}?sutoken=${response}&applicationId=${id}&applicationStatus=${status}`, '_self');
    });
  }

  navigateHome() {
    this.transService.checkLoginAndRedirect(this.parentSectionName);
  }

  isSaveForLaterFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    if ((this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) &&
      this.transService.isPolicyAssociatedWithAgent()) {
      // tslint:disable-next-line:max-line-length
      if (UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName])) {
        // tslint:disable-next-line:max-line-length
        this.showBanner(this.snackBar, 'Business name is mandatory for insurance policy to send a quote to client', BaseFormComponent.ERROR_BAR);
        return;
      }
    }
    if ((this.transService.isAgent() || this.transService.isClientAssociatedWithAgent())) {
      this.setClientProfileToCompany('C');
    }

    this.stateService.editedQuesDetails = {};
    delete this.stateService.insuranceDetails.questionAnswers['premiumOption'];
    this.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_SAVE_FOR_LATER;
    if (this.transService.isUserLogIn()) {
      // login user save for later
      if ((this.transService.isAgent() || this.transService.isClientAssociatedWithAgent())) {
        this.updateClientData('saveforlater', () => {
          if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['isNewCompany'])
            && this.stateService.insuranceDetails['isNewCompany']) {
            const _payloadData = this.transService.encryptPayload(true);
            if (_payloadData) {
              if (!this.transService.isAgent()) {
                if (this.transService.isMandatoryAddressFieldsProvided()) {
                  this.updateBusinessName(this.transService.getPersonalId());
                  this.saveApplication(_payloadData, this.parentSectionName);
                } else {
                  this.showBanner(this.snackBar, this.stringConstant.MANDATORY_ADDR_ERROR, BaseFormComponent.ERROR_BAR);
                }
              } else {
                this.saveApplication(_payloadData, this.parentSectionName);
              }
            }
          } else {
            const _payloadData = this.transService.encryptPayload(true);
            if (_payloadData) {
              if (!this.transService.isAgent()) {
                if (this.transService.isMandatoryAddressFieldsProvided()) {
                  this.updateBusinessName(this.transService.getPersonalId());
                  this.saveApplication(_payloadData, this.parentSectionName);
                } else {
                  this.showBanner(this.snackBar, this.stringConstant.MANDATORY_ADDR_ERROR, BaseFormComponent.ERROR_BAR);
                }
              } else {
                this.saveApplication(_payloadData, this.parentSectionName);
              }
            }
          }

        });
      } else {
        // normal save for later
        const _payloadData = this.transService.encryptPayload(true);
        if (_payloadData) {
          if (!this.transService.isAgent()) {
            if (this.transService.isMandatoryAddressFieldsProvided()) {
              if (this.transService.isBusinessNameMandatory()) {
                if (this.transService.isCompanyPresentForClient()) {
                  this.stateService.isCompanyExist = true;
                }
                this.updateBusinessName(this.stateService.userID, () => {
                  // after company gets created ,Need to refresh encrypt payload to add company id
                  const _payloadDataRefresh = this.transService.encryptPayload(true);
                  if (_payloadDataRefresh) {
                    this.saveApplication(_payloadDataRefresh, this.parentSectionName);
                  }
                });
              } else {
                this.showBanner(this.snackBar, this.stringConstant.MANDATORY_BUSINESSNAME_ERROR, BaseFormComponent.ERROR_BAR);
              }

            } else {
              this.showBanner(this.snackBar, this.stringConstant.MANDATORY_ADDR_ERROR, BaseFormComponent.ERROR_BAR);
            }
          } else {
            this.saveApplication(_payloadData, this.parentSectionName);
          }

        }
      }
    } else {
      // Anonymous user
      const navigationExtras: NavigationExtras = {
        queryParams: {
          action: 'save',
          returnUrl: '/insurance/insuranceDetails',
        },
      };

      if (this.transService.isMandatoryAddressFieldsProvided()) {
        this.stateService.SECTIONS['getQuote']['status'] = 'complete';
        this.router.navigate(['/insurance/create-user'], navigationExtras);
      } else {
        this.showBanner(this.snackBar, this.stringConstant.MANDATORY_ADDR_ERROR, BaseFormComponent.ERROR_BAR);
      }

    }
  }

  setClientProfileToCompany(_type) {
    if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
      this.stateService.clientType = _type;
      let clientTypeForInfo = _type;
      let id: number;
      if (this.stateService.clientType === 'C') {
        if (!UtilMethodsService.isEmpty(this.stateService.clientDetailsPayload.person.companyOfficePersons)) {
          id = this.stateService.clientDetailsPayload.person.companyOfficePersons[0].companyOffice.id;
          this.stateService.insuranceDetails['isNewCompany'] = false;
          this.stateService.clientID = this.stateService.clientDetailsPayload.person.companyOfficePersons[0].companyOffice.id;
        } else {
          clientTypeForInfo = 'P';
          if (!UtilMethodsService.isEmpty(this.stateService.clientDetailsPayload)
            && !UtilMethodsService.isEmpty(this.stateService.clientDetailsPayload.person)) {
            id = this.stateService.clientDetailsPayload.person.id;
            this.stateService.clientID = this.stateService.clientDetailsPayload.person.id;
          } else {
            const personalProfile = this.transService.getPersonalProfileTypeAndProfileId();
            if (!UtilMethodsService.isEmpty(personalProfile)) {
              id = Number(personalProfile[0]);
              this.stateService.clientID = Number(personalProfile[0]);
            }
          }
          // 2nd page agent/client create company if not exist
          // Commenting this below code due to duplicate record getting created on agent screen
          // this.stateService.insuranceDetails['isNewCompany'] = true;
          if (this.form && this.form.controls && this.form.controls['applicantName']) {
            this.form.controls['applicantName'].setValue(null);
            this.form.controls['applicantName'].enable();
            return;
          }
          // }
        }
      } else {
        id = this.stateService.clientDetailsPayload.person.id;
      }

      this.insuranceStaticService.getClientInfoOnType(clientTypeForInfo, id)
        .subscribe((_clientDetails) => {
          if (_clientDetails.policyPurchasedOnCompanyName || _clientDetails.insurancePolicyPurchased) {
            this.stateService.ispolicyPurchasedOnCompanyName = true;
          } else {
            this.stateService.ispolicyPurchasedOnCompanyName = false;
          }
          // tslint:disable-next-line: max-line-length
          this.transService.prePopulateUserDetails(this.insuranceSpinner, id, clientTypeForInfo, false, this.form, _clientDetails.companyPresentForPerson, false);
        }, (err) => {
          console.log('error', err);
        });
    }
  }


  isSendToClientFn(event) {
    const me = this;
    // tslint:disable-next-line:max-line-length
    console.log('STC >>> ', me.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName]);
    // tslint:disable-next-line:max-line-length
    if (UtilMethodsService.isEmpty(me.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName])) {
      // tslint:disable-next-line:max-line-length
      me.showBanner(me.snackBar, 'Business name is mandatory for insurance policy to send a quote to client', BaseFormComponent.ERROR_BAR);
      return;
    }
    // me.setClientProfileToCompany('C');
    const applicationId = me.stateService.insuranceDetails['applicationId'];
    me.insuranceSpinner.show();
    // update Client data
    // updateCLient data will execute first then sendToclientMailDetails will get call;
    // me.setClientProfileToCompany('C');
    me.profileStatusSet = me.stateService.getPorfileSetStatus
      .debounceTime(1000)
      .subscribe((state) => {
        if (state === true) {
          if (!UtilMethodsService.isEmpty(me.profileStatusSet)) {
            me.profileStatusSet.unsubscribe();
          }
          // once agent land on get-quote based on client type and client id all details
          // get fetched and response stored into this.stateService.clientDetailsPayload
          // we cannot get this details from secuiry service
          // check if company already prest or not set cient type accordingly
          if (!UtilMethodsService.isEmpty(me.stateService.clientDetailsPayload)) {
            const _clientDetailsPayload = me.stateService.clientDetailsPayload;
            if (!UtilMethodsService.isEmpty((_clientDetailsPayload.person.companyOfficePersons))
              || (this.transService.isCompanyPresentForClient() && !this.transService.isAgent())) {
              me.stateService.clientType = 'C';
              me.stateService.insuranceDetails['isNewCompany'] = false;
            } else {
              me.stateService.clientType = 'P';
              me.stateService.insuranceDetails['isNewCompany'] = true;
            }
          }

          me.updateClientData('sendtoclient', () => {
            me.insuranceStaticService.sendToclientMailDetails(applicationId).subscribe(res => {
              me.insuranceSpinner.hide();
              const dialogRef = me.dialog.open(EmailPopupComponent, {
                data: res,
              });
              dialogRef.afterClosed().subscribe(result => {
                if (result) {
                  const _payloadData = me.transService.encryptPayload(true);
                  if (_payloadData) {
                    me.saveApplication(_payloadData, me.parentSectionName);
                    // me.isSaveForLaterFn(null);
                    if (this.stateService.originState !== 'rails') {
                      this.router.navigate(['/dashboard']);
                    }
                  }
                }
                // });
              });
            }, (error: any) => {
              const errMsg = me.snackBarErrorMsg(error);
              me.insuranceSpinner.hide();
              me.showBanner(me.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
            });

          });
        }
      });

    // moving setClientProfileToCompany fn below as its getting/setting old client details before update client details
    setTimeout(() => {
      me.setClientProfileToCompany('C');
    }, 1000);
  }

  updateClientData(callfrom, _callbackFn) {
    console.log(' >>>>>> CALL FROM ', callfrom);
    const me = this;
    if (me.stateService.clientType === 'P') {
      // tslint:disable-next-line: max-line-length
      const payloadBody = me.transService.encryptedPersonUpdatePayload(me.stateService.clientDetailsPayload, me.stateService.insuranceDetails.questionAnswers, me.stateService.clientDetailsPayload.company);
      this.stateService.insuranceDetails['isNewCompany'] = false;
      if (!UtilMethodsService.isEmpty(payloadBody)) {
        me.insuranceStaticService.updateClientData(payloadBody, me.transService.agentId).subscribe((res) => {
          if (!UtilMethodsService.isEmpty(res)) {
            // here we get company id so set it to this.stateService.clientID
            this.stateService.clientID = res.companyOffice.id;
            me.insuranceSpinner.hide();
            // this.showBanner(this.snackBar, 'Personal Profile Updated', BaseFormComponent.SUCCESS_BAR);
            _callbackFn();
          }
        }, (error: any) => {
          const errMsg = me.snackBarErrorMsg(error);
          me.insuranceSpinner.hide();
          me.showBanner(me.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        });
      }
    } else if (me.stateService.clientType === 'C') {
      // const payloadBody = this.encryptedCompanyRequestPayload(formValues);
      let payloadBody;
      if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['isNewCompany'])
        && (this.stateService.insuranceDetails['isNewCompany'] === true)) {
        // tslint:disable-next-line: max-line-length
        payloadBody = me.transService.encryptedPersonUpdatePayload(me.stateService.clientDetailsPayload, me.stateService.insuranceDetails.questionAnswers, false);
      } else {
        // tslint:disable-next-line: max-line-length
        payloadBody = me.transService.encryptedCompanyUpdatePayload(me.stateService.clientDetailsPayload, me.stateService.insuranceDetails.questionAnswers);
      }

      if (!UtilMethodsService.isEmpty(payloadBody)) {
        me.insuranceStaticService.updateClientData(payloadBody, me.transService.agentId).subscribe((res) => {
          if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['isNewCompany'])
            && this.stateService.insuranceDetails['isNewCompany'] === true) {
            this.insuranceStaticService.getClientInfoOnType(res.clientType, res.id)
              .subscribe((_clientDetails) => {
                // tslint:disable-next-line: max-line-length
                this.transService.prePopulateUserDetails(this.insuranceSpinner, res.id, res.clientType, false, this.form, _clientDetails.companyPresentForPerson, false, _callbackFn);
                me.insuranceSpinner.hide();
              }, (err) => {
                console.log('error', err);
              });
          } else {
            me.insuranceSpinner.hide();
            // this.showBanner(this.snackBar, 'Company Profile Updated', BaseFormComponent.SUCCESS_BAR);
            _callbackFn();
          }
        }, (error: any) => {
          const errMsg = me.snackBarErrorMsg(error);
          me.insuranceSpinner.hide();
          me.showBanner(me.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        });

      }
    }
  }

  generateApplicationID(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    this.insuranceStaticService.createApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        if (data.data && data.data.knockedOut) {
          this.stateService.isDeclined = true;
          this.router.navigate(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
          return;
        }
        this.stateService.insuranceDetails['applicationId'] = data.id;
        if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['applicationId'])) {
          this.isSaveForLaterFn(null);
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        // this.router.navigate(['/insurance/insuranceDetails']);
      }
    );
  }

  /**
   * Its gettiing call for all insurance product but for pnl only getting value
   * not able to call in ngviewInit ...hooks not getting called so handled in ngOnitInit firstime call
   * when user select profession it will get handled using event emitter
   * @param _profession
   */


  getInsuranceLimit(_profession) {
    // if condtion will execute only for pnl insurnace product
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_LIMIT_ALLOW_PRODUCT)) {
      this.insuranceStaticService.getInsuranceLimit(_profession).subscribe((_limit) => {
        this.stateService.insuranceDetails['insuranceLimit'] = _limit['list'];
      });
    }
  }

  updateBusinessName(userID, callback?) {
    if (userID) {
      this.insuranceStaticService.saveCompanyInfo(userID).subscribe(
        async (data) => {
          if (!UtilMethodsService.isEmpty(data)) {
            Array.isArray(data) ? this.stateService.companyInfo = data : this.stateService.companyInfo = [data];
            this.stateService.directClientCompanyId = data.companyOffices[0].id;
            this.stateService.isCompanyExist = true;
            if (!UtilMethodsService.isEmpty(callback)) {
              callback();
            }
            this.insuranceSpinner.hide();
          }
          this.insuranceSpinner.hide();
        },
        (error) => {
          const errMsg = this.snackBarErrorMsg(error);
          this.insuranceSpinner.hide();
          this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        }
      );
    }
  }

  insuranceAppStartGtmEvent(event, insuranceType, userType, insuranceClass, applicationID) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`,
      `${insuranceClass}`,
      `${applicationID}`
    );
  }

  limiInsuranceManageOption() {
    let limitOption = '';
    const limitOptionObj = {
      id: 62,
      label: '$50,000',
      name: '50000',
    };
    if (this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state] === 'NY') {
      this.getQuoteJson.questions.forEach(_koQuestion => {
        if (_koQuestion['name'] === ComparativeConstants.CUSTOM_VALIDATION_QNS_LIST.EPLI_limitOfInsurance.name) {
          limitOption = _koQuestion['options'].find(opt => opt.name === '50000');
          if (limitOption) {
            _koQuestion['options'].splice(_koQuestion['options'].indexOf(limitOption), 1);
          }
          return;
        }
      });
    } else {
      this.getQuoteJson.questions.forEach(_koQuestion => {
        if (_koQuestion['name'] === ComparativeConstants.CUSTOM_VALIDATION_QNS_LIST.EPLI_limitOfInsurance.name) {
          limitOption = _koQuestion['options'].find(opt => opt.name === '50000');
          if (!limitOption) {
            _koQuestion['options'].insert(0, limitOptionObj);
          }
          return;
        }
      });
    }
  }

  ngOnDestroy() {
    this.unsubscribe();
  }
}
