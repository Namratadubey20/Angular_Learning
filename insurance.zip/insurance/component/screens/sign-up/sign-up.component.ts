import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { LoginPopupComponent } from 'src/app/security/login-popup/login-popup.component';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { AccountService } from 'src/app/user/account.service';
import { SecurityService } from 'src/app/security/security.service';
import { UtilMethodsService } from '../../../services/util-method.service';
import { ISignUp } from './sign-up';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { RequestService } from 'src/app/ibond/service/request.service';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { StateService } from 'src/app/insurance/services/state.service';
import { BaseFormComponent } from '../../base-form.component';
import { TransactionalService } from '../../../services/transactional.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { CreateUserModel } from 'src/app/insurance/models/create-user.model';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { StringConstants } from '../../../constants/string-constants';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';

@Component({
  selector: 'app-security-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss'],
})
export class InsuranceSignUpComponent extends BaseFormComponent implements OnInit, AfterViewInit {
  @Input() applicantInfo: any;
  @Input() set showSignUp(val) {
    if (val) {
      this.viewInit();
    }
  }
  isCompanySignup = false;
  isEmailAlreadyRegister = false;
  gtmBondType: string;
  sudoBond: string;
  nxtRoute;
  fromRoute;
  constructor(
    protected accountService: AccountService,
    public fb: FormBuilder,
    public insuranceStaticService: InsuranceStaticService,
    public matDialog: MatDialog,
    public securityService: SecurityService,
    public insuranceSpinner: InsuranceSpinnerService,
    private gtmService: GoogleTagManagerService,
    private requestService: RequestService,
    private activatedRoute: ActivatedRoute,
    public stateService: StateService,
    private router: Router,
    public transService: TransactionalService,
    public matDialogService: MatDialog,
    public snackBar: MatSnackBarComponent,
    public stringConstant: StringConstants
  ) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.parentSectionName = 'createUser';
    this.sectionName = 'createUser';
    this.modelName = CreateUserModel;
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;
  }

  ngOnInit() {
    this.setSubSectionForValidation(this.parentSectionName, this.sectionName);
    this.getQuoteJson = this.insuranceStaticService.getCreateUserFieldFormJson();
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.setQuestionNameToStack(this.getQuoteJson.data[i]);
    }

    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.loadInitialFields(this.getQuoteJson.data[i].fields);
    }
    this.form = this.createControlwithNewJson(this.questionJSONDatafields);

    // this.initialize();
    this.activatedRoute.params.subscribe(parms => {
      console.log('security create user-->', parms);
      this.gtmBondType = parms.bondType;
      this.sudoBond = this.requestService.setBondType(this.gtmBondType);
    });
    this.activatedRoute.queryParams.subscribe(queryParms => {
      console.log('security create user activatedRoute.queryParams -->', queryParms);
      this.nxtRoute = queryParms.returnUrl;
      this.fromRoute = queryParms.fromUrl;
    });
    console.log('security create user insurance stateService -->', this.stateService, '--applicantInfo--', this.applicantInfo);
    // GTM DLV when route on sign up page
    let insurancePremiumType = this.stateService.insuranceDetails.questionAnswers['premiumOption'];
    if (insurancePremiumType === 'monthlyPay') {
      insurancePremiumType = 'month';
    } else {
      insurancePremiumType = 'year';
    }
    this.insuranceAppRegisterGtmEvent('insurance-app-register', this.stateService.insuranceSelected[0], '',
      'new', this.stateService.insuranceDetails ? this.stateService.insuranceDetails['applicationId'] : '',
      this.stateService.insuranceDetails['premiumAmount'],
      insurancePremiumType);
  }
  ngAfterViewInit() {
    this.getTotalRequiredFieldsForSection();
  }

  validatePageForNavigation() {
    const isValidated = this.checkIfPageValidForNavigation();
    console.log('isValidated >> ', isValidated);
  }

  isSaveForLaterFn(event) { }

  navigateForwardFn(event) {
    if (this.stateService.SECTIONS[this.parentSectionName]['istouched'] === true &&
      // tslint:disable-next-line:triple-equals
      this.stateService.SECTIONS[this.parentSectionName]['errors'] == 0) {
      this.signUpUser();
    } else {
      this.showPageError(this.snackBar, false);
    }
  }
  viewInit(): void {
    const request_email_check = {
      requestedEmail: this.stateService.insuranceDetails.questionAnswers['application_email'],
    }; // applicantInfo.applicantEmail,
    this.accountService.checkEmailAvailability(request_email_check).subscribe(res => {
      this.isEmailAlreadyRegister = !res.available;
    });
  }

  login(): void {
    const dialogRef = this.matDialog.open(LoginPopupComponent, { data: { clickFrom: 'signup', url: this.fromRoute } });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const urlToNavigate = this.activatedRoute.queryParams['_value']['returnUrl'];
        if (!UtilMethodsService.isEmpty(result.response.person)) {
          // start : commenting this save application code for anonymous user if user logged with existing account
          // const navigationExtras: NavigationExtras = {
          //   queryParams: {
          //     action: 'save',
          //     isAnonymousUser: true,
          //   },
          // };
          // this.router.navigate([urlToNavigate], navigationExtras);
          // end .. lets keep this commented code for now.. We can delete it later

          // if anonyous user login using exsting account and user uses agent credential to login then
          // show error msg to user saying log in as non insurance agent
          if (this.transService.isAgent()) {
            this.securityService.deleteCookie();
            this.securityService._loggedIn$.next(false);
            this.showBanner(this.snackBar, this.stringConstant.CLIENT_LOGIN_AS_AGENT, BaseFormComponent.ERROR_BAR);
            dialogRef.close();
            return;
          }
          // if user logged with existing account then update already filled details as per loggedIn user object
          // nevigate user to get-quote page
          const navigationExtras: NavigationExtras = {
            queryParams: {
              isAnonymousUser: true,
              bondClassification: this.stateService.insuranceDetails.questionAnswers['bondClassification'],
            },
          };
          this.router.navigate(['/insurance/evaluator'], navigationExtras);
          this.showBanner(this.snackBar, this.stringConstant.APPLICATION_NOT_SAVED, BaseFormComponent.ERROR_BAR);
        }
        this.insuranceStaticService.setSignUpValue(false);
      }
    }, error => {
    });
    // GTM DLV when route on login overlay page
    let insurancePremiumType = this.stateService.insuranceDetails.questionAnswers['premiumOption'];
    if (insurancePremiumType === 'monthlyPay') {
      insurancePremiumType = 'month';
    } else {
      insurancePremiumType = 'year';
    }
    this.insuranceAppLoginGtmEvent('insurance-app-login', this.stateService.insuranceSelected[0], '',
      'new', this.stateService.insuranceDetails ? this.stateService.insuranceDetails['applicationId'] : '',
      this.stateService.insuranceDetails['premiumAmount'],
      insurancePremiumType);
  }
  checkPasswords(control: FormGroup) {
    const pass = control.get('password').value;
    const confirmPass = control.get('confirmPass').value;

    return pass === confirmPass ? null : { match: true };
  }
  navigateBackwardFn(event): void {
    this.insuranceStaticService.setSignUpValue(false);
    const urlToReturn = this.fromRoute ? this.fromRoute : this.activatedRoute.queryParams['_value']['returnUrl'];
    this.router.navigate([urlToReturn]);
  }
  get password() {
    return this.form.get('application_passWord');
  }
  get username() {
    return this.form.get('application_userName');
  }
  get confirmPassword() {
    return this.form.get('application_confirmPassword');
  }
  get displayPasswordLengthError(): boolean {
    return (this.password.value.length <= 10 && this.password.value.length >= 62)
      || (this.password.touched && (this.password.value === '' || this.password.value === null));
  }
  get validLengthCondition(): boolean {
    // return !this.displayPasswordLengthError && this.password.touched;
    if (this.stateService.insuranceDetails.questionAnswers &&
      this.stateService.insuranceDetails.questionAnswers['application_passWord'] !== undefined) {
      return (this.stateService.insuranceDetails.questionAnswers['application_passWord'].length >= 10 ||
        this.stateService.insuranceDetails.questionAnswers['application_passWord'].lenght <= 62);
    }
  }
  get invalidLengthCondition(): boolean {
    // return this.displayPasswordLengthError && this.password.touched;
    if (this.stateService.insuranceDetails.questionAnswers &&
      this.stateService.insuranceDetails.questionAnswers['application_passWord'] !== undefined) {
      return (this.stateService.insuranceDetails.questionAnswers['application_passWord'].length < 10 ||
        this.stateService.insuranceDetails.questionAnswers['application_passWord'].lenght > 62);
    }
  }

  get validPatternCondition(): boolean {
    return this.displayAlphanumericError && this.password.touched && this.password.value !== '';
  }
  get invalidPatternCondition(): boolean {
    if (this.password.touched) {
      return !(this.displayAlphanumericError);
    }
  }
  get displayAlphanumericError(): boolean {
    const regEx = /^.*(?=.*\d)(?=.*[a-zA-Z]).*$/;
    return (this.password.touched && regEx.test(this.password.value));
    // || (this.password.touched && (this.password.value === '' || this.password.value === null));
  }

  get confirmPasswordErrorMessage(): string {
    return (this.confirmPassword.value && this.confirmPassword.value.length > 0) ? 'Confirm New Password is required.' :
      this.confirmPassword.value.length >= 10 ? 'Confirm New Password must have minimum length of 10.' :
        this.confirmPassword.value === this.password.value ? 'Passwords do not match.' : '';
  }

  signUpUser() {
    this.insuranceSpinner.show();
    if (this.form.valid) {
      // const funcatioName = this.applicantInfo.applicantNameCheck ? 'signIndividual' : 'signCompany';
      this.insuranceStaticService.signUpStandardUser(this.requestObject()).subscribe((response) => {
        if (response) {
          this.insuranceSpinner.show();
          const username = this.stateService.insuranceDetails.questionAnswers['application_userName'];
          const password = this.stateService.insuranceDetails.questionAnswers['application_passWord'];
          this.securityService.loginFromSignup(username, password, {}).then((res) => {
            this.insuranceSpinner.show();
            if (!UtilMethodsService.isEmpty(res)) {
              this.insuranceStaticService.setSignUpValue(false);
              this.insuranceSpinner.hide();
            } else {
              this.insuranceSpinner.hide();
            }
            if (this.nxtRoute) {
              if (!UtilMethodsService.isEmpty(res.person) && this.activatedRoute.queryParams['_value']['action'] === 'save') {
                const navigationExtras: NavigationExtras = {
                  queryParams: {
                    action: 'save',
                    isAnonymousUser: true,
                  },
                };
                this.router.navigate([this.nxtRoute], navigationExtras);
              } else {
                this.router.navigate([this.nxtRoute]);
              }
            }
          });
        }
      }, (err) => {
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, err.error.message, BaseFormComponent.ERROR_BAR);
      });
    }
  }

  requestObject(): ISignUp {
    return {
      personalInformation: {
        firstName: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
          .staticQuestionNames.application_firstName] || null,
        initial: null,
        lastName: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
          .staticQuestionNames.application_lastName] || null,
        suffix: this.stateService.insuranceDetails.questionAnswers['application_suffix'] || null,
        salutation: null,
        phone: UtilMethodsService.serializePhoneNumber(this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
          .staticQuestionNames.application_phone]) || null,
        email: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
          .staticQuestionNames.application_email] || null,
        profession: null,
        address: {
          street1: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
            .staticQuestionNames.application_address1] || null,
          street2: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
            .staticQuestionNames.application_address2] || null,
          city: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
            .staticQuestionNames.application_city] || null,
          state: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
            .staticQuestionNames.application_state] || null,
          zipCode: this.stateService.insuranceDetails.questionAnswers[this.comparativeConstants
            .staticQuestionNames.application_zipCode] || null,
        },
      },
      usernamePassword: {
        username: this.stateService.insuranceDetails.questionAnswers['application_userName'],
        password: this.stateService.insuranceDetails.questionAnswers['application_passWord'],
        confirmPassword: this.stateService.insuranceDetails.questionAnswers['application_confirmPassword'],
        referralCode: null,
      },
    };
  }

  insuranceAppRegisterGtmEvent(event, insuranceType, userType, insuranceClass, applicationID,
    insurancePremium, insurancePremiumType) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`,
      `${insuranceClass}`,
      `${applicationID}`,
      `${insurancePremium}`,
      `${insurancePremiumType}`
    );
  }

  insuranceAppLoginGtmEvent(event, insuranceType, userType, insuranceClass, applicationID,
    insurancePremium, insurancePremiumType) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`,
      `${insuranceClass}`,
      `${applicationID}`,
      `${insurancePremium}`,
      `${insurancePremiumType}`
    );
  }

  onFocusOut(event, field) {
    super.onFocusOut(event, field);
    if (field.name === 'application_confirmPassword' &&
      (this.stateService.insuranceDetails.questionAnswers['application_passWord'] !==
        this.stateService.insuranceDetails.questionAnswers['application_confirmPassword'])) {
      this.stateService.fieldError[field.name] = this.stringConstant.PWS_DONOT_MATCH;
    }
  }

  navigateHome() {
    this.transService.checkLoginAndRedirect(this.parentSectionName);
  }
}
