import { TestBed, async, fakeAsync, getTestBed, ComponentFixture, inject } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators, FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { InsuranceSignUpComponent } from './sign-up.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef, Input, AfterViewInit } from '@angular/core';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { PurchaseSummaryPanelComponent } from '../../common/purchase-summary-panel/purchase-summary-panel.component';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';

import { LoginPopupComponent } from 'src/app/security/login-popup/login-popup.component';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { AccountService } from 'src/app/user/account.service';
import { SecurityService } from 'src/app/security/security.service';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';
import { UtilMethodsService } from '../../../services/util-method.service';
import { ISignUp } from './sign-up';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { RequestService } from 'src/app/ibond/service/request.service';
import { ActivatedRoute, Router } from '@angular/router';
import { StateService } from 'src/app/insurance/services/state.service';
import { BaseFormComponent } from '../../base-form.component';
import { TransactionalService } from '../../../services/transactional.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { CreateUserModel } from 'src/app/insurance/models/create-user.model';
import { StringConstants } from '../../../constants/string-constants';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';

@Component({
  selector: 'app-test-security-sign-up',
  template: '<app-security-sign-up></app-security-sign-up>',
})

class TestInsuranceSignUpComponent {
}

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {
}

class StateServiceMock {
  public SECTIONS = {
    'getQuote': {
      'istouched': false,
    },
    'productInformation': {
      'istouched': false,
    },
    'yourQuote': {
      'istouched': false,
    },
    'agreement': {
      'istouched': false,
    },
    'payment': {
      'istouched': false,
    },
  };
}

describe('Insurance sign-up Component', () => {
  let component: InsuranceSignUpComponent;
  let stateServiceMock: StateServiceMock;
  let router: Router;
  let fixture: ComponentFixture<TestInsuranceSignUpComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  let dataLayer: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'insurance/agreement', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [
        MatSnackBarComponent,
        ServiceHandler,
        GoogleTagManagerService,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        InsuranceStaticService,
        AccountService,
      ],
      declarations: [
        TestInsuranceSignUpComponent,
        MockRouteBlankComponent,
        InsuranceSignUpComponent,
        InsuranceHeadingPanelComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        StringConstantPipe,
        GetLabelPipe,
        LoginPopupComponent,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    stateServiceMock = new StateServiceMock();
    fixture = TestBed.createComponent(TestInsuranceSignUpComponent);
    router = TestBed.get(Router);
    component = fixture.debugElement.children[0].componentInstance as InsuranceSignUpComponent;
    window.dataLayer = dataLayer = [];
    spyOn(component, 'getTotalRequiredFieldsForSection').and.returnValue('');
    spyOn(component, 'checkIfPageValidForNavigation').and.returnValue(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to insurance/agreement', () => {
    const event = '';
    const navigateSpy = spyOn(router, 'navigate');
    component.fromRoute = '/insurance/agreement';
    component.navigateBackwardFn(event);
    expect(navigateSpy).toHaveBeenCalledWith(['/insurance/agreement']);
  });

  it('should check if page is valid for navigation', () => {
    component.validatePageForNavigation();
    expect(component.checkIfPageValidForNavigation).toHaveBeenCalled();
  });

  it('should call isSaveForLaterFn', () => {
    expect(component.isSaveForLaterFn('')).toBeUndefined();
  });

  it('should navigate forward to payment screen', inject([StateService], (stateService: StateService) => {
    stateService.SECTIONS['createUser']['istouched'] = true;
    stateService.SECTIONS['createUser']['errors'] = 0;
    component.navigateForwardFn(null);
    expect(stateService.SECTIONS['createUser']['istouched']).toBeTruthy();
  }));

});
