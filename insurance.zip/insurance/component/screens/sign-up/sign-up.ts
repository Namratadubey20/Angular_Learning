export interface ISignUp {
  personalInformation: IPersonalInformationIndividual;
  usernamePassword: IUsernamePassword;
}
export interface IPersonalInformationIndividual {
  firstName: string;
  initial?: string;
  lastName: string;
  suffix?: string;
  salutation: string;
  phone: string;
  email: string;
  profession?: string;
  address: IAddressIndividual;
}
export interface IAddressIndividual {
  street1: string;
  street2?: string;
  city: string;
  state: string;
  zipCode: string;
}

export interface IUsernamePassword {
  username: string;
  password: string;
  confirmPassword: string;
  referralCode?: string;
}
