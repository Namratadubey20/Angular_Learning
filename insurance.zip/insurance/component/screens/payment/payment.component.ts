import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, ValidatorFn, FormArray } from '@angular/forms';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { TransactionalService } from '../../../services/transactional.service';
import { StateService } from '../../../services/state.service';
import { UtilMethodsService } from '../../../services/util-method.service';
import { BaseFormComponent } from '../../base-form.component';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { PaymentChannelComponent } from '../../../../payment/component/payment-channel/payment-channel.component';
import { InsuranceSpinnerService } from 'src/app/insurance/services/insurance-spinner.service';
import { ProductConfigService } from 'src/app/insurance/services/product-config.service';
import { SecurityService } from 'src/app/security/security.service';
import { PaymentModel } from '../../../models/payment.model';
import { ComparativeConstants } from 'src/app/insurance/constants/comparative-constants';
import { StringConstants } from 'src/app/insurance/constants/string-constants';
import { FileUploadConfig } from 'src/app/form-insurance-components/file-input/file-upload-config';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { AppConfigService } from 'src/app/app-config-service';
import { Observable, Subscription, interval } from 'rxjs';

@Component({
  selector: 'app-insurance-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
  providers: [
    ProductConfigPipe],
})
export class InsurancePaymentComponent extends BaseFormComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(PaymentChannelComponent) paymentPayLoad: PaymentChannelComponent;
  public userId;
  public applicationId;
  public annualPay;
  public monthlyPay;
  public applicantDetails;
  public isFileuploadDone;
  public showPaymentScreen = false;
  appConfig;
  private updateSubscription: Subscription;

  constructor(public insuranceStaticService: InsuranceStaticService, public transService: TransactionalService,
    public productConfigPipe: ProductConfigPipe, public fb: FormBuilder, public stateService: StateService,
    public matDialogService: MatDialog, private router: Router, public insuranceSpinner: InsuranceSpinnerService,
    public snackBar: MatSnackBarComponent, public productConfig: ProductConfigService,
    public securityService: SecurityService, private _changeDetectionRef: ChangeDetectorRef, public stringConstant: StringConstants,
    public fileUploadConfig: FileUploadConfig,
    private gtmService: GoogleTagManagerService,
    private appConfigService: AppConfigService
  ) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.parentSectionName = 'payment';
    this.sectionName = 'paymentChannel';
    this.modelName = PaymentModel;
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;
    this.fileUploadConfig.acceptsFileTypes = '.pdf,.doc,.docx';
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }

  ngOnInit() {
    const me = this;
    me.annualPay = 0;
    this.insuranceSpinner.show();
    me.setSubSectionForValidation(me.parentSectionName, me.sectionName);
    this.stateService.insuranceDetails.questionAnswers.paymentMethod = null;
    this.getPaymentJson = this.insuranceStaticService.getPaymentDetailsFormJson();
    for (let i = 0; i < this.getPaymentJson.data.length; i++) {
      this.setQuestionNameToStack(this.getPaymentJson.data[i]);
    }
    for (let i = 0; i < this.getPaymentJson.data.length; i++) {
      this.loadInitialFields(this.getPaymentJson.data[i].fields);
    }
    this.form = this.createControlwithNewJson(this.questionJSONDatafields);
    // this.insuranceSpinner.hide();
    this.userId = this.securityService.user && this.securityService.user['person'] && this.securityService.user['person']['id'];

    if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['applicationId'])) {
      // loggedIn user will have application ID
      this.applicationId = this.stateService.insuranceDetails['applicationId'];
      if (this.applicationId) {
        this.setApplicantDetails(this.stateService.insuranceDetails['applicationId']);
      }
    } else {
      this.insuranceSpinner.show();
      // Anonymous user does not have application ID yet but have login ID , Now its logged in user
      // user is login and create application ID
      // Need business details in payload
      // create company before create final payload
      // FRN-154 issue Company office must be required
      this.updateBusinessName(this.transService.getPersonalId(), () => {
        const _payloadData = this.transService.encryptPayload(true);
        if (_payloadData && !this.stateService.insuranceDetails['applicationId']
          && this.transService.isUserLogIn()) {
          // need to set parent name as agreement as we are moving from agreement screen hence hardcoded parent name
          this.stateService.getApplicationStatus.subscribe(status => {
            if (!UtilMethodsService.isEmpty(status) && status === true) {
              // this.insuranceSpinner.hide();
              this.setApplicantDetails(this.stateService.insuranceDetails['applicationId']);
            } else {
              me.annualPay = '';
              me.monthlyPay = '';
              this.insuranceSpinner.show();
            }
          });
          this.generateApplicationID(_payloadData, 'agreement');
        }
        //  this.insuranceSpinner.hide();
      });
    }
    // GTM DLV when route on payment page
    let insurancePremiumType = this.stateService.insuranceDetails.questionAnswers['premiumOption'];
    if (insurancePremiumType === 'monthlyPay') {
      insurancePremiumType = 'month';
    } else {
      insurancePremiumType = 'year';
    }
    this.insuranceAppPaymentGtmEvent('insurance-app-payment', this.stateService.insuranceSelected[0], '',
      'new', this.stateService.insuranceDetails ? this.stateService.insuranceDetails['applicationId'] : '',
      this.stateService.insuranceDetails['premiumAmount'],
      insurancePremiumType);
    sessionStorage.setItem('applicationId', this.stateService.insuranceDetails['applicationId']);
  }

  setApplicantDetails(applicationId) {
    // this.insuranceSpinner.show();
    const me = this;
    if (!UtilMethodsService.isEmpty(applicationId)) {
      if (UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers['premiumOption'])) {
        this.stateService.insuranceDetails.questionAnswers['premiumOption'] = 'annualPay';
      }
      if (me.stateService.insuranceDetails['premiumAmount']) {
        me.annualPay = me.stateService.insuranceDetails['premiumAmount'];
        me.monthlyPay = Math.round(me.stateService.insuranceDetails['premiumAmount'] / 12);
      } else {
        me.annualPay = 0;
        me.monthlyPay = 0;
      }
      this.applicantDetails = this.transService.getApplicantDetailsObjPayment(this.stateService.insuranceDetails.questionAnswers);
      //  this.insuranceSpinner.hide();
    }
    this.showPaymentScreen = true;
  }

  ngAfterViewInit() {
    if (this.productConfigPipe.transform(this.productConfig.INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT)) {
      this.isCustomPageValidationRequired = true;
    }
    this.getTotalRequiredFieldsForSection();
    this.highlightInvalidFields(this.form);
    this._changeDetectionRef.detectChanges();
    // UI load Before value set issue , so refreshed the screen
    this.updateSubscription = interval(50).subscribe(
      (val) => {
        if (this.stateService.insuranceDetails['premiumAmount']) {
          this.annualPay = this.stateService.insuranceDetails['premiumAmount'];
          this.monthlyPay = Math.round(this.annualPay / 12);
        }
      });
    setTimeout(() => {
      this.insuranceSpinner.hide();
    }, 1000);
  }

  validatePageForNavigation() {
    const isValidated = this.checkIfPageValidForNavigation();
    console.log('isValidated >> ', isValidated);
  }
  customPTrigg(event) {
    this.stateService.insuranceDetails.questionAnswers.paymentMethod = this.paymentPayLoad.getPaymentPayLoad();
    this.validatePage(false, null, null);
  }
  ifFileUploaded(event) {
    this.stateService.isCyberFileuploadDone = true;
    this.validatePage(false, null, null);
  }
  navigateBackwardFn(event) {
    this.insuranceSpinner.show();
    this.router.navigate(['/insurance/agreement']);
  }

  navigateForwardFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    if (this.stateService.SECTIONS[this.parentSectionName]['istouched'] === true &&
      this.stateService.SECTIONS[this.parentSectionName]['errors'] === 0) {
      this.stateService.editedQuesDetails = {};
      this.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_CONTINUE;
      const _payloadData = this.transService.encryptPayload();
      if (_payloadData) {
        this.submitApplication(_payloadData, this.parentSectionName);
      }
    } else {
      this.showPageError(this.snackBar, false);
    }
  }

  submitApplication(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    this.insuranceStaticService.submitApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        if (data.data && data.data.knockedOut) {
          this.stateService.isDeclined = true;
          if (sessionStorage.getItem('originState') === 'rails') {
            this.navigateToRails(data.id, data.status);
          } else {
            this.router.navigate(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/insurancePayment' } });
          }
        } else {
          console.log('submit application -->', data);
          this.stateService.isDeclined = false;
          if (sessionStorage.getItem('originState') === 'rails') {
            this.navigateToRails(data.id, data.status);
          } else {
            this.router.navigate(['/insurance/insuranceConfirmation']);
          }
        }
        sessionStorage.removeItem('applicationId');
        sessionStorage.removeItem('originState');
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        this.insuranceSpinner.hide();
        sessionStorage.removeItem('applicationId');
        sessionStorage.removeItem('originState');
      }, () => {
        this.insuranceSpinner.hide();
        sessionStorage.removeItem('applicationId');
        sessionStorage.removeItem('originState');
      }
    );
  }

  navigateToRails(id, status) {
    this.securityService.getAccessToken().then(response => {
      sessionStorage.removeItem('originState');
      console.log(this.securityService.requestURL(`?sutoken=${response}`));
      let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
      if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
        railsUrl = this.appConfig.colonial_erisa_TPA_url;
      }
      this.insuranceSpinner.show();
      window.open(`${railsUrl}?sutoken=${response}&applicationId=${id}&applicationStatus=${status}`, '_self');
    });
  }

  navigateHome() {
    this.transService.checkLoginAndRedirect(this.parentSectionName);
  }

  isSaveForLaterFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    this.stateService.editedQuesDetails = {};
    this.stateService.insuranceDetails.questionAnswers['buttonReference'] = ComparativeConstants.BUTTON_REFERENCE_SAVE_FOR_LATER;
    const _payloadData = this.transService.encryptPayload(true);
    console.log('In save for later >> ', _payloadData);
    if (this.transService.isUserLogIn()) {
      // login user save for later , everytime user gets on Payment page user needs to login
      // so save for later only for logged in user , no neeed to handle for anonymous user
      if (_payloadData) {
        this.saveApplication(_payloadData, this.parentSectionName);
      }
    }
  }

  saveApplication(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    // tslint:disable-next-line: max-line-length
    this.insuranceStaticService.saveApplication(_payloadData, _pageReference).subscribe(
      async (data) => {
        const originState = sessionStorage.getItem('originState');
        sessionStorage.removeItem('applicationId');
        this.insuranceSpinner.hide();
        if (originState === 'rails') {
          this.navigateToRails(data.id, data.status);
        } else {
          await this.router.navigateByUrl('/secure/logout');
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  generateApplicationID(_payloadData, _pageReference) {
    this.insuranceSpinner.show();
    if (!UtilMethodsService.isEmpty(this.stateService.quoteId)) {
      _payloadData['quoteId'] = this.stateService.quoteId;
    }
    this.insuranceSpinner.show();
    this.subscriptions.push(this.insuranceStaticService.createApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        if (!UtilMethodsService.isEmpty(data)) {
          if (data.data && data.data.knockedOut) {
            this.stateService.isDeclined = true;
            this.router.navigate(['/insurance/insuranceConfirmation'], { queryParams: { 'fromUrl': '/insurance/insuranceDetails' } });
            return;
          } else {
            this.insuranceSpinner.hide();
            this.showPaymentScreen = true;
          }
          this.stateService.insuranceDetails['applicationId'] = data.id;
          this.applicationId = this.stateService.insuranceDetails['applicationId'];
          this.stateService.getApplicationStatus.next(true);
        }
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    ));
  }

  updateBusinessName(userID, callback?) {
    if (userID) {
      this.insuranceStaticService.saveCompanyInfo(userID).subscribe(
        async (data) => {
          if (!UtilMethodsService.isEmpty(data)) {
            Array.isArray(data) ? this.stateService.companyInfo = data : this.stateService.companyInfo = [data];
            this.stateService.directClientCompanyId = data.companyOffices[0].id;
            this.stateService.isCompanyExist = true;
            callback();
            // this.insuranceSpinner.hide();
          }
          // this.insuranceSpinner.hide();
        },
        (error) => {
          const errMsg = this.snackBarErrorMsg(error);
          this.insuranceSpinner.hide();
          this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
        }
      );
    }
  }

  ngOnDestroy() {
    setTimeout(() => {
      this.insuranceSpinner.hide();
    }, 1000);
    this.unsubscribe();
  }

  insuranceAppPaymentGtmEvent(event, insuranceType, userType, insuranceClass, applicationID, insurancePremium, insurancePremiumType) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`,
      `${insuranceClass}`,
      `${applicationID}`,
      `${insurancePremium}`,
      `${insurancePremiumType}`
    );
  }

}
