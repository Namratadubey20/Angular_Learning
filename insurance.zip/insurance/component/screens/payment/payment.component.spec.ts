import { TestBed, async, fakeAsync, getTestBed, ComponentFixture, inject } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { BrowserModule } from '@angular/platform-browser';
import { InsurancePaymentComponent } from './payment.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PaymentChannelComponent } from '../../../../payment/component/payment-channel/payment-channel.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { InsurancePaymentMethodComponent } from '../../shared/insurance-payment-method/insurance-payment-method.component';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { PurchaseSummaryPanelComponent } from '../../common/purchase-summary-panel/purchase-summary-panel.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { SecurityService } from 'src/app/security/security.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { ApplicationPopulateService } from 'src/app/ibond/service/application-populate.service';
import { AppConfigService } from '../../../../app-config-service';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PaymentService } from '../../../../payment/services/payment.service';
import { ProductConfigService } from 'src/app/insurance/services/product-config.service';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { StateService } from 'src/app/insurance/services/state.service';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { of, Observable, throwError } from 'rxjs';
import { TransactionalService } from 'src/app/insurance/services/transactional.service';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { BaseFormComponent } from '../../base-form.component';

@Component({
  selector: 'app-test-insurance-payment',
  template: '<app-insurance-payment></app-insurance-payment>',
})

class TestInsurancePaymentComponent extends BaseFormComponent {
}

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {
}

describe('Insurance Payment Component', () => {
  let component: InsurancePaymentComponent;
  let fixture: ComponentFixture<TestInsurancePaymentComponent>;
  const childComponent = jasmine.createSpyObj('PaymentChannelComponent', ['getPaymentPayLoad']);
  let router: Router;
  let dataLayer: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'insurance/insuranceConfirmation', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        NoopAnimationsModule,
      ],
      providers: [
        SecurityService,
        ServiceHandler,
        ApplicationPopulateService,
        AppConfigService,
        PaymentService,
        MatSnackBarComponent,
        ProductConfigService,
        GoogleTagManagerService,
      ],
      declarations: [
        MockRouteBlankComponent,
        TestInsurancePaymentComponent,
        InsurancePaymentComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        InsuranceHeadingPanelComponent,
        InsurancePaymentMethodComponent,
        PaymentChannelComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
      ],

    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsurancePaymentComponent);
    router = TestBed.get(Router);
    component = fixture.debugElement.children[0].componentInstance as InsurancePaymentComponent;
    window.dataLayer = dataLayer = [];
    spyOn(component, 'checkIfPageValidForNavigation').and.returnValue(true);
    fixture.detectChanges();
  });

  /* it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it(`should genrate application id`, async () => {
    const payloadData = component.transService.encryptPayload();
    const pageRef = 'payment';
    component.generateApplicationID(payloadData, pageRef);
    fixture.detectChanges();
    // fixture.whenStable().then(() => {
    expect(component.stateService.insuranceDetails.applicationId).toEqual('');
    // });
  });

  it('should return API response error when generateApplicationID called',
    inject([StateService, InsuranceStaticService], (stateService: StateService,
      insuranceService: InsuranceStaticService) => {
      const payloadData = component.transService.encryptPayload();
      const pageRef = 'payment';
      const showBanner = spyOn(component, 'showBanner').and.returnValue('');
      const generateApplicationID = spyOn(insuranceService, 'createApplication').and.
        returnValue(throwError({ status: 404, error: { message: '' } }));
      component.generateApplicationID(payloadData, pageRef);
      expect(generateApplicationID).toHaveBeenCalled();
      expect(showBanner).toHaveBeenCalled();
    }));

  it('should set pageLoaded after view init and get total required fields', () => {
    spyOn(component, 'getTotalRequiredFieldsForSection');
    component.ngAfterViewInit();
    expect(component.getTotalRequiredFieldsForSection).toHaveBeenCalled();
  });

  it('should check if page is valid for navigation', () => {
    component.validatePageForNavigation();
    expect(component.checkIfPageValidForNavigation).toHaveBeenCalled();
  });

  it('should get the payment payload', () => {
    const event = '';
    component.paymentPayLoad = childComponent;
    component.customPTrigg(event);
    expect(childComponent.getPaymentPayLoad).toHaveBeenCalled();
  });

  it('should set the applicant details', inject([StateService, InsuranceStaticService,
    TransactionalService],
    (stateService: StateService, insuranceService: InsuranceStaticService, transService: TransactionalService) => {
      const applicatioID = '20727';
      const applicantDetails = spyOn(transService, 'getApplicantDetailsObjPayment').and.returnValue('');
      component.setApplicantDetails(applicatioID);
      expect(applicantDetails).toHaveBeenCalled();
    }));

  it('should navigate forward to insuranceConfirmation screen and submit Application', inject([StateService, InsuranceStaticService,
    TransactionalService],
    (stateService: StateService, insuranceService: InsuranceStaticService, transService: TransactionalService) => {
      const navigateSpy = spyOn(router, 'navigate');
      stateService.SECTIONS['payment']['istouched'] = true;
      stateService.SECTIONS['payment']['errors'] = 0;
      const data = {};

      const submitApplication = spyOn(insuranceService, 'submitApplication').and.callFake(() => {
        return of(data);
      });

      component.navigateForwardFn('');
      expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceConfirmation']);
      expect(submitApplication).toHaveBeenCalled();
    }));

  it('should navigate forward show error pop up', inject([StateService, InsuranceStaticService], (stateService: StateService,
    insuranceService: InsuranceStaticService) => {
    const navigateSpy = spyOn(router, 'navigate');
    stateService.SECTIONS['payment']['istouched'] = false;
    stateService.SECTIONS['payment']['errors'] = 2;
    const showPageError = spyOn(component, 'showPageError').and.returnValue('');
    expect(component.navigateForwardFn('')).toBeUndefined();
    expect(showPageError).toHaveBeenCalled();
  }));

  it('should submitApplication application', inject([StateService, InsuranceStaticService],
    (stateService: StateService, insuranceService: InsuranceStaticService) => {
      const navigateSpy = spyOn(router, 'navigate');
      const data = {};
      const payloadData = component.transService.encryptPayload();
      const pageRef = 'payment';

      const submitApplication1 = spyOn(insuranceService, 'submitApplication').and.callFake(() => {
        return of(data);
      });

      component.submitApplication(payloadData, pageRef);
      expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceConfirmation']);
      expect(submitApplication1).toHaveBeenCalled();
    }));

  it('should save the application for later and logout', inject([StateService, InsuranceStaticService,
    TransactionalService],
    (stateService: StateService, insuranceService: InsuranceStaticService, transService: TransactionalService) => {
      const navigateSpy = spyOn(router, 'navigateByUrl');
      const data = {};
      const payloadData = component.transService.encryptPayload();
      const pageRef = 'payment';

      component.isSaveForLaterFn('');
      component.saveApplication(payloadData, pageRef);
      fixture.detectChanges();
      expect(component).toBeTruthy();
    }));

  it('should save application for later', inject([StateService, InsuranceStaticService],
    (stateService: StateService, insuranceService: InsuranceStaticService) => {
      const navigateSpy = spyOn(router, 'navigateByUrl');
      const data = {};
      const payloadData = component.transService.encryptPayload();
      const pageRef = 'payment';

      const saveApplication = spyOn(insuranceService, 'saveApplication').and.callFake(() => {
        return of(data);
      });

      component.saveApplication(payloadData, pageRef);
      expect(navigateSpy).toHaveBeenCalledWith('/secure/logout');
      expect(saveApplication).toHaveBeenCalled();
    }));

  it('should return API response error when saveApplication called',
    inject([StateService, InsuranceStaticService], (stateService: StateService,
      insuranceService: InsuranceStaticService) => {
      const payloadData = component.transService.encryptPayload();
      const pageRef = 'payment';
      const showBanner = spyOn(component, 'showBanner').and.returnValue('');
      const saveApplication = spyOn(insuranceService, 'saveApplication').and.
        returnValue(throwError({ status: 404, error: { message: '' } }));
      component.saveApplication(payloadData, pageRef);
      expect(saveApplication).toHaveBeenCalled();
      expect(showBanner).toHaveBeenCalled();
    }));

  it('should return API response error when submitApplication called',
    inject([StateService, InsuranceStaticService], (stateService: StateService,
      insuranceService: InsuranceStaticService) => {
      const payloadData = component.transService.encryptPayload();
      const pageRef = 'payment';
      const showBanner = spyOn(component, 'showBanner').and.returnValue('');
      const submitApplication = spyOn(insuranceService, 'submitApplication').and.
        returnValue(throwError({ status: 404, error: { message: '' } }));
      component.submitApplication(payloadData, pageRef);
      expect(submitApplication).toHaveBeenCalled();
      expect(showBanner).toHaveBeenCalled();
    }));

  it('should navigate to home', inject([StateService, TransactionalService], (stateService: StateService,
    transactionalService: TransactionalService) => {
    const checkLoginAndRedirect = spyOn(transactionalService, 'checkLoginAndRedirect').and.returnValue('');
    component.navigateHome();
    expect(checkLoginAndRedirect).toHaveBeenCalled();
  }));

  it('should navigate to /insurance/agreement', () => {
    const event = '';
    const navigateSpy = spyOn(router, 'navigateByUrl');
    fixture.detectChanges();
    component.navigateBackwardFn(event);
    fixture.detectChanges();
    expect(navigateSpy).toHaveBeenCalled();
  });

  it('should check for file upload event', inject([StateService, InsuranceStaticService], (stateService: StateService) => {
    const event = '';
    component.ifFileUploaded(event);
    expect(stateService.isCyberFileuploadDone).toBeTruthy();
  }));

  afterEach(() => {
    fixture.destroy();
  }); */

});
