import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { FormBuilder } from '@angular/forms';
import { TransactionalService } from '../../../services/transactional.service';
import { BaseFormComponent } from '../../base-form.component';
import { StateService } from '../../../services/state.service';
import { GetQuoteModel } from '../../../models/get-quote.model';
import { MatDialog } from '@angular/material';
import { PreloadService } from '../../../services/preload.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { StringConstantPipe } from 'src/app/insurance/pipe/string-constant.pipe';
import { StringConstants } from '../../../constants/string-constants';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { UtilMethodsService } from 'src/app/insurance/services/util-method.service';
import { InsuranceSpinnerService } from 'src/app/insurance/services/insurance-spinner.service';
import { ProductConfigService } from '../../../services/product-config.service';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-insurance-get-quotes',
  templateUrl: './get-quotes.component.html',
  styleUrls: ['./get-quotes.component.scss'],
  providers: [
    StringConstantPipe, ProductConfigPipe],
})
export class InsuranceGetQuotesComponent extends BaseFormComponent implements OnInit, OnDestroy, AfterViewInit {
  // comparativeConstants: ComparativeConstants;
  // userRole: UserImpl = null;
  appConfig;
  constructor(public insuranceStaticService: InsuranceStaticService, public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public productConfig: ProductConfigService,
    public productConfigPipe: ProductConfigPipe,
    public matDialogService: MatDialog, private router: Router,
    public snackBar: MatSnackBarComponent, public stringConstantPipe: StringConstantPipe,
    public preloadService: PreloadService, public stringConstant: StringConstants,
    public insuranceSpinner: InsuranceSpinnerService,
    private gtmService: GoogleTagManagerService,
    public appConfigService: AppConfigService,
    public securityService: SecurityService, private activatedRoute: ActivatedRoute) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    // this.ComparativeConstants = ComparativeConstants;
    // this.matDialog = MatDialog;
    this.parentSectionName = 'getQuote';
    this.sectionName = 'getQuote';
    this.modelName = GetQuoteModel;
    // this.comparativeConstants = ComparativeConstants;
    this.configurationType = BaseFormComponent.CONFIG_MULTIPLE;
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }

  ngOnInit() {
    this.setSubSectionForValidation(this.parentSectionName, this.sectionName);
    this.getQuoteJson = this.insuranceStaticService.getQuotesFormJson();
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.setQuestionNameToStack(this.getQuoteJson.data[i]);
    }
    this.stateService.preloadData.state = UtilMethodsService.copyObject(this.stateService.preloadData.allStates);
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.loadInitialFields(this.getQuoteJson.data[i].fields);
    }
    this.form = this.createControlwithNewJson(this.questionJSONDatafields);

    // prepopulated fields control only disable for loggedIn user
    // tslint:disable-next-line: max-line-length
    this.disableFormControls(this.stateService.insuranceDetails['isPrepopulateUserDetails'], this.form, this.stateService.originState === 'rails'); // ,true for disable state
    if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
      const formValues = this.form.getRawValue();
      if (!UtilMethodsService.isEmpty(formValues['state'])) {
        this.form.controls['state'].disable();
      } else {
        this.form.controls['state'].enable();
      }

      const _value = this.activatedRoute.queryParams['_value'];
      if (!UtilMethodsService.isEmpty(_value)
        && Boolean(JSON.parse(_value['isWarningPopUp'])) === true) {
        if (!this.stateService.ispolicyPurchasedOnCompanyName) {
          this.form.controls['state'].enable();
        }
      }
    }
    // GTM DLV triggered when route on Insurance product visit quote page
    this.getQuoteGtmEvent('insurance-quote-visit', this.stateService.insuranceSelected[0],
      this.transService.isLoggedIn() ? (this.transService.isAgent ? 'Insurance agent' : 'client') : 'anonymous');
  }

  ngAfterViewInit() {
    this.getTotalRequiredFieldsForSection();
    this.insuranceSpinner.showFooter();
    this.highlightInvalidFields(this.form);
  }

  validatePageForNavigation() {
    const isValidated = this.checkIfPageValidForNavigation();
    console.log('isValidated >> ', isValidated);
  }

  onFocusOut(event: any, field: any) {
    super.onFocusOut(event, field);
    if (this.form.controls[field.name] && this.form.controls[field.name].value && this.transService.isFieldTypeInput(field.type)) {
      this.form.controls[field.name].setValue(this.form.controls[field.name].value.trim());
    }
    if (field.name === ComparativeConstants.staticQuestionNames.application_firstName ||
      field.name === ComparativeConstants.staticQuestionNames.application_lastName) {
      const businessName = (this.form.controls[ComparativeConstants.staticQuestionNames.application_firstName].value).concat(' ')
        .concat(this.form.controls[ComparativeConstants.staticQuestionNames.application_lastName].value);
      // tslint:disable-next-line: max-line-length
      if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName])
        && !UtilMethodsService.isEmpty(businessName)
        && this.stateService.insuranceDetails
          .questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName].toUpperCase()
        !== businessName.toUpperCase()
        &&
        this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.setApplicantName] === true
      ) {
        this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.setApplicantName] = false;
        this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName] = null;
      } else {
        return;
      }
    }
  }

  onSelectChange(event, field) {
  }

  onSelectWithSearchChange(event, field) {
    super.onSelectWithSearchChange(event, field);
    if (field.name === ComparativeConstants.staticQuestionNames.application_state) {
      // if user select state everytime reset the address field
      // use case handled when user came back on get-quote from anywhere and...
      // change state, address will reset so state n city will be synch as user need to refill it
      this.stateService.insuranceDetails.questionAnswers['city'] = null;
      this.stateService.insuranceDetails.questionAnswers['street1'] = null;
      this.stateService.insuranceDetails.questionAnswers['street2'] = null;
      this.stateService.insuranceDetails.questionAnswers['zipCode'] = null;
      const selectedState = this.form.controls[field.name].value;
      // tslint:disable-next-line:no-unused-expression
      if (selectedState) {
        const selectedStateObj = this.stateService.preloadData.allStates.find(x => x.name === selectedState);
        if (this.stateService.preloadData.sanctionStates.includes(selectedState)) {
          // tslint:disable-next-line:max-line-length
          this.showBanner(this.snackBar, this.stringConstant.SANCTIONSTATE_SEL_MESSAGE.concat(selectedStateObj.label), BaseFormComponent.ERROR_BAR);
          this.form.controls[field.name].reset();
          delete this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state];
        }
      }
      if (field.name === ComparativeConstants.staticQuestionNames.application_state) {
        if (this.productConfigPipe.transform(this.productConfig.refreshKOQuestion)) {
          this.stateService.insuranceDetails.questionAnswers.dynamicQuestions = {};
          this.removeKOQuestion(this.stateService.screenMapObject);

        }
      }
    }

    if (field.name === ComparativeConstants.staticQuestionNames.application_profession) {
      if (this.productConfigPipe.transform(this.productConfig.refreshKOQuestion)
        && this.stateService.insuranceSelected[0] !== ComparativeConstants.EPLI_PRODUCT_CODE) {
        this.stateService.insuranceDetails.questionAnswers.dynamicQuestions = {};
        this.removeKOQuestion(this.stateService.screenMapObject);
      }
    }
  }

  onDateChange(event, fields) {
  }

  navigateBackwardFn(event) {
    if (sessionStorage.getItem('originState') && this.stateService.originState === 'rails') {
      this.navigateToRails();
    } else {
      this.router.navigate(['/dashboard']);
    }
  }

  navigateToRails() {
    this.securityService.getAccessToken().then(response => {
      let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
      if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
        railsUrl = this.appConfig.colonial_erisa_TPA_url;
      }
      if (this.stateService && this.stateService.insuranceDetails
        && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.applicationId)) {
        // tslint:disable-next-line: max-line-length
        const paramRails = `?sutoken=${response}&applicationId=${this.stateService.insuranceDetails.applicationId}&applicationStatus=In Progress`;
        console.log(this.securityService.requestURL(paramRails));
        sessionStorage.removeItem('originState');
        window.open(`${railsUrl}${paramRails}`, '_self');
      } else {
        console.log(this.securityService.requestURL(`?sutoken=${response}`));
        sessionStorage.removeItem('originState');
        window.open(`${railsUrl}?sutoken=${response}`, '_self');
      }
    });
  }

  navigateForwardFn(event) {
    if (!this.stateService.isApplicationReadyToAction) {
      return;
    }
    this.insuranceSpinner.show();
    if (this.stateService.SECTIONS[this.parentSectionName]['istouched'] === true &&
      // tslint:disable-next-line:triple-equals
      this.stateService.SECTIONS[this.parentSectionName]['errors'] == 0) {
      this.stateService.editedQuesDetails = {};
      if (!this.transService.isUserLogIn()) {
        // if anonymous user , allow user to jump on insuranceDetails page
        // call Save Anonymous Quote API
        const _payloadData = this.transService.saveQuoteEncryptPayload();
        if (_payloadData) {
          this.saveAnonymousQuote(_payloadData);
        }
      } else {
        const _payloadData = this.transService.encryptPayload();
        if (_payloadData && !this.stateService.insuranceDetails['applicationId']
          && this.transService.isUserLogIn()) {
          // if loggedIn user then call create application API
          // we can remove below if/else block once application api get ready for cyber
          this.generateApplicationID(_payloadData, this.parentSectionName);
        } else if (this.stateService.insuranceDetails['applicationId']
          && this.transService.isUserLogIn()) {
          this.router.navigate(['/insurance/insuranceDetails']);
        }
      }
    } else {
      this.insuranceSpinner.hide();
      this.highlightInvalidFields(this.form);
      this.showPageError(this.snackBar, true);
    }
  }

  navigateHome() {
    this.transService.checkLoginAndRedirect(this.parentSectionName);
  }

  generateApplicationID(_payloadData, _pageReference) {
    this.subscriptions.push(this.insuranceStaticService.createApplication(_payloadData, _pageReference).subscribe(
      (data) => {
        this.stateService.insuranceDetails['applicationId'] = data.id;
        this.insuranceSpinner.show();
        this.router.navigate(['/insurance/insuranceDetails']);
      },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    ));
  }

  saveAnonymousQuote(_payloadData) {
    this.insuranceStaticService.saveAnonymousQuote(_payloadData).subscribe((data) => {
      if (!UtilMethodsService.isEmpty(data)) {
        this.stateService.quoteId = data.id;
        this.router.navigate(['/insurance/insuranceDetails']);
      }
    },
      (error) => {
        const errMsg = this.snackBarErrorMsg(error);
        this.insuranceSpinner.hide();
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }
    );
  }

  ngOnDestroy() {
    this.insuranceSpinner.hide();
    this.unsubscribe();
  }

  getQuoteGtmEvent(event, insuranceType, userType) {
    this.gtmService.sendInsuranceEvent(
      `${event}`,
      `${insuranceType}`,
      `${userType}`
    );
  }

}
