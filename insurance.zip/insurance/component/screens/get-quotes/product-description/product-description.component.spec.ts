import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ProductDescriptionComponent } from './product-description.component';
import { StringConstantPipe } from '../../../../pipe/string-constant.pipe';

@Component({
  selector: 'app-test-insurance-product-description',
  template: '<app-product-description></app-product-description>',
})

class TestInsuranceProductDescriptionComponent {
}

describe('Insurance Product Description Component', () => {
  let component: ProductDescriptionComponent;
  let fixture: ComponentFixture<TestInsuranceProductDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [],
      declarations: [
        TestInsuranceProductDescriptionComponent,
        ProductDescriptionComponent,
        StringConstantPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceProductDescriptionComponent);
    component = fixture.debugElement.children[0].componentInstance as ProductDescriptionComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
