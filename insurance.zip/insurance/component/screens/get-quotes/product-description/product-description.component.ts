import { Component, OnInit } from '@angular/core';
import { StringConstants } from '../../../../constants/string-constants';
import { ViewEncapsulation } from '@angular/compiler/src/core';
import { StateService } from '../../../../services/state.service';

@Component({
  selector: 'app-product-description',
  templateUrl: './product-description.component.html',
  styleUrls: ['./product-description.component.scss'],
})
export class ProductDescriptionComponent implements OnInit {

  constructor(public stringConstant: StringConstants, public stateService: StateService) { }

  ngOnInit() {
  }

}
