// /* tslint:disable:no-unused-variable */
import { TestBed, async, fakeAsync, getTestBed, ComponentFixture, inject } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { InsuranceHeadingPanelComponent } from '../../common/insurance-heading-panel/insurance-heading-panel.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { ProductDescriptionComponent } from './product-description/product-description.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { InsuranceGetQuotesComponent } from './get-quotes.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { ProgressSpinnerDialogComponent } from '../../common/modal/modal.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppConfigService } from 'src/app/app-config-service';
import { Router } from '@angular/router';
import { StateService } from 'src/app/insurance/services/state.service';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { of, Observable, throwError } from 'rxjs';
import { TransactionalService } from 'src/app/insurance/services/transactional.service';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';

@Component({
  selector: 'app-test-insurance-get-quotes',
  template: '<app-insurance-get-quotes></app-insurance-get-quotes>',
})

class TestInsuranceGetQuotesComponent {
}

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {

}

declare global {
  interface Window {
    dataLayer: any;
  }
}

describe('Insurance Get Quotes Component', () => {
  let component: InsuranceGetQuotesComponent;
  let fixture: ComponentFixture<TestInsuranceGetQuotesComponent>;
  let router: Router;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  let dataLayer: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'dashboard', component: MockRouteBlankComponent },
          { path: 'insurance/insuranceDetails', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [
        MatSnackBarComponent,
        ServiceHandler,
        GoogleTagManagerService,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestInsuranceGetQuotesComponent,
        MockRouteBlankComponent,
        InsuranceHeadingPanelComponent,
        InsuranceGetQuotesComponent,
        ProductDescriptionComponent,
        StringConstantPipe,
        ProgressSpinnerDialogComponent,
      ],
    })
      .overrideModule(BrowserAnimationsModule, { set: { entryComponents: [ProgressSpinnerDialogComponent] } }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceGetQuotesComponent);
    router = TestBed.get(Router);
    component = fixture.debugElement.children[0].componentInstance as InsuranceGetQuotesComponent;
    window.dataLayer = dataLayer = [];
    spyOn(component, 'checkIfPageValidForNavigation').and.returnValue(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check if page is valid for navigation', () => {
    component.validatePageForNavigation();
    expect(component.checkIfPageValidForNavigation).toHaveBeenCalled();
  });

  it('should navigate back to dashbord', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateBackwardFn('');
    expect(navigateSpy).toHaveBeenCalledWith(['/dashboard']);
  });

  it('should navigate forward to insuranceDetails screen and generate Application ID', inject([StateService, InsuranceStaticService,
    TransactionalService],
    (stateService: StateService, insuranceService: InsuranceStaticService, transService: TransactionalService) => {
      const navigateSpy = spyOn(router, 'navigate');
      stateService.SECTIONS['getQuote']['istouched'] = true;
      stateService.SECTIONS['getQuote']['errors'] = 0;
      const isUserLogIn = spyOn(transService, 'isUserLogIn').and.returnValue(true);
      const applicatioID = {
        'id': 1456,
      };

      const createApplication = spyOn(insuranceService, 'createApplication').and.callFake(() => {
        return of(applicatioID);
      });

      component.navigateForwardFn('');
      expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceDetails']);
      expect(isUserLogIn).toHaveBeenCalled();
      expect(createApplication).toHaveBeenCalled();
    }));

  it('should return error', inject([StateService, InsuranceStaticService, TransactionalService], (stateService: StateService,
    insuranceService: InsuranceStaticService, transService: TransactionalService) => {
    stateService.SECTIONS['getQuote']['istouched'] = true;
    stateService.SECTIONS['getQuote']['errors'] = 0;
    const isUserLogIn = spyOn(transService, 'isUserLogIn').and.returnValue(true);
    const createApplication = spyOn(insuranceService, 'createApplication').and.returnValue(throwError({ status: 404 }));
    component.navigateForwardFn('');
    expect(isUserLogIn).toHaveBeenCalled();
    expect(createApplication).toHaveBeenCalled();
  }));

  it('should navigate forward show error pop up', inject([StateService, InsuranceStaticService], (stateService: StateService,
    insuranceService: InsuranceStaticService) => {
    const navigateSpy = spyOn(router, 'navigate');
    stateService.SECTIONS['getQuote']['istouched'] = false;
    stateService.SECTIONS['getQuote']['errors'] = 2;
    const showPageError = spyOn(component, 'showPageError').and.returnValue('');
    expect(component.navigateForwardFn('')).toBeUndefined();
    expect(showPageError).toHaveBeenCalled();
  }));

  it('should navigate to home', inject([StateService, TransactionalService], (stateService: StateService,
    transactionalService: TransactionalService) => {
    const checkLoginAndRedirect = spyOn(transactionalService, 'checkLoginAndRedirect').and.returnValue('');
    component.navigateHome();
    expect(checkLoginAndRedirect).toHaveBeenCalled();
  }));

  it('should call onSelectWithSearchChange', () => {
    const field = {
      'question_reference_id': 1,
      'sequence_number': 1,
      'label': 'State',
      'name': 'state',
      'type': 'selectwithsearch',
      'value': '',
      'event': 'true',
      'optionReference': 'state',
      'visible_by_default': 1,
      'tooltip': 'State deatils',
      'validations': [
        {
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
      ],
      'options': [],
    };

    expect(component.onSelectWithSearchChange('AL', field)).toBeUndefined();
  });

  it('should call onSelectChange', () => {
    expect(component.onSelectChange('', '')).toBeUndefined();
  });

  it('should call onSelectChange', () => {
    expect(component.onDateChange('', '')).toBeUndefined();
  });

  it('should focus out trim the value', () => {
    const field = {
      'question_reference_id': 1,
      'sequence_number': 1,
      'label': 'First Name',
      'name': 'firstName',
      'type': 'textbasic',
      'value': '',
      'visible_by_default': 1,
      'placeholder': 'Your First Name',
      'validations': [{
        'name': 'required',
        'value': '',
        'message': 'This field is required',
      },
      {
        'name': 'pattern',
        // tslint:disable-next-line:quotemark
        'value': "^[a-zA-Z0-9 '-]*$",
        'message': 'Please enter valid values',
      },
      {
        'name': 'maxlength',
        'value': 100,
        'message': '',
      }],
    };

    component.form.controls['firstName'].setValue('abc    ');
    expect(component.onFocusOut(field, field)).toBeUndefined();
    expect(component.form.controls['firstName'].value).toEqual('abc');
  });

});
