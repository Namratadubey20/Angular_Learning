import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SecurityService } from 'src/app/security/security.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { ApplicationPopulateService } from 'src/app/ibond/service/application-populate.service';
import { AppConfigService } from '../../../../app-config-service';
import { RouterTestingModule } from '@angular/router/testing';
import { BaseFormComponent } from '../../base-form.component';
import { EmailPopupComponent } from './email-popup.component';
import { MatSnackBarComponent } from '../banner/banner.component';

@Component({
  selector: 'app-test-email-popup',
  template: '<app-email-popup></app-email-popup>',
})

class TestEmailPopupComponent { }

describe('Email Popup Component', () => {
  let component: EmailPopupComponent;
  let fixture: ComponentFixture<TestEmailPopupComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  const dialogMock = {
    close: () => { },
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule,
        RouterTestingModule,
        ReactiveFormsModule,
        FormInsuranceComponentModule,
        HttpClientTestingModule,
        CommonModule,
        FlexLayoutModule,
        BrowserModule,
        MaterialModule,
      ],
      providers: [SecurityService,
        MatSnackBarComponent,
        ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        MatDialog,
        {
          provide: MatDialogRef,
          useValue: dialogMock,
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {},
        },
      ],
      declarations: [TestEmailPopupComponent, EmailPopupComponent],
    })
      .overrideModule(BrowserModule, { set: { entryComponents: [EmailPopupComponent] } })
      .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestEmailPopupComponent);
    component = fixture.debugElement.children[0].componentInstance as EmailPopupComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call the function to close the dialog', () => {
    component.close();
    spyOn(component.dialogRef, 'close');
    expect(true).toBeTruthy();
  });

  it('should call the function to send the mail and close the dialog', () => {
    component.sendMailToClient();
    spyOn(component.dialogRef, 'close');
    expect(true).toBeTruthy();
  });
});
