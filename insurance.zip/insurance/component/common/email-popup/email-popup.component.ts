import { Component, OnInit, Inject } from '@angular/core';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { GetEmailFieldJsonService } from '../../../jsons/get-emaildetails-common.service';
import { FormBuilder } from '@angular/forms';
import { TransactionalService } from '../../../services/transactional.service';
import { StateService } from '../../../services/state.service';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { MatDialog } from '@angular/material';
import { BaseFormComponent } from '../../base-form.component';
import { UtilMethodsService } from 'src/app/insurance/services/util-method.service';
import { MatSnackBarComponent } from '../banner/banner.component';
import { StringConstants } from 'src/app/insurance/constants/string-constants';
import { Router } from '@angular/router';

@Component({
  selector: 'app-email-popup',
  templateUrl: './email-popup.component.html',
  styleUrls: ['./email-popup.component.scss'],
})
export class EmailPopupComponent extends BaseFormComponent implements OnInit {
  public emailBody;
  constructor(public insuranceStaticService: InsuranceStaticService, public dialogRef: MatDialogRef<EmailPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public emailData: any, public _getEmailDetailService: GetEmailFieldJsonService, public fb: FormBuilder,
    public stateService: StateService, public matDialogService: MatDialog, public transService: TransactionalService,
    public insuranceSpinner: InsuranceSpinnerService, public snackBar: MatSnackBarComponent, public stringConstant: StringConstants,
    private router: Router
  ) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
  }

  ngOnInit() {
    this.getQuoteJson = this.insuranceStaticService.getEmailtDetailsFormJson();
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.setQuestionNameToStack(this.getQuoteJson.data[i]);
    }
    for (let i = 0; i < this.getQuoteJson.data.length; i++) {
      this.loadInitialFields(this.getQuoteJson.data[i].fields);
    }
    this.form = this.createControlwithNewJson(this.questionJSONDatafields);
    this.applyFormValuesFn(this.form, this.emailData);
  }
  public applyFormValuesFn(group, formValues) {
    Object.keys(formValues).forEach(key => {
      if (typeof formValues[key] !== 'object') {
        this.applyControlValues(group, formValues, key);
      } else {
        if (!UtilMethodsService.isEmpty(formValues[key]) && Object.keys(formValues[key]).length > 0) {
          Object.keys(formValues[key]).forEach(nestedkey => {
            this.applyControlValues(group, formValues[key], nestedkey);
          });
        }
      }
    });
    this.emailBody = this.emailData.body;
  }

  sendMailToClient() {
    const applicationId = this.stateService.insuranceDetails['applicationId'];
    this.insuranceStaticService.sendMailToclient(applicationId).subscribe(res => {
      this.showBanner(this.snackBar, this.stringConstant.EMAIL_SUCCESS, BaseFormComponent.SUCCESS_BAR);
      this.dialogRef.close(true);
      // this.router.navigate(['/dashboard']);
    }, (error) => {
      const errMsg = this.snackBarErrorMsg(error);
      this.insuranceSpinner.hide();
      this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
    });
  }
  close() {
    this.stateService.isApplicationReadyToAction = true;
    this.dialogRef.close(false);
  }
}
