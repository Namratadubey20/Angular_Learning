import { OnInit, Component, OnDestroy, Inject } from '@angular/core';
import { BaseFormComponent } from '../../base-form.component';
import { Router } from '@angular/router';
import { StateService } from '../../../services/state.service';
import { FormBuilder } from '@angular/forms';
import { TransactionalService } from '../../../services/transactional.service';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { UtilMethodsService } from '../../../services/util-method.service';
import { PreloadService } from '../../../services/preload.service';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { InsuranceStaticService } from '../../../services/insurance-static-service';
import { MatSnackBarComponent } from '../banner/banner.component';
import { StringConstants } from '../../../constants/string-constants';
import { SecurityService } from '../../../../security/security.service';
import { AppConfigService } from 'src/app/app-config-service';

@Component({
  selector: 'app-evaluator',
  templateUrl: './evaluator.component.html',
  styleUrls: ['./evaluator.component.scss'],
})
export class EvaluatorComponent extends BaseFormComponent implements OnInit, OnDestroy {

  appConfig;
  getDecryptSubStatus = null;
  constructor(public transService: TransactionalService, public fb: FormBuilder, public matDialogService: MatDialog,
    public stateService: StateService, private router: Router, private activatedRoute: ActivatedRoute,
    public preloadService: PreloadService, public insuranceSpinner: InsuranceSpinnerService,
    public insuranceStaticService: InsuranceStaticService, public snackBar: MatSnackBarComponent, protected _snackBar: MatSnackBar,
    public stringConstant: StringConstants, public securityService: SecurityService, public appConfigService: AppConfigService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
    this.stateService.getDecryptStatus.next({});
    this.stateService.quoteId = null;
    this.stateService.clientID = null;
    this.stateService.agentId = null;
    this.stateService.clientType = null;
    this.stateService.clientDetailsPayload = null;
    this.stateService.isCheckboxDisabled = null;
    this.stateService.isLoadComponent.next(false);
    this.stateService.isCompanyExist = false;
    this.stateService.directClientCompanyId = null;
    this.stateService.exitingAddress = {};
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }

  ngOnInit() {
    const me = this;
    window.document.body.classList.remove('main-body-background');
    window.document.body.classList.add('main-insurance-body-background');
    me.insuranceSpinner.show();
    me.insuranceSpinner.hideFooter();
    me.stateService.SECTIONS = UtilMethodsService.copyObject(ComparativeConstants.SECTIONS_INTERFACE);
    me.stateService.fieldError = UtilMethodsService.copyObject(ComparativeConstants.fieldError);
    me.stateService.screenMapObject = UtilMethodsService.copyObject(ComparativeConstants.screenMapObject);
    me.stateService.isDeclined = false;
    me.stateService.companyInfo = UtilMethodsService.copyObject(ComparativeConstants.companyInfo);
    me.stateService.insuranceDetails = UtilMethodsService.copyObject(ComparativeConstants.DET_INTERFACE_FOR_Q);
    if (!UtilMethodsService.isEmpty(me.activatedRoute.queryParams['_value']['applicationId'])) {
      // should set applicationId for save later if user click one more time
      me.stateService.insuranceDetails.applicationId = me.activatedRoute.queryParams['_value']['applicationId'];
      me.stateService.insuranceDetails['isPrepopulateUserDetails'] = true;
      me.getDecryptSubStatus = me.stateService.getDecryptStatus.subscribe((data) => {
        if (!UtilMethodsService.isEmpty(data)) {
          me.stateService.insuranceSelected = me.getSelectedInsuranceProductCode(data['bondClassification']);
          // me.stateService.agentId = data['agent'].id ? data['agent'].id : null;
          if (UtilMethodsService.isEmpty(me.stateService.insuranceSelected)) {
            if (me.transService.isUserLogIn()) {
              if (sessionStorage.getItem('originState') && sessionStorage.getItem('originState') === 'rails') {
                this.navigateToRails();
              } else {
                me.router.navigate(['/dashboard']);
              }
            } else {
              window.location.href = 'https://www.colonialsurety.com/';
            }
          } else {
            me.getPreloadData(data['pageReference']);
          }
        }
      });
      me.getAppData(me.activatedRoute.queryParams['_value']['applicationId']);
    } else {
      me.stateService.insuranceSelected = me.getSelectedInsuranceProductCode();
      me.stateService.editedQuesDetails = {};
      me.stateService.insuranceDetails = UtilMethodsService.copyObject(ComparativeConstants.DET_INTERFACE_FOR_Q);

      if (!UtilMethodsService.isEmpty(me.activatedRoute.queryParams['_value'])
        && !UtilMethodsService.isEmpty(me.activatedRoute.queryParams['_value']['isAnonymousUser'])) {
        // User will land on get quote page from sign up page, hence selected product get reset , need to add to state service
        if (Boolean(JSON.parse(me.activatedRoute.queryParams['_value']['isAnonymousUser'])) === true
          && !UtilMethodsService.isEmpty(me.activatedRoute.queryParams['_value']['bondClassification'])) {
          me.stateService.insuranceSelected = [];
          me.stateService.insuranceSelected.push(me.activatedRoute.queryParams['_value']['bondClassification']);
        }
      }

      if (UtilMethodsService.isEmpty(me.stateService.insuranceSelected)) {
        if (me.transService.isUserLogIn()) {
          if (sessionStorage.getItem('applicationId')) {
            const appId = sessionStorage.getItem('applicationId');
            sessionStorage.removeItem('applicationId');
            me.stateService.insuranceDetails.applicationId = appId;
            me.stateService.insuranceDetails['isPrepopulateUserDetails'] = true;
            this.getDecryptSubStatus = me.stateService.getDecryptStatus.subscribe((data) => {
              if (!UtilMethodsService.isEmpty(data)) {
                me.stateService.insuranceSelected = me.getSelectedInsuranceProductCode(data['bondClassification']);
                if (UtilMethodsService.isEmpty(me.stateService.insuranceSelected)) {
                  if (me.transService.isUserLogIn()) {
                    if (sessionStorage.getItem('originState') && sessionStorage.getItem('originState') === 'rails') {
                      this.navigateToRails();
                    } else {
                      me.router.navigate(['/dashboard']);
                    }
                  } else {
                    window.location.href = 'https://www.colonialsurety.com/';
                  }
                } else {
                  me.getPreloadData(data['pageReference']);
                }
              }
            });
            me.getAppData(appId);
          } else {

            me.router.navigate(['/dashboard']);

          }
        } else {
          window.location.href = 'https://www.colonialsurety.com/';
        }
      } else {
        me.getPreloadData();
      }
    }
  }

  getPreloadData(__pageReference?) {
    const me = this;
    if (!UtilMethodsService.isEmpty(this.getDecryptSubStatus)) {
      this.getDecryptSubStatus.unsubscribe();
    }
    if (!UtilMethodsService.isEmpty(me.stateService.insuranceSelected) && Array.isArray(me.stateService.insuranceSelected)) {
      me.preloadService.startPreloading((preloadDone: Function) => {
        me.stateService.insuranceDetails.questionAnswers['bondClassification'] = me.stateService.insuranceSelected[0];
        me.stateService.isPreload = true;
        if (!UtilMethodsService.isEmpty(__pageReference)) {
          switch (__pageReference) {
            case ComparativeConstants.GET_QUOTE:
              if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
                me.router.navigate([`/insurance/getquotes`]);
                // tslint:disable-next-line: max-line-length
                if (UtilMethodsService.isEmpty(me.stateService.clientID) && me.transService.isClientAssociatedWithAgent()) {
                  // when client associated with agent direclty try to purchase policy;
                  // allow defult user to prefill with personal profile
                  const personalProfile = me.transService.getPersonalProfileTypeAndProfileId();
                  this.stateService.clientID = personalProfile[0];
                  me.transService.prePopulateUserDetails(me.insuranceSpinner, personalProfile[0], personalProfile[1], true);
                } else {
                  // tslint:disable-next-line: max-line-length
                  this.transService.prePopulateUserDetails(this.insuranceSpinner, this.stateService.clientID, this.stateService.clientType, true);
                }
              } else {
                // me.router.navigate([`/insurance/getquotes`]);
                // need to prePopulateUserDetails of direct client
                me.transService.prePopulateUserDetails(me.insuranceSpinner, me.stateService.clientID, me.stateService.clientType, true);
              }

              break;
            case ComparativeConstants.PRODUCT_INFORMATION:
              me.setcompletionStatus('getQuote');
              if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {

                if (UtilMethodsService.isEmpty(me.stateService.clientID) && me.transService.isClientAssociatedWithAgent()) {
                  // when client associated with agent direclty try to purchase policy;
                  // allow defult user to prefill with personal profile
                  const personalProfile = me.transService.getPersonalProfileTypeAndProfileId();
                  this.stateService.clientID = personalProfile[0];
                  me.transService.prePopulateUserDetails(me.insuranceSpinner, personalProfile[0], personalProfile[1], true);
                } else {
                  // component load with stale data so kept component load n prepopulate operation in sync
                  this.subscriptions.push(me.stateService.isLoadComponent.subscribe((_isLoadComponent) => {
                    if (!UtilMethodsService.isEmpty(_isLoadComponent) && _isLoadComponent === true) {
                      me.router.navigate([`/insurance/insuranceDetails`]);
                    }
                  }));
                  // tslint:disable-next-line: max-line-length
                  this.transService.prePopulateUserDetails(this.insuranceSpinner, this.stateService.clientID, this.stateService.clientType, false);
                }
              } else {
                // direct client prepopulate details and navigate
                me.transService.prePopulateUserDetails(me.insuranceSpinner, me.stateService.clientID, me.stateService.clientType, false);
                me.router.navigate([`/insurance/insuranceDetails`]);
              }
              // me.router.navigate([`/insurance/insuranceDetails`]);
              break;
            case ComparativeConstants.YOUR_QUOTE:
              me.setcompletionStatus('getQuote,productInformation');
              if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
                if (UtilMethodsService.isEmpty(me.stateService.clientID) && me.transService.isClientAssociatedWithAgent()) {
                  // when client associated with agent direclty try to purchase policy;
                  // allow defult user to prefill with personal profile
                  const personalProfile = me.transService.getPersonalProfileTypeAndProfileId();
                  this.stateService.clientID = personalProfile[0];
                  me.transService.prePopulateUserDetails(me.insuranceSpinner, personalProfile[0], personalProfile[1], true);
                } else {
                  // component load with stale data so kept component load n prepopulate operation in sync
                  this.subscriptions.push(me.stateService.isLoadComponent.subscribe((_isLoadComponent) => {
                    if (!UtilMethodsService.isEmpty(_isLoadComponent) && _isLoadComponent === true) {
                      me.router.navigate([`/insurance/yourquotes`]);
                    }
                  }));
                  // tslint:disable-next-line: max-line-length
                  this.transService.prePopulateUserDetails(this.insuranceSpinner, this.stateService.clientID, this.stateService.clientType, false);
                }
              } else {
                me.router.navigate([`/insurance/yourquotes`]);
              }
              break;
            case ComparativeConstants.AGREEMENT:
              me.setcompletionStatus('getQuote,productInformation,yourQuote');
              if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
                if (UtilMethodsService.isEmpty(me.stateService.clientID) && me.transService.isClientAssociatedWithAgent()) {
                  // when client associated with agent direclty try to purchase policy;
                  // allow defult user to prefill with personal profile
                  const personalProfile = me.transService.getPersonalProfileTypeAndProfileId();
                  this.stateService.clientID = personalProfile[0];
                  me.transService.prePopulateUserDetails(me.insuranceSpinner, personalProfile[0], personalProfile[1], true);
                } else {
                  // component load with stale data so kept component load n prepopulate operation in sync
                  this.subscriptions.push(me.stateService.isLoadComponent.subscribe((_isLoadComponent) => {
                    if (!UtilMethodsService.isEmpty(_isLoadComponent) && _isLoadComponent === true) {
                      me.router.navigate([`/insurance/agreement`]);
                    }
                  }));
                  // tslint:disable-next-line: max-line-length
                  this.transService.prePopulateUserDetails(this.insuranceSpinner, this.stateService.clientID, this.stateService.clientType, false);
                }

              } else {
                me.router.navigate([`/insurance/agreement`]);
              }
              break;
            case ComparativeConstants.PAYMENT:
              // Always last pageReference will be payment page so need to check application status
              // if status completed or submit then move to confirmation page after all required data set to state service
              me.setcompletionStatus('getQuote,productInformation,yourQuote,agreement');
              if (me.stateService.applicationStatus === 'Completed') {
                me.router.navigate(['/insurance/insuranceConfirmation']);
              } else {
                if (this.transService.isAgent() || this.transService.isClientAssociatedWithAgent()) {
                  if (UtilMethodsService.isEmpty(me.stateService.clientID) && me.transService.isClientAssociatedWithAgent()) {
                    // when client associated with agent direclty try to purchase policy;
                    // allow defult user to prefill with personal profile
                    const personalProfile = me.transService.getPersonalProfileTypeAndProfileId();
                    this.stateService.clientID = personalProfile[0];
                    me.transService.prePopulateUserDetails(me.insuranceSpinner, personalProfile[0], personalProfile[1], true);
                  } else {
                    // component load with stale data so kept component load n prepopulate operation in sync
                    this.subscriptions.push(me.stateService.isLoadComponent.subscribe((_isLoadComponent) => {
                      if (!UtilMethodsService.isEmpty(_isLoadComponent) && _isLoadComponent === true) {
                        me.router.navigate([`/insurance/insurancePayment`]);
                      }
                    }));
                    // tslint:disable-next-line: max-line-length
                    this.transService.prePopulateUserDetails(this.insuranceSpinner, this.stateService.clientID, this.stateService.clientType, false);
                  }
                } else {
                  me.router.navigate([`/insurance/insurancePayment`]);
                }
              }
              break;
            default:
              console.log('deafult case no page reference ');
          }
        } else {
          me.navigateToGetQuotesFn();
        }
        console.log('Preloading Completed >>..... ');
      });
    }
  }

  getAppData(_applicationId) {
    this.insuranceSpinner.show();
    this.subscriptions.push(this.insuranceStaticService.getApplicationData(_applicationId).subscribe(data => {
      if (data) {
        if (this.transService.isClientAssociatedWithAgent() || this.transService.isAgent()) {
          if (!UtilMethodsService.isEmpty(data.person)) {
            this.stateService.clientID = data.person.id;
            this.stateService.clientType = 'P';
          } else if (!UtilMethodsService.isEmpty(data.companyOffice)) {
            this.stateService.clientID = data.companyOffice.id;
            this.stateService.clientType = 'C';
          }
        }
        // UNAUTHORIZED_ACCESS check
        if (!this.transService.isAgent() && data.person &&
          data.person.id !== (!UtilMethodsService.isEmpty(this.securityService.user['person'])
            && this.securityService.user['person']['id'])) {
          if (sessionStorage.getItem('originState') && sessionStorage.getItem('originState') === 'rails') {
            this.navigateToRails();
          } else {
            this.router.navigate(['/dashboard']);
          }
          this.showBanner(this.snackBar, this.stringConstant.UNAUTHORIZED_ACCESS, BaseFormComponent.ERROR_BAR);
          return;
        }
        // Insurance with type In Progress are only for edit check
        if (data.status === this.stringConstant.STATUS_DECLINED) {
          this.stateService.isDeclined = true;
          this.router.navigate(['/insurance/insuranceConfirmation']);
        } else {
          this.stateService.applicationStatus = data.status;
          if (!UtilMethodsService.isEmpty(data.agent)) {
            this.stateService.agentId = data.agent.id;
          }
          this.transService.decryptPayload(data.data, data.premium);
          // FRN-401 Updated company address was not showing on UI
          if (!UtilMethodsService.isEmpty(data.companyOffice) && !UtilMethodsService.isEmpty(data.companyOffice.address)) {
            this.updateApplicantAddressToCompnayAddress(data);
          }
        }
      }
    },
      (error) => {
        const errMsg = !UtilMethodsService.isEmpty(error.error) && error.error.responseDesc || `Application ID doesn't exist`;
        this.showBanner(this.snackBar, errMsg, BaseFormComponent.ERROR_BAR);
      }));
  }

  updateApplicantAddressToCompnayAddress(_data) {
    const _address = _data.companyOffice.address;
    Object.keys(_address).forEach(_keys => {
      this.stateService.insuranceDetails.questionAnswers[_keys] = _address[_keys];
    });
  }
  navigateToGetQuotesFn() {
    const me = this;
    if (me.transService.isUserLogIn()) {
      if (UtilMethodsService.isEmpty(me.stateService.clientID) && me.transService.isClientAssociatedWithAgent()) {
        // when client associated with agent direclty try to purchase policy;
        // allow defult user to prefill with personal profile
        const personalProfile = me.transService.getPersonalProfileTypeAndProfileId();
        // if agent come from rails and try to purchase policy
        // profile type set to 'C'
        this.stateService.clientID = sessionStorage.getItem('originState') === 'rails' ?
          me.transService.getRailsClientAssocaiateWithAgentId() : personalProfile[0];
        this.stateService.clientType = sessionStorage.getItem('originState') === 'rails' ? 'C' : personalProfile[1];
        me.transService.prePopulateUserDetails(me.insuranceSpinner, this.stateService.clientID, this.stateService.clientType, true);
      } else {
        me.transService.prePopulateUserDetails(me.insuranceSpinner, me.stateService.clientID, me.stateService.clientType, true);
      }
    } else {
      me.router.navigate(['/insurance/getquotes']);
    }
  }

  getSelectedInsuranceProductCode(_productCode?) {
    let productCode = [];
    if (!UtilMethodsService.isEmpty(_productCode)) {
      productCode.push(_productCode);
      localStorage.setItem('productCode', JSON.stringify(productCode) || null);
    } else {
      this.activatedRoute.queryParams.subscribe(_state => {
        if (!UtilMethodsService.isEmpty(_state['product_code'])) {
          if (Array.isArray(_state['product_code'])) {
            productCode = _state['product_code'];
            localStorage.setItem('productCode', JSON.stringify(_state['product_code']) || null);
            this.stateService.clientID = null;
            this.stateService.clientType = null;
            if (!UtilMethodsService.isEmpty(_state.client_id)) {
              this.stateService.clientID = _state.client_id;
              this.stateService.clientType = _state.client_type;
            }
          } else {
            productCode = Array.from([_state['product_code']]);
            localStorage.setItem('productCode', JSON.stringify(_state['product_code']) || null);
          }
        }
      });
    }
    return !UtilMethodsService.isEmpty(productCode) && productCode || null;
  }

  setcompletionStatus(_section) {
    for (const sectionName of _section.split(',')) {
      this.stateService.SECTIONS[sectionName] = UtilMethodsService.copyObject(this.comparativeConstants.SECTION_COMPLETE_STATUS);
    }
  }

  navigateToRails() {
    this.securityService.getAccessToken().then(response => {
      sessionStorage.removeItem('originState');
      let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
      if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
        railsUrl = this.appConfig.colonial_erisa_TPA_url;
      }
      if (this.stateService && this.stateService.insuranceDetails) {
        // tslint:disable-next-line: max-line-length
        const paramRails = `?sutoken=${response}&applicationId=${this.stateService.insuranceDetails.applicationId}&applicationStatus=${this.stateService.applicationStatus}`;
        console.log(this.securityService.requestURL(paramRails));
        window.open(`${railsUrl}${paramRails}`, '_self');
      } else {
        console.log(this.securityService.requestURL(`?sutoken=${response}`));
        window.open(`${railsUrl}?sutoken=${response}`, '_self');
      }
    });
  }

  ngOnDestroy() {
    this.insuranceSpinner.hide();
    this.unsubscribe();
  }

}
