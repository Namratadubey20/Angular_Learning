import { Component } from '@angular/core';
import { EvaluatorComponent } from './evaluator.component';
import { ComponentFixture, async, TestBed, tick, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
import { CommonModule } from '@angular/common';
import { FormInsuranceComponentModule } from 'src/app/form-insurance-components/form-insurance-components.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ProgressSpinnerDialogComponent } from '../modal/modal.component';
import { InsuranceHeadingPanelComponent } from '../insurance-heading-panel/insurance-heading-panel.component';
import { ProductDescriptionComponent } from '../../screens/get-quotes/product-description/product-description.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { Router, ActivatedRoute } from '@angular/router';
import { of, throwError } from 'rxjs';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from '../../../../app-config-service';
import { PreloadService } from '../../../services/preload.service';
import { StateService } from '../../../services/state.service';
import { TransactionalService } from '../../../services/transactional.service';
import { InsuranceStaticService } from 'src/app/insurance/services/insurance-static-service';
import { MatSnackBarComponent } from '../../common/banner/banner.component';
import { MockTransactionalService, MockPreloadService } from 'src/app/common/mock';
import { state } from '@angular/animations';

@Component({
  selector: 'app-test-evaluator',
  template: '<app-evaluator></app-evaluator>',
})

class TestEvaluatorComponent {
}

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {
}

describe('Evaluator Component', () => {
  let component: EvaluatorComponent;
  let fixture: ComponentFixture<TestEvaluatorComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  let activatedRoute: ActivatedRoute;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'insurance/getquotes', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
        BrowserAnimationsModule,
      ],
      providers: [
        MatSnackBarComponent,
        ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        { provide: TransactionalService, useClass: MockTransactionalService },
        { provide: PreloadService, useClass: MockPreloadService },
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: {
              _value: {
                applicationId: '12345',
              },
            },
          },
        },
      ],
      declarations: [
        TestEvaluatorComponent,
        MockRouteBlankComponent,
        EvaluatorComponent,
        InsuranceHeadingPanelComponent,
        ProductDescriptionComponent,
        StringConstantPipe,
        ProgressSpinnerDialogComponent,
      ],
    }).overrideModule(BrowserAnimationsModule, { set: { entryComponents: [ProgressSpinnerDialogComponent] } }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestEvaluatorComponent);
    component = fixture.debugElement.children[0].componentInstance as EvaluatorComponent;
    activatedRoute = TestBed.get(ActivatedRoute);
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', inject([StateService], (stateService: StateService) => {
    expect(component).toBeTruthy();
  }));

  it('should create Application ID and getDecryptStatus data and set insuranceSelected from data bondClassification',
    inject([StateService], (stateService: StateService) => {
      const data = {
        bondClassification: 'pnl',
        pageReference: 'productInformation',
      };
      stateService.getDecryptStatus.next(data);
      expect(component).toBeTruthy();
    }));

  it('should navigate to insurance get quotes', inject([PreloadService, InsuranceStaticService],
    (service: PreloadService, insuranceService: InsuranceStaticService) => {
      console.log('queryParams', activatedRoute);
      const routerstub: Router = TestBed.get(Router);
      const navigateSpy = spyOn(routerstub, 'navigate').and.returnValue(['/insurance/getquotes']);
      component.navigateToGetQuotesFn();
      expect(navigateSpy()).toEqual(['/insurance/getquotes']);
    }));

  it('should set completion Status to respective spection', inject([StateService], (stateService: StateService) => {
    const SECTION_COMPLETE_STATUS = {
      'istouched': true,
      'status': 'complete',
      'errors': 0,
    };
    component.setcompletionStatus('getQuote,productInformation');
    expect(stateService.SECTIONS['getQuote']['status']).toEqual(SECTION_COMPLETE_STATUS.status);
    expect(stateService.SECTIONS['productInformation']['status']).toEqual(SECTION_COMPLETE_STATUS.status);
  }));

  it('should set insuranceSelected from activatedRoute queryParams', inject([StateService], (stateService: StateService) => {
    activatedRoute.queryParams = of({ product_code: ['pnl'] });
    const productCode = component.getSelectedInsuranceProductCode();
    expect(productCode).toEqual(['pnl']);
  }));

  it('should return API response error when getApplicationData called',
    inject([StateService, InsuranceStaticService], (stateService: StateService,
      insuranceService: InsuranceStaticService) => {
      const getApplicationData = spyOn(insuranceService, 'getApplicationData').and.
        returnValue(throwError({ status: 404, error: { message: '' } }));
      component.getAppData('12345');
      expect(getApplicationData).toHaveBeenCalled();
    }));

  it('should return decryptPayload data',
    inject([StateService, InsuranceStaticService], (stateService: StateService,
      insuranceService: InsuranceStaticService) => {
      activatedRoute.queryParams = of({ product_code: ['pnl'] });
      const data = {
        data: {
          bondClassification: 'pnl',
          pageReference: 'productInformation',
        },
      };
      const getApplicationData = spyOn(insuranceService, 'getApplicationData').and.returnValue(of(data));
      component.getAppData('12345');
      expect(getApplicationData).toHaveBeenCalled();
    }));

  it('should navigate as per Page reference passed to getPreload Data function Client Associated to Agent',
    inject([StateService, InsuranceStaticService, TransactionalService], (stateService: StateService,
      insuranceService: InsuranceStaticService, transService: TransactionalService) => {
      stateService.insuranceSelected = ['pnl'];
      stateService.clientID = null;
      component.getPreloadData('getQuote');
      const routerstub: Router = TestBed.get(Router);
      const navigateSpy = spyOn(routerstub, 'navigate').and.returnValue(['/insurance/getquotes']);
      expect(navigateSpy()).toEqual(['/insurance/getquotes']);
    }));

});
