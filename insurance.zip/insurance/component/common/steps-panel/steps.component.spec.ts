import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { StepsComponent } from './steps.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { PurchaseSummaryPanelComponent } from '../purchase-summary-panel/purchase-summary-panel.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';

@Component({
  selector: 'app-test-step-component',
  template: '<app-insurance-steps></app-insurance-steps>',
})

class TestInsuranceStepComponent {
}

describe('Insurance Steps Component', () => {
  let component: StepsComponent;
  let fixture: ComponentFixture<TestInsuranceStepComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestInsuranceStepComponent,
        StepsComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceStepComponent);
    component = fixture.debugElement.children[0].componentInstance as StepsComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
