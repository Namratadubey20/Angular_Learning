import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { MatSnackBarComponent } from './banner.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { PurchaseSummaryPanelComponent } from '../purchase-summary-panel/purchase-summary-panel.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';

@Component({
  selector: 'app-test-insurance-banner-panel',
  template: '<app-banner-bar></app-banner-bar>',
})

class TestInsuranceBannerComponent {
}

describe('Insurance Heading Panel Component', () => {
  let component: MatSnackBarComponent;
  let fixture: ComponentFixture<TestInsuranceBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [],
      declarations: [
        TestInsuranceBannerComponent,
        MatSnackBarComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceBannerComponent);
    component = fixture.debugElement.children[0].componentInstance as MatSnackBarComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
