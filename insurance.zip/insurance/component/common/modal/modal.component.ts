import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spinner-dialog',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
})
export class ProgressSpinnerDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    if (document.querySelector('app-spinner-dialog')) {
      document.querySelector('app-spinner-dialog').parentElement.classList.add('spinner-background');
    }
  }

}
