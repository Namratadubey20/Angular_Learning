import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { ProgressSpinnerDialogComponent } from './modal.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { SummaryPanelComponent } from '../../common/summary-panel/summary-panel.component';
import { PurchaseSummaryPanelComponent } from '../purchase-summary-panel/purchase-summary-panel.component';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';

@Component({
  selector: 'app-test-insurance-modal-panel',
  template: '<app-spinner-dialog></app-spinner-dialog>',
})

class TestInsuranceModalComponent {
}

describe('Insurance Modal Component', () => {
  let component: ProgressSpinnerDialogComponent;
  let fixture: ComponentFixture<TestInsuranceModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [],
      declarations: [
        TestInsuranceModalComponent,
        ProgressSpinnerDialogComponent,
        StepsComponent,
        SummaryPanelComponent,
        PurchaseSummaryPanelComponent,
        StringConstantPipe,
        GetLabelPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceModalComponent);
    component = fixture.debugElement.children[0].componentInstance as ProgressSpinnerDialogComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
