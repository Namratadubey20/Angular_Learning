import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { BaseFormComponent } from '../../base-form.component';
import { TransactionalService } from '../../../services/transactional.service';
import { StateService } from '../../../services/state.service';
import { Router } from '@angular/router';
import { StringConstants } from '../../../constants/string-constants';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { ProductConfigService } from '../../../services/product-config.service';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { UtilMethodsService } from '../../../services/util-method.service';
import { DirectiveValidationService } from '../../../services/directive-validation.service';

@Component({
  selector: 'app-insurance-summary-panel',
  templateUrl: './summary-panel.component.html',
  styleUrls: ['./summary-panel.component.scss'],
})
export class SummaryPanelComponent extends BaseFormComponent implements OnInit {
  math = Math;
  constructor(public transService: TransactionalService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog,
    private router: Router, public stringConstant: StringConstants, public productConfig: ProductConfigService,
    public insuranceSpinner: InsuranceSpinnerService) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
  }

  ngOnInit() { }

  navigateGetQuote() {
    if (UtilMethodsService.isEmpty(this.stateService.editedQuesDetails)) {
      this.stateService.editedQuesDetails = UtilMethodsService.copyObject(this.stateService.insuranceDetails);
      this.stateService.editedSectionStates = JSON.parse(JSON.stringify(this.stateService.SECTIONS));
    } else {
      this.stateService.insuranceDetails = UtilMethodsService.copyObject(ComparativeConstants.DET_INTERFACE_FOR_Q);
      this.stateService.insuranceDetails = UtilMethodsService.copyObject(this.stateService.editedQuesDetails);
      this.stateService.SECTIONS = JSON.parse(JSON.stringify(ComparativeConstants.SECTIONS_INTERFACE));
      this.stateService.SECTIONS = JSON.parse(JSON.stringify(this.stateService.editedSectionStates));
    }
    this.router.navigate(['/insurance/getquotes']);
  }

  navigateContactDetails() {
    if (UtilMethodsService.isEmpty(this.stateService.editedQuesDetails)) {
      this.stateService.editedQuesDetails = UtilMethodsService.copyObject(this.stateService.insuranceDetails);
      this.stateService.editedSectionStates = JSON.parse(JSON.stringify(this.stateService.SECTIONS));
    } else {
      this.stateService.insuranceDetails = UtilMethodsService.copyObject(ComparativeConstants.DET_INTERFACE_FOR_Q);
      this.stateService.insuranceDetails = UtilMethodsService.copyObject(this.stateService.editedQuesDetails);
      this.stateService.SECTIONS = JSON.parse(JSON.stringify(ComparativeConstants.SECTIONS_INTERFACE));
      this.stateService.SECTIONS = JSON.parse(JSON.stringify(this.stateService.editedSectionStates));
    }
    this.router.navigate(['/insurance/insuranceDetails']);
  }

  navigateYourQuote() {
    if (UtilMethodsService.isEmpty(this.stateService.editedQuesDetails)) {
      this.stateService.editedQuesDetails = UtilMethodsService.copyObject(this.stateService.insuranceDetails);
      this.stateService.editedSectionStates = JSON.parse(JSON.stringify(this.stateService.SECTIONS));
    } else {
      this.stateService.insuranceDetails = UtilMethodsService.copyObject(ComparativeConstants.DET_INTERFACE_FOR_Q);
      this.stateService.insuranceDetails = UtilMethodsService.copyObject(this.stateService.editedQuesDetails);
      this.stateService.SECTIONS = JSON.parse(JSON.stringify(ComparativeConstants.SECTIONS_INTERFACE));
      this.stateService.SECTIONS = JSON.parse(JSON.stringify(this.stateService.editedSectionStates));
    }
    this.router.navigate(['/insurance/yourquotes']);
  }

  getFormatLimitDeductVal(_val) {
    return '$' + DirectiveValidationService.formatMoney(_val);
  }

}
