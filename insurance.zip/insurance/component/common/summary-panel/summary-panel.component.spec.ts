import { TestBed, async, fakeAsync, getTestBed, ComponentFixture } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { MaterialModule } from '../../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { SummaryPanelComponent } from './summary-panel.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { StepsComponent } from '../../common/steps-panel/steps.component';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { StringConstantPipe } from '../../../pipe/string-constant.pipe';
import { Router } from '@angular/router';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';
import { ProductConfigPipe } from '../../../pipe/product-config.pipe';


@Component({
  selector: 'app-test-insurance-summary-panel',
  template: '<app-insurance-summary-panel></app-insurance-summary-panel>',
})

class TestInsuranceSummaryComponent {
}

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {
}

describe('Insurance Summary Component', () => {
  let component: SummaryPanelComponent;
  let fixture: ComponentFixture<TestInsuranceSummaryComponent>;
  let router: Router;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'insurance/getquotes', component: MockRouteBlankComponent },
          { path: 'insurance/insuranceDetails', component: MockRouteBlankComponent },
          { path: 'insurance/yourquotes', component: MockRouteBlankComponent },
        ]),
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [
        ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
      declarations: [
        TestInsuranceSummaryComponent,
        MockRouteBlankComponent,
        SummaryPanelComponent,
        StepsComponent,
        SummaryPanelComponent,
        GetLabelPipe,
        StringConstantPipe,
        ProductConfigPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsuranceSummaryComponent);
    router = TestBed.get(Router);
    component = fixture.debugElement.children[0].componentInstance as SummaryPanelComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to insurance get quotes', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateGetQuote();
    expect(navigateSpy).toHaveBeenCalledWith(['/insurance/getquotes']);
  });

  it('should navigate to contact details', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateContactDetails();
    expect(navigateSpy).toHaveBeenCalledWith(['/insurance/insuranceDetails']);
  });

  it('should navigate to insurance insurance payment', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateYourQuote();
    expect(navigateSpy).toHaveBeenCalledWith(['/insurance/yourquotes']);
  });

});
