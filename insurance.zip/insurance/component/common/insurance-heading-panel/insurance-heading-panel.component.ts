import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { StringConstants } from 'src/app/insurance/constants/string-constants';
import { StateService } from 'src/app/insurance/services/state.service';

@Component({
  selector: 'app-insurance-heading-panel',
  templateUrl: './insurance-heading-panel.component.html',
  styleUrls: ['./insurance-heading-panel.component.scss'],
})
export class InsuranceHeadingPanelComponent implements OnInit {

  @Input() mainHeading;
  @Input() secondaryHeading;
  @Input() subheading;
  @Input() headingIcon;
  @Input() showBreadcrumb = false;
  @Input() applicationId;
  @Output() isBackClicked = new EventEmitter<any>();
  @Output() isHomeClicked = new EventEmitter<any>();
  originState;
  sessionStorage;
  constructor(public stringConstant: StringConstants,
    public stateService: StateService) {
    this.originState = sessionStorage.getItem('originState');
  }

  ngOnInit() {
  }

  backRoutingEmit() {
    this.isBackClicked.emit(true);
  }

  homeRouting() {
    this.isHomeClicked.emit(true);
  }
}
