import { Component } from '@angular/core';
import { PurchaseSummaryPanelComponent } from './purchase-summary-panel.component';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StateService } from '../../../services/state.service';
import { MaterialModule } from 'src/app/material.module';
import { CommonModule } from '@angular/common';
import { FormInsuranceComponentModule } from '../../../../form-insurance-components/form-insurance-components.module';
import { StepsComponent } from '../steps-panel/steps.component';
import { GetLabelPipe } from '../../../pipe/get-label.pipe';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';

const summar = {
  'product': {
    'productNo': 12345,
    'productType': {
      'name': 'ABC Insurance',
      'code': 'cyber',
    },
  },
  'applicant': {
    'data': {
      'applicantEmail': 'abc@abc.com',
      'effectiveDate': '2020/10/01',
      'expiryDate': '2021/10/01',
      'paymentMethod': {
        'response': {
          'transaction': 12345,
        },
      },
    },
  },
};
@Component({
  selector: 'app-test-insurance-purchase-summary-panel',
  // tslint:disable-next-line: max-line-length
  template: '<app-insurance-purchase-summary-panel [summaryData]="summar"></app-insurance-purchase-summary-panel>',
})

class TestInsurancePurchaseSummaryComponent {
}

describe('Insurance Purchase Summary Component', () => {
  let component: PurchaseSummaryPanelComponent;
  let fixture: ComponentFixture<TestInsurancePurchaseSummaryComponent>;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule,
        FormInsuranceComponentModule,
      ],
      providers: [ServiceHandler,
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
        StateService,
      ],
      declarations: [
        TestInsurancePurchaseSummaryComponent,
        PurchaseSummaryPanelComponent,
        StepsComponent,
        PurchaseSummaryPanelComponent,
        GetLabelPipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestInsurancePurchaseSummaryComponent);
    component = fixture.debugElement.children[0].componentInstance as PurchaseSummaryPanelComponent;
    fixture.detectChanges();
  });

  it('should create', () => {
    const stateService: StateService = TestBed.get(StateService);
    stateService.isConfirmationPageLoad.next(true);
    component.applicant = summar['applicant'] && summar['applicant'].data;
    console.log(' -----> ', component.applicant);
    expect(component).toBeTruthy();
  });

  it('should destroy', () => {
    component.ngOnDestroy();
    fixture.detectChanges();
    expect(component.stateService.isConfirmationPageLoad.value).toBeFalsy();
  });

});
