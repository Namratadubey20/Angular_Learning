import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { BaseFormComponent } from '../../base-form.component';
import { TransactionalService } from '../../../services/transactional.service';
import { StateService } from '../../../services/state.service';
import { StringConstants } from '../../../constants/string-constants';
import { ComparativeConstants } from '../../../constants/comparative-constants';
import { InsuranceSpinnerService } from '../../../services/insurance-spinner.service';
import { DirectiveValidationService } from '../../../services/directive-validation.service';

@Component({
  selector: 'app-insurance-purchase-summary-panel',
  templateUrl: './purchase-summary-panel.component.html',
  styleUrls: ['./purchase-summary-panel.component.scss'],
})
export class PurchaseSummaryPanelComponent extends BaseFormComponent implements OnInit, OnDestroy {
  @Input() summaryData: Object;
  applicantAddress = '';
  public product;
  public applicant;
  aggregate: string;
  deductible: string;
  totalPlanAmount: string;
  constructor(public transService: TransactionalService, public insuranceSpinner: InsuranceSpinnerService,
    public fb: FormBuilder, public stateService: StateService, public matDialogService: MatDialog, public stringConstant: StringConstants) {
    super(fb, transService, stateService, matDialogService, insuranceSpinner);
  }

  ngOnInit() {
    // set purchase summary data when confirmation page load all data
    if (this.stateService.isConfirmationPageLoad.value) {
      this.applicantAddress = this.formatAddress(this.stateService);
      this.product = this.summaryData['product'];
      this.applicant = this.summaryData['applicant'] && this.summaryData['applicant'].data;
      this.aggregate = DirectiveValidationService.formatMoney(this.applicant.amount, true);
      this.deductible = DirectiveValidationService.formatMoney(this.applicant.deductible, true);
      if (this.stateService.insuranceDetails.questionAnswers['premiumOption'] === 'annualPay') {
        this.totalPlanAmount = DirectiveValidationService.formatMoney(this.getTotalPlanAmount());
      } else {
        this.totalPlanAmount = DirectiveValidationService.formatMoney(this.applicant.applicationPaymentPlan.initialAmount);
      }
    }
  }

  getTotalPlanAmount() {
    // if (this.comparativeConstants.DELIVERY_METHOD_FEES.indexOf(this.applicant.deliveryMethod.deliveryMethod) > -1) {
    return this.applicant.applicationPaymentPlan.totalPlanAmount;
    // } else {
    //   return this.summaryData['applicant'] && this.summaryData['applicant'].premium;
    // }
  }

  ngOnDestroy() {
    this.stateService.isConfirmationPageLoad.next(false);
    this.insuranceSpinner.hide();
  }

}
