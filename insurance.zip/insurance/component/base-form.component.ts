import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { TransactionalService } from '../services/transactional.service';
import { ComparativeConstants } from '../constants/comparative-constants';
import { StringConstants } from '../constants/string-constants';
import { UtilMethodsService } from '../services/util-method.service';
import { StateService } from '../services/state.service';
import { Subscription } from 'rxjs';
import { Validation } from '../services/validation';
import { ProgressSpinnerDialogComponent } from './common/modal/modal.component';
import { InsuranceSpinnerService } from '../services/insurance-spinner.service';
import { MatSnackBarComponent } from './common/banner/banner.component';
import 'rxjs/add/operator/debounceTime';
import { GetLabelPipe } from '../pipe/get-label.pipe';
import { EvaluateExpressionPipe } from '../pipe/evaluate-expression.pipe';
import { DirectiveValidationService } from '../services/directive-validation.service';
import { DialogComponent } from 'src/app/form-insurance-components/dialog/dialog.component';
import { NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-base',
  template: `
      <p>
        base works!
      </p>
    `,
  styles: [],
})

export class BaseFormComponent implements OnInit, OnDestroy {
  public static ERROR_BAR = 'red-snackbar';
  public static SUCCESS_BAR = 'green-snackbar';
  public static INFORMATION_BAR = 'blue-snackbar';
  public static CONFIG_MULTIPLE = 'multiple';
  public static CONFIG_SINGLE = 'single';
  public form: FormGroup;
  public getQuoteJson;
  public getPaymentJson;
  public questionJSONDatafields: Array<[{}]>;
  public questionJSONConditionalfields: Array<[{}]>;
  public componentStaticQuestionStack = {};
  public valueChangeSubscribe;
  public parentSectionName = null;
  public sectionName = null;
  public modelName = null;
  public configurationType = null;
  public isCustomPageValidationRequired = false;
  protected subscriptions: Array<Subscription> = [];
  public associatedProduct = null; // Only required if configuration type is single.
  public comparativeConstants = ComparativeConstants;
  protected spinners: Array<any> = [];
  public TN_FORM_ELE_INVALID = 'tn-form-ele-invalid';
  constructor(public fb: FormBuilder, public transService: TransactionalService, public stateService: StateService,
    public matDialogService: MatDialog, public insuranceSpinner: InsuranceSpinnerService) { }

  ngOnInit() { }

  loadInitialFields(questionJSONSubData) {
    let addQuestionIndex = 0;
    const removeQuestion = 0;
    this.questionJSONDatafields = [];
    this.questionJSONConditionalfields = [];
    questionJSONSubData.forEach((questionDFields, idx) => {
      let _dcResult;
      if (!UtilMethodsService.isEmpty(questionDFields.optionReference)) {
        questionDFields.options = this.stateService.preloadData[questionDFields.optionReference];
      }
      questionDFields.sequence_number = idx;
      if (!UtilMethodsService.isEmpty(questionDFields.displayCriteria)) {
        _dcResult = new EvaluateExpressionPipe(this.stateService).transform(questionDFields, this.form);
      }
      if (_dcResult === false) {
        this.questionJSONConditionalfields.push(questionDFields);
      } else {
        addQuestionIndex = this.transService.getRightPlaceForQuestion(questionDFields.sequence_number, this.questionJSONDatafields);
        if (addQuestionIndex < 0) {
          addQuestionIndex = this.questionJSONDatafields.length;
        }
        this.questionJSONDatafields.insert(addQuestionIndex, questionDFields);
      }
    });
    console.log('questionJSONDatafields >>> ', this.questionJSONDatafields);
    console.log('questionJSONConditionalfields >>> ', this.questionJSONConditionalfields);
  }



  evaluateDisplayCriteriaForQuestions() {
    const me = this;
    if (!UtilMethodsService.isEmpty(me.questionJSONConditionalfields)) {
      // Check Conditional Array for moving to Question Array based on passed display criteria
      const _copyQuestionJSONConditionalfields = UtilMethodsService.copyObject(me.questionJSONConditionalfields);
      _copyQuestionJSONConditionalfields.forEach((questionCDFields, idx) => {
        let addQuestionIndex = 0;
        const _dcResult = new EvaluateExpressionPipe(me.stateService).transform(questionCDFields, me.form);
        if (_dcResult) {
          addQuestionIndex = me.transService.getRightPlaceForQuestion(questionCDFields['sequence_number'], me.questionJSONDatafields);
          if (addQuestionIndex < 0) {
            addQuestionIndex = me.questionJSONDatafields.length;
          }
          const _existingIdxToAdd = me.transService.getQuestionIdxFromQuestionnair(questionCDFields['name'], me.questionJSONDatafields);
          if (_existingIdxToAdd < 0) {
            let control = null;
            if (questionCDFields['type'] === ComparativeConstants.CHECKBOX_QUESTION_TYPE) {
              control = me.fb.array([], me.transService.bindValidations(questionCDFields['validations'] || []));
            } else {
              control =
                me.fb.control(questionCDFields['value'], me.transService.bindValidations(questionCDFields['validations'] || []));
            }
            if (me.form) {
              me.form.addControl(questionCDFields['name'], control);
              me.subscribeControl(me.form, questionCDFields);
            }
            me.questionJSONDatafields.insert(addQuestionIndex, questionCDFields);
          }
          const _existingIdxToRemove =
            me.transService.getQuestionIdxFromQuestionnair(questionCDFields['name'], me.questionJSONConditionalfields);
          if (_existingIdxToRemove >= 0) {
            me.questionJSONConditionalfields.splice(_existingIdxToRemove, 1);
          }
        }
      });
    }

    if (!UtilMethodsService.isEmpty(me.questionJSONDatafields)) {
      // Check Question Array for moving from Question Array to Conditional Array for failed display criteria
      const _copyQuestionJSONDatafields = UtilMethodsService.copyObject(me.questionJSONDatafields);
      _copyQuestionJSONDatafields.forEach((questionDFields, idx) => {
        if (!UtilMethodsService.isEmpty(questionDFields['displayCriteria'])) {
          const _dcResult = new EvaluateExpressionPipe(me.stateService).transform(questionDFields, me.form);
          if (!_dcResult) {
            me.form.removeControl(questionDFields['name']);
            const _existingIdxToRemove =
              me.transService.getQuestionIdxFromQuestionnair(questionDFields['name'], me.questionJSONDatafields);
            if (_existingIdxToRemove >= 0) {
              me.questionJSONDatafields.splice(_existingIdxToRemove, 1);
            }
            const _existingIdxToAdd =
              me.transService.getQuestionIdxFromQuestionnair(questionDFields['name'], me.questionJSONConditionalfields);
            if (_existingIdxToAdd < 0) {
              me.questionJSONConditionalfields.push(questionDFields);
            }
          }
        }
      });
    }

    console.log('questionJSONDatafields >>> ', me.questionJSONDatafields);
    console.log('questionJSONConditionalfields >>> ', me.questionJSONConditionalfields);
  }

  createControlwithNewJson(blockJson) {
    const group = this.fb.group({});
    blockJson.forEach(fields => {
      let control = null;
      if (fields.type === ComparativeConstants.CHECKBOX_QUESTION_TYPE) {
        control = this.fb.array([], this.transService.bindValidations(fields.validations || []));
      } else {
        control = this.fb.control(fields.value, this.transService.bindValidations(fields.validations || []));
      }
      group.addControl(fields.name, control);
      this.subscribeControl(group, fields);
    });
    this.applyFormValues(group, this.stateService.insuranceDetails.questionAnswers);
    return group;
  }

  public subscribeControl(group, field) {
    const me = this;
    me.valueChangeSubscribe = group.get(field.name).valueChanges
      // .debounceTime(500)
      .subscribe((answerEvent) => {
        this.stateService.isApplicationReadyToAction = false;
        if (!UtilMethodsService.isEmpty(answerEvent)) {
          // if (field.name === ComparativeConstants.staticQuestionNames.application_phone) {
          //   me.stateService.insuranceDetails.questionAnswers[field.name] = UtilMethodsService.serializePhoneNumber(answerEvent);
          // }
          console.log('answerEvent >> ', answerEvent);
          console.log('name >> ', field.name);
          me.stateService.insuranceDetails.questionAnswers[field.name] = answerEvent;
          me.stateService.screenMapObject[field.name] = answerEvent;
          if (field.type === 'date') {
            me.stateService.insuranceDetails.questionAnswers[field.name] = UtilMethodsService.formatDateToString(answerEvent);
            me.stateService.screenMapObject[field.name] = UtilMethodsService.formatDateToString(answerEvent);
          }
          if (field.type === 'textcurrency') {
            const formattedValue = DirectiveValidationService.formatMoney(answerEvent);
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = formattedValue.replace(/,/ig, '');
            me.stateService.screenMapObject[field.name] = formattedValue.replace(/,/ig, '');
          }
          if (field.name === 'state') {
            me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name] = answerEvent;
          }
          if (field.name === 'applicantName') {
            /* will uncomment below line once update business name api runs */
            if (this.stateService.companyInfo) {
              this.stateService.companyInfo[0].name = answerEvent;
              this.stateService.companyInfo[0].companyOffices[0].name = answerEvent;
            }
          }
          if (field.name === 'applicantEmail') {
            if (this.stateService.companyInfo) {
              this.stateService.companyInfo[0].companyOffices[0].email = answerEvent;
            }
          }
        } else {
          delete me.stateService.insuranceDetails.questionAnswers[field.name];
          if (field.name === 'state') {
            delete me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[field.name];
          }
        }
        console.log('Payload >> ', me.stateService.insuranceDetails.questionAnswers);
        if (me.parentSectionName && me.sectionName) {
          me.validatePage(false, [], null);
        }
      });
    this.stateService.isApplicationReadyToAction = true;
  }

  public applyFormValues(group, formValues) {
    Object.keys(formValues).forEach(key => {
      if (typeof formValues[key] !== 'object') {
        this.applyControlValues(group, formValues, key);
      } else {
        // tslint:disable-next-line:no-shadowed-variable
        if (!UtilMethodsService.isEmpty(formValues[key]) && Object.keys(formValues[key]).length > 0) {
          Object.keys(formValues[key]).forEach(nestedkey => {
            this.applyControlValues(group, formValues[key], nestedkey);
          });
        }
      }
    });
  }

  public applyControlValues(group, formValues, key) {
    if (group.controls[key]) {
      const formControl = <FormControl>group.controls[key];
      if (formControl instanceof FormGroup) {
        this.applyFormValues(formControl, formValues[key]);
      } else {
        if (this.componentStaticQuestionStack[key]
          && this.componentStaticQuestionStack[key].type === 'checkbox') {
          formValues[key] = String(formValues[key]).split(','); /* .map(Number) */
        }
        if (formControl instanceof FormArray) {
          if (Array.isArray(formValues[key]) && formValues[key].length > 0) {
            Object.keys(formValues[key]).forEach(idVal => {
              formControl.controls.push(new FormControl(formValues[key][idVal]));
            });
          }

        } else {
          if (this.componentStaticQuestionStack[key]
            && this.componentStaticQuestionStack[key].type === 'textcurrency') {
            formValues[key] = DirectiveValidationService.formatMoney(formValues[key]);
          }
          formControl.setValue(formValues[key]);
        }
      }
    }
  }

  public setGooglePlaceValues(placeValue, formElementNames, snackBarInst, stringConstInst,
    isStateProfessionWarningDialog?, _router?, _dialogService?, zipCodeChangeState?) {
    const me = this;
    let _isSancState = false;
    let formatedAddress;
    if (placeValue.address_components) {
      placeValue.address_components.map(item => {
        if (item['types'].indexOf('administrative_area_level_1') > -1) {
          if (this.stateService.preloadData.sanctionStates.includes(item['short_name'])) {
            _isSancState = true;
            // tslint:disable-next-line:max-line-length
            this.showBanner(snackBarInst, stringConstInst.SANCTIONSTATE_SEL_MESSAGE.concat(item['short_name']), BaseFormComponent.ERROR_BAR);
          }
        }
      });
    }
    if (placeValue.state) {
      if (this.stateService.preloadData.sanctionStates.includes(placeValue.state)) {
        _isSancState = true;
        this.showBanner(snackBarInst, stringConstInst.SANCTIONSTATE_SEL_MESSAGE.concat(placeValue.state), BaseFormComponent.ERROR_BAR);
      }
    }
    if (_isSancState) {
      return;
    }

    if (placeValue.formatted_address) {
      formatedAddress = me.transService.getFormattedAddress(placeValue);
    } else {
      formatedAddress = placeValue;
    }

    // Check autopopulate state equality with state service state
    // If user change the address and if state difference then applicant should jump on get-quote
    // Profession filed should disable on insurance-details page
    // Applicant can change Profession on get-quote page

    if (UtilMethodsService.isEmpty(formatedAddress.state)) {
      formatedAddress.state = zipCodeChangeState;
    }

    if (isStateProfessionWarningDialog === true
      && formatedAddress.state !== me.stateService.insuranceDetails.questionAnswers['state']) {
      // set old values so if user cancel or click close icon , old values will get set to form control
      // if user click continue then applicant will jump to get-quote and address get reset based on user selection
      // zipCodeChangeState is state when user change zip code

      const newState = new GetLabelPipe(me.stateService).transform(me.stateService.insuranceDetails.questionAnswers['state'], 'state');
      const oldState = new GetLabelPipe(me.stateService).transform(formatedAddress.state, 'state');
      if (!UtilMethodsService.isEmpty(this.form.controls)) {
        if (this.form.controls['street1']) {
          this.form.controls['street1'].setValue(this.stateService.exitingAddress['street1']);
        }
        if (this.form.controls['zipCode']) {
          this.form.controls['zipCode'].setValue(this.stateService.exitingAddress['zipCode']);
        }
        if (this.form.controls['city']) {
          this.form.controls['city'].setValue(this.stateService.exitingAddress['city']);
        }
      }

      this.insuranceSpinner.show();
      // this.showBanner(snackBarInst, "Applicant's State mismatch! Continue from get-quote page", BaseFormComponent.ERROR_BAR);
      const dialogRef = _dialogService.open(DialogComponent, {
        data: {
          isContinueButton: true,
          isCancelButton: true,
          iswarningMessage: true,
          warningMessage: `You have updated the State from ${newState} to ${oldState}
          and hence needs to start again`,
          newState: formatedAddress.state,
          existingState: me.stateService.insuranceDetails.questionAnswers['state'],
        },
        width: '550px', position: { top: '100px' },
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          const navigationExtras: NavigationExtras = {
            queryParams: {
              isWarningPopUp: true,
            },
          };
          _router.navigate([`/insurance/getquotes`], navigationExtras);
        }
      });
      this.insuranceSpinner.hide();
      return;
    }

    // tslint:disable-next-line:max-line-length
    // formatedAddress[ComparativeConstants.staticQuestionNames.application_state] = new GetLabelPipe(this.stateService).transform(formatedAddress[ComparativeConstants.staticQuestionNames.application_state], 'state');
    formElementNames.forEach(ele => {
      me.removeFieldError(ele);
      me.stateService.insuranceDetails.questionAnswers[ele] = formatedAddress[ele];
      if (!UtilMethodsService.isEmpty(me.stateService.companyInfo[0].companyOffices[0].address)) {
        me.stateService.companyInfo[0].companyOffices[0].address[ele] = formatedAddress[ele];
      }
      if (ele === 'state') {
        me.stateService.insuranceDetails.questionAnswers.dynamicQuestions[ele] = formatedAddress[ele];
      }
    });
    me.applyFormValues(me.form, me.stateService.insuranceDetails.questionAnswers);
  }

  // Focus Events
  onFocusOut(event, field, _formArr?: any) {
    const me = this;
    const _formArray = _formArr ? _formArr : me.form;
    const _event = event._field ? event._field : event;
    if (!_event.name) {
      _event.name = field.name;
    }

    if (_event) {
      let _value = null;
      let _contrlVal;

      const _errors = _formArray && _formArray.get(_event.name).errors;
      if (!UtilMethodsService.isEmpty(_errors) && UtilMethodsService.isEmpty(_errors.required)) {
        _formArray.controls[_event.name].setValue('');
        _formArray.controls[_event.name].value = null;
      }

      if (_formArray && _formArray.controls && _formArray.controls[_event.name]) {
        _contrlVal = _formArray.controls[_event.name].value;
      }

      _value = (field.type === ComparativeConstants.MULTISELECT_QUESTION_TYPE || field.type === ComparativeConstants.DATE_QUESTION_TYPE) ?
        _event._value : _contrlVal;
      me.isValid(_event, _value, _errors);
    }
  }

  unsubscribe() {
    for (const subscription of this.subscriptions) {
      if (subscription) {
        subscription.unsubscribe();
      }
    }
  }

  isValid(element: any, _value, _errors): boolean {
    let message: string;
    message = this.getValidationMessageOptional(element, element.validations, _value, _errors);
    if (!UtilMethodsService.isEmpty(message)) {
      this.stateService.fieldError[element.name] = message;
    } else {
      this.removeFieldError(element.name);
    }
    return UtilMethodsService.isEmpty(message);
  }

  removeFieldError(_name: string, deleteAll?: boolean) {
    if (!UtilMethodsService.isEmpty(this.stateService.fieldError) && deleteAll) {
      this.stateService.fieldError = {};
    } else if (!UtilMethodsService.isEmpty(this.stateService.fieldError) && _name &&
      !UtilMethodsService.isEmpty(this.stateService.fieldError[_name])) {
      delete this.stateService.fieldError[_name];
    } else {
      return;
    }
  }

  getValidationMessageOptional(field: any, validationArray: any, _value: any, _errors: any): string {
    if (validationArray && validationArray.length > 0) {
      validationArray = validationArray;
    } else if (field.fieldName && field.fieldName.validations.length > 0) {
      validationArray = field.fieldName.validations;
    } else {
      validationArray = validationArray;
    }
    if (!UtilMethodsService.isEmpty(_errors)) {
      if (validationArray && validationArray.length > 0) {
        for (let i = 0; i < validationArray.length; i++) {
          if (validationArray[i].name === Object.keys(_errors)[0]) {
            return validationArray[i].message;
          }
        }
      }
    }
    return Validation.getValidationErrorMsg(field, _value, _errors, this.stateService);
  }

  getFieldError(_fieldName) {
    if (!UtilMethodsService.isEmpty(this.stateService.fieldError) &&
      !UtilMethodsService.isEmpty(this.stateService.fieldError[_fieldName])) {
      return this.stateService.fieldError[_fieldName];
    } else {
      return null;
    }
  }

  onFocus(event, field, _formArr?: any) {
    const me = this;
    const _formArray = _formArr ? _formArr : me.form;
    const _event = event._field ? event._field : event;
    if (_formArray && _formArray.controls && _formArray.controls[_event.name]) {
      _formArray.controls[_event.name].markAsUntouched();
    }
    me.removeFieldError(_event.name);
  }

  getMaxlength(validationArray: any) {
    if (validationArray && validationArray.length > 0) {
      for (let i = 0; i < validationArray.length; i++) {
        if (validationArray[i].name === 'maxLength') {
          return validationArray[i].value;
        }
      }
    }
    return '256';
  }

  getMinlength(validationArray: any) {
    if (validationArray && validationArray.length > 0) {
      for (let i = 0; i < validationArray.length; i++) {
        if (validationArray[i].name === 'minLength') {
          return validationArray[i].value;
        }
      }
    }
    return '0';
  }

  isRequired(validationArray: any): boolean {
    if (validationArray && validationArray.length > 0) {
      for (let i = 0; i < validationArray.length; i++) {
        if (validationArray[i].name === 'required') {
          return true;
        }
      }
    }
    return false;
  }

  setQuestionNameToStack(blockJson) {
    blockJson.fields.forEach(question => {
      this.componentStaticQuestionStack[question.name] = {};
    });
    this.publishQuestionForForm(blockJson);
  }

  publishQuestionForForm(blockJson) {
    const _qNameKeys = Object.keys(this.componentStaticQuestionStack);
    _qNameKeys.forEach((key) => {
      this.componentStaticQuestionStack[key] = this.transService.getQuestionFromQuestionnair(key, blockJson);
      if (this.stateService.preloadData.APIstaticQuestionStack.hasOwnProperty(key)) {
        // set insurance limit on your quote page..Need to update options from APIstaticQuestionStack when key equal to amount
        if (key === 'amount') {
          if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['insuranceLimit'])) {
            this.stateService.preloadData.APIstaticQuestionStack[key]['options'] = this.stateService.insuranceDetails['insuranceLimit'];
          }
        }
        this.componentStaticQuestionStack[key] = this.transService.modifyStaticQuestionProperty(key, this.componentStaticQuestionStack);
      }
    });

    console.log('componentStaticQuestionStack >>> ', this.componentStaticQuestionStack);
  }

  showBanner(snackBar: MatSnackBarComponent, _message, _type, getDuration?) {
    let setDurationInMilliSec;
    if (getDuration) {
      setDurationInMilliSec = getDuration * 1000;
    }
    snackBar.openSnackBar(_message, 'X', _type, setDurationInMilliSec);
  }

  /* showSpinner(matDialogService: MatDialog) {
    if (matDialogService) {
      return matDialogService.open(ProgressSpinnerDialogComponent, {
        panelClass: 'transparent',
        disableClose: true,
      });
    } else {
      return null;
    }
  }
  closeSpinner() {
    for (const spinner of this.spinners) {
      if (spinner) {
        spinner.close();
      }
    }
  } */

  setSubSectionForValidation(parentKey, subSection) {
    if (subSection) {
      if (UtilMethodsService.isEmpty(this.stateService.SECTIONS[parentKey][subSection])) {
        this.stateService.SECTIONS[parentKey][subSection] = UtilMethodsService.copyObject(ComparativeConstants.COUNTER_DEFAULT_OBJ);
      }
    }
    console.log('SECTIONS >>> ', this.stateService.SECTIONS);
  }

  checkIfPageValidForNavigation(_parentSectionName?) {
    let nbrErrors = 0;
    let istouched = true;
    const _parentSName = _parentSectionName ? _parentSectionName : this.parentSectionName;
    const _sections = Object.keys(this.stateService.SECTIONS[_parentSName]);
    const _totalSubSec = (_sections.length - 4);
    let _touchedTrueSubSec = 0;
    let _isvalidated = true;
    _sections.forEach((subSection) => {
      if (subSection && _parentSName) {
        if (this.stateService.SECTIONS[_parentSName][subSection]['istouched'] === false) {
          istouched = false;
          _isvalidated = false;
        } else if (this.stateService.SECTIONS[_parentSName][subSection]['istouched'] === true) {
          _touchedTrueSubSec++;
          // tslint:disable-next-line:triple-equals
          if (this.stateService.SECTIONS[_parentSName][subSection]['istouched'] &&
            !UtilMethodsService.isEmpty(parseInt(this.stateService.SECTIONS[_parentSName][subSection]['errors'], 10))) {
            nbrErrors += parseInt(this.stateService.SECTIONS[_parentSName][subSection]['errors'], 10);
            _isvalidated = false;
          }
        }
      }
    });

    if (this.stateService.SECTIONS && _parentSName) {
      this.stateService.SECTIONS[_parentSName]['errors'] += nbrErrors;
    }


    if (_touchedTrueSubSec === 0) {
      this.stateService.SECTIONS[_parentSName]['status'] = 'default';
    } else if (_touchedTrueSubSec > 0 && _touchedTrueSubSec !== _totalSubSec) {
      this.stateService.SECTIONS[_parentSName]['status'] = 'inProgress';
    } else if (_touchedTrueSubSec === _totalSubSec && this.stateService.SECTIONS[_parentSName]['errors'] > 0) {
      this.stateService.SECTIONS[_parentSName]['status'] = 'inProgress';
    } else if (_touchedTrueSubSec === _totalSubSec && this.stateService.SECTIONS[_parentSName]['errors'] === 0) {
      this.stateService.SECTIONS[_parentSName]['status'] = 'complete';
    }
    this.stateService.SECTIONS[_parentSName]['istouched'] = istouched;
    this.stateService.isApplicationReadyToAction = true;
    // tslint:disable-next-line: max-line-length
    console.log('%c SECTIONS FOR ERRORS >>> ', 'background: yellow; color: red;font-weight: bold;', this.stateService.SECTIONS[this.parentSectionName]);
  }

  highlightInvalidFields(_formArr) {
    if (this.stateService && this.stateService.SECTIONS && this.parentSectionName && this.sectionName &&
      this.stateService.SECTIONS[this.parentSectionName] &&
      this.stateService.SECTIONS[this.parentSectionName][this.sectionName] &&
      this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['invalidFields']) {
      if (!UtilMethodsService.isEmpty(this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['invalidFields'])) {
        const _fields = this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['invalidFields'];
        _fields.forEach(_flds => {
          const _ele = _formArr && _formArr.get(_flds);
          const _errors = _ele && _ele.errors;
          console.log(_ele, ' <<< hghlt >>> ', _errors);
          if (_ele && _errors && !UtilMethodsService.isEmpty(this.componentStaticQuestionStack)) {
            this.isValid(this.componentStaticQuestionStack[_flds], this.stateService.screenMapObject[_flds], _errors);
          }
        });
      }
    }
  }

  showPageError(snackBar, _focuInitialField) {
    if (this.stateService.SECTIONS[this.parentSectionName]['istouched'] === false) {
      this.showBanner(snackBar, 'Please enter all the values', BaseFormComponent.ERROR_BAR);
    } else if (this.stateService.SECTIONS[this.parentSectionName]['istouched'] === true) {
      // const _errTxt = 'There are ' + this.stateService.SECTIONS[this.parentSectionName]['errors'] + ' invalid fields on this page.';
      let _errTxt;
      if (!UtilMethodsService.isEmpty(this.stateService.SECTIONS[this.parentSectionName]['msg'])) {
        _errTxt = this.stateService.SECTIONS[this.parentSectionName]['msg'];
      } else {
        _errTxt = 'Please enter all the values';
      }

      this.showBanner(snackBar, _errTxt, BaseFormComponent.ERROR_BAR, 10);
      // if (_focuInitialField &&
      //   this.stateService.SECTIONS[this.parentSectionName] &&
      //   this.stateService.SECTIONS[this.parentSectionName][this.sectionName] &&
      //   this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['invalidFields']) {
      //   const _invalidFields = this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['invalidFields'];
      //   if (_invalidFields && _invalidFields.length > 0) {
      //     _invalidFields[0].focus();
      //   }
      // }
    }
  }

  getTotalRequiredFieldsForSection() {
    const types = ['input', 'select', 'mat-select', 'mat-checkbox', 'mat-radio-group', 'mat-checkbox-layout', 'textarea'];
    let inputs;
    let input;
    // let firstInvalidField = null;
    if (this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['istouched'] === false) {
      for (const type of types) {
        inputs = document.getElementsByTagName(type);
        if (inputs) {
          for (let i = 0; i < inputs.length; i++) {
            input = inputs[i];
            let _id;
            if (type === 'mat-checkbox') {
              _id = String(input.id).split('-')[0];
            } else {
              _id = input.id;
            }
            if (this.componentStaticQuestionStack[_id] &&
              !UtilMethodsService.isEmpty(this.componentStaticQuestionStack[_id].validations)) {
              if (this.isRequired(this.componentStaticQuestionStack[_id].validations)) {
                this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['requiredFields']++;
              }
            }
          }
        }
      }
    }
    this.validatePage(false, [], null);
    // tslint:disable-next-line: max-line-length
    if (this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['requiredFields'] === 0 && this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['errors'] === 0) {
      if (this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['istouched'] === false) {
        this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['istouched'] = true;
      }
    }
  }

  /*
     * Validates all elements and returns the number of errors encountered.
     * @param firstInvalidFieldFocus
     * @param exceptions (optional)
     */
  validateAllElements(firstInvalidFieldFocus?: boolean, exceptions?: any): number {
    const fieldfocus = firstInvalidFieldFocus === undefined ? true : firstInvalidFieldFocus;
    let nbrErrors = 0;
    const me = this;
    const types = ['input', 'select', 'mat-select', 'mat-checkbox', 'mat-radio-group', 'mat-checkbox-layout', 'textarea'];
    let inputs;
    let input;
    // let firstInvalidField = null;
    for (const type of types) {
      inputs = document.getElementsByTagName(type);
      if (inputs) {
        for (let i = 0; i < inputs.length; i++) {
          input = inputs[i];
          if (UtilMethodsService.isEmpty(exceptions) || exceptions.indexOf(input.id) < 0) {
            if (this.form) { // } && this.form.get(input.id)) {
              let _id;
              if (type === 'mat-checkbox') {
                _id = String(input.id).split('-')[0];
              } else {
                _id = input.id;
              }
              if (this.form.get(_id)) {
                const _errors = this.form.get(_id).errors;
                if (!UtilMethodsService.isEmpty(this.componentStaticQuestionStack[_id]) &&
                  (this.isRequired(this.componentStaticQuestionStack[_id].validations) ||
                    (this.isRequired(this.componentStaticQuestionStack[_id].validations) === false &&
                      !UtilMethodsService.isEmpty(this.stateService.screenMapObject[_id])))) {
                  if (!UtilMethodsService.isEmpty(_errors)) {
                    input.classList.add(this.TN_FORM_ELE_INVALID);
                    nbrErrors++;
                  } else {
                    if (!UtilMethodsService.isEmpty(Validation.getValidationErrorMsg(this.componentStaticQuestionStack[_id],
                      this.stateService.screenMapObject[_id], _errors, this.stateService))) {
                      input.classList.add(this.TN_FORM_ELE_INVALID);
                      nbrErrors++;
                    } else {
                      input.classList.remove(this.TN_FORM_ELE_INVALID);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if (this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['istouched'] === false) {
      this.stateService.SECTIONS[this.parentSectionName][this.sectionName]['istouched'] = true;
    }

    const assignInvalidFlds = function() {
      const invalidFields = me.extractInvalidFieldNames(document.getElementsByClassName(me.TN_FORM_ELE_INVALID));
      if (me.parentSectionName && me.sectionName && me.stateService.SECTIONS &&
        me.stateService.SECTIONS[me.parentSectionName][me.sectionName]) {
        me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['invalidFields'] = new Array([]);
        me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['invalidFields'] =
          UtilMethodsService.copyObject(invalidFields);
      }
    };
    const assngInvldFldsDC = me.transService.debounce(assignInvalidFlds, 100);
    assngInvldFldsDC();


    return nbrErrors;
  }

  extractInvalidFieldNames(_invalidFields) {
    const _InVfieldNameArr = [];
    if (!UtilMethodsService.isEmpty(_invalidFields)) {
      for (let i = 0; i < _invalidFields.length; i++) {
        const _id = String(_invalidFields[i].id).split('-');
        const _idx = _InVfieldNameArr.findIndex(_fldId => {
          return _id[0] === _fldId;
        });
        if (_idx < 0) {
          _InVfieldNameArr.push(_id[0]);
        }
      }
    }
    return UtilMethodsService.copyObject(_InVfieldNameArr);
  }

  validatePage(firstInvalidFieldFocus?: boolean, exceptions?: any, callback?: Function) {
    const me = this;
    if (!this.isCustomPageValidationRequired) {
      if (!this.parentSectionName || !this.sectionName) {
        return;
      }
      this.stateService.SECTIONS[this.parentSectionName]['msg'] = '';
      if (me.stateService.SECTIONS && me.parentSectionName && me.sectionName) {
        if (this.stateService.SECTIONS[this.parentSectionName]) {
          this.stateService.SECTIONS[this.parentSectionName]['errors'] = 0;
        }
        if (me.stateService.SECTIONS[me.parentSectionName][me.sectionName]) {
          me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['errors'] = 0;
        }
        if (this.configurationType === BaseFormComponent.CONFIG_SINGLE) {
          // tslint:disable-next-line:no-eval
          if (eval(this.modelName)) {
            if (me.stateService.SECTIONS[me.parentSectionName][me.sectionName]) {
              me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['errors'] +=
                // tslint:disable-next-line:no-eval
                eval(this.modelName).getCustomPageValidation(me.associatedProduct, me.parentSectionName, me.stateService);
            }
          }
        } else {
          this.stateService.insuranceSelected.forEach((_insuranceType) => {
            // tslint:disable-next-line:no-eval
            if (eval(this.modelName)) {
              if (me.stateService.SECTIONS[me.parentSectionName][me.sectionName]) {
                // tslint:disable-next-line:no-eval
                me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['errors'] +=
                  // tslint:disable-next-line:no-eval
                  eval(this.modelName).getCustomPageValidation(_insuranceType, me.parentSectionName, me.stateService);
              }
            }
          });
        }
        if (me.stateService.SECTIONS[me.parentSectionName][me.sectionName]) {
          me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['errors'] +=
            me.validateAllElements(firstInvalidFieldFocus, exceptions);
        }
      }
    } else {
      // this.isCustomPageValidationRequired = false;
      if (this.parentSectionName) {
        this.stateService.SECTIONS[this.parentSectionName]['msg'] = '';
        if (me.stateService.SECTIONS[me.parentSectionName]) {
          me.stateService.SECTIONS[me.parentSectionName]['errors'] = 0;
        }
      }
      if (this.parentSectionName && this.sectionName) {
        if (me.stateService.SECTIONS[me.parentSectionName][me.sectionName]) {
          me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['errors'] = 0;
        }
      }
      if (me.stateService.SECTIONS && me.parentSectionName && me.modelName) {
        // tslint:disable-next-line:no-eval
        if (eval(this.modelName)) {
          if (me.stateService.SECTIONS[me.parentSectionName]) {
            // tslint:disable-next-line:no-eval
            me.stateService.SECTIONS[me.parentSectionName]['errors'] +=
              // tslint:disable-next-line:no-eval
              eval(this.modelName).getCustomPageValidation(this.stateService.insuranceSelected[0], me.parentSectionName, me.stateService);
          }
        }
      }
      if (this.parentSectionName && this.sectionName) {
        me.stateService.SECTIONS[me.parentSectionName][me.sectionName]['errors'] +=
          me.validateAllElements(firstInvalidFieldFocus, exceptions);
      }
    }
    me.checkIfPageValidForNavigation();
  }

  setDelay(callback: Function, milliseconds?: number) {
    if (callback) {
      const delay = milliseconds || 250;
      setTimeout(() => {
        callback();
      }, delay);
    }
  }

  getDate(dateType: string, days?: number) {
    switch (dateType) {
      case 'todaysDate':
        return new Date();
        break;
      case 'futureDate':
        return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
        break;
      case 'pastDate':
        return new Date(Date.now() - days * 24 * 60 * 60 * 1000);
        break;
      default:
        return new Date();
    }
  }

  formatAddress(_stateService?: StateService) {
    const stateLabel = new GetLabelPipe(_stateService).transform(this.stateService.insuranceDetails.
      questionAnswers[ComparativeConstants.staticQuestionNames.application_state], 'state');
    // tslint:disable-next-line: max-line-length
    const address2 = this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_address2] || '';
    return this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_address1] + ' ' +
      address2 + '\n' +
      this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_city] + ',' + stateLabel +
      ',' + this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode];
  }

  handlCheckBoxChange(eventObj: any, field?: any) {
    if (field && this.isRequired(field.validations)) {
      if (eventObj.checked) {
        this.form.get(eventObj.fieldName.name).setValue(true);
        this.form.get(eventObj.fieldName.name).setErrors(null);
      } else {
        this.form.get(eventObj.fieldName.name).setValue(null);
        this.form.get(eventObj.fieldName.name).setErrors({ 'required': true });
      }
    }
  }

  onMultiCheckBoxChange(event: any, field: any) {
    if (event.checked) {
      this.onFocus(event, field);
    } else {
      this.onFocusOut(event, field);
    }
  }

  onSelectChange(event: any, field: any) {
  }

  onDateChange(event: any, field: any) {
  }

  onSelectWithSearchChange(event: any, field: any) { }

  resetKnockOutQuestions(event) {
    event.emit('profession/state change');
    const dynamicQuesKeys = Object.keys(this.stateService.insuranceDetails.questionAnswers.dynamicQuestions);
    if (dynamicQuesKeys.length) {
      dynamicQuesKeys.forEach((key) => {
        if (!ComparativeConstants.EPLI_KOQUES.includes(key)) {
          delete this.stateService.insuranceDetails.questionAnswers.dynamicQuestions[key];
          delete this.stateService.screenMapObject[key];
        }
      });
      // this.stateService.insuranceDetails.questionAnswers.dynamicQuestions = {};
    }
    this.removeKOQuestion(this.stateService.screenMapObject);
    this.validatePage(false, null, null);
  }

  removeKOQuestion(obj: Object) {
    const staticQueskeys = Object.values(ComparativeConstants.staticQuestionNames);
    Object.entries(obj).forEach(([key, value]) => {
      if (!staticQueskeys.includes(key)) {
        delete obj[key];
      }
    });
  }

  checkIfPremiumParams(_name, value) {
    this.stateService.insuranceSelected.forEach((_insuranceType) => {
      const key = _insuranceType.toString().toUpperCase() + '_' + ComparativeConstants.DEDUCTIBLE;
      if (_name.indexOf(key) > -1) {
        this.stateService.insuranceDetails.questionAnswers[key] = value;
      }
    });
  }

  onInputChange(event: any, field: any) {
  }

  snackBarErrorMsg(err) {
    if (!UtilMethodsService.isEmpty(err.error) &&
      !UtilMethodsService.isEmpty(err.error.message)) {
      if (!UtilMethodsService.isEmpty(err.error.errors) && Array.isArray(err.error.errors)) {
        return `${err.error.errors[0]}`;
      } else {
        return err.error.message;
      }
    } else {
      return this.comparativeConstants.DEFAULT_ERROR_MSG;
    }
  }

  /**
   * This method is used to disable prepopulated user details on get quote and applicant details page
   * @param _insuranceDetails - insurance details from state service
   * @param _currentForm - pass current form
   */
  disableFormControls(_isPrepopulateUserDetails, _currentForm, _isStateCityDisable?) {
    if (_isStateCityDisable) {
      this.comparativeConstants.DISABLE_STATE_CITY.forEach(_controlName => {
        if (!UtilMethodsService.isEmpty(_currentForm.controls[_controlName])) {
          _currentForm.controls[_controlName].disable();
        }
      });
    }

    if (_isPrepopulateUserDetails) {
      this.comparativeConstants.DISABLE_FORM_CONTROLS.forEach(_controlName => {
        if (!UtilMethodsService.isEmpty(_currentForm.controls[_controlName])) {
          _currentForm.controls[_controlName].disable();
        }
      });
    }
  }

  ngOnDestroy() {

  }

  disableControl(controls) {
    const quesNameKeys = Object.keys(controls);
    quesNameKeys.forEach((_quesname) => {
      if (ComparativeConstants.QUESTIONTODISABLE.includes(_quesname)) {
        if (this.form && this.form.controls && this.form.controls[_quesname]) {
          this.form.controls[_quesname].disable();
        }
      }
    });
  }

  getDisplayAmount(amount, decimalNotRequired = false) {
    return DirectiveValidationService.formatMoney(amount, decimalNotRequired);
  }

  getNumberFormat(num): number {
    return Number(DirectiveValidationService.toRawNumber(num));
  }
}
