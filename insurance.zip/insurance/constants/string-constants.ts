import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})

export class StringConstants {
  public static PAYMENT_CUST_ERR_MSG_PAYMETHOD_SEL = 'Please select payment method';
  public static PAYMENT_CUST_ERR_MSG_FILE_UPLOAD = 'Please upload required documents';
  public static YOUR_QOT_CUST_ERR_MSG_PREM_SEL = 'Please select premium option';
  public static CUSTOM_VALIDATION_MSG = {
    'totalEmpExceedsLimit': 'Your total current year employee exceeds 19 hence insurance maximum limit is $100k.',
    'antiDiscrimination': `You don't provide training for anti-discrimination or anti-sexual harassment and other written policies
     hence the maximum limit of insurance is $50K.`,
    'contractOf50000': `You have 50 or more employees for the current year hence the maximum limit of insurance is $50K.`,
    'max50kLimit': 'Your limit of insurance is $50k.',
    'numberOfEmpTerminatedInvo1YearAgo': `Even if a single person is Involuntary Terminated in current or
    previous year then maximum limit is $50k`,
    'newYorkAntiDiscrimination': `You don't provide training for anti-discrimination or anti-sexual harassment and other written policies
     hence the maximum limit of insurance is $100K.`,
    'newYorkContractOf100000': `You have 50 or more employees for the current year hence the maximum limit of insurance is $100K.`,
    'newYorkMax100kLimit': 'Your limit of insurance is $100k.',
    'newYorkEmployAbove50Salary50K': 'For total employees more than 50 and salary more than $50K than maximum limit of insurance is $100K.',
    'newYorkNumberOfEmpTerminatedInvo1YearAgo': `Even if a single person is Involuntary Terminated in current or
    previous year then maximum limit is $100k`,
    'maxLimit250k': `Your limit of insurance is $250k.`,
    'deductibleAmount': `For a deductible contribution of $2,500 limit of Insurance available is $50,000`,
  };

  public GET_QUOTE_HEADING = {
    'pnl': 'Professional Liability',
    'cyber': 'Cyber',
    'epli': 'Employment Practices Liability',
  };

  public AGGREGATE_LIMIT_KEY = {
    'pnl': 'PNL_insuranceLimitToPurchase',
    'cyber': 'CYBER_insuranceLimitToPurchase',
    'epli': 'EPLI_insuranceLimitToPurchase',
  };

  public DEDUCTIBLE_KEY = {
    'pnl': 'PNL_deductibleToPurchase',
    'cyber': 'CYBER_deductibleToPurchase',
    'epli': 'EPLI_deductibleToPurchase',
  };

  public INSURANCE_ACCORDIAN_PANEL1_HEADING = {
    'pnl': 'Applicant Details<span class="mat-insurance-required-icon">*</span>',
    'cyber': 'Contact Details<span class="mat-insurance-required-icon">*</span>',
    'epli': 'Organizational Information<span class="mat-insurance-required-icon">*</span>',
  };
  public INSURANCE_ACCORDIAN_PANEL2_HEADING = {
    'pnl': 'Business Details for Professional Liability<span class="mat-insurance-required-icon">*</span>',
    'cyber': 'Business Details for Cyber Insurance<span class="mat-insurance-required-icon">*</span>',
    'epli': 'Employment Practices<span class="mat-insurance-required-icon">*</span>',
  };
  public INSURANCE_ACCORDIAN_PANEL3_HEADING = {
    'pnl': 'Prior Claims and Circumstances<span class="mat-insurance-required-icon">*</span>',
    'cyber': 'Business Information Security Details<span class="mat-insurance-required-icon">*</span>',
    'epli': 'Loss History<span class="mat-insurance-required-icon">*</span>',
  };
  public INSURANCE_ACCORDIAN_PANEL4_HEADING = {
    'epli': 'Representation<span class="mat-insurance-required-icon">*</span>',
  };
  public YOUR_QUOTE_TITLE = 'Your Quote';
  public YOUR_QUOTE_SINGLE_ANNUAL_PAY = 'Annual Premium - ';
  public PAY_METHOD_MONTHLY_PAYMENT_PLAN = 'Payment Plan - ';
  public PAY_METHOD_MONTHLY_PREMIUM_PAYMENT_PLAN = 'Monthly Plan - ';
  public PAY_METHOD_PROFESS_ANNUAL_PAY = 'Annual Premium - $';
  public PAY_METHOD_PROFESS_MONTHLY_PAY = 'Monthly Pay - $';
  public PAYMENT_YEARLY = 'Yearly';
  public PAYMENT_MONTHLY = 'Monthly';
  public File_DWLD_UNAVAILABLE = 'This file is currently not available for download.';
  public YOUR_QUOTE_COVERAGE_INCLUDES = {
    'pnl': [{
      'label': 'This Coverage Includes:',
      'description': '<div>- Defense expense for covered claims</div>'
        + '<div>- Alleged or actual negligence related to providing covered professional services to others</div>'
        + '<div>- Libel and/or slander in connection with covered claims situations</div>'
        + '<div>- Employee, temporary staff, and independent contractor negligence related to the delivery of professional services</div>'
        + '<div>- Amounts of monetary settlement or judgement subject to policy limits and deductible amounts</div>'
        + '<div>- Multiple claims during the policy period</div>',
    }],
    'cyber': [{
      'label': 'Breach response',
      'description': '<div>- Legal services</div>'
        + '<div>- Computer forensic services</div>'
        + '<div>- Public relations and crisis management expenses</div>'
        + '<div>- Notification services</div>'
        + '<div>- Call center services</div>'
        + '<div>- Credit monitoring, identity monitoring or other personal fraud or loss prevention solutions</div>',
    },
    {
      'label': 'First party',
      'description': '<div>- Violations of Privacy Law</div>'
        + '<div>- Business interruption loss from security breach or system failure</div>'
        + '<div>- Cyber extortion loss</div>'
        + '<div>- Data recovery loss</div>',
    },
    {
      'label': 'Third party coverage',
      'description': '<div>- Indemnity and defense for covered lawsuits and losses</div>'
        + '<div>- Third party information security and privacy coverage</div>'
        + '<div>- Website media liability </div>'
        + '<div>- Regulatory defense and penalties</div>'
        + '<div>- Payment card fines and costs</div>',
    }],
    'epli': [{
      'label': 'This Coverage Includes:',
      'description': '<div>- Coverage is provided on a "duty to defend" basis, for covered claim</div>'
        + '<div>- Coverage applies to situations described as covered within the policy, '
        + 'subject to the limit of insurance and per claim retention (deductible) amount, '
        + 'and the limit includes defense expenses, as well as settlements and/or judgements</div>'
        + '<div>- Coverage applies to claims made against directors, officers and employees (including temporary employees)</div>'
        + '<div>- Claims are covered when reported within the policy period, if having occurred after '
        + 'the indicated retroactive date on the policy</div>'
        + '<div>- The policy territory is worldwide, provided the suit for damages is filed in the USA, '
        + 'its territories/possessions, or Canada</div>'
        + '<div>- Loss includes punitive damages, where allowable by law</div>'
        + '<div>- In addition to basic coverage provided for "discrimination", "harassment", and "retaliation", '
        + 'coverage also applies to "inappropriate employment conduct", as defined in the policy</div>'
        + '<div>- Insureds must consent to settle covered claims (if consent is withheld, coverage still applies, '
        + 'on a pro-rata basis, relative to the final settlement)</div>',
    }],
  };
  public AGREEMENT_TITLE = 'Agreement';
  public IMPORTANT_LEGAL_INFO_SIGN = 'Please read and sign';
  public AGREEMENT_TERMS = 'Terms & Conditions';
  public FRAUD_AND_WARNING_TITLE = 'Fraud Warning Disclosure';
  public AGREEMENT_AUTH_SIGN_APPLI_AGREE = 'Applicant’s Authorized to Signature Application Agree:';
  public AGREEMENT_TXT1 = 'The undersigned is authorized by the applicant to sign this application on the applicant’s behalf and declares'
    + ' that the statements set forth herein and all written statements and materials furnished to the insurer in conjunction with this '
    + 'application are true. Signing of this application does not bind the applicant or the insurer to complete the insurance, but '
    + ' the statements contained in this application, any supplemental applications, and the materials submitted herewith are the basis of'
    + ' the contract should a policy be issued and have been relied upon by the insurer in issuing any policy.'
    + '<br/><br/>'
    + 'Thisapplication and materials submitted with its stall be retained on file with the insurer and shall be deemed attached to '
    + ' part of the policy if issued. The insurer is authorized to make any investigation and inquiry in connection with this application'
    + ' it deems necessary.'
    + '<br/><br/>'
    + 'The applicant agrees that if the information supplied on this application changes between the date of this application and the '
    + 'effective date of the insurance, the applicant will, in order for the information to be accurate on the effective date of the '
    + 'insurance, immediately notify the insurer of such changes, and the insurer may withdraw or modify any outstanding quotations'
    + ' or authorizations or agreements to bind the insurance.'
    + '<br/><br/>';
  public AGREEMENT_TXT2 = 'I have read the foregoing application for insurance and represent that the responses provided'
    + 'on behalf of the applicant are true and correct.';
  public AGREEMENT_TXT3 = 'Signature <br/>'
    + 'Section'
    + '<br/><br/>'
    + 'The undersigned authorized employee of the applicant declares that the statements set forth herein are true. The undersigned '
    + 'authorized employee agrees that if the information supplied on this application changes between the date of this application and'
    + ' the effective date of the insurance, he/she will, in order for the information to be accurate on the effective date of the '
    + ' insurance, immediately notify the underwriter of such changes and the underwriter may withdraw or modify and outstanding quotations'
    + ' or authorizations or agreements to bind the insurance. For New Hampshire applicants, the foregoing statement is limited to'
    + 'the best of the undersigned’s knowledge, after reasonable inquiry. In Maine, the underwriters may modify but may not withdraw'
    + ' and outstanding quotations or authorizations or agreements to bind the insurance.'
    + '<br/><br/>'
    + 'Nothing'
    + 'contained herein or incorporated herein by reference shall constitute notice of a claim or potential claim to trigger coverage'
    + ' under any contract of insurance. No coverage shall be afforded for any claims arising out of a circumstance not disclosed in'
    + ' this application.';
  public FIELDS_MARKED_REQUIRED = 'Fields marked with <span class="mat-insurance-required-icon">*</span> are required';
  public YOUR_PRODUCTS = 'Your Products';
  public SIMILAR_PRODUCTS = 'Similar Products';
  public CUSTOMERS_BOUGHT_THESE_PRODUCTS = 'Customers like you also bought these products:';
  public SIGN_BY = 'Signed by ';
  public INSURANCE_BOX_HEADING_TEXT = 'Please fill in the Insurance details';
  public CONTACT_DETAIL_TOOLTIP_TEXT = `Details to apply for the Insurance policy`;
  public BUSINESS_DETAIL_TOOLTIP_TEXT = `Business detail help text is yet to confirm!
   Edit me in in string constant once get final confirmation.`;
  public PRODUCT_TITLE_IMG = {
    'pnl': 'assets/img/pl-icon.svg',
    'cyber': 'assets/img/cyber_get_quotes_icon.svg',
    'epli': 'assets/img/cyber_get_quotes_icon.svg',
  };
  public PRODUCT_INFO_COVERS = 'Insurance Covers:';
  public PRODUCT_INFO = {
    'pnl': '<ul class="product-list"><li>'
      + 'Defense expense for covered claims'
      + '</li><li>'
      + 'Alleged or actual negligence related to providing covered professional services to others'
      + '</li><li>'
      + 'Libel and/or slander in connection with covered claims situations'
      + '</li><li>'
      + 'Employee, temporary staff, and independent contractor negligence related to the delivery of professional services'
      + '</li><li>'
      + 'Amounts of monetary settlement or judgement subject to policy limits and deductible amounts'
      + '</li><li>'
      + 'Multiple claims during the policy period'
      + '</li></ul>',

    'cyber': '<hr class="cyber-product-list-separator">'
      + '<div  fxLayout="row" fxLayoutAlign="space-between none" fxLayoutGap="10px" fxLayout.xs="column">'
      // tslint:disable-next-line:max-line-length
      + '<div class="cyber-product-list-container" fxLayout="row" fxLayout.xs="column" fxLayoutGap="20px" fxLayout.xs="column" fxLayoutAlign="space-between none">'
      + '<div class="cyber-product-list-fxflex" fxFlex="33.3%" ><b>Breach response</b>'
      + '<ul><li>Legal services</li>'
      + '<li>Computer forensic services</li>'
      + '<li>Public relations and crisis management expenses</li>'
      + '<li>Notification services</li>'
      + '<li>Call center services</li>'
      + '<li>Credit monitoring, identity monitoring or other personal fraud or loss prevention solutions</li></ul>'
      + '</div>'
      + '<span class="cyber-product-list-vertical-line">&nbsp;&nbsp;</span>'
      + '<div class="cyber-product-list-fxflex" fxFlex="33.3%" ><b>First party</b>'
      + '<ul><li>Business interruption loss from security breach or system failure</li>'
      + '<li>Cyber extortion loss</li>'
      + '<li>Data recovery loss</li></ul>'
      + '</div>'
      + '<span class="cyber-product-list-vertical-line">&nbsp;&nbsp;</span>'
      + '<div class="cyber-product-list-fxflex" fxFlex="33.3%" ><b>Third party coverage</b>'
      + '<ul><li>Indemnity and defense for covered lawsuits and losses</li>'
      + '<li>Third party information security and privacy coverage</li>'
      + '<li>Website media liability</li>'
      + '<li>Regulatory defense and penalties</li>'
      + '<li>Payment card fines and costs</li></ul>'
      + '</div>'
      + '</div></div>',

    'epli': '<ul class="product-list"><li>'
      + 'Coverage is provided on a "duty to defend" basis, for covered claim</li>'
      + '<li>Coverage applies to situations described as covered within the policy, '
      + 'subject to the limit of insurance and per claim retention (deductible) amount, '
      + 'and the limit includes defense expenses, as well as settlements and/or judgements</li>'
      + '<li>Coverage applies to claims made against directors, officers and employees (including temporary employees)</li>'
      + '<li>Claims are covered when reported within the policy period, if having occurred after '
      + 'the indicated retroactive date on the policy</li>'
      + '<li>The policy territory is worldwide, provided the suit for damages is filed in the USA, '
      + 'its territories/possessions, or Canada</li>'
      + '<li>Loss includes punitive damages, where allowable by law</li>'
      + '<li>In addition to basic coverage provided for "discrimination", "harassment", and "retaliation", '
      + 'coverage also applies to "inappropriate employment conduct", as defined in the policy</li>'
      + '<li>Insureds must consent to settle covered claims (if consent is withheld, coverage still applies, '
      + 'on a pro-rata basis, relative to the final settlement)'
      + '</li></ul>',

  };
  public AGREEMENT_POPUP = {
    'pnl': 'Please read the terms and conditions and click the check box to continue',
    'cyber': 'Please read the terms and conditions and click the check box to continue',
    'epli': 'Please read the terms and conditions and click the check box to continue',
  };
  public SIMILAR_PRODUCT = {
    'pnl': [{
      'name': 'General Liability',
      'newOrPopular': 'New',
      'description': 'This covers injury to a third party (including related medical expenses) or damage to someone'
        + 'else’s property. Claims of libel and slander arising from your services are also covered.',
    },
    {
      'name': 'Cyber Security',
      'newOrPopular': 'Popular',
      'description': 'If your business handles customer and employee data, like credit card details and personal '
        + 'information, your cyber insurance policy covers the following'
        + 'in the event of a loss resulting from a cyber attack or cyber crime.',
    }],
    'cyber': [{
      'name': 'General Liability',
      'newOrPopular': 'New',
      'description': 'This covers injury to a third party (including related medical expenses) or damage to someone'
        + 'else’s property. Claims of libel and slander arising from your services are also covered.',
    }],
    'epli': [{
      'name': 'Business  Owner\'s Policy',
      'newOrPopular': 'New',
      'description': 'A Business Owners Policy (BOP) is an enhanced insurance policy'
        + 'that combines general liability insurance and property insurance.',
    }],
  };

  public PAYMENT_METHOD = 'Payment Method';
  public CLEAR = 'clear';
  public PLEASE_LOGIN = 'If already have an account, please login to complete the purchase';
  public SIGN_IN = 'Sign In';
  public FORGOT_PWD = 'Forgot Password?';

  public SUMMARY = 'Summary';
  public PROFESSION = 'Profession';
  public STATE = 'State';
  public CONTACT_DETAILS = 'Contact Details';
  public BUSINESS_OWNER = 'Business Owner';
  public EMAIL_ADDRESS = 'Email Address';
  public BUSINESS_NAME = 'Business Name';
  public APPLICANT_DETAILS = 'Applicant Details';
  public FIRST_NAME = 'First Name';
  public LAST_NAME = 'Last Name';
  public PHONE = 'Phone';
  public AGGREGATE_LIMIT = 'Aggregate Limit';
  public YOUR_QUOTE = 'Your Quote';
  public SELECTED_PLAN = 'Selected plan';
  public QUICK_PURCHASE_SUMMARY = 'Quick Purchase Summary';
  public NAME_INSURED = 'Name Insured';
  public EMAIL = 'Email';
  public ADDRESS = 'Address';
  public INSURANCE = 'Insurance';
  public POLICY_NO = 'Policy No.';
  public INSURANCE_TERM = 'Insurance Term';
  public AGGREGATE = 'Aggregate';
  public DEDUCTIBLE = 'Deductible';
  public PAYMENT_PLAN = 'Payment Plan';
  public INVOICE_NO = 'Invoice No.';
  public AMOUNT_PAID = 'Amount Paid';
  public CONTINUE_CREATE_ACCOUNT = 'Continue to Create Your Account';
  public THE_EMAIL_ADDRESS = 'The email address ';
  public EMAIL_ALREADY_REGISTERED = ' you have entered is already registered. ';
  public PWD_LENGTH = 'Your password must be at least 10 characters long.';
  public PWD_MUST_ALPHANUMERIC = 'Your password must include at least one alphabet and one number.';
  public PWS_DONOT_MATCH = 'Password do not match';
  public SANCTIONSTATE_SEL_MESSAGE = 'Product is not available for sale in selected state - ';
  public PREMIUM_CALC_MESG = 'Premium calculated:';
  public CONFIRMATION_MSG_SUCCESS_1 = 'Congratulations, ';
  public APPLICATION_SAVED = 'Application saved!';
  public MANDATORY_ADDR_ERROR = 'Please add address details to save application';
  public MANDATORY_BUSINESSNAME_ERROR = 'Please add business name to save application';
  public CONFIRMATION_MSG_SUCCESS_2 = '! You have successfully purchased the Professional Liability Policy.';
  public APPLICATION_STATUS = 'Application Status: ';
  public CONTACT_INFO = 'For any questions about your policy, please contact us at 800-221-3662.';
  public CONFIRMATION_MSG_DOWNLOAD = 'Download your policy documents, We have also emailed you a copy of your'
    + ' application and the policy documents to';
  public ONLY_INPROGRESS_CAN_EDIT = 'Insurance with type In Progress can only be opend for editing';
  public UNAUTHORIZED_ACCESS = 'Access is Denied. User is not authorized to access this resource.';
  public STATUS_DECLINED = 'Declined';
  public DEFAULT_PAYMENT_METHOD = {
    'cyber': 'annualPay',
  };
  public DUMMY_HELP_TEXT = `help text is yet to confirm from Business!
         Edit me in in string constant once get final confirmation.`;
  public YOUR_QUOTE_PRODUCT_INFORMATION_HELP_TEXT = 'You can choose a different Aggregate limit and Deductible amount';
  public PURCHASE_SUMMARY = 'Purchase Summary';
  public COMPLETED = 'Completed';
  public INSURANCE_ONLINE_APPLIC = 'Online application';
  public POLICY = ' Policy';
  public SINGLE_ANNUAL_PAY = 'Annual Premium';
  public APPLICATION_NOT_SAVED = `Cannot save application due to Data Mismatch. Press continue to proceed with Logged Profile details.`;
  public YOUR_QUOTE_INSTALLMENTS_HELP_TEXT = 'due at start (2 payments), 10 monthly installments due thereafter';
  public CLIENT_LOGIN_AS_AGENT = `Log in as non insurance agent`;
  public EMAIL_SUCCESS = `Email sent successfully!`;
  public FILE_INVALID_EXTENSION = 'Invalid file extension';
  public FILE_UPLOAD_ERROR = 'Document upload failed';
  public APPLICANTID_NOTFOUND = 'Applicant Id is not exist';
  public FILE_UPLOAD_SUCCESS = 'The document has beeen uploaded successfully';
  public PDF_HEADINGS = {
    'pnl': 'Professional Liability Insurance',
    'cyber': 'Cyber Liability Insurance',
    'epli': 'EPLI',
  };
  public SELECT_PAYMENT_METHOD_TITLE = 'Please select your desired Payment method';
  public ROLE_TPA = 'ROLE_TPA';
  public SELECT_COVERAGE_LIMIT = 'Select Your Coverage Limit';
  public CONFIRM_YOUR_QUOTE_BACK = 'Going back & making any changes to the previously answered questions, may result in changes'
    + ' to the Coverage Limit, Deductible and the final Premium.';
}

