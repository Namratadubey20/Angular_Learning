import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})

export class UrlConstant {
  public GET_STATE = 'api/insurance/states';
  public GET_SANCTIONED_STATE = 'api/insurance/sanctioned-states/{productTypeCode}';
  public GET_PROFESSION = 'api/insurance/professions-by-producttype/{productTypeCode}';
  public GET_ZIPFROMADDRESS = 'api/util/usps/zip/{zipCode}';
  public GET_SAVED_CARDS_PROFILE = 'api/billing-profile/person';
  public GET_PAYMENT_METHOD = 'api/payment-plan-type/calculated/list/application';
  public GET_SAVED_CARDS_AVAILABILITY = 'api/billing-profile/availability';
  // tslint:disable-next-line:max-line-length
  public GET_KO_QUESTIONS = 'api/insurance/ko-questions?productTypeCode={productTypeCode}&stateCode={stateCode}&professionCode={professionCode}';
  public GET_STATIC_QUESTIONS = 'api/insurance/static-questions-by-producttype/{productTypeCode}';
  public POST_CREATE_APPLICATION = 'api/application/';
  public POST_PREMIUM_CALCULATOR = '/api/insurance/premium-calculator/';
  public PUT_UPDATE_APPLICATION = 'api/application/{productTypeCode}/{applicationId}';
  public PUT_SAVE_APPLICATION = 'api/application/{productTypeCode}/save-for-later/{applicationId}';
  public PUT_SUBMIT_APPLICATION = 'api/application/submit/{productTypeCode}/{applicationId}';
  public SIGNUP = 'api/account/client';
  public GET_APPLICATION_DATA = 'api/application/{applicationId}';
  public AGREEMENT_TERMS = '/api/insurance/tnc/{productTypeCode}';
  public POST_SAVE_ANONYMOUS_QUOTE = '/api/insurance/premium-calculator/quote';
  public GET_PRODUCT = '/api/product/{productId}';
  public GET_PRODUCT_DOCUMENT = 'api/product-document?productId={productId}';
  public GET_SUCCESS_DECLINE = 'api/insurance/insurance-parameter?productCode={productCode}&parameterName={parameterName}';
  public GET_DOWNLOAD_FILE = 'api/file/content/{fileId}';
  public GET_FILE_CONTENT = 'api/file/content/';
  public GET_INSURANCE_LIMIT = '/api/insurance/limit-options/{professionCode}';
  public GET_CLIENT_DETAILS_BY_TYPE = 'api/client/{clientType}/{clientId}';
  public GET_SEND_TO_CLIENT_DETAIL = 'api/application/hand-off/email/{applicationId}';
  public SEND_MAIL_TO_CLIENT = 'api/application/hand-off/secured/{applicationId}';
  public CLIENT_INFO = '/api/client-info/{clientType}/{clientId}';
  public UPDATE_CLIENT = '/api/client/{agentId}';
  public GET_COMPANY = '/api/person/{applicationId}/company';
  public POST_COMPANY = 'api/person/';
  public BUSINESS_UPDATE = 'api/person-company/{personId}';
}
