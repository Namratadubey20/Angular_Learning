export class ComparativeConstants {
  // Question Type Constants
  public static MULTISELECT_QUESTION_TYPE = 'multiselect';
  public static DATE_QUESTION_TYPE = 'date';
  public static DATE_QUESTION_PHONE = 'textphone';
  public static TEXT_SUBSTR = 'text';
  public static CHECKBOX_QUESTION_TYPE = 'checkbox';
  public static PAYLOAD_EXCEPTION_LIST = ['person', 'data', 'dynamicQuestions', 'paymentMethod'];
  public static INSURANCE_CODE_ARRAY = [
    'Professional Liability Insurance',
    'Cyber Insurance',
    'Employment Practices Liability Insurance',
  ];
  public static COUNTER_DEFAULT_OBJ = {
    'errors': 0,
    'requiredFields': 0,
    'istouched': false,
    'invalidFields': [],
  };
  public static PAYLOAD_INTERFACE = {
    'person': {
      'id': null,
    },
    'agent': {},
    'companyOffice': {},
    'premium': 0,
    'agreeToAutoRenewal': '',
    'data': {
      'applicantId': '',
      'reviewAgentApplication': '',
      'applicantAddress': {
        'city': '',
        'state': '',
        'street1': '',
        'street2': '',
        'zipCode': '',
      },

      'amount': 0,
      'dynamicQuestions': [],
      'paymentMethod': {},
      'premiumCalculation': {},
      'deliveryMethod': {
        'deliveryMethod': 'Email',
      },
      'termsAndConditions': {
        'readAndAgreeToTerms': '',
        'acknowledgeTerms': '',
        'acknowledgeFraudWarning': '',
        'declareTrue': '',
        'premiumAcknowledged': '',
        'signatureName': '',
        'emailSignature': '',
        'companyEmailSignature': '',
        'agreementDate': '',
      },
      'agreeToRenewPolicy': '',
    },
  };
  public static KO_INTERFACE_FOR_Q = {
    'question': {
      'name': null,
    },
    'value': null,
  };

  public static DET_INTERFACE_FOR_Q = {
    'applicationId': '',
    'agreeToAutoRenewal': '',
    'questionAnswers': {
      'dynamicQuestions': {},
      'paymentMethod': {},
      'premiumCalculation': {},
      'agreeToRenewPolicy': '',
    },
    isSetBusinessNameChecked: false,
  };

  public static companyInfo = [{
    'id': null,
    'name': '',
    'companyOffices': [
      {
        'id': null,
        'agentId': null,
        'name': 'company name',
        'address': {
          'street1': '',
          'street2': '',
          'city': '',
          'state': '',
          'zipCode': '',
        },
        'email': null,
        'fax': null,
        'officeType': 'Main',
        'clientsId': null,
        'companyOfficePersons': [
          {
            'id': null,
          },
        ],
      },
    ],
  }];

  public static SECTIONS_INTERFACE = {
    'getQuote': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'productInformation': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'yourQuote': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'agreement': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'payment': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'createUser': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
  };

  public static fieldError = {};
  public static screenMapObject = {};


  public static staticQuestionNames = {
    application_firstName: 'firstName',
    application_lastName: 'lastName',
    application_phone: 'applicantPhone',
    application_email: 'applicantEmail',
    application_state: 'state',
    application_city: 'city',
    application_profession: 'profession',
    application_businessName: 'applicantName',
    application_address1: 'street1',
    application_address2: 'street2',
    application_zipCode: 'zipCode',
    businessStructure: 'businessStructure',
    businessLocations: 'businessLocations',
    policyStartDate: 'policyStartDate',
    application_selectedPlan: 'application_selectedPlan',
    setApplicantName: 'setApplicantName',
    readAndAgreeToTerms: 'readAndAgreeToTerms',
    acknowledgeFraudWarning: 'acknowledgeFraudWarning',
    reviewAgentApplication: 'reviewAgentApplication',
    agreeToRenewPolicy: 'agreeToRenewPolicy',
    acknowledgeTerms: 'acknowledgeTerms',
    yearInBusiness: 'yearInBusiness',
    epli_attach_details: 'attachDetails',
    cyber_attach_details: 'attachDetails',
  };
  public static DEDUCTIBLE = 'deductibleToPurchase';
  public static AGGREGATE = 'insuranceLimitToPurchase';
  public static GROSS_SALE = ['_ESTIMATEDALLGROSSSALESINNEXTTWELVEMONTHS', '_ESTIMATEDCOMMISSIONINNEXTTWELVEMONTHS',
    '_ESTIMATEDGROSSSALESINNEXTTWELVEMONTHS', '_ESTIMATEDGROSSSALESINNEXTYEAR', '_ESTIMATEDREVFORNEXTYEAR'];
  public static YOUR_DEDUCTIBLE = 'deductible';
  public static YOUR_AGGREGATE = 'amount';
  public static SET_BUSINESSNAME_CHECKBOX_ID = 101;

  public static SECTION_COMPLETE_STATUS = {
    'istouched': true,
    'status': 'complete',
    'errors': 0,
    'msg': '',
  };

  public static SUB_SECTION_COMPLETE_STATUS = {
    'errors': 0,
    'requiredFields': 0,
    'istouched': true,
    'invalidFields': [],
  };

  public static SUB_SECTION_INCOMPLETE_STATUS = {
    'errors': 0,
    'requiredFields': 0,
    'istouched': false,
    'invalidFields': [],
  };

  public static GET_QUOTE = 'getQuote';
  public static MAX_DATE = 'maxDate';
  public static PRODUCT_INFORMATION = 'productInformation';
  public static YOUR_QUOTE = 'yourQuote';
  public static AGREEMENT = 'agreement';
  public static PAYMENT = 'payment';
  public static MONTHS_TXT = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

  public static APPLICANT_DETAILS_PAYMENT = {
    'application_firstName': '',
    'application_lastName': '',
    'application_address1': '',
    'application_address2': '',
    'application_city': '',
    'application_state': '',
    'application_zipCode': '',
    'application_phone': '',
  };

  public static defaultPanelName = {
    'cyber': 'applicantDtl',
    'pnl': 'applicantDtl',
    'epli': 'epliApplicantDtl',
  };

  // tslint:disable-next-line: max-line-length
  public static insuranceDetailsPanelNames = ['applicantDtl', 'knockOutPanel', 'SecurityDetailsPanel', 'RepresentationPanel', 'epliApplicantDtl'];

  public static PANEL1_NAMES_PRODUCTWISE = {
    'INSURANCE_ACCORDIAN_PANEL1_SECTION': {
      'cyber': 'applicantDetails',
      'pnl': 'applicantDetails',
      'epli': 'applicantDetails',
    },
  };

  public static SUBSECTION_NAMES_PRODUCTWISE = {
    'INSURANCE_ACCORDIAN_PANEL2_SECTION': {
      'pnl': 'pnl',
      'cyber': 'CYBER_panel2',
      'epli': 'EPLI_panel2',
    },
    'INSURANCE_ACCORDIAN_PANEL3_SECTION': {
      'pnl': 'PNL_panel3',
      'cyber': 'CYBER_panel3',
      'epli': 'EPLI_panel3',
    },
    'INSURANCE_ACCORDIAN_PANEL4_SECTION': {
      'epli': 'EPLI_panel4',
    },

    'EPLI_ACCORDIAN_PANEL1_SECTION': {
      'epli': 'applicantDetails',
    },


  };

  public static QUESTION_SECTION_NAME = {
    'INSURANCE_ACCORDIAN_PANEL2_SECTION': {
      'cyber': ['CYBER_businessActivities'],
      'pnl': ['PL_businessActivities'],
      'epli': ['employmentpractises'],
    },
    'INSURANCE_ACCORDIAN_PANEL3_SECTION': {
      'cyber': ['mainSection', 'CYBER_InfoSecurityPrivacyControls', 'CYBER_websiteContentControls', 'CYBER_priorClaimsCircumstances'],
      'epli': ['losshistory'],
      'pnl': ['PL_priorClaimsCircumstances'],
    },
    'INSURANCE_ACCORDIAN_PANEL4_SECTION': {
      'epli': ['representaion'],
    },

    'EPLI_ACCORDIAN_PANEL1_SECTION': {
      'epli': ['organizationalinformation'],
    },
  };

  public static SAVE_ANONYMOUS_QUOTE_OBJECT_KEY_MAPPER = {
    applicantEmail: 'email',
    applicantPhone: 'phone',
    bondClassification: 'productType',
  };

  public static BUTTON_REFERENCE_SAVE_FOR_LATER = 'save_for_later';
  public static BUTTON_REFERENCE_CONTINUE = 'continue';

  public static CONFIRM_PRINT = {
    applicationFile: 'applicationFile',
    insuranceDeclarationFile: 'insuranceDeclarationFile',
    insurancePolicyFile: 'insurancePolicyFile',
    insuranceCOIFile
      : 'insuranceCOIFile',
    insuranceEOFile: 'insuranceEOFile',
  };

  public static PERCENTAGE_ERROR = 'Value out of range';
  public static REVENUE_ERROR = 'Total revenue should not exceed $10000000.00';
  public static DELIVERY_METHOD_FEES = ['FedEx', 'UPS'];
  public static PURCHASE_SUMMARY_CYBER_PRODUCTCODE = 'cyber';
  public static PURCHASE_SUMMARY_PNL_PRODUCTCODE = 'pnl';
  public static DEFAULT_ERROR_MSG = 'Something went wrong..';

  public static CUSTOM_VALIDATION_QNS_LIST = {
    EPLI_employeeHandbook:
    {
      name: 'EPLI_employeeHandbook',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_handbookReviewed: {
      name: 'EPLI_handbookReviewed',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_equalOpportunityEmployment: {
      name: 'EPLI_equalOpportunityEmployment',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_employmentAtWill: {
      name: 'EPLI_employmentAtWill',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_AntisexualHarassment: {
      name: 'EPLI_AntisexualHarassment',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_employeeComplaints: {
      name: 'EPLI_employeeComplaints',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_aDAAccommodations: {
      name: 'EPLI_aDAAccommodations',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_terminationsWithHuman: {
      name: 'EPLI_terminationsWithHuman',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_releasesForTerminations: {
      name: 'EPLI_releasesForTerminations',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_performanceEvaluations: {
      name: 'EPLI_performanceEvaluations',
      employeeCount: 19,
      maxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_contractOf50000: {
      name: 'EPLI_contractOf50000',
      maxLimit: 50000,
      newYorkMaxLimit: 100000,
      employeeCount: 49,
      invalidAnswer: 'yes',
    },
    EPLI_numberOfEmployees_TerminatedInvoCurrentYear: {
      name: 'EPLI_numberOfEmployees_TerminatedInvoCurrentYear',
      maxLimit: 50000,
      newYorkMaxLimit: 100000,
      invalidAnswer: 0,
    },
    EPLI_numberOfEmployees_TerminatedInvo1YearAgo: {
      name: 'EPLI_numberOfEmployees_TerminatedInvo1YearAgo',
      maxLimit: 50000,
      newYorkMasLimit: 100000,
      invalidAnswer: 0,
    },
    EPLI_trainingForAntiDiscrimination: {
      name: 'EPLI_trainingForAntiDiscrimination',
      maxLimit: 50000,
      newYorkMaxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_furtherReviewConclude: {
      name: 'EPLI_furtherReviewConclude',
      maxLimit: 50000,
      newYorkMaxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_twelvemonthsCircumstances: {
      name: 'EPLI_twelvemonthsCircumstances',
      maxLimit: 50000,
      newYorkMaxLimit: 100000,
      invalidAnswer: 'no',
    },
    EPLI_civilOrCriminal_ClaimsOpenMoreThan2k: {
      name: 'EPLI_civilOrCriminal_ClaimsOpenMoreThan2k',
      maxLimit: 250000,
      invalidAnswer: 'no',
    },
    EPLI_lossesLawsuits_ClaimsOpenMoreThan2k: {
      name: 'EPLI_lossesLawsuits_ClaimsOpenMoreThan2k',
      maxLimit: 250000,
      invalidAnswer: 'no',
    },
    EPLI_applicantPredecessors_ClaimsOpenMoreThan2k: {
      name: 'EPLI_applicantPredecessors_ClaimsOpenMoreThan2k',
      maxLimit: 250000,
      invalidAnswer: 'no',
    },
    EPLI_deductibleAmount: {
      name: 'deductible',
      maxLimit: 50000,
      invalidAnswer: '2500',
    },
    EPLI_limitOfInsurance: { name: 'amount' },
    EPLI_numberOfEmployees_TotalCurrentYear: {
      name: 'EPLI_numberOfEmployees_TotalCurrentYear',
      minLimit: 1,
    },
    CYBER_revenueInformation_TotalRevenueLast12Months: { name: 'CYBER_revenueInformation_TotalRevenueLast12Months' },
    CYBER_revenueInformation_TotalRevenuePreviousYear: { name: 'CYBER_revenueInformation_TotalRevenuePreviousYear' },
    CYBER_revenueInformation_TotalRevenueNextYear: { name: 'CYBER_revenueInformation_TotalRevenueNextYear' },
    Email_Signature: { name: 'emailSignature' },

  };
  public static CUSTOM_ERROR_MSG = {
    numberOfEmployeesError: 'Number of Employees should not be 0',
    revenueError: 'Revenue should not exceed $10000000.00',
    emailSignatureError: 'E-Signature must match applicant email',
  };

  // tslint:disable-next-line:max-line-length
  public static READONLYQUESTIONS = {
    // tslint:disable-next-line:max-line-length
    CYBER_revenueInformation_TotalRevenueLast12Months: ['CYBER_revenueInformation_USRevenueLast12Months',
      'CYBER_revenueInformation_NonUSRevenueLast12Months'],
    CYBER_revenueInformation_TotalRevenuePreviousYear: ['CYBER_revenueInformation_USRevenuePreviousYear',
      'CYBER_revenueInformation_NonUSRevenuePreviousYear'],
    CYBER_revenueInformation_TotalRevenueNextYear: ['CYBER_revenueInformation_USRevenueNextYear',
      'CYBER_revenueInformation_NonUSRevenueNextYear'],
    EPLI_numberOfEmployees_TotalCurrentYear: ['EPLI_numberOfEmployees_FullTimeCurrentYear',
      'EPLI_numberOfEmployees_PartTimeCurrentYear', 'EPLI_numberOfEmployees_SeasonalCurrentYear',
      'EPLI_numberOfEmployees_IndContractCurrentYear', 'EPLI_numberOfEmployees_TempEmployeesCurrentYear',
      'EPLI_numberOfEmployees_TerminatedInvoCurrentYear'],
    EPLI_numberOfEmployees_Total1YearAgo: ['EPLI_numberOfEmployees_FullTime1YearAgo', 'EPLI_numberOfEmployees_PartTime1YearAgo',
      'EPLI_numberOfEmployees_Seasonal1YearAgo', 'EPLI_numberOfEmployees_IndContract1YearAgo',
      'EPLI_numberOfEmployees_TempEmployees1YearAgo', 'EPLI_numberOfEmployees_TerminatedInvo1YearAgo'],

  };
  // tslint:disable-next-line:max-line-length
  public static QUESTIONTODISABLE = ['CYBER_revenueInformation_TotalRevenueLast12Months', 'CYBER_revenueInformation_TotalRevenuePreviousYear',
    'CYBER_revenueInformation_TotalRevenueNextYear', 'emailCC', 'emailSubject', 'emailRefCode', 'emailSignature',
    'EPLI_numberOfEmployees_TotalCurrentYear', 'EPLI_numberOfEmployees_Total1YearAgo'];
  public static DISABLE_FORM_CONTROLS = ['firstName', 'lastName', 'applicantEmail'];
  public static DISABLE_STATE_CITY = ['state', 'city'];
  public static DISABLE_ADDRESS_RAILS = ['street1', 'street2', 'state', 'city', 'zipCode'];
  public static PNL_INSURANCE_LIMIT_TO_PURCHASE_QUESTION = 'PNL_insuranceLimitToPurchase';
  public static KO_QUESTION_ON_FREE_TEXT = ['EPLI_applicantLocations1_stateOrCountry', 'EPLI_applicantLocations2_stateOrCountry',
    // tslint:disable-next-line:max-line-length
    'EPLI_applicantLocations3_stateOrCountry', 'EPLI_applicantLocations4_stateOrCountry', 'EPLI_applicantLocations5_stateOrCountry', 'EPLI_applicantLocations6_stateOrCountry',
    'CYBER_breachResponseContract'];

  public static EPLI_FILE_UPLOAD_PARENT_KEY = 'EPLI_subjectOFCCPAudit';
  public static EPLI_PRODUCT_CODE = 'epli';
  public static FILE_NAME = 'name';
  public static FILE_TYPE = 'fileTypeName';
  public static FILE_ENCODED_CONTENT = 'encodedFileContents';
  public static FILE_ID = 'id';
  public static FILE_DESCRIPTION = 'description';
  public static PARENT_OBJECT_ID = 'parentObjectId';
  public static PARENT_OBJECT_TYPE = 'parentObjectTypeName';
  public static PARENT_OBJECT_TYPE_NAME = 'Application_Attachment';
  public static IS_HISTORY_LOGGED = 'historyLogged';
  public static CYBER_PRODUCT_CODE = 'cyber';
  public static CYBER_WEBSITE_CONTENT = 'CYBER_websiteContent';
  public static CYBER_CHECKBOX_QUESLIST = ['CYBER_websiteContent', 'CYBER_backingUpStorage'];
  public static EPLI_KOQUES = ['EPLI_applicantCurrentLiability', 'EPLI_businessOrganization',
    'EPLI_other', 'EPLI_subsidiaryOfAnothercompany'];
  public static NEW_YORK_CODE = 'NY';
  public static TOTAL_FIELDS_HIDE_FLAG = [
    'CYBER_revenueInformation_TotalRevenueLast12Months',
    'CYBER_revenueInformation_TotalRevenueNextYear',
    'CYBER_revenueInformation_TotalRevenuePreviousYear',
    'EPLI_numberOfEmployees_TotalCurrentYear',
    'EPLI_numberOfEmployees_Total1YearAgo',
  ];
  // public static STATE_CHANGE_WARNING = 'You have updated the State and hence needs to start again'
  public static EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT = {
    '100k': 100000,
    '50k': 50000,
    '250k': 250000,
  };
  public static yearQue = ['CYBER_yearEstablished', 'PNL_whenBusinessBegan'];

}

