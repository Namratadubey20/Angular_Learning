import { Directive, ElementRef, HostListener, OnInit } from '@angular/core';
import { DirectiveValidationService } from '../services/directive-validation.service';

@Directive({
  selector: '[appInsFieldFormatCurrency]',
})
export class InsuranceCurrencyFormatDirective implements OnInit {

  allowedCharacters = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'];
  allowedActions = ['ArrowRight', 'ArrowLeft', 'Backspace', 'Tab'];

  constructor(protected element: ElementRef) { }

  ngOnInit() { }

  @HostListener('blur')
  public onBlur() {
    this.formatMoney();
  }

  @HostListener('keydown', ['$event'])
  public onKeydown(event) {
    const key = event.key;
    if (!(this.allowedCharacters.includes(key) || this.allowedActions.includes(key) || this.element.nativeElement.value.length === 1)) {
      return false;
    }
  }

  formatMoney() {
    if (this.element.nativeElement.value !== null && this.element.nativeElement.value !== '') {
      const value = this.convertValueToNumber();
      this.element.nativeElement.value = DirectiveValidationService.formatMoney(value);
    }
  }

  convertValueToNumber() {
    return DirectiveValidationService.toRawNumber(this.element.nativeElement.value);
  }

  get value(): number {
    return this.convertValueToNumber();
  }
}
