import {
  ComponentFactoryResolver,
  ComponentRef,
  Directive,
  Input,
  OnInit,
  ViewContainerRef,
  Output,
  EventEmitter
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Fields } from '../interface/field.inteface';
import { BasicInputComponent } from '../../form-insurance-components/input/basic-input/input.component';
import { YearPickerComponent } from '../../form-insurance-components/year-picker-component/year-picker.component';
import { MultiDatepickerComponent } from '../../form-insurance-components/multidatepicker/multidatepicker.component';
import { LabelComponent } from '../../form-insurance-components/label/label.component';
import { GoogleInputComponent } from '../../form-insurance-components/input/google-input/google-input.component';
import { CurrencyInputComponent } from '../../form-insurance-components/input/currency-input/currency-input.component';
import { PhoneInputComponent } from '../../form-insurance-components/input/phone-input/phone-input.component';
import { BasicTextAreaComponent } from '../../form-insurance-components/text-area/text-area.component';
import { NumberInputComponent } from '../../form-insurance-components/input/number-input/number-input.component';
import { FormControl } from '@angular/forms';
import { CheckboxComponent } from '../../form-insurance-components/checkbox/checkbox.component';
import { RadiobuttonComponent } from '../../form-insurance-components/radiobutton/radiobutton.component';
import { SelectComponent } from '../../form-insurance-components/select/select.component';
import { SelectWithSearchComponent } from '../../form-insurance-components/select-with-search/select-with-search.component';
import { DateComponent } from '../../form-insurance-components/date/date.component';
import { PasswordInputComponent } from 'src/app/form-insurance-components/input/password-input/password-input.component';
import { SingleCheckboxComponent } from 'src/app/form-insurance-components/single-checkbox/single-checkbox.component';
import { PercentageInputComponent } from '../../form-insurance-components/input/percentage-input/percentage-input.component';
import { SeparatorLineComponent } from '../../form-insurance-components/separator-line/separator-line.component';
import { FileInputComponent } from '../../form-insurance-components/file-input/file-input.component';

const componentMapper = {
  textbasic: BasicInputComponent,
  // date: DateComponent,
  textgoogle: GoogleInputComponent,
  textcurrency: CurrencyInputComponent,
  textpercentage: PercentageInputComponent,
  textnumber: NumberInputComponent,
  textphone: PhoneInputComponent,
  textarea: BasicTextAreaComponent,
  checkbox: CheckboxComponent,
  singlecheckbox: SingleCheckboxComponent,
  radio: RadiobuttonComponent,
  select: SelectComponent,
  selectwithsearch: SelectWithSearchComponent,
  date: MultiDatepickerComponent,
  password: PasswordInputComponent,
  label: LabelComponent,
  grid: LabelComponent,
  sectionSeparator: SeparatorLineComponent,
  fileinput: FileInputComponent,
};

@Directive({
  selector: '[appDynamicField]',
})

export class DynamicFieldDirective implements OnInit {
  @Input() group: FormGroup;
  @Input() field: Fields;
  @Input() control: FormControl;
  // @Input() isChecked;
  @Output() inputChangeEvent = new EventEmitter();
  @Output() inputFocusInEvent = new EventEmitter();
  @Output() inputFocusOutEvent = new EventEmitter();
  @Output() radioFocusOutEvent = new EventEmitter();
  @Output() radioFocusInEvent = new EventEmitter();
  @Output() textAreaChangeEvent = new EventEmitter();
  @Output() textAreaFocusInEvent = new EventEmitter();
  @Output() textAreaFocusOutEvent = new EventEmitter();
  @Output() checkboxChangeEvent = new EventEmitter();
  @Output() multiCheckboxChangeEvent = new EventEmitter();
  @Output() radioChangeEvent = new EventEmitter();
  @Output() selectEvent = new EventEmitter();
  @Output() selectFocusInEvent = new EventEmitter();
  @Output() selectFocusOutEvent = new EventEmitter();
  @Output() selectWithSearchEvent = new EventEmitter();
  @Output() selectWithSearchFocusInEvent = new EventEmitter();
  @Output() selectWithSearchFocusOutEvent = new EventEmitter();
  @Output() dateEvent = new EventEmitter();
  @Output() dateFocusInEvent = new EventEmitter();
  @Output() dateFocusOutEvent = new EventEmitter();
  @Output() yearEvent = new EventEmitter();
  @Output() yearFocusInEvent = new EventEmitter();
  @Output() yearFocusOutEvent = new EventEmitter();
  componentRef: any;

  constructor(
    private resolver: ComponentFactoryResolver,
    private container: ViewContainerRef
  ) { }

  ngOnInit() {
    if (this.field.type) {
      const factory = this.resolver.resolveComponentFactory(
        componentMapper[this.field.type]
      );
      this.componentRef = this.container.createComponent(factory);
      this.componentRef.instance.field = this.field;
      this.componentRef.instance.group = this.group;
      this.componentRef.instance.control = this.control;
      this.componentRef.instance.inputChangeEvent = this.inputChangeEvent;
      this.componentRef.instance.inputFocusInEvent = this.inputFocusInEvent;
      this.componentRef.instance.inputFocusOutEvent = this.inputFocusOutEvent;
      this.componentRef.instance.radioFocusInEvent = this.inputFocusInEvent;
      this.componentRef.instance.radioFocusOutEvent = this.inputFocusOutEvent;
      this.componentRef.instance.textAreaChangeEvent = this.inputChangeEvent;
      this.componentRef.instance.textAreaFocusInEvent = this.inputFocusInEvent;
      this.componentRef.instance.textAreaFocusOutEvent = this.inputFocusOutEvent;
      this.componentRef.instance.checkboxChangeEvent = this.checkboxChangeEvent;
      this.componentRef.instance.multiCheckboxChangeEvent = this.multiCheckboxChangeEvent;
      this.componentRef.instance.radioChangeEvent = this.radioChangeEvent;
      this.componentRef.instance.selectEvent = this.selectEvent;
      this.componentRef.instance.selectFocusInEvent = this.selectFocusInEvent;
      this.componentRef.instance.selectFocusOutEvent = this.selectFocusOutEvent;
      this.componentRef.instance.selectWithSearchEvent = this.selectWithSearchEvent;
      this.componentRef.instance.selectWithSearchFocusInEvent = this.selectWithSearchFocusInEvent;
      this.componentRef.instance.selectWithSearchFocusOutEvent = this.selectWithSearchFocusOutEvent;
      this.componentRef.instance.dateEvent = this.dateEvent;
      this.componentRef.instance.dateFocusInEvent = this.dateFocusInEvent;
      this.componentRef.instance.dateFocusOutEvent = this.dateFocusOutEvent;
      this.componentRef.instance.yearEvent = this.yearEvent;
      this.componentRef.instance.yearFocusInEvent = this.yearFocusInEvent;
      this.componentRef.instance.yearFocusOutEvent = this.yearFocusOutEvent;
    }

  }
}
