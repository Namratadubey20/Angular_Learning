import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class DirectiveValidationService {

  // Currency Formatter
  public static formatMoney(value, decimalNotRequired = false): string {
    if (value === '' || value === null) {
      return null;
    }

    value = this.toRawNumber(value);
    let negative = false;
    if (value < 0) {
      negative = true;
      value = Math.abs(value);
    }
    const valueWithDecimal = Number(value).toFixed(2).toString();


    const [num, dec] = valueWithDecimal.split('.');

    const length = num.length;
    let numberOfCommas = Math.floor(length / 3);
    let remainder = length % 3;
    if (remainder === 0) {
      remainder = 3;
      numberOfCommas--;
    }

    let formattedValue = '';
    if (numberOfCommas > 0) {
      let startOfTriplet = length - 3;
      let endOfTriplet = length;

      for (let i = 0; i < numberOfCommas; i++) {
        const numberTriplet = num.substring(startOfTriplet, endOfTriplet);
        formattedValue = `,${numberTriplet}${formattedValue}`;
        startOfTriplet = startOfTriplet - 3;
        endOfTriplet = endOfTriplet - 3;
      }

      const frontOfNumber = num.substring(0, remainder);
      formattedValue = `${frontOfNumber}${formattedValue}`;
    } else {
      formattedValue = num;
    }

    if (negative) {
      formattedValue = `-${formattedValue}`;
    }

    return decimalNotRequired ? `${formattedValue}` : `${formattedValue}.${dec}`;
  }

  // currency to Raw Number
  public static toRawNumber(value): number {
    if (value === '' || !value) {
      return null;
    }
    if (typeof value !== 'number') {
      return Number(Number(value.replace(/,/g, '')).toFixed(2));
    } else {
      return value;
    }
  }
  //
}
