import { TestBed, async, inject } from '@angular/core/testing';
import { Validation } from './validation';

describe('Service: Validation Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Validation],
    });
  });

  it('should create an instance', inject([Validation], (service: Validation) => {
    expect(service).toBeTruthy();
  }));

  it('should return null and call deafult case', inject([Validation], (service: Validation) => {
    const element = {
      'type': '',
    };
    const errMsg = Validation.getValidationErrorMsg(element, null, null);
    expect(errMsg).toBe(null);
  }));

  it('should return custom date error msg if min date', inject([Validation], (service: Validation) => {
    const element = {
      'type': 'date',
      'validations': [
        {
          'name': 'maxDate',
          'message': 'past date is not allowed.',
        },
      ],
    };

    const minErr = {
      'matDatepickerMin': {
        'min': 'max not allowed',
      },
    };

    const minDateNotAllowed = Validation.getValidationErrorMsg(element, null, minErr);
    expect(minDateNotAllowed).toBe('past date is not allowed.');
  }));

  it('should return custom date error msg if max date', inject([Validation], (service: Validation) => {
    const element = {
      'type': 'date',
      'validations': [
        {
          'name': 'maxDate',
          'message': 'Future date is not allowed.',
        },
      ],
    };

    const maxErr = {
      'matDatepickerMax': {
        'max': 'max not allowed',
      },
    };

    const maxDateNotAllowed = Validation.getValidationErrorMsg(element, null, maxErr);
    expect(maxDateNotAllowed).toBe('Future date is not allowed.');
  }));

});
