import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class TempAPIMockData {
  public static state = {
    'state': [
      {
        'id': 1,
        'code': 'MH',
        'label': 'MH',
        'tooltip': null,
      },
      {
        'id': 2,
        'code': 'GA',
        'label': 'GA',
        'tooltip': null,
      },
      {
        'id': 798,
        'code': 'NONE',
        'label': 'None',
        'tooltip': null,
      },
    ],
  };

  public static profession = {
    'profession': [
      {
        'id': 1,
        'code': 'accounting',
        'label': 'Accounting',
        'tooltip': null,
      },
      {
        'id': 2,
        'code': 'actuarialServices',
        'label': 'Actuarial Services',
        'tooltip': null,
      },
      {
        'id': 3,
        'code': 'accupuntureServices',
        'label': 'Accupunture Services',
        'tooltip': null,
      },
      {
        'id': 4,
        'code': 'accupressureServices',
        'label': 'Accupressure Services',
        'tooltip': null,
      },
      {
        'id': 5,
        'code': 'advertising',
        'label': 'Advertising',
        'tooltip': null,
      },
    ],
  };

  public static section =
    {
      'questions': [
        {
          'id': 2,
          'name': 'PNL_completionSignOff_DE_directMarketing',
          // tslint:disable-next-line:max-line-length
          'label': 'Which of the following does your business implements?<BR><BR>Customer sign-off on deliverables<BR>Formal change management procedures<BR>Legal review of contracts<BR>Contracts with indemnification clauses in your favor',
          'type': 'radio',
          'required': true,
          'options': [
            {
              'id': 20,
              'name': 'yes',
              'label': 'Yes',
            },
            {
              'id': 21,
              'name': 'no',
              'label': 'No',
            },
          ],
        },
        {
          'id': 31643,
          'name': 'PNL_complyLaws_DE_directMarketing',
          'label': 'Does your business comply with applicable federal, state, and local laws and regulations?',
          'type': 'radio',
          'required': true,
          'options': [
            {
              'id': 20,
              'name': 'yes',
              'label': 'Yes',
            },
            {
              'id': 21,
              'name': 'no',
              'label': 'No',
            },
          ],
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          }],
        },
        {
          'id': 11291,
          'name': 'PNL_deductibleToPurchase_DE_directMarketing',
          'label': 'What deductible do you wish to purchase?',
          'type': 'select',
          'required': true,
          'options': [
            {
              'id': 39,
              'name': 'fivehundred',
              'label': '$500',
            },
            {
              'id': 40,
              'name': 'twentyfivehundred',
              'label': '$2500',
            },
            {
              'id': 41,
              'name': 'fivethousand',
              'label': '$5000',
            },
          ],
        },
        {
          'id': 15902,
          'name': 'PNL_estimatedGrossSalesInNextTwelveMonths_DE_directMarketing',
          'label': 'What are your business??s estimated gross sales during the next 12 months?',
          'type': 'textbasic',
          'required': true,
          'options': [],
          'validations': [{
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          }],
        },
        {
          'id': 5461,
          'name': 'PNL_insuranceLimitToPurchase_DE_directMarketing',
          'label': 'What limit of insurance do you wish to purchase?',
          'type': 'select',
          'required': true,
          'options': [
            {
              'id': 34,
              'name': 'twofifty',
              'label': '250,000',
            },
            {
              'id': 35,
              'name': 'fivehundred',
              'label': '500,000',
            },
            {
              'id': 36,
              'name': 'onethousand',
              'label': '1,000,000',
            },
            {
              'id': 37,
              'name': 'twothousand',
              'label': '2,000,000',
            },
            {
              'id': 38,
              'name': 'threethousand',
              'label': '3,000,000',
            },
          ],
        },
        {
          'id': 32120,
          'name': 'PNL_noInfringementIP_DE_directMarketing',
          // tslint:disable-next-line:max-line-length
          'label': 'Do your contracts state that to the best of your knowledge any materials or intellectual property created are original and do not infringe upon the intellectual property rights of others?',
          'type': 'radio',
          'required': true,
          'options': [
            {
              'id': 22,
              'name': 'yes',
              'label': 'Yes',
            },
            {
              'id': 23,
              'name': 'no',
              'label': 'No',
            },
            {
              'id': 24,
              'name': 'notapplicable',
              'label': 'Not Applicable',
            },
          ],
        },
        {
          'id': 41554,
          'name': 'PNL_processForScreeningMaterial_DE_directMarketing',
          // tslint:disable-next-line:max-line-length
          'label': 'Do you have a process in place to screen materials for any potential violation of another party??s copyrights, trademarks or other intellectual property rights?',
          'type': 'radio',
          'required': true,
          'options': [
            {
              'id': 22,
              'name': 'yes',
              'label': 'Yes',
            },
            {
              'id': 23,
              'name': 'no',
              'label': 'No',
            },
            {
              'id': 24,
              'name': 'notapplicable',
              'label': 'Not Applicable',
            },
          ],
        },
        {
          'id': 40865,
          'name': 'PNL_processForScreeningMaterialForPotentialSlander_DE_directMarketing',
          'label': 'Do you have a process in place to screen materials for potential libel, slander or advertising injury?',
          'type': 'radio',
          'required': true,
          'options': [
            {
              'id': 22,
              'name': 'yes',
              'label': 'Yes',
            },
            {
              'id': 23,
              'name': 'no',
              'label': 'No',
            },
            {
              'id': 24,
              'name': 'notapplicable',
              'label': 'Not Applicable',
            },
          ],
        },
        {
          'id': 29894,
          'name': 'PNL_promoteEntertainment_DE_directMarketing',
          // tslint:disable-next-line:max-line-length
          'label': 'Does your business promote media, artists or entertainers on behalf of or for any entertainment, publishing, music, internet or media company?',
          'type': 'radio',
          'required': true,
          'options': [
            {
              'id': 20,
              'name': 'yes',
              'label': 'Yes',
            },
            {
              'id': 21,
              'name': 'no',
              'label': 'No',
            },
          ],
        },
        {
          'id': 34081,
          'name': 'PNL_stateOwnershipRightForIP_DE_directMarketing',
          // tslint:disable-next-line:max-line-length
          'label': 'Do your contracts clearly state the ownership rights, licensing, and use of any materials or intellectual property created for or during an engagement?',
          'type': 'radio',
          'required': true,
          'options': [
            {
              'id': 22,
              'name': 'yes',
              'label': 'Yes',
            },
            {
              'id': 23,
              'name': 'no',
              'label': 'No',
            },
            {
              'id': 24,
              'name': 'notapplicable',
              'label': 'Not Applicable',
            },
          ],
        },
        {
          'id': 47758,
          'name': 'PNL_whenBusinessBegan_DE_directMarketing',
          'label': 'Approximately when did your business begin?',
          'type': 'date',
          'required': true,
          'options': [],
        },
        {
          'id': 23269,
          'name': 'PNL_whenWouldCoverageStart_DE_directMarketing',
          'label': 'If you purchase a policy, when would you like your coverage to start?',
          'type': 'date',
          'required': true,
          'options': [],
        },
      ],
    };

  public static creditCardNumber = {
    'creditCardNumber': [
      {
        'id': 1,
        'name': 'visa',
        'label': 'Visa',
        'cvvLength': 3,
      },
      {
        'id': 2,
        'name': 'american-express',
        'label': 'American Express',
        'cvvLength': 4,
      },
      {
        'id': 3,
        'name': 'discover',
        'label': 'Discover',
        'cvvLength': 3,
      },
      {
        'id': 4,
        'name': 'master-card',
        'label': 'Master Card',
        'cvvLength': 3,
      },
    ],
  };

  public static getStates() {
    return TempAPIMockData.state['state'];
  }

  public static getProfessions() {
    return TempAPIMockData.profession['profession'];
  }

  public static getKnockOutSections() {
    return TempAPIMockData.section;
  }

  public static getCreditCards() {
    return TempAPIMockData.creditCardNumber['creditCardNumber'];
  }
}
