import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export class StateService {
  public fieldError = {};
  public screenMapObject = {};
  public isApplicationReadyToAction = true;
  public isCheckboxDisabled = false;
  public userID;
  public isCompanyExist = false;
  public company = '/company';
  public companyInfo = [{
    'id': null,
    'name': '',
    'companyOffices': [
      {
        'id': null,
        'agentId': null,
        'name': 'company name',
        'address': {
          'street1': '',
          'street2': '',
          'city': '',
          'state': '',
          'zipCode': '',
        },
        'email': null,
        'fax': null,
        'officeType': 'Main',
        'clientsId': null,
        'companyOfficePersons': [
          {
            'id': null,
            'responsiblePerson': true,
          },
        ],
      },
    ],
  }];
  public ispolicyPurchasedOnCompanyName = false;
  public preloadData = {
    'state': [],
    'profession': [],
    'sanctionStates': [],
    'allowedStates': [],
    'allStates': [],
    'APIstaticQuestionStack': {},
  };
  public editedQuesDetails = {};
  public editedSectionStates = {};

  public insuranceDetails = {
    'applicationId': '',
    'agreeToAutoRenewal': '',
    'questionAnswers': {
      'dynamicQuestions': {},
      'paymentMethod': {},
      'premiumCalculation': {},
      'deliveryMethod': {},
      'termsAndConditions': {},
      'agreeToRenewPolicy': '',
      'amount': '',
      'deductible': '',
    },
    isSetBusinessNameChecked: false,
  };
  public SECTIONS = {
    'getQuote': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'productInformation': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'yourQuote': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'agreement': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'payment': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
    'createUser': {
      'istouched': false,
      'status': 'default',
      'errors': 0,
      'msg': '',
    },
  };
  public insuranceSelected = [];
  public isPreload = false;
  public previousPageRout;
  public quoteId: any;
  public getDecryptStatus = new BehaviorSubject<Object>({});
  public getApplicationStatus = new BehaviorSubject<Boolean>(false);
  public getPorfileSetStatus = new BehaviorSubject<Boolean>(false);
  public isConfirmationPageLoad = new BehaviorSubject<Boolean>(false);
  public isLoadComponent = new BehaviorSubject<Boolean>(false);
  public isPageVaildate = new BehaviorSubject<Boolean>(false);
  public isDeclined = false;
  public applicationStatus: any;
  public uploadedFileName: string;
  public clientID: any;
  public clientType: any;
  public agentId: any;
  public isCyberFileuploadDone = false;
  public clientDetailsPayload: any;
  //  public agreeToRenewPolicy: any;
  //  public agreeToAutoRenewal: boolean;
  public originState;
  public directClientCompanyId: any;
  public exitingAddress = {};
  public limitOfInsuranceMaxLimit: any;
  constructor() {

  }
}
