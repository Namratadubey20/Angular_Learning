import { TestBed, async, inject } from '@angular/core/testing';
import { DirectiveValidationService } from './directive-validation.service';

describe('Service: Directive Validation for Currency', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DirectiveValidationService],
    });
  });

  it('should create an instance', inject([DirectiveValidationService], (service: DirectiveValidationService) => {
    expect(service).toBeTruthy();
  }));

  it('should format value to Money', inject([DirectiveValidationService], (service: DirectiveValidationService) => {
    expect(DirectiveValidationService.formatMoney(20)).toEqual('20.00');
  }));

  it('should return format money null if value is null or empty',
    inject([DirectiveValidationService], (service: DirectiveValidationService) => {
      const formatMoney = DirectiveValidationService.formatMoney(null);
      expect(formatMoney).toBe(null);
    }));

  it('should  return the absolute value if value negative and  negative format value',
    inject([DirectiveValidationService], (service: DirectiveValidationService) => {
      const formatMoney = DirectiveValidationService.formatMoney(-10);
      expect(formatMoney).toEqual('-10.00');
    }));

  it('should return correct money format value if passed value with commas',
    inject([DirectiveValidationService], (service: DirectiveValidationService) => {
      const formatMoney = DirectiveValidationService.formatMoney('99,999,9');
      expect(formatMoney).toEqual('999,999.00');
    }));

  it('should return null if value to toRawNumber method is null or empty',
    inject([DirectiveValidationService], (service: DirectiveValidationService) => {
      const formatMoney = DirectiveValidationService.toRawNumber(null);
      expect(formatMoney).toEqual(null);
    }));
});
