import { TestBed, inject } from '@angular/core/testing';

import { RestService } from './rest.service';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';

describe('RestService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
    providers: [RestService, HttpClient],
  }));

  it('should be created', inject([RestService], (service: RestService) => {
    expect(service).toBeTruthy();
  }));

  it('should return http get method call response', inject([RestService], (service: RestService) => {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    const response = service.get('api/util/usps/zip/{zipCode}', { 'zipCode': 22 }, '22', httpOptions);
    expect(typeof response).toBe('object');
  }));

  it('should return http delete method call response', inject([RestService], (service: RestService) => {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    const response = service.delete('api/util/usps/zip/{zipCode}', { 'zipCode': 22 }, '22', httpOptions);
    expect(typeof response).toBe('object');
  }));

  it('should return http post method call response', inject([RestService], (service: RestService) => {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    const zipCode = {
      'zipCode': 22,
    };
    const response = service.post('api/util/usps/zip/', zipCode, httpOptions, '', '22');
    expect(typeof response).toBe('object');
  }));


  it('should return http put method call response', inject([RestService], (service: RestService) => {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    const zipCode = {
      'zipCode': 22,
    };
    const response = service.put('api/util/usps/zip/', zipCode, httpOptions, '', '22', '22');
    expect(typeof response).toBe('object');
  }));

});
