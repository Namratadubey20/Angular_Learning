import { TestBed, async, inject } from '@angular/core/testing';
import { StateService } from './state.service';

describe('Service: State Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StateService],
    });
  });

  it('should create an instance', inject([StateService], (service: StateService) => {
    expect(service).toBeTruthy();
  }));
});
