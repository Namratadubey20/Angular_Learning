import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class InsuranceSpinnerService {
  private spinnerSubject = new BehaviorSubject<boolean>(false);
  private footerSubject = new BehaviorSubject<boolean>(false);
  insuranceSpinnerState = this.spinnerSubject.asObservable();
  insuranceFooterState = this.footerSubject.asObservable();
  constructor() { }
  show(): void {
    this.spinnerSubject.next(true);
  }
  hide(): void {
    this.spinnerSubject.next(false);
  }

  showFooter(): void {
    this.footerSubject.next(true);
  }
  hideFooter(): void {
    this.footerSubject.next(false);
  }
}
