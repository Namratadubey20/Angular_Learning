import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UtilMethodsService } from './util-method.service';

@Injectable({
  providedIn: 'root',
})
export class RestService {

  constructor(private http: HttpClient) {
  }

  post(url: string, data: any, options: any, fcname: string, queryParam?: any): Observable<any> {
    const _httpOptions = {};
    if (!UtilMethodsService.isEmpty(queryParam)) {
      _httpOptions['params'] = queryParam;
    } else {
      delete _httpOptions['params'];
    }
    return this.http.post<any>(url, data, _httpOptions);
  }

  put(url: string, data: any, options: any, fcname: string, pathParam?: any, queryParam?: any): Observable<any> {
    const _httpOptions = {};
    if (!UtilMethodsService.isEmpty(queryParam)) {
      _httpOptions['params'] = queryParam;
    }
    let apiUrl = url;
    if (!UtilMethodsService.isEmpty(pathParam)) {
      apiUrl = this.prepareUrl(url, pathParam);
    }
    return this.http.put<any>(apiUrl, data, _httpOptions);
  }

  get(url: string, pathParam: any, queryParam: any, options?: any): Observable<any> {
    const _httpOptions = {};
    if (!UtilMethodsService.isEmpty(_httpOptions['params'])) {
      _httpOptions['params'] = null;
    }
    if (!UtilMethodsService.isEmpty(queryParam)) {
      _httpOptions['params'] = queryParam;
    }
    const apiUrl = this.prepareUrl(url, pathParam);
    return this.http.get<any>(apiUrl, _httpOptions);
  }

  delete(url: string, pathParam: any, queryParam: any, options?: any): Observable<any> {
    const _httpOptions = {};
    if (!UtilMethodsService.isEmpty(_httpOptions['params'])) {
      _httpOptions['params'] = null;
    }
    if (!UtilMethodsService.isEmpty(queryParam)) {
      _httpOptions['params'] = queryParam;
    }
    const apiUrl = this.prepareUrl(url, pathParam);
    return this.http.delete<any>(apiUrl, _httpOptions);
  }

  prepareUrl(url: string, params: any) {
    if (params) {
      for (const key in params) {
        if (params.hasOwnProperty(key)) {
          url = url.replace('{' + key + '}', params[key]);
        }
      }
    }
    return url;
  }
}
