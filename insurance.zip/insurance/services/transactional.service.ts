import { Injectable } from '@angular/core';
import { UtilMethodsService } from './util-method.service';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { StateService } from '../services/state.service';
import { ComparativeConstants } from '../constants/comparative-constants';
import { SecurityService } from 'src/app/security/security.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { InsuranceStaticService } from './insurance-static-service';

export { };
declare global {
  interface Array<T> {
    insert(index: number, item: T): Array<T>;
  }
}

if (!Array.prototype.insert) {
  Array.prototype.insert = function <T>(index: number, item: T): T[] {
    return this.splice(index, 0, item);
  };
}

@Injectable({
  providedIn: 'root',
})

export class TransactionalService {
  loggedIn$: Subscription;
  loggedIn: boolean;
  constructor(
    public securityService: SecurityService,
    private router: Router,
    public stateService: StateService,
    public insuranceStaticService: InsuranceStaticService) {
    this.loggedIn$ = this.securityService.loggedIn$.subscribe(
      loggedIn$ => {
        this.loggedIn = loggedIn$;
      }
    );
  }

  /*
* // TO DO: Create more generalize logic here to decide if the question should be created or not.
* @author:Amarjit Panhalkar (KYC-Persistent)
* @description: return right index for the question (used when tnew question is added on screen)
* @param questionSequenceNumber: [number] Sequence number of new question to be added on screen.
* @param globalDisplayedArray: [Array] Array displayed on screenk.
* @returns index where question needs to be added on screen.
*/
  public getRightPlaceForQuestion(questionSequenceNumber: number, globalDisplayedArray: Array<any>): number {
    return globalDisplayedArray.findIndex(element => {
      return element.sequence_number > questionSequenceNumber;
    });
  }

  public getQuestionFromQuestionnair(_name, _objArr: any) {
    if (_objArr) {
      let _field;
      _field = _objArr.fields.find(question => question.name === _name);
      if (_field) {
        return _field;
      }
    }
  }

  public getQuestionValueByKey(obj: any, key: string) {
    if (key in obj) {
      return obj[key];
    } else {

      for (const k in obj) {
        if (obj.hasOwnProperty(k)) {
          const t = obj[k];

          // tslint:disable-next-line:triple-equals
          if (typeof t == 'object' && !Array.isArray(t) && t !== null) {
            return this.getQuestionValueByKey(t, key);
          }
        }
      }
    }

    if (this.isClientAssociatedWithAgent() || this.isAgent()) {
      if (key === 'setApplicantName') {
        if (this.stateService.clientType === 'P') {
          return true;
        } else if (this.stateService.clientType === 'C') {
          return false;
        }
      }
    }
    return false;
  }

  public getQuestionIdxFromQuestionnair(_name, _objArr: any) {
    if (_objArr) {
      let _index;
      const _objToSearch = _objArr.fields || _objArr;

      // tslint:disable-next-line:triple-equals
      _index = _objToSearch.findIndex(question => question.name == _name);
      return _index;
    }
  }

  bindValidations(validations: any) {
    if (validations.length > 0) {
      const validList = [];
      let requiredIndex = -1;
      let isPatterned = false;
      validations.forEach((valid, index) => {
        if (valid.name === 'required') {
          valid.validator = Validators.required;
          requiredIndex = index;
        }
        if (valid.name === 'pattern') {
          if (typeof valid.value === 'string') {
            valid.validator = Validators.pattern(valid.value);
          } else {
            valid.validator = Validators.pattern(/\S/);
          }
          isPatterned = true;
        }
        if (valid.name === 'maxLength') {
          valid.validator = Validators.maxLength(valid.value);
        }
        if (valid.name === 'minLength') {
          valid.validator = Validators.minLength(valid.value);
        }
        validList.push(valid.validator);
      });
      if (requiredIndex > -1 && !isPatterned) {
        const validObj = {
          'name': 'pattern',
          'pattern': /\S/,
          'message': validations[requiredIndex].message,
          'validator': Validators.pattern(/\S/),
        };
        validations.push(validObj);
        validList.push(validObj.validator);
      }
      return Validators.compose(validList);
    }
    return null;
  }

  getFormattedAddress(place) {
    // @params: place - Google Autocomplete place object
    // @returns: location_obj - An address object in human readable format
    const location_obj = {};
    place.address_components.map(item => {
      location_obj['formatted_address'] = place.formatted_address;
      location_obj['address_name'] = place.name;
      if (item['types'].indexOf('sublocality_level_1') > -1) {
        location_obj['sublocality'] = item['long_name'];
      } else if (item['types'].indexOf('administrative_area_level_1') > -1) {
        location_obj[ComparativeConstants.staticQuestionNames.application_state] = item['short_name'];
      } else if (item['types'].indexOf('country') > -1) {
        location_obj['country'] = item['long_name'];
      } else if (item['types'].indexOf('postal_code') > -1) {
        location_obj[ComparativeConstants.staticQuestionNames.application_zipCode] = item['short_name'];
      } else if (item['types'].indexOf('administrative_area_level_3') > -1) {
        location_obj['locality_level_3'] = item['long_name'];
      } else if (item['types'].indexOf('locality') > -1) {
        location_obj[ComparativeConstants.staticQuestionNames.application_city] = item['long_name'];
      } else if (item['types'].indexOf('street_number') > -1) {
        location_obj[ComparativeConstants.staticQuestionNames.application_address1] = item['long_name'] + ' ';
      } else if (item['types'].indexOf('route') > -1) {
        if (location_obj[ComparativeConstants.staticQuestionNames.application_address1]) {
          location_obj[ComparativeConstants.staticQuestionNames.application_address1] += item['long_name'];
        } else {
          location_obj[ComparativeConstants.staticQuestionNames.application_address1] = item['long_name'];
        }
      }
    });

    if (!UtilMethodsService.isEmpty(location_obj['locality_level_3'])) {
      location_obj[ComparativeConstants.staticQuestionNames.application_city] = location_obj['locality_level_3'];
    }

    if (UtilMethodsService.isEmpty(location_obj[ComparativeConstants.staticQuestionNames.application_address1])) {
      location_obj[ComparativeConstants.staticQuestionNames.application_address1] = place.formatted_address;
    }
    return location_obj;
  }

  formatPhoneNumber(phoneNumber: string): string {
    return phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/g, '$1-$2-$3') : phoneNumber;
  }

  modifyStaticQuestionProperty(key: string, componentStaticQuestionStack: Object) {
    if (this.stateService.preloadData.APIstaticQuestionStack[key].label && componentStaticQuestionStack[key].label) {
      componentStaticQuestionStack[key].label = this.stateService.preloadData.APIstaticQuestionStack[key].label;
    }
    if (this.stateService.preloadData.APIstaticQuestionStack[key].validations && componentStaticQuestionStack[key].validations) {
      componentStaticQuestionStack[key].validations = this.stateService.preloadData.APIstaticQuestionStack[key].validations;
    }
    if (this.stateService.preloadData.APIstaticQuestionStack[key].options && componentStaticQuestionStack[key].options) {
      componentStaticQuestionStack[key].options = this.stateService.preloadData.APIstaticQuestionStack[key].options;
    }
    return componentStaticQuestionStack[key];
  }

  checkLoginAndRedirect(parentSection) {
    if (this.isLoggedIn()) {
      if (parentSection === 'getQuote') {
        this.router.navigate(['/dashboard']);
      } else {
        this.router.navigate(['/insurance/getquotes']);
      }
    } else {
      console.log('is not logged in');
      window.location.href = 'https://www.colonialsurety.com/';
    }
  }

  isLoggedIn() {
    return this.loggedIn;
  }

  isFieldTypeInput(_type: String) {
    return _type.includes(ComparativeConstants.TEXT_SUBSTR);
  }

  encryptPayload(_applyExceptions?: boolean) {
    // tslint:disable-next-line:prefer-const
    let _payload_interface = UtilMethodsService.copyObject(ComparativeConstants.PAYLOAD_INTERFACE);
    const clientId = this.stateService.clientID;
    const clientType = this.stateService.clientType;
    if (clientId) {
      if (clientType === 'C') {
        _payload_interface['companyOffice']['id'] = clientId && clientId || this.stateService.clientDetailsPayload
          && this.stateService.clientDetailsPayload.companyOffice
          && this.stateService.clientDetailsPayload.companyOffice.company.id;
        _payload_interface['companyOffice']['responsiblePerson'] = {};
        // tslint:disable-next-line: max-line-length
        _payload_interface['companyOffice']['responsiblePerson']['id'] = this.stateService.clientDetailsPayload && this.stateService.clientDetailsPayload['person']
          && this.stateService.clientDetailsPayload['person']['id'];

        _payload_interface.data['termsAndConditions']['companyEmailSignature'] = this.stateService.clientDetailsPayload
          && this.stateService.clientDetailsPayload.companyOffice
          && this.stateService.clientDetailsPayload.companyOffice.email
          || this.stateService.insuranceDetails.questionAnswers['applicantEmail'];

        _payload_interface.data.applicantName = this.stateService.clientDetailsPayload.name;
        delete _payload_interface['person'];
      } else {
        _payload_interface['person']['id'] = this.stateService.clientDetailsPayload && this.stateService.clientDetailsPayload['person']
          && this.stateService.clientDetailsPayload['person']['id'];

        // Number(clientId);
        _payload_interface.data.applicantName = this.stateService.clientDetailsPayload.name;
      }
      _payload_interface['agent']['id'] = this.securityService.user && this.securityService.user['agent']
        && this.securityService.user['agent']['id'] || delete _payload_interface['agent'];
    } else {
      // Update company office id for Direct client
      if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['applicationId'])
        && this.isCompanyPresentForClient()) {
        if (this.isCompanyPresentForClient()) {
          _payload_interface['companyOffice']['id'] = this.securityService.user && this.securityService.user.person
            && this.securityService.user.person.companyOfficePersons[0].companyOffice.id;
          _payload_interface['companyOffice']['responsiblePerson'] = {};
          // tslint:disable-next-line: max-line-length
          _payload_interface['companyOffice']['responsiblePerson']['id'] = this.securityService.user && this.securityService.user['person']['id'];
          delete _payload_interface['person'];
        } else if (this.stateService.companyInfo && this.stateService.companyInfo[0].companyOffices[0].id) {
          _payload_interface['companyOffice']['id'] = this.stateService.companyInfo[0].companyOffices[0].id;
          _payload_interface['companyOffice']['responsiblePerson'] = {};
          // tslint:disable-next-line: max-line-length
          _payload_interface['companyOffice']['responsiblePerson']['id'] = this.securityService.user && this.securityService.user['person']['id'];
          delete _payload_interface['person'];
        } else {
          // if company already present then use company object else person object
          if (this.isCompanyPresentForClient()) {
            _payload_interface['companyOffice']['id'] = this.stateService.companyInfo[0].companyOffices[0].id;
            _payload_interface['companyOffice']['responsiblePerson'] = {};
            // tslint:disable-next-line: max-line-length
            _payload_interface['companyOffice']['responsiblePerson']['id'] = this.securityService.user && this.securityService.user['person']['id'];
            delete _payload_interface['person'];
          } else {
            _payload_interface['person']['id'] = this.securityService.user && this.securityService.user['person']
              && this.securityService.user['person']['id'] || delete _payload_interface['person'];
          }

        }
      } else {
        if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['applicationId']) && !this.isCompanyPresentForClient()) {
          if (!UtilMethodsService.isEmpty(this.securityService.user && this.securityService.user.person.companyOfficePersons)) {
            _payload_interface['companyOffice']['id'] = this.securityService.user && this.securityService.user.person
              && this.securityService.user.person.companyOfficePersons[0].companyOffice.id;
          } else {
            _payload_interface['companyOffice']['id'] = this.stateService.directClientCompanyId;
          }
          _payload_interface['companyOffice']['responsiblePerson'] = {};
          // tslint:disable-next-line: max-line-length
          _payload_interface['companyOffice']['responsiblePerson']['id'] = this.securityService.user && this.securityService.user['person']['id'];
          delete _payload_interface['person'];
        } else {
          // anonymous user after sign up comes here and use directClientCompanyId and set company details in payload
          if (this.isCompanyPresentForClient() || !UtilMethodsService.isEmpty(this.stateService.directClientCompanyId)) {
            _payload_interface['companyOffice']['id'] = this.stateService.companyInfo[0].companyOffices[0].id;
            _payload_interface['companyOffice']['responsiblePerson'] = {};
            // tslint:disable-next-line: max-line-length
            _payload_interface['companyOffice']['responsiblePerson']['id'] = this.securityService.user && this.securityService.user['person']['id'];
            delete _payload_interface['person'];
          } else {
            _payload_interface['person']['id'] = this.securityService.user && this.securityService.user['person']
              && this.securityService.user['person']['id'] || delete _payload_interface['person'];
          }
        }
      }
      if (!UtilMethodsService.isEmpty(this.stateService.agentId)) {
        _payload_interface['agent']['id'] = this.stateService.agentId;
      }
    }
    const _ssPayloadKeys = Object.keys(this.stateService.insuranceDetails.questionAnswers);
    _ssPayloadKeys.forEach(_key => {
      if (_key !== 'dynamicQuestions' || 'premiumCalculation' || 'paymentMethod') {
        const _Obj = this.getObjects(_payload_interface, _key, '');
        if (UtilMethodsService.isEmpty(_Obj)) {
          _payload_interface.data[_key] = this.stateService.insuranceDetails.questionAnswers[_key];
        } else {
          _Obj[0][_key] = this.stateService.insuranceDetails.questionAnswers[_key];
        }
      }
    });
    if (_payload_interface.data.hasOwnProperty('firstName') && _payload_interface.data.hasOwnProperty('lastName')) {
      _payload_interface.data['ownerName'] = _payload_interface.data['firstName'] + ' ' + _payload_interface.data['lastName'];
    }
    _payload_interface.data.applicantId = this.stateService.insuranceDetails['applicationId'];
    _payload_interface.data.dynamicQuestions = this.encryptPayloadForKO();
    _payload_interface.premium = this.stateService.insuranceDetails['premiumAmount'];

    _payload_interface['id'] = this.stateService.insuranceDetails['applicationId'] || '';

    _payload_interface.data.premiumCalculation = this.stateService.insuranceDetails.questionAnswers['premiumCalculation'];
    _payload_interface.data.paymentMethod = this.stateService.insuranceDetails.questionAnswers['paymentMethod'];

    _payload_interface['agreeToAutoRenewal'] = this.stateService.insuranceDetails['agreeToAutoRenewal'];
    _payload_interface.data.agreeToRenewPolicy = this.stateService.insuranceDetails['questionAnswers'].agreeToRenewPolicy;

    let sortedFinalPayload;
    if (_applyExceptions === true) {
      // tslint:disable-next-line:max-line-length
      sortedFinalPayload = UtilMethodsService.filterEmptyValueFromObject(UtilMethodsService.copyObject(_payload_interface), ComparativeConstants.PAYLOAD_EXCEPTION_LIST);
    } else {
      sortedFinalPayload = UtilMethodsService.filterEmptyValueFromObject(UtilMethodsService.copyObject(_payload_interface));
    }
    console.log('sortedFinalPayload >>> ', sortedFinalPayload, ': ', _payload_interface.id);
    return sortedFinalPayload;
  }

  saveQuoteEncryptPayload() {
    // tslint:disable-next-line: max-line-length
    const sortedPayload = UtilMethodsService.filterEmptyValueFromObject(UtilMethodsService.copyObject(this.stateService.insuranceDetails.questionAnswers));
    const saveQuotePayload = UtilMethodsService.renameObjectKeys(ComparativeConstants.SAVE_ANONYMOUS_QUOTE_OBJECT_KEY_MAPPER,
      sortedPayload);
    return saveQuotePayload;
  }

  encryptPayloadForKO() {
    const _koPayload = [];

    const _KOKeys = Object.keys(this.stateService.insuranceDetails.questionAnswers['dynamicQuestions']);
    _KOKeys.forEach(_key => {
      const _KOQObj = UtilMethodsService.copyObject(ComparativeConstants.KO_INTERFACE_FOR_Q);
      _KOQObj.question.name = _key;
      if (ComparativeConstants.CYBER_CHECKBOX_QUESLIST.includes(_key)) {
        _KOQObj.value = this.stateService.insuranceDetails.questionAnswers['dynamicQuestions'][_key].toString();
      } else {
        _KOQObj.value = this.stateService.insuranceDetails.questionAnswers['dynamicQuestions'][_key];
      }
      _koPayload.push(_KOQObj);
    });
    return _koPayload;
  }

  getObjects(obj, key, val) {
    let objects = [];
    for (const i in obj) {
      if (!obj.hasOwnProperty(i)) {
        continue;
      }
      if (typeof obj[i] === 'object') {
        objects = objects.concat(this.getObjects(obj[i], key, val));
      } else
        // if key matches and value matches or if key matches and value is not
        // passed (eliminating the case where key matches but passed value does not)
        if (i === key && obj[i] === val || i === key && val === '') { //
          objects.push(obj);
        } else if (obj[i] === val && key === '') {
          // only add if the object is not already in the array
          if (objects.lastIndexOf(obj) === -1) {
            objects.push(obj);
          }
        }
    }
    return objects;
  }

  decryptPayload(appData, premiumAmount) {
    const sortedGetDataResObj = UtilMethodsService.filterEmptyValueFromObject(UtilMethodsService.copyObject(appData));
    const appValues = this.flattenObject(sortedGetDataResObj);
    const appPayload = Object.keys(appValues);
    appPayload.forEach(_key => {
      if (_key !== 'dynamicQuestions' && _key !== 'premiumCalculation' && _key !== 'paymentMethod') {
        this.stateService.insuranceDetails.questionAnswers[_key] = appValues[_key];
      }
    });

    if (!UtilMethodsService.isEmpty(premiumAmount)) {
      this.stateService.insuranceDetails['premiumAmount'] = premiumAmount;
    }

    if (!UtilMethodsService.isEmpty(appData.dynamicQuestions)) {
      this.stateService.insuranceDetails.questionAnswers.dynamicQuestions = this.decryptPayloadForKO(appData.dynamicQuestions);
      this.stateService.screenMapObject = this.decryptPayloadForKO(appData.dynamicQuestions);
    }

    if (!UtilMethodsService.isEmpty(appData.premiumCalculation)) {
      this.stateService.insuranceDetails.questionAnswers.premiumCalculation = appData.premiumCalculation;
    }

    if (!UtilMethodsService.isEmpty(sortedGetDataResObj.paymentMethod)) {
      this.stateService.insuranceDetails.questionAnswers.paymentMethod = sortedGetDataResObj.paymentMethod;
    }

    if (sessionStorage.getItem('originState') === 'rails' && this.securityService.user && this.securityService.user.person &&
      this.securityService.user.person.companyOfficePersons && this.securityService.user.person.companyOfficePersons.length > 0) {
      // tslint:disable-next-line: max-line-length
      this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName] = this.securityService.user.person.companyOfficePersons[0].companyOffice.company.name;
      const tempAddress = this.securityService.user.person.companyOfficePersons[0].companyOffice.address;
      Object.keys(tempAddress).forEach(_keys => {
        this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys];
      });
    }
    this.stateService.getDecryptStatus.next(appData);
    console.log('decryptPayload --- ', this.stateService.insuranceDetails.questionAnswers);
  }

  flattenObject(obj) {
    const flattenned = {};
    Object.keys(obj).forEach((key) => {
      if (typeof obj[key] === 'object' && obj[key] !== null && key !== 'dynamicQuestions'
        && key !== 'premiumCalculation' && key !== 'paymentMethod') {
        Object.assign(flattenned, this.flattenObject(obj[key]));
      } else {
        flattenned[key] = obj[key];
      }
    });
    return flattenned;
  }

  decryptPayloadForKO(koPayload) {
    const generateObj = {};
    koPayload.forEach(_obj => {
      generateObj[_obj.question.name] = _obj.value;
      // if(question type == checkbox) then  it should split
      // Now handled this way as type not getting from API, Once Type get need to modify condtion
      if (ComparativeConstants.CYBER_CHECKBOX_QUESLIST.includes(_obj.question.name)) {
        const _value = _obj.value.split(',');
        // filtered out NaN values if present in array
        const FilteredValue = _value.filter((val) => !Number.isNaN(val));
        generateObj[_obj.question.name] = FilteredValue;
      } else {
        generateObj[_obj.question.name] = _obj.value;
      }
    });
    return generateObj;
  }

  formatDateTo(date, key): string {
    let formatedDate;
    switch (key) {
      case 'MMMDDYYYY':
        formatedDate = ComparativeConstants.MONTHS_TXT[date.getMonth()] + ' ' + date.getDate() + ',' + date.getFullYear();
        break;
      case 'mm-DD-YYYY':
        formatedDate = (date.getMonth() + 1) + '-' + date.getDate() + '-' + date.getFullYear();
        break;
      case 'DD-mm-YYYY':
        formatedDate = date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear();
        break;
      default:
        formatedDate = ComparativeConstants.MONTHS_TXT[date.getMonth()] + ' ' + date.getDate() + ',' + date.getFullYear();
        break;
    }
    return formatedDate;
  }

  getApplicantDetailsObjPayment(data) {
    const applicantDetails_obj = UtilMethodsService.copyObject(ComparativeConstants.APPLICANT_DETAILS_PAYMENT);
    applicantDetails_obj['application_firstName'] = data['firstName'];
    applicantDetails_obj['application_lastName'] = data['lastName'];
    applicantDetails_obj['application_address1'] = data['street1'];
    applicantDetails_obj['application_address2'] = data['street2'];
    applicantDetails_obj['application_city'] = data['city'];
    applicantDetails_obj['application_state'] = data['state'];
    applicantDetails_obj['application_zipCode'] = data['zipCode'];
    applicantDetails_obj['application_phone'] = data['applicantPhone'];
    return applicantDetails_obj;
  }

  isMandatoryAddressFieldsProvided() {
    if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers
    [ComparativeConstants.staticQuestionNames.application_address1])
      && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers
      [ComparativeConstants.staticQuestionNames.application_city])
      && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers
      [ComparativeConstants.staticQuestionNames.application_state])
      && !UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers
      [ComparativeConstants.staticQuestionNames.application_zipCode])
    ) {
      return true;
    }
    return false;
  }

  isBusinessNameMandatory() {
    if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails.questionAnswers
    [ComparativeConstants.staticQuestionNames.application_businessName])) {
      return true;
    } else {
      return false;
    }
  }

  isUserLogIn() {
    if (this.securityService.user && this.securityService.user['person']
      && this.securityService.user['person']['id']) {
      return true;
    } else {
      return false;
    }
  }

  isCompanyPresentForClient() {
    if (this.securityService.user && this.securityService.user['person']
      && this.securityService.user && this.securityService.user['person'].companyOfficePersons[0]
      && this.securityService.user && this.securityService.user['person'].companyOfficePersons[0].companyOffice
      && this.securityService.user && this.securityService.user['person'].companyOfficePersons[0].companyOffice.id) {
      return true;
    } else {
      return false;
    }
  }

  // tslint:disable-next-line: max-line-length
  prePopulateUserDetails(_spinner, _clientId?, clientType?, _isJumpOnGetQuote?, _form?, isCompanyExistForPersonProfile?, _isCheckBoxCheked?, _callbackFn?) {
    if (!UtilMethodsService.isEmpty(this.stateService.clientID) && (this.isAgent() || this.isClientAssociatedWithAgent())) {
      _spinner.show();
      this.insuranceStaticService.getClientDetailsById(_clientId, clientType).subscribe((res => {
        this.stateService.clientDetailsPayload = {};
        this.stateService.clientDetailsPayload = res;
        const _clientDetails = res;
        this.stateService.insuranceDetails.questionAnswers['firstName'] = _clientDetails.person['firstName'];
        this.stateService.insuranceDetails.questionAnswers['lastName'] = _clientDetails.person['lastName'];
        this.stateService.insuranceDetails.questionAnswers['applicantEmail'] = _clientDetails.person['email'];
        this.stateService.insuranceDetails.questionAnswers['applicantPhone'] =
          UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']);


        if (_clientDetails.clientType === 'P') {
          if (_isCheckBoxCheked) {
            // show business name as fn last
            // Personal address prepoplate
            // tslint:disable-next-line: max-line-length
            // const businessName = `${this.stateService.insuranceDetails.questionAnswers['firstName']} ${this.stateService.insuranceDetails.questionAnswers['lastName']}`;
            if (!UtilMethodsService.isEmpty(_form)) {
              _form.controls['applicantName'].setValue();
              // _form.controls['applicantName'].disable();
              _form.controls['applicantPhone'].setValue(UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']));
              if (!UtilMethodsService.isEmpty(_clientDetails.person.personAddresses[0])) {
                _form.controls['state'].setValue(_clientDetails.person.personAddresses[0].state);
                _form.controls['city'].setValue(_clientDetails.person.personAddresses[0].city);
                _form.controls['street1'].setValue(_clientDetails.person.personAddresses[0].street1);
                _form.controls['street2'].setValue(_clientDetails.person.personAddresses[0].street2);
                _form.controls['zipCode'].setValue(_clientDetails.person.personAddresses[0].zipCode);
              }
            }
            // this.stateService.insuranceDetails.questionAnswers['applicantName'] = businessName;
            this.stateService.insuranceDetails.questionAnswers['applicantPhone'] =
              UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']);
            if (_clientDetails.person.personAddresses.length > 0) {
              this.stateService.insuranceDetails.questionAnswers['state'] = _clientDetails.person.personAddresses[0].state;
              this.stateService.insuranceDetails.questionAnswers['city'] = _clientDetails.person.personAddresses[0].city;
              this.stateService.insuranceDetails.questionAnswers['street1'] = _clientDetails.person.personAddresses[0].street1;
              this.stateService.insuranceDetails.questionAnswers['street2'] = _clientDetails.person.personAddresses[0].street2;
              this.stateService.insuranceDetails.questionAnswers['zipCode'] = _clientDetails.person.personAddresses[0].zipCode;
            }


            // policy purchased is person and agent generate person policy
            if (!_clientDetails.policyPurchasedOnCompanyName && !_clientDetails.insurancePolicyPurchased
              && _clientDetails.totalPolicyPurchased > 0) {
              const ctrlsToDisable = ['street1', 'street2', 'city', 'state', 'zipCode',
              ];
              ctrlsToDisable.forEach((control) => {
                if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                  _form.controls[control].disable();
                }
              });
            }
          } else {
            if (isCompanyExistForPersonProfile) {
              // business name set with companany name
              // n busniess address populated
              if (!UtilMethodsService.isEmpty(_form)) {
                _form.controls['applicantName'].setValue(_clientDetails.person.companyOfficePersons[0].companyOffice.name);
                if (!this.stateService.ispolicyPurchasedOnCompanyName) {
                  _form.controls['applicantName'].enable();
                }
                _form.controls['applicantPhone'].setValue(UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']));
                if (!UtilMethodsService.isEmpty(_clientDetails.person.companyOfficePersons[0].companyOffice.address)) {
                  _form.controls['state'].setValue(_clientDetails.person.companyOfficePersons[0].companyOffice.address.state);
                  _form.controls['city'].setValue(_clientDetails.person.companyOfficePersons[0].companyOffice.address.city);
                  _form.controls['street1'].setValue(_clientDetails.person.companyOfficePersons[0].companyOffice.address.street1);
                  _form.controls['street2'].setValue(_clientDetails.person.companyOfficePersons[0].companyOffice.address.street2);
                  _form.controls['zipCode'].setValue(_clientDetails.person.companyOfficePersons[0].companyOffice.address.zipCode);
                }
              }
              this.stateService.insuranceDetails.questionAnswers['applicantPhone'] =
                UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']);

              if (!UtilMethodsService.isEmpty(_clientDetails.person.companyOfficePersons[0].companyOffice)) {
                this.stateService.insuranceDetails.
                  questionAnswers['applicantName'] = _clientDetails.person.companyOfficePersons[0].companyOffice.name;
                this.stateService.insuranceDetails.
                  questionAnswers['state'] = _clientDetails.person.companyOfficePersons[0].companyOffice.address.state;
                this.stateService.insuranceDetails.
                  questionAnswers['city'] = _clientDetails.person.companyOfficePersons[0].companyOffice.address.city;
                this.stateService.insuranceDetails.
                  questionAnswers['street1'] = _clientDetails.person.companyOfficePersons[0].companyOffice.address.street1;
                this.stateService.insuranceDetails.
                  questionAnswers['street2'] = _clientDetails.person.companyOfficePersons[0].companyOffice.address.street2;
                this.stateService.insuranceDetails.
                  questionAnswers['zipCode'] = _clientDetails.person.companyOfficePersons[0].companyOffice.address.zipCode;
              }

            } else {
              // show msg no company existing
              // Agent can add company /update company
              // no address field rest
              if (!UtilMethodsService.isEmpty(_form)) {
                _form.controls['applicantName'].setValue();
                _form.controls['applicantName'].enable();
                _form.controls['applicantPhone'].setValue(UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']));
                if (!UtilMethodsService.isEmpty(_clientDetails.person.personAddresses[0])) {
                  _form.controls['state'].setValue(_clientDetails.person.personAddresses[0].state);
                  _form.controls['city'].setValue(_clientDetails.person.personAddresses[0].city);
                  _form.controls['street1'].setValue(_clientDetails.person.personAddresses[0].street1);
                  _form.controls['street2'].setValue(_clientDetails.person.personAddresses[0].street2);
                  _form.controls['zipCode'].setValue(_clientDetails.person.personAddresses[0].zipCode);
                }

              }
              this.stateService.insuranceDetails.questionAnswers['applicantPhone'] =
                UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']);
              if (_clientDetails.person.personAddresses.length > 0) {
                this.stateService.insuranceDetails.questionAnswers['state'] = _clientDetails.person.personAddresses[0].state;
                this.stateService.insuranceDetails.questionAnswers['city'] = _clientDetails.person.personAddresses[0].city;
                this.stateService.insuranceDetails.questionAnswers['street1'] = _clientDetails.person.personAddresses[0].street1;
                this.stateService.insuranceDetails.questionAnswers['street2'] = _clientDetails.person.personAddresses[0].street2;
                this.stateService.insuranceDetails.questionAnswers['zipCode'] = _clientDetails.person.personAddresses[0].zipCode;
              } else if (_clientDetails.person.companyOfficePersons.length > 0) {
                const _address = _clientDetails.person.companyOfficePersons[0].companyOffice.address;
                if (!UtilMethodsService.isEmpty(_address)) {
                  this.stateService.insuranceDetails.questionAnswers['state'] = _address.state;
                  this.stateService.insuranceDetails.questionAnswers['city'] = _address.city;
                  this.stateService.insuranceDetails.questionAnswers['street1'] = _address.street1;
                  this.stateService.insuranceDetails.questionAnswers['street2'] = _address.street2;
                  this.stateService.insuranceDetails.questionAnswers['zipCode'] = _address.zipCode;
                  // tslint:disable-next-line: max-line-length
                  this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName] = _clientDetails.person.companyOfficePersons[0].companyOffice.company.name;
                }
              }
            }
          }
        } else if (_clientDetails.clientType === 'C') {
          if (_isCheckBoxCheked) {
            // tslint:disable-next-line: max-line-length
            const businessName = `${this.stateService.insuranceDetails.questionAnswers['firstName']} ${this.stateService.insuranceDetails.questionAnswers['lastName']}`;
            if (!UtilMethodsService.isEmpty(_form)) {
              _form.controls['applicantName'].setValue(businessName);
              _form.controls['applicantName'].disable();
              _form.controls['applicantPhone'].setValue(UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']));

              if (!UtilMethodsService.isEmpty(_clientDetails.companyOffice.address)) {
                _form.controls['state'].setValue(_clientDetails.person.personAddresses[0].state);
                _form.controls['city'].setValue(_clientDetails.person.personAddresses[0].city);
                _form.controls['street1'].setValue(_clientDetails.person.personAddresses[0].street1);
                _form.controls['street2'].setValue(_clientDetails.person.personAddresses[0].street2);
                _form.controls['zipCode'].setValue(_clientDetails.person.personAddresses[0].zipCode);
              }
            }
            this.stateService.insuranceDetails.questionAnswers['applicantName'] = businessName;
            this.stateService.insuranceDetails.questionAnswers['applicantPhone'] =
              UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']);
            if (_clientDetails.person.personAddresses.length > 0) {
              this.stateService.insuranceDetails.questionAnswers['state'] = _clientDetails.person.personAddresses[0].state;
              this.stateService.insuranceDetails.questionAnswers['city'] = _clientDetails.person.personAddresses[0].city;
              this.stateService.insuranceDetails.questionAnswers['street1'] = _clientDetails.person.personAddresses[0].street1;
              this.stateService.insuranceDetails.questionAnswers['street2'] = _clientDetails.person.personAddresses[0].street2;
              this.stateService.insuranceDetails.questionAnswers['zipCode'] = _clientDetails.person.personAddresses[0].zipCode;
            } else if (_clientDetails.person.companyOfficePersons.length > 0) {
              const _address = _clientDetails.person.companyOfficePersons[0].companyOffice.address;
              if (!UtilMethodsService.isEmpty(_address)) {
                this.stateService.insuranceDetails.questionAnswers['state'] = _address.state;
                this.stateService.insuranceDetails.questionAnswers['city'] = _address.city;
                this.stateService.insuranceDetails.questionAnswers['street1'] = _address.street1;
                this.stateService.insuranceDetails.questionAnswers['street2'] = _address.street2;
                this.stateService.insuranceDetails.questionAnswers['zipCode'] = _address.zipCode;
                // tslint:disable-next-line: max-line-length
                this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName] = _clientDetails.person.companyOfficePersons[0].companyOffice.company.name;
              }
            }

          } else {
            if (!UtilMethodsService.isEmpty(_form)) {
              _form.controls['applicantName'].setValue(_clientDetails.companyOffice.name);
              if (!this.stateService.ispolicyPurchasedOnCompanyName) {
                _form.controls['applicantName'].enable();
              }
              if (this.stateService.isCheckboxDisabled) {
                _form.controls['applicantName'].disable();
              }
              _form.controls['applicantPhone'].setValue(UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']));

              if (!UtilMethodsService.isEmpty(_clientDetails.companyOffice.address)) {
                _form.controls['state'].setValue(_clientDetails.companyOffice.address.state);
                _form.controls['city'].setValue(_clientDetails.companyOffice.address.city);
                _form.controls['street1'].setValue(_clientDetails.companyOffice.address.street1);
                _form.controls['street2'].setValue(_clientDetails.companyOffice.address.street2);
                _form.controls['zipCode'].setValue(_clientDetails.companyOffice.address.zipCode);
              }

            }
            this.stateService.insuranceDetails.
              questionAnswers['applicantName'] = _clientDetails.companyOffice.name;
            this.stateService.insuranceDetails.questionAnswers['applicantPhone'] =
              UtilMethodsService.deserializePhoneNumber(_clientDetails['phone']);
            if (_clientDetails.person.personAddresses.length > 0 && UtilMethodsService.isEmpty(this.isCompanyPresentForClient())) {
              this.stateService.insuranceDetails.questionAnswers['state'] = _clientDetails.person.personAddresses[0].state;
              this.stateService.insuranceDetails.questionAnswers['city'] = _clientDetails.person.personAddresses[0].city;
              this.stateService.insuranceDetails.questionAnswers['street1'] = _clientDetails.person.personAddresses[0].street1;
              this.stateService.insuranceDetails.questionAnswers['street2'] = _clientDetails.person.personAddresses[0].street2;
              this.stateService.insuranceDetails.questionAnswers['zipCode'] = _clientDetails.person.personAddresses[0].zipCode;
            } else if (_clientDetails.person.companyOfficePersons.length > 0) {
              const _address = _clientDetails.person.companyOfficePersons[0].companyOffice.address;
              if (!UtilMethodsService.isEmpty(_address)) {
                this.stateService.insuranceDetails.questionAnswers['state'] = _address.state;
                this.stateService.insuranceDetails.questionAnswers['city'] = _address.city;
                this.stateService.insuranceDetails.questionAnswers['street1'] = _address.street1;
                this.stateService.insuranceDetails.questionAnswers['street2'] = _address.street2;
                this.stateService.insuranceDetails.questionAnswers['zipCode'] = _address.zipCode;
                // tslint:disable-next-line: max-line-length
                this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName] = _clientDetails.person.companyOfficePersons[0].companyOffice.company.name;
              } else if (_clientDetails.person.personAddresses.length > 0) {
                this.stateService.insuranceDetails.questionAnswers['state'] = _clientDetails.person.personAddresses[0].state;
                this.stateService.insuranceDetails.questionAnswers['city'] = _clientDetails.person.personAddresses[0].city;
                this.stateService.insuranceDetails.questionAnswers['street1'] = _clientDetails.person.personAddresses[0].street1;
                this.stateService.insuranceDetails.questionAnswers['street2'] = _clientDetails.person.personAddresses[0].street2;
                this.stateService.insuranceDetails.questionAnswers['zipCode'] = _clientDetails.person.personAddresses[0].zipCode;
              }
            }

            if (!_clientDetails.policyPurchasedOnCompanyName && !_clientDetails.insurancePolicyPurchased &&
              _clientDetails.totalPolicyPurchased > 0) {
              const ctrlsToEnable = ['street1', 'street2', 'city', 'state', 'zipCode',
              ];
              if (!UtilMethodsService.isEmpty(_form)) {
                ctrlsToEnable.forEach((control) => {
                  if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                    _form.controls[control].enable();
                  }
                });
              }
            }

            if (!UtilMethodsService.isEmpty(this.stateService.insuranceDetails['isNewCompany'])
              && this.stateService.insuranceDetails['isNewCompany']) {
              _callbackFn();
              // agent try to add new company but normal update API get fail then isNewCompany should false
              // before normal update company get added
              // after add company , n continue click company should get updated
              this.stateService.insuranceDetails['isNewCompany'] = false;
            }

          }
        }
        this.stateService.getPorfileSetStatus.next(true);

        // if rails user client associated with agent and zip code 9 digit then split it
        // prepopulate address bName for rails user
        if (sessionStorage.getItem('originState') === 'rails') {
          if (!UtilMethodsService.isEmpty(_clientDetails.person.companyOfficePersons)
            && _clientDetails.person.companyOfficePersons.length > 0) {
            // tslint:disable-next-line: max-line-length
            this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName] = _clientDetails.person.companyOfficePersons[0].companyOffice.company.name;
            const tempAddress = _clientDetails.person.companyOfficePersons[0].companyOffice.address;
            Object.keys(tempAddress).forEach(_keys => {
              // Rails - SSO Zip Code Chnage new CR implemenation
              if (_keys === 'zipCode') {
                const indexOfDash = tempAddress[_keys].indexOf('-');
                if (indexOfDash > -1) {
                  // cosidering zipCode always have dash inside it
                  this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys].substring(0, indexOfDash);
                } else if (tempAddress[_keys].length === 9) {
                  // cosidering zipCode without dash but lenght with 9 digit
                  this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys].substring(0, 5);
                } else {
                  // considering zipCode lentgh with five digit only as accepted criteria
                  this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys].substring(0, 5);
                }

                if (!UtilMethodsService.isEmpty(_form)) {
                  _form.controls['zipCode'].setValue(this.stateService.insuranceDetails.questionAnswers[_keys]);
                }

              } else {
                this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys];
                if (!UtilMethodsService.isEmpty(_form)) {
                  _form.controls[_keys].setValue(this.stateService.insuranceDetails.questionAnswers[_keys]);
                }

              }
            });
          }
        }

        this.stateService.insuranceDetails['isPrepopulateUserDetails'] = true;
        this.stateService.isLoadComponent.next(true);
        _spinner.hide();
        if (_isJumpOnGetQuote) { this.router.navigate(['/insurance/getquotes']); }

      }), (err) => {
        _spinner.hide();
      });
    } else if (!UtilMethodsService.isEmpty(this.securityService.user)
      && !UtilMethodsService.isEmpty(this.securityService.user['person'])) {
      const _userDetails = this.securityService.user['person'];
      this.stateService.insuranceDetails.questionAnswers['firstName'] = _userDetails.firstName;
      this.stateService.insuranceDetails.questionAnswers['lastName'] = _userDetails.lastName;
      if (!UtilMethodsService.isEmpty(_userDetails.companyOfficePersons)
        && !UtilMethodsService.isEmpty(_userDetails.companyOfficePersons[0].companyOffice)
        && !UtilMethodsService.isEmpty(_userDetails.companyOfficePersons[0].companyOffice.phone)) {
        // set phone number from company profile
        this.stateService.insuranceDetails.questionAnswers['applicantPhone'] = _userDetails.companyOfficePersons[0].companyOffice.phone;
      } else {
        // set phone number from personal profile if phone number not exist in company profile
        this.stateService.insuranceDetails.questionAnswers['applicantPhone'] = _userDetails.phone;
      }

      if (!UtilMethodsService.isEmpty(_userDetails.companyOfficePersons)
        && !UtilMethodsService.isEmpty(_userDetails.companyOfficePersons[0].companyOffice)
        && !UtilMethodsService.isEmpty(_userDetails.companyOfficePersons[0].companyOffice.email)) {
        // set email from company profile
        this.stateService.insuranceDetails.questionAnswers['applicantEmail'] = _userDetails.companyOfficePersons[0].companyOffice.email;
      } else {
        // set email from personal profile if email not exist in company profile
        this.stateService.insuranceDetails.questionAnswers['applicantEmail'] = _userDetails.email;
      }
      if (this.securityService.user.person.companyOfficePersons && this.securityService.user.person.companyOfficePersons.length > 0) {
        // this.stateService.insuranceDetails.questionAnswers['applicantEmail'] = _userDetails.companyOfficePersons[0].companyOffice.email;
        // this.stateService.insuranceDetails.questionAnswers['applicantEmail'] = 'neha@gmail.com';
        if (sessionStorage.getItem('originState') === 'rails') {
          // tslint:disable-next-line: max-line-length
          this.stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_businessName] = this.securityService.user.person.companyOfficePersons[0].companyOffice.company.name;
          const tempAddress = _userDetails.companyOfficePersons[0].companyOffice.address;
          Object.keys(tempAddress).forEach(_keys => {
            // Rails - SSO Zip Code Chnage new CR implemenation
            if (_keys === 'zipCode') {
              const indexOfDash = tempAddress[_keys].indexOf('-');
              if (indexOfDash > -1) {
                // cosidering zipCode always have dash inside it
                this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys].substring(0, indexOfDash);
              } else if (tempAddress[_keys].length === 9) {
                // cosidering zipCode without dash but lenght with 9 digit
                this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys].substring(0, 5);
              } else {
                // considering zipCode lentgh with five digit only as accepted criteria
                this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys].substring(0, 5);
              }
            } else {
              this.stateService.insuranceDetails.questionAnswers[_keys] = tempAddress[_keys];
            }

          });
        }
      }
      this.stateService.userID = _userDetails.id;
      this.insuranceStaticService.getCompanyInfo(_userDetails.id).subscribe((res => {
        if (res.length !== 0) {
          this.stateService.companyInfo = res;
          if (res[0].name) {
            this.stateService.insuranceDetails.questionAnswers['applicantName'] = res[0].name;
          }
          if (!UtilMethodsService.isEmpty(res[0].companyOffices)) {
            this.stateService.isCompanyExist = true;
            this.stateService.directClientCompanyId = res[0].companyOffices[0].id;
            if (res[0].companyOffices.length > 0) {
              const _address = res[0].companyOffices[0].address;
              if (!UtilMethodsService.isEmpty(_address)) {
                this.stateService.insuranceDetails.questionAnswers['state'] = _address.state;
                this.stateService.insuranceDetails.questionAnswers['city'] = _address.city;
                this.stateService.insuranceDetails.questionAnswers['street1'] = _address.street1;
                this.stateService.insuranceDetails.questionAnswers['street2'] = _address.street2;
                this.stateService.insuranceDetails.questionAnswers['zipCode'] = _address.zipCode;
              }
            }
            this.stateService.getPorfileSetStatus.next(true);
            this.stateService.insuranceDetails['isPrepopulateUserDetails'] = true;
            if (_isJumpOnGetQuote) { this.router.navigate(['/insurance/getquotes']); }
          }
        } else {
          this.stateService.getPorfileSetStatus.next(true);
          this.stateService.insuranceDetails['isPrepopulateUserDetails'] = true;
          if (_isJumpOnGetQuote) { this.router.navigate(['/insurance/getquotes']); }
        }
      }));
    }
  }


  setControlState(_spinner, _form) {
    if (!UtilMethodsService.isEmpty(this.stateService.clientID) && !UtilMethodsService.isEmpty(this.stateService.clientType)) {
      _spinner.show();
      this.insuranceStaticService.getClientInfoOnType(this.stateService.clientType, this.stateService.clientID).subscribe((res => {
        const _clientDetails = res;

        if (_clientDetails.policyPurchasedOnCompanyName || _clientDetails.insurancePolicyPurchased) {
          this.stateService.ispolicyPurchasedOnCompanyName = true;
        } else {
          this.stateService.ispolicyPurchasedOnCompanyName = false;
        }

        // if (this.stateService.clientType === 'P') {
        //   // account personal personal address get filled
        //   // set fist name last name
        //   // tslint:disable-next-line: max-line-length
        //   // for defect 3814 commenting below lines
        // tslint:disable-next-line:max-line-length
        //   // this.prePopulateUserDetails(_spinner, this.stateService.clientID, this.stateService.clientType, false, _form, _clientDetails.companyPresentForPerson, true);
        // } else if (_clientDetails.accountType === 'C') {
        //   // if account company address get filled
        //   // this.prePopulateUserDetails(_spinner, this.stateService.clientID, this.stateService.clientType, false, _form);
        // }
        console.log('_clientDetails >>> ', _clientDetails);
        if (!UtilMethodsService.isEmpty(_form.controls['applicantEmail'])) {
          _form.controls['applicantEmail'].disable();
        }
        if (this.isAgent() || this.isClientAssociatedWithAgent()) {
          if (!_clientDetails.quoteSent && !this.isClientAssociatedWithAgent()) {
            this.stateService.isCheckboxDisabled = false;
            // quote sent and account is not registered
          } else if (_clientDetails.quoteSent && !_clientDetails.accountRegistered && !this.isClientAssociatedWithAgent()) {
            const ctrlsToDisable = ['firstName', 'lastName', 'street1', 'street2', 'city', 'state', 'zipCode', 'applicantPhone'
              , 'applicantName'];
            ctrlsToDisable.forEach((control) => {
              if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                _form.controls[control].disable();
              }
            });
            this.stateService.isCheckboxDisabled = true;
          } else if (_clientDetails.accountRegistered) {
            // In Progress Policy
            // tslint:disable-next-line:triple-equals
            if (_clientDetails.applicationInProgress && _clientDetails.applicationInProgress > 0 &&
              // tslint:disable-next-line:max-line-length
              _clientDetails.totalPolicyPurchased === 0 && _clientDetails.applicationDeclined === 0 && !this.isClientAssociatedWithAgent()) {
              const ctrlsToDisable = ['firstName', 'lastName', 'applicantEmail', 'applicantName'];
              ctrlsToDisable.forEach((control) => {
                if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                  _form.controls[control].disable();
                }
              });
              // Complete policy
              // tslint:disable-next-line:max-line-length
            } else if (_clientDetails.totalPolicyPurchased > 0 || _clientDetails.applicationDeclined > 0 || (this.isClientAssociatedWithAgent() && _clientDetails.totalPolicyPurchased > 0 || _clientDetails.applicationDeclined > 0)) {

              const ctrlsToDisable = ['firstName', 'lastName', 'street1', 'street2', 'city', 'state', 'zipCode',
                , 'applicantEmail', 'applicantName'];
              ctrlsToDisable.forEach((control) => {
                if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                  _form.controls[control].disable();
                }
              });
              // policy purchased is person and agent generate company policy
              if (_clientDetails.accountType === 'C' && !_clientDetails.policyPurchasedOnCompanyName
                && !_clientDetails.insurancePolicyPurchased) {
                const ctrlsToEnable = ['street1', 'street2', 'city', 'state', 'zipCode',
                  , 'applicantName'];
                ctrlsToEnable.forEach((control) => {
                  if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                    _form.controls[control].enable();
                  }
                });
                // policy purchased is company and agent generate person policy
              } else if (_clientDetails.accountType === 'P' && (_clientDetails.policyPurchasedOnCompanyName
                || _clientDetails.insurancePolicyPurchased)) {
                const ctrlsToEnable = ['street1', 'street2', 'city', 'state', 'zipCode',
                  , 'applicantName'];
                ctrlsToEnable.forEach((control) => {
                  if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                    _form.controls[control].enable();
                  }
                });
              }
            }
            if (!_clientDetails.policyPurchasedOnCompanyName && !_clientDetails.insurancePolicyPurchased) {
              if (!UtilMethodsService.isEmpty(_form.controls['applicantName'])) {
                _form.controls['applicantName'].enable();
              }
              this.stateService.isCheckboxDisabled = false;
            }
          }
        } else {
          if (_clientDetails.totalPolicyPurchased > 0) {
            const ctrlsToDisable = ['firstName', 'lastName', 'applicantEmail'];
            ctrlsToDisable.forEach((control) => {
              if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                _form.controls[control].disable();
              }
            });
          }

          if (_clientDetails.totalPolicyPurchased > 0 && ((_clientDetails.policyPurchasedOnCompanyName &&
            _clientDetails.policyPurchasedOnCompanyName === true) || (_clientDetails.insurancePolicyPurchased &&
              _clientDetails.insurancePolicyPurchased === true))) {
            const ctrlsToDisable = ['applicantName'];
            ctrlsToDisable.forEach((control) => {
              if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                _form.controls[control].disable();
              }
            });
          } else {
            const ctrlsToEnable = ['applicantName', 'setApplicantName'];
            ctrlsToEnable.forEach((control) => {
              if (!UtilMethodsService.isEmpty(_form.controls[control])) {
                _form.controls[control].enable();
              }
            });
          }


        }
        _spinner.hide();
      }), (err) => {
        _spinner.hide();
      });
    }
  }

  debounce(func, wait, immediate?) {
    let timeout;
    return function() {
      const context = this, args = arguments;
      const later = function() {
        timeout = null;
        if (!immediate) {
          func.apply(context, args);
        }
      };
      const callNow = (immediate && !timeout);
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) {
        func.apply(context, args);
      }
    };
  }

  setReadOnly(fieldName) {
    return ComparativeConstants.QUESTIONTODISABLE.includes(fieldName);
  }

  isAgent() {
    if (!UtilMethodsService.isEmpty(this.securityService.user)) {
      return this.securityService.user.hasAgentRole;
    }
  }

  isPolicyAssociatedWithAgent() {
    if (!UtilMethodsService.isEmpty(this.stateService.agentId)) {
      return true;
    } else {
      return false;
    }
  }

  isClientAssociatedWithAgent() {
    if (this.securityService.user && this.securityService.user['person']
      && this.securityService.user['person']['agentId']) {
      return true;
    } else {
      return false;
    }
  }

  getPersonalProfileTypeAndProfileId() {
    if (this.securityService.user && this.securityService.user['person']
      && this.securityService.user['person']['id']) {
      if (this.isCompanyPresentForClient()) {
        return [this.securityService.user['person'].companyOfficePersons[0].companyOffice.id, 'C'];
      } else {
        return [this.securityService.user['person']['id'], 'P'];
      }
    }
  }

  getPersonalId() {
    if (this.securityService.user && this.securityService.user['person']
      && this.securityService.user['person']['id']) {
      return this.securityService.user['person']['id'];
    }
  }

  get agentId() {
    if (!UtilMethodsService.isEmpty(this.securityService.user.agent)) {
      return this.securityService.user.agent.id;
    } else if (!UtilMethodsService.isEmpty(this.securityService.user.person)) {
      return this.securityService.user.person.agentId;
    }
  }

  encryptedPersonUpdatePayload(_requestPayload, _stateSeviceQA, _companyPresentStat?) {
    const _requestPayloadCopy = UtilMethodsService.copyObject(_requestPayload);
    _requestPayloadCopy.person.firstName = _stateSeviceQA.firstName;
    _requestPayloadCopy.person.lastName = _stateSeviceQA.lastName;
    _requestPayloadCopy.person.phone = UtilMethodsService.serializePhoneNumber(_stateSeviceQA.applicantPhone);
    _requestPayloadCopy.phone = UtilMethodsService.serializePhoneNumber(_stateSeviceQA.applicantPhone);

    if (!UtilMethodsService.isEmpty(_stateSeviceQA['applicantName']) &&
      !UtilMethodsService.isEmpty(_companyPresentStat) && _companyPresentStat === false) {
      const companyOfficeObject = {
        'agentId': this.agentId,
        'name': _stateSeviceQA['applicantName'],
        'address': {
          'street1': _stateSeviceQA['street1'],
          'street2': _stateSeviceQA['street2'],
          'city': _stateSeviceQA['city'],
          'state': _stateSeviceQA['state'],
          'zipCode': _stateSeviceQA['zipCode'],
        },
        'email': _stateSeviceQA['applicantEmail'],
        'phone': UtilMethodsService.serializePhoneNumber(_stateSeviceQA.applicantPhone),
        'officeType': 'Main',
        'company': {
          'name': _stateSeviceQA['applicantName'],
        },
      };
      _requestPayloadCopy.companyOffice = companyOfficeObject;
      return _requestPayloadCopy;
    } else {

      if (UtilMethodsService.isEmpty(_requestPayloadCopy.person.personAddresses[0])) {
        _requestPayloadCopy.person.personAddresses[0] = {};
      }

      if (UtilMethodsService.isEmpty(_requestPayloadCopy.person.personAddresses[0])) {
        _requestPayloadCopy.person.personAddresses[0] = {};
      }

      _requestPayloadCopy.person.personAddresses[0].street1 = _stateSeviceQA['street1'];
      _requestPayloadCopy.person.personAddresses[0].street2 = _stateSeviceQA['street2'];
      _requestPayloadCopy.person.personAddresses[0].state = _stateSeviceQA['state'];
      _requestPayloadCopy.person.personAddresses[0].city = _stateSeviceQA['city'];
      _requestPayloadCopy.person.personAddresses[0].zipCode = _stateSeviceQA['zipCode'];
      return _requestPayloadCopy;
    }
  }

  encryptedCompanyUpdatePayload(_requestPayload, _stateSeviceQA) {
    const _requestPayloadCopy = UtilMethodsService.copyObject(_requestPayload);
    _requestPayloadCopy.person.firstName = _stateSeviceQA.firstName;
    _requestPayloadCopy.person.lastName = _stateSeviceQA.lastName;
    if (_requestPayloadCopy.companyOffice) {
      _requestPayloadCopy.companyOffice.phone = UtilMethodsService.serializePhoneNumber(_stateSeviceQA.applicantPhone);
      _requestPayloadCopy.companyOffice.company.name = _stateSeviceQA['applicantName'];
      _requestPayloadCopy.companyOffice.name = _stateSeviceQA['applicantName'];
    }
    _requestPayloadCopy.phone = UtilMethodsService.serializePhoneNumber(_stateSeviceQA.applicantPhone);
    // _formDataValuesCopy.name = formValue.businessDetails.applicantBusinessName;
    if (_requestPayloadCopy.person.companyOfficePersons[0] && _requestPayloadCopy.person.companyOfficePersons[0].companyOffice) {
      _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.name = _stateSeviceQA['applicantName'];
    }
    if (_requestPayloadCopy.companyOffice) {
      if (UtilMethodsService.isEmpty(_requestPayloadCopy.companyOffice.address)) {
        _requestPayloadCopy.companyOffice.address = {};
      }
      if (_requestPayloadCopy.companyOffice.address) {
        _requestPayloadCopy.companyOffice.address.street1 = _stateSeviceQA.street1 || null;
        _requestPayloadCopy.companyOffice.address.street2 = _stateSeviceQA.street2 || null;
        _requestPayloadCopy.companyOffice.address.state = _stateSeviceQA.state || null;
        _requestPayloadCopy.companyOffice.address.city = _stateSeviceQA.city || null;
        _requestPayloadCopy.companyOffice.address.zipCode = _stateSeviceQA.zipCode || null;
      }
    }
    if (_requestPayloadCopy.person.companyOfficePersons[0] && _requestPayloadCopy.person.companyOfficePersons[0].companyOffice
      && _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address) {
      if (UtilMethodsService.isEmpty(_requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address)) {
        _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address = {};
      }
      _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address.street1 = _stateSeviceQA.street1 || null;
      _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address.street2 = _stateSeviceQA.street2 || null;
      _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address.state = _stateSeviceQA.state || null;
      _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address.city = _stateSeviceQA.city || null;
      _requestPayloadCopy.person.companyOfficePersons[0].companyOffice.address.zipCode = _stateSeviceQA.zipCode || null;
    }

    return _requestPayloadCopy;
  }

  getRailsClientAssocaiateWithAgentId() {
    if (!UtilMethodsService.isEmpty((this.securityService.user))) {
      if (this.securityService.user.isCompany === true) {
        return this.securityService.user.person.companyOfficePersons[0].companyOffice.id;
      }
    }
  }

}
