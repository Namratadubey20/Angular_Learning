import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ProductConfigService {
  public PAYMENT_METHOD_MONTHLY = {
    allowed_products: ['pnl', 'epli'],
  };
  public PAYMENT_METHOD_YEARLY = {
    allowed_products: ['pnl', 'cyber', 'epli'],
  };
  public INSURANCE_ACCORDIAN_PANEL1 = {
    allowed_products: ['pnl', 'cyber'],
  };

  public INSURANCE_ACCORDIAN_PANEL2 = {
    allowed_products: ['pnl', 'cyber', 'epli'],
  };

  public EPLI_APPLICANT_DETAILS = {
    allowed_products: ['epli'],
  };

  public INSURANCE_ACCORDIAN_PANEL3 = {
    allowed_products: ['pnl', 'cyber', 'epli'],
  };

  public INSURANCE_ACCORDIAN_PANEL4 = {
    allowed_products: ['epli'],
  };

  public INSURANCE_DEDUCTIBLE = {
    allowed_products: ['pnl', 'epli'],
  };

  public readAndAgreeToTerms = {
    allowed_products: ['pnl', 'cyber', 'epli'],
  };

  public acknowledgeTerms = {
    allowed_products: ['cyber'],
  };

  public acknowledgeFraudWarning = {
    allowed_products: ['cyber', 'epli'],
  };

  public reviewAgentApplication = {
    allowed_products: ['pnl', 'cyber', 'epli'],
  };

  public refreshKOQuestion = {
    allowed_products: ['pnl', 'epli'],
  };

  public SUMMARY_PANEL_SELECTED_PLAN = {
    allowed_products: ['pnl', 'epli'],
  };

  public SUMMARY_PANEL_PAYMENT_PLAN = {
    allowed_products: ['cyber'],
  };

  public SHOW_BUSINESSICON = {
    allowed_products: ['pnl', 'epli'],
  };

  public INSURANCE_LIMIT_ALLOW_PRODUCT = {
    allowed_products: ['pnl'],
  };

  public INSURANCE_CUSTOM_VALIDATION_ALLOW_PRODUCT = {
    allowed_products: ['epli', 'cyber'],
  };

  public LOGIN_INSURANCE_ALLOW_PRODUCT = {
    allowed_products: ['pnl', 'cyber', 'epli'],
  };
  public HELP_TEXT_MONTHLY_PAYMENT_PLAN = {
    allowed_products: ['pnl', 'epli'],
  };

  constructor() { }
}
