import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { GetQuoteFieldJsonService } from '../jsons/get-quotes-common.service';
import { TempAPIMockData } from '../services/temp-apimock.service';
import { GetInsuranceFieldJsonService } from '../jsons/get-insurancedetails-common.service';
import { GetYourQuoteFieldJsonService } from '../jsons/get-your-quotes-common.service';
import { GetAgreementFieldJsonService } from '../jsons/get-agreement-common.service';
import { GetPaymentFieldJsonService } from '../jsons/get-paymentdetails-common.service';
import { RestService } from '../services/rest.service';
import { UrlConstant } from '../constants/url-constant';
import { ComparativeConstants } from '../constants/comparative-constants';
import { HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { StateService } from '../services/state.service';
import { HttpClient } from '@angular/common/http';
import { ISignUp } from '../component/screens/sign-up/sign-up';
import { GetCreateUserFieldJsonService } from '../jsons/get-create-user-common.service';
import { GetEmailFieldJsonService } from '../jsons/get-emaildetails-common.service';
import { GetConfirmResponseJsonService } from '../jsons/get-confirm-response-common.service';
import { GetPrintOptionsFieldJsonService } from '../jsons/get-print-options-common.service';
import { GetAddressGridFieldJsonService } from '../jsons/get-address-grid-common.service';
import { UtilMethodsService } from './util-method.service';

@Injectable({
  providedIn: 'root',
})

export class InsuranceStaticService {
  public showSignup = new BehaviorSubject<boolean>(false);
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };
  constructor(public _getQuoteJsonService: GetQuoteFieldJsonService, public _getInsuranceDetailService: GetInsuranceFieldJsonService,
    public _getYourQuoteJsonService: GetYourQuoteFieldJsonService, public _getAgreementJsonService: GetAgreementFieldJsonService,
    public _getPaymentDetailService: GetPaymentFieldJsonService, private restService: RestService, private urlConstant: UrlConstant,
    public _stateService: StateService, public httpClient: HttpClient,
    public _getCreateUserFieldJsonService: GetCreateUserFieldJsonService, public _getEmailDataJsonService: GetEmailFieldJsonService,
    public _getConfirmResponseJsonService: GetConfirmResponseJsonService,
    public _getPrintOptionsJsonService: GetPrintOptionsFieldJsonService,
    public _getAddressGridFieldJsonService: GetAddressGridFieldJsonService) {

  }

  getSignUpValue() {
    return this.showSignup.asObservable();
  }

  setSignUpValue(value) {
    this.showSignup.next(value);
  }

  signUpStandardUser(request_obj: ISignUp) {
    return this.restService.post(this.urlConstant.SIGNUP, request_obj, {}, '');
  }

  getQuotesFormJson() {
    return this._getQuoteJsonService.getData();
  }

  getYourQuotesFormJson() {
    return this._getYourQuoteJsonService.getData();
  }

  getAgreementFormJson() {
    return this._getAgreementJsonService.getData();
  }

  getStates(): Observable<any> {
    return this.restService.get(this.urlConstant.GET_STATE, {}, {}, this.httpOptions);
  }

  getSanctionedStates(): Observable<any> {
    return this.restService.get(this.urlConstant.GET_SANCTIONED_STATE,
      {
        productTypeCode: this._stateService.insuranceSelected[0] || 'pnl',
      }, {}, this.httpOptions);
  }

  getProfession(): Observable<any> {
    return this.restService.get(this.urlConstant.GET_PROFESSION, { productTypeCode: this._stateService.insuranceSelected[0] || 'pnl' },
      {}, this.httpOptions);
  }

  getInsuranceDetailFormJson() {
    return this._getInsuranceDetailService.getData();
  }

  getInsuranceSectionFormJson(): Observable<any> {
    return this.restService.get(this.urlConstant.GET_KO_QUESTIONS,
      {
        productTypeCode: this._stateService.insuranceSelected[0] || 'pnl'
        , stateCode: this._stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state],
        // tslint:disable-next-line:max-line-length
        professionCode: this._stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_profession],
      },
      {}, this.httpOptions);
    // return TempAPIMockData.getKnockOutSections();
  }

  getZipCodeFromAddress(zipCode): Observable<any> {
    return this.restService.get(this.urlConstant.GET_ZIPFROMADDRESS, { 'zipCode': zipCode }, {});
  }

  getRevisedPremiumQuite() {
    return Math.floor(Math.random() * (500 - 200)) + 200;
  }
  getPaymentDetailsFormJson() {
    return this._getPaymentDetailService.getData();
  }
  getEmailtDetailsFormJson() {
    return this._getEmailDataJsonService.getData();
  }
  getNewCardsList() {
    return TempAPIMockData.getCreditCards();
  }

  getStaticQuestion(): Observable<any> {
    // tslint:disable-next-line:max-line-length
    return this.restService.get(this.urlConstant.GET_STATIC_QUESTIONS, { productTypeCode: this._stateService.insuranceSelected[0] || 'pnl' },
      {}, this.httpOptions);
  }

  createApplication(_payload, _pageReference) {
    _payload['data']['pageReference'] = _pageReference;
    return this.restService.post(`${this.urlConstant.POST_CREATE_APPLICATION}${this._stateService.insuranceSelected[0] || 'pnl'}`,
      _payload, this.httpOptions, '');
  }

  premiumCalculator(_payload, _pageReference) {
    _payload['data']['pageReference'] = _pageReference;
    _payload['data']['premiumOption'] = 'annualPay';
    return this.restService.post(`${this.urlConstant.POST_PREMIUM_CALCULATOR}${this._stateService.insuranceSelected[0] || 'pnl'}`,
      _payload, this.httpOptions, '');
  }

  saveAnonymousQuote(_payload) {
    return this.restService.post(this.urlConstant.POST_SAVE_ANONYMOUS_QUOTE, _payload, this.httpOptions, '');
  }

  updateApplication(_payload, _pageReference) {
    _payload['data']['pageReference'] = _pageReference;
    return this.restService.put(this.urlConstant.PUT_UPDATE_APPLICATION, _payload, this.httpOptions, '',
      {
        'productTypeCode': this._stateService.insuranceSelected[0] || 'pnl',
        'applicationId': this._stateService.insuranceDetails.applicationId,
      });
  }

  saveApplication(_payload, _pageReference) {
    _payload['data']['pageReference'] = _pageReference;
    return this.restService.put(this.urlConstant.PUT_SAVE_APPLICATION, _payload, this.httpOptions, '',
      {
        'productTypeCode': this._stateService.insuranceSelected[0] || 'pnl',
        'applicationId': this._stateService.insuranceDetails.applicationId,
      });
  }

  saveCompanyInfo(id) {
    const _payload = this._stateService.companyInfo;
    _payload[0].companyOffices[0].companyOfficePersons[0]['responsiblePerson'] = true;
    _payload[0].companyOffices[0].address = {
      street1: this._stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_address1] || null,
      street2: this._stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_address2] || null,
      city: this._stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_city] || null,
      state: this._stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state] || null,
      zipCode: this._stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_zipCode] || null,
    };
    if (_payload) {
      return this.restService.put(this.urlConstant.BUSINESS_UPDATE, _payload[0], this.httpOptions, '',
        {
          'personId': id,
        });
    }

    // old implementation
    // if (this._stateService.isCompanyExist) {
    //   return this.restService.put(this.urlConstant.GET_COMPANY, _payload[0], this.httpOptions, '',
    //     {
    //       'applicationId': id,
    //     });
    // } else {
    //   return this.restService.post(`${this.urlConstant.POST_COMPANY}${id}${this._stateService.company}`,
    //     _payload[0], this.httpOptions, '');
    // }
  }

  submitApplication(_payload, _pageReference) {
    console.log('In submitApplcatipn.. _payload : _pageReference', _payload, ' : ', _pageReference);
    _payload['data']['pageReference'] = _pageReference;
    return this.restService.put(this.urlConstant.PUT_SUBMIT_APPLICATION, _payload, this.httpOptions, '',
      {
        'productTypeCode': this._stateService.insuranceSelected[0] || 'pnl',
        'applicationId': this._stateService.insuranceDetails.applicationId,
      });
  }

  getCreateUserFieldFormJson() {
    return this._getCreateUserFieldJsonService.getData();
  }

  getApplicationData(_applicationId): Observable<any> {
    return this.restService.get(this.urlConstant.GET_APPLICATION_DATA, { applicationId: _applicationId }, {});
  }

  getAgreementTerms(): Observable<any> {
    // tslint:disable-next-line:max-line-length
    return this.restService.get(this.urlConstant.AGREEMENT_TERMS, { productTypeCode: this._stateService.insuranceSelected[0] || 'pnl' },
      {}, this.httpOptions);
  }

  getConfirmResponseFormJson() {
    return this._getConfirmResponseJsonService.getData();
  }

  getInsuranceProduct(_productId): Observable<any> {
    return this.restService.get(this.urlConstant.GET_PRODUCT, { productId: _productId },
      {}, this.httpOptions);
  }

  getInsuranceProductDocument(_productId): Observable<any> {
    return this.restService.get(this.urlConstant.GET_PRODUCT_DOCUMENT, { productId: _productId },
      {}, this.httpOptions);
  }

  getInsuranceProductSuccessDeclineMessage(successOrDecline): Observable<any> {
    return this.restService.get(this.urlConstant.GET_SUCCESS_DECLINE,
      {
        productCode: this._stateService.insuranceSelected[0] || 'pnl',
        parameterName: successOrDecline,
      },
      {}, this.httpOptions);
  }

  downloadFile(fileId) {
    return this.restService.get(this.urlConstant.GET_DOWNLOAD_FILE, { fileId: fileId },
      {}, this.httpOptions);
  }

  getPrintOptionsFormJson() {
    return this._getPrintOptionsJsonService.getData();
  }

  getInsuranceLimit(_professionCode) {
    return this.restService.get(this.urlConstant.GET_INSURANCE_LIMIT, { professionCode: _professionCode },
      {}, this.httpOptions);
  }

  getClientDetailsById(client_id, _clientType) {
    return this.restService.get(this.urlConstant.GET_CLIENT_DETAILS_BY_TYPE, { clientType: _clientType, clientId: Number(client_id) },
      {}, this.httpOptions);
  }

  getClientInfoOnType(_clientType, client_id: number): Observable<any> {
    return this.restService.get(this.urlConstant.CLIENT_INFO, { clientType: _clientType, clientId: Number(client_id) },
      {}, this.httpOptions);
  }

  sendToclientMailDetails(_applicationId) {
    return this.restService.get(this.urlConstant.GET_SEND_TO_CLIENT_DETAIL, { applicationId: _applicationId },
      {}, this.httpOptions);
  }

  sendMailToclient(_applicationId) {
    return this.restService.put(this.urlConstant.SEND_MAIL_TO_CLIENT, { optionalMessage: '' },
      this.httpOptions, '', { 'applicationId': _applicationId });
  }

  getCompanyInfo(_applicationId) {
    return this.restService.get(this.urlConstant.GET_COMPANY, { applicationId: _applicationId },
      {}, this.httpOptions);
  }

  updateClientData(_payload, agentId: number): Observable<any> {
    return this.restService.put(this.urlConstant.UPDATE_CLIENT, _payload, this.httpOptions, '', { agentId: agentId });
  }

  getAddressGridFromJson() {
    return this._getAddressGridFieldJsonService.getData();
  }
}
