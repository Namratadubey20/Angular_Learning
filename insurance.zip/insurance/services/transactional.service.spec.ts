import { TestBed, async, inject } from '@angular/core/testing';
import { TransactionalService } from './transactional.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppConfigService } from 'src/app/app-config-service';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SecurityService } from 'src/app/security/security.service';

describe('Service: Transactional Service', () => {
  // const routerSpy = {
  //   navigate: jasmine.createSpy('navigate'),
  // };
  let router: Router;

  const mockedServiceHandler: ServiceHandler = null;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, RouterTestingModule],
      providers: [TransactionalService,
        {
          provide: ServiceHandler,
          useValue: mockedServiceHandler,
        }, HttpClient,
        // { provide: Router, useValue: routerSpy },
        {
          provide: AppConfigService,
          useValue: mockedAppConfigServic,
        },
      ],
    });
    router = TestBed.get(Router);
  });

  it('should create an instance', inject([TransactionalService], (service: TransactionalService) => {
    expect(service).toBeTruthy();
    spyOn(service, 'loggedIn$').and.returnValue(true);
  }));

  it('should return location object if getFormattedAddress method call', inject([TransactionalService], (service: TransactionalService) => {

    const place = {
      'address_components': [
        {
          'long_name': 'suite k',
          'short_name': 'suite k',
          'types': ['subpremise'],
        },
        {
          'long_name': '530',
          'short_name': '530',
          'types': ['street_number'],
        },
        {
          'long_name': 'West Eaton Avenue',
          'short_name': 'W Eaton Ave',
          'types': ['route'],
        },
        {
          'long_name': 'Tracy',
          'short_name': 'Tracy',
          'types': ['locality', 'political'],
        },
        {
          'long_name': 'San Joaquin County',
          'short_name': 'San Joaquin County',
          'types': ['administrative_area_level_2', 'political'],
        },
        {
          'long_name': 'California',
          'short_name': 'CA',
          'types': ['administrative_area_level_1', 'political'],
        },
        {
          'long_name': 'United States',
          'short_name': 'US',
          'types': ['country', 'political'],
        },
        {
          'long_name': 'ABC',
          'short_name': 'AB',
          'types': ['country', 'political', 'sublocality_level_1'],
        },
        {
          'long_name': '95376',
          'short_name': '95376',
          'types': ['postal_code'],
        },
      ],
      'formatted_address': '530 W Eaton Ave suite k, Tracy, CA 95376, USA',
      'name': 'Puneet Grewal, MD',
    };
    const result = service.getFormattedAddress(place);
    expect(typeof result).toBe('object');
  }));

  it('if no locality then addressLine2 will be sublocality', inject([TransactionalService], (service: TransactionalService) => {
    expect(service).toBeTruthy();
    const place = {
      'address_components': [
        {
          'long_name': 'suite k',
          'short_name': 'suite k',
          'types': ['subpremise'],
        },
        {
          'long_name': 'ABC',
          'short_name': 'AB',
          'types': ['country', 'political', 'sublocality_level_1'],
        },
      ],
      'formatted_address': '530 W Eaton Ave suite k, Tracy, CA 95376, USA',
      'name': 'Puneet Grewal, MD',
    };

    const result = service.getFormattedAddress(place);
    expect(typeof result).toBe('object');
  }));

  it('if no addressLine2 and state then formatted_address considered as address object', inject([TransactionalService],
    (service: TransactionalService) => {
      expect(service).toBeTruthy();
      const place = {
        'address_components': [{
          'long_name': 'suite k',
          'short_name': 'suite k',
          'types': ['subpremise'],
        }],
        'formatted_address': '530 W Eaton Ave suite k, Tracy, CA 95376, USA',
        'name': 'Puneet Grewal, MD',
      };

      const result = service.getFormattedAddress(place);
      expect(typeof result).toBe('object');
    }));


  it('if no addressLine2 then state considered as with formatted_address', inject([TransactionalService],
    (service: TransactionalService) => {
      expect(service).toBeTruthy();
      const place = {
        'address_components': [{
          'long_name': 'suite k',
          'short_name': 'suite k',
          'types': ['subpremise'],
        },
        {
          'long_name': 'California',
          'short_name': 'CA',
          'types': ['administrative_area_level_1', 'political'],
        },
        ],
        'formatted_address': '530 W Eaton Ave suite k, Tracy, CA 95376, USA',
        'name': 'Puneet Grewal, MD',
      };

      const result = service.getFormattedAddress(place);
      expect(typeof result).toBe('object');
    }));

  it('should format phone number', inject([TransactionalService], (service: TransactionalService) => {
    const formattedPhoneNumber = service.formatPhoneNumber('8098989898');
    expect(formattedPhoneNumber).toBe('809-898-9898');
  }));

  // tslint:disable-next-line: max-line-length
  // it('should navigate to colonialsurety portal when user not logged in', inject([TransactionalService], (service: TransactionalService) => {
  //   spyOn(service, 'isLoggedIn').and.returnValue(false);
  //   service.checkLoginAndRedirect('getQuote');
  //   expect(window.location.href).toContain('https://www.colonialsurety.com/');
  // }));

  it('should navigate to dashboard when user loggedIn and parent section is getQuote',
    inject([TransactionalService], (service: TransactionalService) => {
      spyOn(service, 'isLoggedIn').and.returnValue(true);
      const navigateSpy = spyOn(router, 'navigate');
      service.checkLoginAndRedirect('getQuote');
      expect(navigateSpy).toHaveBeenCalledWith(['/dashboard']);
    }));

  it('should navigate to insurance/getquotes when user loggedIn and parent section not getQuote',
    inject([TransactionalService], (service: TransactionalService) => {
      spyOn(service, 'isLoggedIn').and.returnValue(true);
      const navigateSpy = spyOn(router, 'navigate');
      service.checkLoginAndRedirect('insuranceDetails');
      expect(navigateSpy).toHaveBeenCalledWith(['/insurance/getquotes']);
    }));

  it('should return true if login',
    inject([TransactionalService], (service: TransactionalService) => {
      spyOn(service, 'isLoggedIn').and.returnValue(true);
      const _isLoggedIn = service.isLoggedIn();
      expect(_isLoggedIn).toBe(true);
    }));

  it('should return false if not login',
    inject([TransactionalService], (service: TransactionalService) => {
      spyOn(service, 'isLoggedIn').and.returnValue(false);
      const _isLoggedIn = service.isLoggedIn();
      expect(_isLoggedIn).toBe(false);
    }));

  it('should format date MMMDDYYYY',
    inject([TransactionalService], (service: TransactionalService) => {
      const formattedDate = service.formatDateTo(new Date(), 'MMMDDYYYY');
      expect(formattedDate).toBeTruthy();
      // expect(formattedDate).toBe('NOV 4,2020');
    }));

  it('should format date mm-DD-YYYY',
    inject([TransactionalService], (service: TransactionalService) => {
      const formattedDate = service.formatDateTo(new Date(), 'mm-DD-YYYY');
      expect(formattedDate).toBeTruthy();
      // expect(formattedDate).toBe('11-4-2020');
    }));

  it('should format date DD-mm-YYYY',
    inject([TransactionalService], (service: TransactionalService) => {
      const formattedDate = service.formatDateTo(new Date(), 'DD-mm-YYYY');
      expect(formattedDate).toBeTruthy();
      // expect(formattedDate).toBe('4-11-2020');
    }));

  it('should default format date',
    inject([TransactionalService], (service: TransactionalService) => {
      const formattedDate = service.formatDateTo(new Date(), '');
      expect(formattedDate).toBeTruthy();
      // expect(formattedDate).toBe('NOV 4,2020');
    }));

  it('should retrun ApplicantDetailsObjPayment',
    inject([TransactionalService], (service: TransactionalService) => {
      const data = {
        'firstName': 'abc',
        'lastName': 'xv',
        'street1': 'pune',
        'street2': 'pune',
        'city': 'pune',
        'state': 'MH',
        'zipCode': '411033',
        'applicantPhone': '8098989898',
      };
      const dataObject = service.getApplicantDetailsObjPayment(data);
      expect(typeof dataObject).toBe('object');
    }));

  // it('should return true when login success',
  //   inject([TransactionalService, SecurityService], (service: TransactionalService, securityService: SecurityService) => {
  //     securityService._loggedIn$.subscribe(() => true);
  //     const isUser = securityService.user;
  //     console.log('isUser', isUser);
  //     // securityService.user['person']['id'] = 12345;
  //     const login = service.isUserLogIn();
  //     expect(login).toBe(true);
  //   }));

  it('should return false when login success',
    inject([TransactionalService, SecurityService], (service: TransactionalService, securityService: SecurityService) => {
      // const isUser = securityService.user;
      // securityService.user['person']['id'] = null;
      const login = service.isUserLogIn();
      expect(login).toBe(false);
    }));

});
