import { TestBed, inject } from '@angular/core/testing';
import { ProductConfigService } from './product-config.service';

describe('Service: Product Config Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProductConfigService],
    });
  });

  it('should create an instance', inject([ProductConfigService], (service: ProductConfigService) => {
    expect(service).toBeTruthy();
  }));
});
