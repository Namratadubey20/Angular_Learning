import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { TempAPIMockData } from '../services/temp-apimock.service';
import { StateService } from '../services/state.service';
import { InsuranceStaticService } from '../services/insurance-static-service';
import { MatSnackBarComponent } from '../component/common/banner/banner.component';
import { BaseFormComponent } from '../component/base-form.component';
import { ComparativeConstants } from '../constants/comparative-constants';

@Injectable({
  providedIn: 'root',
})

export class PreloadService {
  public preload_sequence = {};

  constructor(public _stateService: StateService, public insuranceService: InsuranceStaticService) {
  }

  startPreloading(callback?: Function) {
    const totalCount = 4;
    let count = 0;
    this.insuranceService.getStates().subscribe(data => {
      if (data) {
        this._stateService.preloadData.allStates = data.list;
        this.insuranceService.getSanctionedStates().subscribe(data1 => {
          if (data1 && data1.list) {
            this._stateService.preloadData.sanctionStates = data1.list;
            if (this._stateService.preloadData.allStates) {
              this._stateService.preloadData.allowedStates =
                this._stateService.preloadData.allStates.filter((obj) => {
                  return !this._stateService.preloadData.sanctionStates.includes(obj.name);
                });
            }
            if (++count === totalCount) {
              this.adjustStateIfNeccessary(callback);
              /* if (callback) {
                callback();
              } */
            }
          }
        }, (error: any) => {
          const errorData = error.message;
          // this.snackBar.openSnackBar(errorData, 'X', BaseFormComponent.ERROR_BAR);
        });
        if (++count === totalCount) {
          this.adjustStateIfNeccessary(callback);
          /* if (callback) {
            callback();
          } */
        }
      }
    }, (error: any) => {
      const errorData = error.message;
      // this.snackBar.openSnackBar(errorData, 'X', BaseFormComponent.ERROR_BAR);
    });
    this.insuranceService.getProfession().subscribe(data => {
      if (data) {
        this._stateService.preloadData.profession = data.list;
        if (++count === totalCount) {
          this.adjustStateIfNeccessary(callback);
          /* if (callback) {
            callback();
          } */
        }
      }
    }, (error: any) => {
      const errorData = error.message;
      // this.snackBar.openSnackBar(errorData, 'X', BaseFormComponent.ERROR_BAR);
    });
    this.insuranceService.getStaticQuestion().subscribe(data => {
      if (data && data.questions) {
        // this._stateService.preloadData.applicantStack = data.questions;
        data.questions.forEach((element: any) => {
          this._stateService.preloadData.APIstaticQuestionStack[element.name] = element;
        });
        if (++count === totalCount) {
          this.adjustStateIfNeccessary(callback);
          /* if (callback) {
            callback();
          } */
        }
      }
    }, (error: any) => {
      const errorData = error.message;
      // this.snackBar.openSnackBar(errorData, 'X', BaseFormComponent.ERROR_BAR);
    });
  }

  adjustStateIfNeccessary(callback) {

    const _asIndex = this._stateService.preloadData.allStates.findIndex(_obj => _obj.name === 'AS');
    if (_asIndex >= 0) {
      this._stateService.preloadData.allStates.splice(_asIndex, 1);
    }
    const _allSIndex = this._stateService.preloadData.allowedStates.findIndex(_obj => _obj.name === 'AS');
    if (_allSIndex >= 0) {
      this._stateService.preloadData.allowedStates.splice(_allSIndex, 1);
    }

    if (callback) {
      callback();
    }
  }

}
