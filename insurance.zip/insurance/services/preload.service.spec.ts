import { TestBed, async, inject } from '@angular/core/testing';
import { PreloadService } from './preload.service';
import { InsuranceStaticService } from '../services/insurance-static-service';
import { StateService } from '../services/state.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { MockInsuranceStaticService } from '../../common/mock';

describe('Service: Preload Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [
        PreloadService,
        { provide: InsuranceStaticService, useClass: MockInsuranceStaticService },
        StateService,
        HttpClient,
      ],
    });
  });

  it('should create an instance', inject([PreloadService], (service: PreloadService) => {
    expect(service).toBeTruthy();
  }));

  it('should return error', inject([PreloadService, InsuranceStaticService], (service: PreloadService,
    insuranceService: InsuranceStaticService) => {
    const res = service.startPreloading();
    expect(res).toBe(undefined);
  }));

  it('should return state and professional list', inject([PreloadService, InsuranceStaticService], (service: PreloadService,
    insuranceService: InsuranceStaticService) => {

    const stateList = {
      list: [{
        'id': 1,
        'label': 'Alabama',
        'name': 'AL',
      }],
    };

    const sanctionStateList = {
      list: [
        'AS',
        'CA',
      ],
    };

    const professionsList = {
      list: [{
        'id': 1,
        'label': 'Accountants',
        'name': 'accountants',
      }],
    };

    const callback = () => { console.log('callback is done'); };
    const isPreload = () => { console.log('isPreload is true'); };

    const getprofessionsList = spyOn(insuranceService, 'getProfession').and.callFake(() => {
      return of(professionsList);
    });


    const getState = spyOn(insuranceService, 'getStates').and.callFake(() => {
      return of(stateList);
    });

    const getSanctionedStates = spyOn(insuranceService, 'getSanctionedStates').and.callFake(() => {
      return of(sanctionStateList);
    });

    service.startPreloading(callback);
    expect(getprofessionsList).toHaveBeenCalled();
    expect(getState).toHaveBeenCalled();
    expect(getSanctionedStates).toHaveBeenCalled();

  }));

});
