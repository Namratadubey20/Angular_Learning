import { TestBed, async, inject } from '@angular/core/testing';
import { InsuranceStaticService } from './insurance-static-service';
import { HttpClient, HttpClientModule } from '@angular/common/http';

describe('Service: Insurance Static', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [InsuranceStaticService, HttpClient],
    });
  });

  it('should create an instance', inject([InsuranceStaticService], (service: InsuranceStaticService) => {
    expect(service).toBeTruthy();
  }));
});
