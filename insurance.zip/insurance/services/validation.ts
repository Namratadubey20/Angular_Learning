import { Injectable, Inject } from '@angular/core';
import { Observable, of } from 'rxjs';
import { UtilMethodsService } from './util-method.service';
import { ComparativeConstants } from '../constants/comparative-constants';

@Injectable({
  providedIn: 'root',
})

export class Validation {
  public static getValidationErrorMsg(element: any, _value: any, _err, _stateService?: any) {
    const me = this;
    switch (element.type) {
      case 'date':
        return me.dateCustomValidation(element, _err);
        break;
      case 'textPercentage':
        return me.percentageCustomValidation(_err);
      case 'textnumber':
        return me.yearCustomValidation(_err);
      default:
        console.log('default case');
    }

    switch (element.name) {
      case ComparativeConstants.CUSTOM_VALIDATION_QNS_LIST.EPLI_numberOfEmployees_TotalCurrentYear.name:
        return me.employeeCountCustomValidation(_value, _err);
      case ComparativeConstants.CUSTOM_VALIDATION_QNS_LIST.Email_Signature.name:
        return me.emailSignatureCustomValidation(element, _value, _err, _stateService);
      default:
        break;
      // console.log('default case');
    }
    return null;
  }

  private static dateCustomValidation(element: any, _err: any) {
    if (!UtilMethodsService.isEmpty(_err)) {
      for (const { name, message } of element.validations) {
        if (_err.matDatepickerMin && name === ComparativeConstants.MAX_DATE) {
          return message;
        } else if (_err.matDatepickerMax && name === ComparativeConstants.MAX_DATE) {
          return message;
        }
      }
    }
  }

  public static yearCustomValidation(_err) {
    if (!UtilMethodsService.isEmpty(_err)) {
      return _err.yearErr.message;
    }
  }

  private static percentageCustomValidation(_err) {
    if (!UtilMethodsService.isEmpty(_err)) {
      return _err.percentageErr.message;
    }
  }

  private static employeeCountCustomValidation(_value, _err) {
    if (!UtilMethodsService.isEmpty(_value) &&
      _value < ComparativeConstants.CUSTOM_VALIDATION_QNS_LIST.EPLI_numberOfEmployees_TotalCurrentYear.minLimit) {
      return ComparativeConstants.CUSTOM_ERROR_MSG.numberOfEmployeesError;
    }
  }

  private static emailSignatureCustomValidation(element, _value, _err, _stateService) {
    if (!UtilMethodsService.isEmpty(_value)) {
      if (String(_value).toLowerCase().trim() !==
        String(_stateService.insuranceDetails['questionAnswers']['applicantEmail']).toLowerCase().trim()) {
        return ComparativeConstants.CUSTOM_ERROR_MSG.emailSignatureError;
      }
    } else {
      return ComparativeConstants.CUSTOM_ERROR_MSG.emailSignatureError;
    }
  }
}
