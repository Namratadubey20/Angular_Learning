import { TestBed } from '@angular/core/testing';

import { InsuranceSpinnerService } from './insurance-spinner.service';

describe('InsuranceSpinnerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InsuranceSpinnerService = TestBed.get(InsuranceSpinnerService);
    expect(service).toBeTruthy();
  });
});
