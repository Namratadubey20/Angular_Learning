import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree, NavigationStart } from '@angular/router';
import { Observable } from 'rxjs';
import { SecurityService } from '../../security/security.service';
import { map } from 'rxjs/operators';
import { AppConfigService } from 'src/app/app-config-service';
import { UtilMethodsService } from '../services/util-method.service';
import { StringConstants } from '../constants/string-constants';

@Injectable()
export class AuthGuardLoadUserService implements CanActivate {

  appConfig;
  constructor(private router: Router, private securityService: SecurityService, public appConfigService: AppConfigService,
    public stringConstant: StringConstants) {
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean {
    return this.checkLogin(route, state);
  }

  private checkLogin(route, state): Observable<boolean | UrlTree> | boolean {
    return this.securityService.loggedIn$.pipe(
      map(loggedIn => {
        if (loggedIn) {
          return loggedIn;

          /* // if user click browser's back button or refresh button then move user to dasboard
          // we can use popstate event to jump on dasboard if user click back button of browser
          // We can use router nivigated to check if page is refreshed or not
          // nivigated property is false when the router starts and after the first navigation it changes to true.
          // When page get refreshed it become false
          this.router.events.subscribe((event: NavigationStart) => {
            if (event.navigationTrigger === 'popstate' || !this.router.navigated) {
              if (sessionStorage.getItem('originState') === 'rails') {
                this.navigateToRails();
              } else {
                return loggedIn;
              }
              return false;
            } else if (event.navigationTrigger === 'imperative') {
              // event.navigationTrigger === 'imperative' bound to an html button, link or other elements
              // will navigate to the specified page, and the router will log the activity in the browsers history
              return loggedIn;
            }
          }); */
        } else {
          /* // if user click browser's back button or refresh button then move user to dasboard
          // we can use popstate event to jump on dasboard if user click back button of browser
          // We can use router nivigated to check if page is refreshed or not
          // nivigated property is false when the router starts and after the first navigation it changes to true.
          // When page get refreshed it become false
          this.router.events.subscribe((event: NavigationStart) => {
            if (event.navigationTrigger === 'popstate' || !this.router.navigated) {
              if (sessionStorage.getItem('originState') === 'rails') {
                this.navigateToRails();
              } else {
                // this.router.navigate(['/dashboard']);
              }
              return false;
            }
          }); */
          if (!UtilMethodsService.isEmpty(route.queryParams.applicationId)) {
            this.router.navigate(['/secure/login'], {
              queryParams:
                { returnUrl: state.url },
            });
            return false;
          } else {
            return true;
          }
        }
      })
    );
  }

}
