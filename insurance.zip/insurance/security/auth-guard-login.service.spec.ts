import { TestBed, inject } from '@angular/core/testing';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AppConfigService } from '../../app-config-service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AuthGuardLoginService } from './auth-guard-login.service';



describe('Login AuthGuardService', () => {
  const routerSpy = {
    navigate: jasmine.createSpy('navigate'),
  };
  const mockedServiceHandler: ServiceHandler = null;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      RouterTestingModule,
      HttpClientModule,
      HttpClientTestingModule,
    ],
    providers: [
      AuthGuardLoginService,
      { provide: Router, useValue: routerSpy },
      {
        provide: ServiceHandler,
        useValue: mockedServiceHandler,
      },
      {
        provide: AppConfigService,
        useValue: mockedAppConfigServic,
      },
    ],
    declarations: [

    ],
  }));


  it('should be created', inject([AuthGuardLoginService], (service: AuthGuardLoginService) => {
    expect(service).toBeTruthy();
  }));

  it('should return true for a logged in user', inject([AuthGuardLoginService], (service: AuthGuardLoginService) => {
    const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
    expect(result).toBeTruthy();
  }));

});
