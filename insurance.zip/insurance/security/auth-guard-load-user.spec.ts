import { TestBed, inject } from '@angular/core/testing';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AppConfigService } from '../../app-config-service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AuthGuardLoadUserService } from './auth-guard-load-user';

describe('Load User Auth Guard', () => {
  const routerSpy = {
    navigate: jasmine.createSpy('navigate'),
  };
  const mockedServiceHandler: ServiceHandler = null;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);

  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      RouterTestingModule,
      HttpClientModule,
      HttpClientTestingModule,
    ],
    providers: [
      AuthGuardLoadUserService,
      { provide: Router, useValue: routerSpy },
      {
        provide: ServiceHandler,
        useValue: mockedServiceHandler,
      },
      {
        provide: AppConfigService,
        useValue: mockedAppConfigServic,
      },
    ],
    declarations: [

    ],
  }));


  it('should be created', inject([AuthGuardLoadUserService], (service: AuthGuardLoadUserService) => {
    expect(service).toBeTruthy();
  }));

  it('should return true for a logged in user', inject([AuthGuardLoadUserService], (service: AuthGuardLoadUserService) => {
    const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
    expect(result).toBeTruthy();
  }));

});
