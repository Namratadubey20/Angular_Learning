import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { StateService } from '../services/state.service';

@Injectable()
export class AuthGuardInsuranceDetailsService implements CanActivate {

  constructor(private router: Router, public stateService: StateService) { }

  canActivate(route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean {

    if (this.stateService.SECTIONS['getQuote']['status'] !== 'complete') {
      this.router.navigate(['/insurance/evaluator']);
      return false;
    }
    return true;
  }

}
