import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { SecurityService } from '../../security/security.service';
import { map } from 'rxjs/operators';
import { AppConfigService } from 'src/app/app-config-service';
import { StateService } from '../services/state.service';


@Injectable()
export class AuthGuardLoginService implements CanActivate {
  cookieName: string;

  constructor(private router: Router, private securityService: SecurityService, private acs: AppConfigService,
    public stateService: StateService) {
    this.acs.getConfig().subscribe(config => this.cookieName = config.cookieName);
  }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean {
    return this.checkLogin(route, state);
  }

  private checkLogin(route, state): Observable<boolean | UrlTree> | boolean {
    return this.securityService.loggedIn$.pipe(
      map(loggedIn => {
        if (loggedIn) {
          if (this.stateService.SECTIONS['agreement']['status'] !== 'complete') {
            this.router.navigate(['/insurance/evaluator']);
            return false;
          }
          return loggedIn;
        } else {
          const loginAndReturn = this.router.parseUrl('/insurance/create-user');
          loginAndReturn.queryParams = {
            'returnUrl': '/insurance/' + route.routeConfig.path,
            'fromUrl': route.queryParams.fromUrl,
          };
          return loginAndReturn;
        }
      })
    );
  }

}
