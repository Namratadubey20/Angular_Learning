import { TestBed, async, inject } from '@angular/core/testing';
import { AuthGuardInsuranceCreateUserService } from './auth-guard-insurance-create-user.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('Insurance Create User AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [AuthGuardInsuranceCreateUserService],
    });
  });

  /* it('should create an instance', inject([AuthGuardInsuranceCreateUserService], (service: AuthGuardInsuranceCreateUserService) => {
    expect(service).toBeTruthy();
  })); */
});
