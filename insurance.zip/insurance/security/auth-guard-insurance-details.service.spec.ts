import { Component } from '@angular/core';
import { TestBed, inject } from '@angular/core/testing';
import { AuthGuardInsuranceDetailsService } from './auth-guard-insurance-details.service';
import { RouterTestingModule } from '@angular/router/testing';
import { StateService } from '../services/state.service';
import { RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {
}

describe('Insurance Details AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'insurance/evaluator', component: MockRouteBlankComponent },
        ]),
      ],
      providers: [AuthGuardInsuranceDetailsService, StateService],
      declarations: [
        MockRouteBlankComponent,
      ],
    });
  });

  it('should create an instance', inject([AuthGuardInsuranceDetailsService], (service: AuthGuardInsuranceDetailsService) => {
    expect(service).toBeTruthy();
  }));

  it('should navigate to blank page and return result should be false',
    inject([AuthGuardInsuranceDetailsService], (service: AuthGuardInsuranceDetailsService) => {
      const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
      expect(result).toBe(false);
    }));

  it('should navigate to insurance details and return result should be true',
    inject([AuthGuardInsuranceDetailsService, StateService], (service: AuthGuardInsuranceDetailsService, stateService: StateService) => {
      stateService.SECTIONS['getQuote']['status'] = 'complete';
      const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
      expect(result).toBe(true);
    }));

});
