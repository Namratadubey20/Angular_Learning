import { TestBed, async, inject } from '@angular/core/testing';
import { AuthGuardInsuranceAgreementService } from './auth-guard-insurance-agreement.service';
import { StateService } from '../services/state.service';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';

describe('Insurance Agreement AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
      ],
      providers: [AuthGuardInsuranceAgreementService, StateService],
    });
  });

  it('should create an instance', inject([AuthGuardInsuranceAgreementService], (service: AuthGuardInsuranceAgreementService) => {
    expect(service).toBeTruthy();
  }));
  it('should navigate to blank page and return result should be false',
    inject([AuthGuardInsuranceAgreementService], (service: AuthGuardInsuranceAgreementService) => {
      const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
      expect(result).toBe(false);
    }));
  it('should navigate to insurance details and return result should be true',
    inject([AuthGuardInsuranceAgreementService, StateService],
      (service: AuthGuardInsuranceAgreementService, stateService: StateService) => {
        stateService.SECTIONS['yourQuote']['status'] = 'complete';
        const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
        expect(result).toBe(true);
      }));
});
