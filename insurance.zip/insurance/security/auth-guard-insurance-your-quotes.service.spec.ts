import { TestBed, inject } from '@angular/core/testing';
import { AuthGuardInsuranceYourQuotesService } from './auth-guard-insurance-your-quotes.service';
import { StateService } from '../services/state.service';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';

describe('Insurance Your Quote AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
      ],
      providers: [AuthGuardInsuranceYourQuotesService, StateService],
    });
  });

  it('should create an instance', inject([AuthGuardInsuranceYourQuotesService], (service: AuthGuardInsuranceYourQuotesService) => {
    expect(service).toBeTruthy();
  }));
  it('should navigate to blank page and return result should be false',
    inject([AuthGuardInsuranceYourQuotesService], (service: AuthGuardInsuranceYourQuotesService) => {
      const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
      expect(result).toBe(false);
    }));
  it('should navigate to insurance details and return result should be true',
    inject([AuthGuardInsuranceYourQuotesService, StateService],
      (service: AuthGuardInsuranceYourQuotesService, stateService: StateService) => {
        stateService.SECTIONS['productInformation']['status'] = 'complete';
        const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
        expect(result).toBe(true);
      }));

});
