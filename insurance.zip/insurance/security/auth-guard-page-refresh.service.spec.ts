import { Component } from '@angular/core';
import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthGuardLoginService } from './auth-guard-login.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthGuardPageRefreshService } from './auth-guard-page-refresh.service';
import { StateService } from '../services/state.service';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCheckboxModule, MatFormFieldModule, MatInputModule, MatSnackBar, MatSelectModule } from '@angular/material';
import { SecurityService } from '../../security/security.service';
import { HttpClientModule } from '@angular/common/http';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AppConfigService } from 'src/app/app-config-service';

@Component({
  selector: 'app-mock-route-blank-component',
  template: '<span></span>',
})

class MockRouteBlankComponent {
}

describe('Page refresh AuthGuardService', () => {

  const mockedServiceHandler: ServiceHandler = null;
  const mockedAppConfigServic: AppConfigService = new AppConfigService(null);
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      BrowserAnimationsModule,
      FormsModule,
      ReactiveFormsModule,
      MatInputModule,
      MatFormFieldModule,
      MatSelectModule,
      MatCheckboxModule,
      RouterTestingModule.withRoutes([
        { path: 'insurance/evaluator', component: MockRouteBlankComponent },
      ]),
      HttpClientModule,
      HttpClientTestingModule,
    ],
    providers: [
      AuthGuardPageRefreshService,
      SecurityService,
      StateService,
      ServiceHandler,
      AppConfigService,
      MatSnackBar,
      {
        provide: ServiceHandler,
        useValue: mockedServiceHandler,
      },
      {
        provide: AppConfigService,
        useValue: mockedAppConfigServic,
      },
    ],
    declarations: [
      MockRouteBlankComponent,
    ],
  }));

  it('should be created', inject([AuthGuardPageRefreshService], (service: AuthGuardPageRefreshService) => {
    expect(service).toBeTruthy();
  }));

  it('should navigate to evaluator ', inject([AuthGuardPageRefreshService], (service: AuthGuardPageRefreshService) => {
    const result = service.canActivate(new ActivatedRouteSnapshot(), <RouterStateSnapshot>{ url: 'testUrl' });
    expect(result).toBeTruthy();
  }));

});

