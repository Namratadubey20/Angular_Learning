import { TestBed, inject } from '@angular/core/testing';
import { AuthGuardInsuranceConfirmationService } from './auth-guard-insurance-confirmation.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('Insurance Confirmation AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [AuthGuardInsuranceConfirmationService],
    });
  });

  /* it('should create an instance', inject([AuthGuardInsuranceConfirmationService], (service: AuthGuardInsuranceConfirmationService) => {
    expect(service).toBeTruthy();
  })); */

});
