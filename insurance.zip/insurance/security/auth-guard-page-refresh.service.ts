import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree, Router, NavigationStart } from '@angular/router';
import { Observable } from 'rxjs';
import { StateService } from '../services/state.service';
import { UtilMethodsService } from '../services/util-method.service';
import { SecurityService } from 'src/app/security/security.service';
import { AppConfigService } from 'src/app/app-config-service';
import { StringConstants } from '../constants/string-constants';

@Injectable()
export class AuthGuardPageRefreshService implements CanActivate {
  appConfig;
  constructor(private router: Router, public stateService: StateService, private securityService: SecurityService,
    public appConfigService: AppConfigService, public stringConstant: StringConstants) {
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }

  canActivate(route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean {
    // if user click browser's back button or refresh button then move user to dasboard
    // we can use popstate event to jump on dasboard if user click back button of browser
    // We can use router nivigated to check if page is refreshed or not
    // nivigated property is false when the router starts and after the first navigation it changes to true.
    // When page get refreshed it become false
    this.router.events.subscribe((event: NavigationStart) => {
      if (event.navigationTrigger === 'popstate' || !this.router.navigated) {
        if (sessionStorage.getItem('originState') === 'rails') {
          this.navigateToRails();
        }
        return false;
      } else {
        if (this.stateService.isPreload === false) {
          this.router.navigate(['/insurance/evaluator']);
          return false;
        }
        return true;
      }
    });
    return true;
  }

  navigateToRails() {
    sessionStorage.removeItem('originState');
    let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
    if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
      railsUrl = this.appConfig.colonial_erisa_TPA_url;
    }
    this.securityService.getAccessToken().then(response => {
      console.log(this.securityService.requestURL(`?sutoken=${response}`));
      window.open(`${railsUrl}?sutoken=${response}`, '_self');
      return;
    });
  }

}
