import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree, Router, NavigationStart } from '@angular/router';
import { Observable } from 'rxjs';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';
import { UtilMethodsService } from '../services/util-method.service';
import { StringConstants } from '../constants/string-constants';

@Injectable()
export class AuthGuardInsuranceConfirmationService implements CanActivate {
  appConfig;
  constructor(public router: Router,
    public appConfigService: AppConfigService,
    public securityService: SecurityService,
    public stringConstant: StringConstants) {
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }

  canActivate(route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean {

    // if user click browser's back button or refresh button then move user to dasboard
    // we can use popstate event to jump on dasboard if user click back button of browser
    // We can use router nivigated to check if page is refreshed or not
    // nivigated property is false when the router starts and after the first navigation it changes to true.
    // When page get refreshed it become false
    this.router.events.subscribe((event: NavigationStart) => {
      if (event.navigationTrigger === 'popstate' || !this.router.navigated) {
        if (sessionStorage.getItem('originState') === 'rails') {
          this.navigateToRails();
        } else {
          this.router.navigate(['/dashboard']);
        }
        return false;
      }
    });
    return true;
  }
  navigateToRails() {
    sessionStorage.removeItem('originState');
    let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
    if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
      railsUrl = this.appConfig.colonial_erisa_TPA_url;
    }
    this.securityService.getAccessToken().then(response => {
      console.log(this.securityService.requestURL(`?sutoken=${response}`));
      window.open(`${railsUrl}?sutoken=${response}`, '_self');
    });
  }

}
