import { Injectable } from '@angular/core';
import { UtilMethodsService } from '../services/util-method.service';
import { ComparativeConstants } from '../constants/comparative-constants';
import { StringConstants } from '../constants/string-constants';

@Injectable({
  providedIn: 'root',
})

export class PaymentModel {

  public static getCustomPageValidation(_insuranceType, _parentSectionName, stateService): number {
    switch (_insuranceType) {
      case 'pnl':
        return this.customPaymentPageValidation(stateService);
        break;
      case 'cyber':
        return this.customPaymentPageValidationForCYBER(_parentSectionName, stateService);
        break;
      case 'epli':
        return this.customPaymentPageValidation(stateService);
        break;
    }
  }

  public static customPaymentPageValidation(stateService): number {
    let nbrErrors = 0;
    if (UtilMethodsService.isEmpty(stateService.insuranceDetails.questionAnswers.paymentMethod)) {
      nbrErrors++;
    }
    return nbrErrors;
  }

  public static customPaymentPageValidationForCYBER(_parentSectionName, stateService): number {
    let nbrErrors = 0;
    if (UtilMethodsService.isEmpty(stateService.insuranceDetails.questionAnswers.paymentMethod)) {
      stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.PAYMENT_CUST_ERR_MSG_PAYMETHOD_SEL;
      nbrErrors++;
    }

    const customValidation = ComparativeConstants.CUSTOM_VALIDATION_QNS_LIST;
    // tslint:disable-next-line: max-line-length
    if (stateService.insuranceDetails.questionAnswers.dynamicQuestions['CYBER_revenueInformation_TotalRevenueLast12Months'] > 10000000) {
      if (stateService.isCyberFileuploadDone === false) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.PAYMENT_CUST_ERR_MSG_FILE_UPLOAD;
        nbrErrors++;
      }
    }
    return nbrErrors;
  }
}
