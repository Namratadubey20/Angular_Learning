import { TestBed, async, inject } from '@angular/core/testing';
import { AgreementModel } from './agreement.model';
import { UtilMethodsService } from '../services/util-method.service';
import { StateService } from '../services/state.service';

describe('Model: Agreement Model', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AgreementModel, UtilMethodsService, StateService],
    });
  });

  it('should create an instance', inject([AgreementModel], (service: AgreementModel) => {
    expect(service).toBeTruthy();
  }));

  it('should call getCustomPageValidation', inject([AgreementModel, StateService], (service: AgreementModel, stateServ: StateService) => {
    AgreementModel.getCustomPageValidation('pnl', 'getQuote', stateServ);
    expect(service).toBeTruthy();
  }));

  it('should call getCustomPageValidation with error',
    inject([AgreementModel, StateService], (service: AgreementModel, stateServ: StateService) => {
      stateServ.insuranceDetails.questionAnswers['emailSignature'] = 'abcd';
      stateServ.insuranceDetails.questionAnswers['applicantEmail'] = 'efgh';
      const _err = AgreementModel.getCustomPageValidation('pnl', 'getQuote', stateServ);
      expect(_err).toEqual(1);
    }));

});
