import { TestBed, async, inject } from '@angular/core/testing';
import { PaymentModel } from './payment.model';
import { UtilMethodsService } from '../services/util-method.service';
import { StateService } from '../services/state.service';

describe('Model: Payment', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PaymentModel, UtilMethodsService, StateService],
    });
  });

  it('should create an instance', inject([PaymentModel], (service: PaymentModel) => {
    expect(service).toBeTruthy();
  }));

  it('should call getCustomPageValidation for pnl',
    inject([PaymentModel, StateService], (service: PaymentModel, stateServ: StateService) => {
      PaymentModel.getCustomPageValidation('pnl', 'getQuote', stateServ);
      expect(service).toBeTruthy();
    }));

  it('should call getCustomPageValidation for cyber',
    inject([PaymentModel, StateService], (service: PaymentModel, stateServ: StateService) => {
      PaymentModel.getCustomPageValidation('cyber', 'getQuote', stateServ);
      expect(service).toBeTruthy();
    }));

  it('should call getCustomPageValidation for epli',
    inject([PaymentModel, StateService], (service: PaymentModel, stateServ: StateService) => {
      PaymentModel.getCustomPageValidation('epli', 'getQuote', stateServ);
      expect(service).toBeTruthy();
    }));

  it('should call getCustomPageValidation for cyber with file upload custom error',
    inject([PaymentModel, StateService], (service: PaymentModel, stateServ: StateService) => {
      stateServ.insuranceDetails.questionAnswers.dynamicQuestions['CYBER_revenueInformation_TotalRevenueLast12Months'] = 20000000;
      stateServ.isCyberFileuploadDone = false;
      expect(PaymentModel.getCustomPageValidation('cyber', 'getQuote', stateServ)).toEqual(2);
    }));

});
