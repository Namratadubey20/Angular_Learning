import { TestBed, async, inject } from '@angular/core/testing';
import { GetQuoteModel } from './get-quote.model';
import { UtilMethodsService } from '../services/util-method.service';
import { StateService } from '../services/state.service';

describe('Model: Get Quote', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetQuoteModel, UtilMethodsService, StateService],
    });
  });

  it('should create an instance', inject([GetQuoteModel], (service: GetQuoteModel) => {
    expect(service).toBeTruthy();
  }));

  it('should call getCustomPageValidation with Pnl Product',
    inject([GetQuoteModel, StateService], (service: GetQuoteModel, stateServ: StateService) => {
      expect(GetQuoteModel.getCustomPageValidation('pnl', 'getQuote', stateServ)).toEqual(0);
    }));

  it('should call getCustomPageValidation with cyber Product',
    inject([GetQuoteModel, StateService], (service: GetQuoteModel, stateServ: StateService) => {
      expect(GetQuoteModel.getCustomPageValidation('cyber', 'getQuote', stateServ)).toEqual(0);
    }));

  it('should call getCustomPageValidation with epli Product',
    inject([GetQuoteModel, StateService], (service: GetQuoteModel, stateServ: StateService) => {
      expect(GetQuoteModel.getCustomPageValidation('epli', 'getQuote', stateServ)).toEqual(0);
    }));

  it('should call getCustomPageValidation with wrong Product',
    inject([GetQuoteModel, StateService], (service: GetQuoteModel, stateServ: StateService) => {
      expect(GetQuoteModel.getCustomPageValidation('abc', 'getQuote', stateServ)).toBeUndefined();
    }));

});
