import { TestBed, async, inject } from '@angular/core/testing';
import { CreateUserModel } from './create-user.model';
import { UtilMethodsService } from '../services/util-method.service';
import { StateService } from '../services/state.service';

describe('Model: Create User', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateUserModel, UtilMethodsService, StateService],
    });
  });

  it('should create an instance', inject([CreateUserModel], (service: CreateUserModel) => {
    expect(service).toBeTruthy();
  }));

  it('should call getCustomPageValidation', inject([CreateUserModel, StateService], (service: CreateUserModel, stateServ: StateService) => {
    CreateUserModel.getCustomPageValidation('pnl', 'getQuote', stateServ);
    expect(service).toBeTruthy();
  }));

  it('should call getCustomPageValidation with error',
    inject([CreateUserModel, StateService], (service: CreateUserModel, stateServ: StateService) => {
      stateServ.insuranceDetails.questionAnswers['application_passWord'] = 'abcd';
      stateServ.insuranceDetails.questionAnswers['application_confirmPassword'] = 'efgh';
      const _err = CreateUserModel.getCustomPageValidation('pnl', 'getQuote', stateServ);
      expect(_err).toEqual(1);
    }));

});
