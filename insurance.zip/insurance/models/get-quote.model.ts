import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})

export class GetQuoteModel {

  public static getCustomPageValidation(_insuranceType, _parentSectionName, stateService): number {
    switch (_insuranceType) {
      case 'pnl':
        return this.customeGetQuotePageValidationForPL();
        break;
      case 'cyber':
        return this.customeGetQuotePageValidationForPL();
        break;
      case 'epli':
        return this.customeGetQuotePageValidationForPL();
        break;
    }
  }

  public static customeGetQuotePageValidationForPL(): number {
    const nbrErrors = 0;
    return nbrErrors;
  }
}
