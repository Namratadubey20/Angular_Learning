import { Injectable } from '@angular/core';
import { UtilMethodsService } from '../services/util-method.service';
import { StringConstants } from '../constants/string-constants';
import { ComparativeConstants } from '../constants/comparative-constants';

@Injectable({
  providedIn: 'root',
})

export class InsuranceDetailsModel {

  public static validSectionOnload(_questions, _stateService, _insuranceType, evaluationExpPipe) {
    const dynamicQuestionsKey = Object.keys(_stateService.insuranceDetails.questionAnswers.dynamicQuestions);
    let isSectionValidOnLoad = true;
    for (let i = 0; i < _questions.length; i++) {
      if (evaluationExpPipe.transform(_questions[i])) {
        if (this.isRequired(_questions[i].validations)) {
          if (!dynamicQuestionsKey.includes(_questions[i].name)) {
            isSectionValidOnLoad = false;
            break;
          }
        }
      }
    }
    return isSectionValidOnLoad;
  }

  private static isRequired(validationArray: any): boolean {
    if (validationArray && validationArray.length > 0) {
      for (let i = 0; i < validationArray.length; i++) {
        if (validationArray[i].name === 'required') {
          return true;
        }
      }
    }
    return false;
  }

  public static getCustomPageValidation(_insuranceType: string, _parentSectionName, stateService): number {
    switch (_insuranceType) {
      case 'pnl':
        return this.customeGetQuotePageValidationForPL();
      case 'cyber':
        return this.customeGetQuotePageValidationForCY();
      case 'epli':
        // return this.customeGetQuotePageValidationForEPLI(_parentSectionName, stateService);
        return this.customeGetQuotePageValidationForPL();
      default:
        break;
    }
  }

  public static customeGetQuotePageValidationForPL(): number {
    const nbrErrors = 0;
    return nbrErrors;
  }

  public static customeGetQuotePageValidationForCY(): number {
    const nbrErrors = 0;
    return nbrErrors;
  }

  public static customeGetQuotePageValidationForEPLI(_parentSectionName, stateService): number {
    let nbrErrors = 0;
    const dynamicQuestions = stateService.insuranceDetails.questionAnswers.dynamicQuestions;
    const customValidation = ComparativeConstants.CUSTOM_VALIDATION_QNS_LIST;
    const limitOfInsurance = stateService.insuranceDetails.questionAnswers[customValidation.EPLI_limitOfInsurance.name];
    const numberOfEmployees = dynamicQuestions[customValidation.EPLI_numberOfEmployees_TotalCurrentYear.name];
    const employeeHandbook = dynamicQuestions[customValidation.EPLI_employeeHandbook.name];
    const handbookReviewed = dynamicQuestions[customValidation.EPLI_handbookReviewed.name];
    const equalOpportunityEmployment = dynamicQuestions[customValidation.EPLI_equalOpportunityEmployment.name];
    const employmentAtWill = dynamicQuestions[customValidation.EPLI_employmentAtWill.name];
    const antisexualHarassment = dynamicQuestions[customValidation.EPLI_AntisexualHarassment.name];
    const employeeComplaints = dynamicQuestions[customValidation.EPLI_employeeComplaints.name];
    const aDAAccommodations = dynamicQuestions[customValidation.EPLI_aDAAccommodations.name];
    const terminationsWithHuman = dynamicQuestions[customValidation.EPLI_terminationsWithHuman.name];
    const releasesForTerminations = dynamicQuestions[customValidation.EPLI_releasesForTerminations.name];
    const performanceEvaluations = dynamicQuestions[customValidation.EPLI_performanceEvaluations.name];
    const numberOfEmpTerminatedInvo1YearAgo = dynamicQuestions[customValidation.EPLI_numberOfEmployees_TerminatedInvo1YearAgo.name];
    const numberOfEmpTerminatedInvoCurrentYear = dynamicQuestions[customValidation.EPLI_numberOfEmployees_TerminatedInvoCurrentYear.name];
    const trainingForAntiDiscrimination = dynamicQuestions[customValidation.EPLI_trainingForAntiDiscrimination.name];
    const contractOf50000 = dynamicQuestions[customValidation.EPLI_contractOf50000.name];
    const furtherReviewConclude = dynamicQuestions[customValidation.EPLI_furtherReviewConclude.name];
    const twelvemonthsCircumstances = dynamicQuestions[customValidation.EPLI_twelvemonthsCircumstances.name];
    const criminalClaimsOpenMoreThan2k = dynamicQuestions[customValidation.EPLI_civilOrCriminal_ClaimsOpenMoreThan2k.name];
    const lawClaimsOpenMoreThan2k = dynamicQuestions[customValidation.EPLI_lossesLawsuits_ClaimsOpenMoreThan2k.name];
    const applicantClaimsOpenMoreThan2k = dynamicQuestions[customValidation.EPLI_applicantPredecessors_ClaimsOpenMoreThan2k.name];
    const deductibleAmount = stateService.insuranceDetails.questionAnswers[customValidation.EPLI_deductibleAmount.name];
    // tslint:disable-next-line: max-line-length
    const isNewYork = stateService.insuranceDetails.questionAnswers[ComparativeConstants.staticQuestionNames.application_state] === ComparativeConstants.NEW_YORK_CODE;
    let _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['100k'];
    if (!UtilMethodsService.isEmpty(numberOfEmployees) && !UtilMethodsService.isEmpty(limitOfInsurance)) {
      if ((Number(numberOfEmployees) > customValidation.EPLI_employeeHandbook.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_employeeHandbook.maxLimit)
        && employeeHandbook === customValidation.EPLI_employeeHandbook.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_handbookReviewed.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_handbookReviewed.maxLimit)
        && handbookReviewed === customValidation.EPLI_handbookReviewed.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_equalOpportunityEmployment.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_equalOpportunityEmployment.maxLimit)
        && equalOpportunityEmployment === customValidation.EPLI_equalOpportunityEmployment.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_employmentAtWill.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_employmentAtWill.maxLimit)
        && employmentAtWill === customValidation.EPLI_employmentAtWill.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_AntisexualHarassment.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_AntisexualHarassment.maxLimit)
        && antisexualHarassment === customValidation.EPLI_AntisexualHarassment.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_employeeComplaints.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_employeeComplaints.maxLimit)
        && employeeComplaints === customValidation.EPLI_employeeComplaints.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_aDAAccommodations.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_aDAAccommodations.maxLimit)
        && aDAAccommodations === customValidation.EPLI_aDAAccommodations.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_terminationsWithHuman.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_terminationsWithHuman.maxLimit)
        && terminationsWithHuman === customValidation.EPLI_terminationsWithHuman.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_releasesForTerminations.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_releasesForTerminations.maxLimit)
        && releasesForTerminations === customValidation.EPLI_releasesForTerminations.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_performanceEvaluations.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_performanceEvaluations.maxLimit)
        && performanceEvaluations === customValidation.EPLI_performanceEvaluations.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.totalEmpExceedsLimit;
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_contractOf50000.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_contractOf50000.maxLimit)
        && contractOf50000 === customValidation.EPLI_contractOf50000.invalidAnswer
        && !isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.contractOf50000;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['50k'];
        nbrErrors++;
      } else if ((Number(numberOfEmployees) > customValidation.EPLI_contractOf50000.employeeCount)
        && (Number(limitOfInsurance) > customValidation.EPLI_contractOf50000.newYorkMaxLimit)
        && contractOf50000 === customValidation.EPLI_contractOf50000.invalidAnswer
        && isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.newYorkContractOf100000;
        nbrErrors++;
      }
    }

    if (!UtilMethodsService.isEmpty(limitOfInsurance)) {
      if (!UtilMethodsService.isEmpty(numberOfEmpTerminatedInvo1YearAgo) &&
        (Number(limitOfInsurance) > customValidation.EPLI_numberOfEmployees_TerminatedInvo1YearAgo.maxLimit) &&
        customValidation.EPLI_numberOfEmployees_TerminatedInvo1YearAgo.invalidAnswer < Number(numberOfEmpTerminatedInvo1YearAgo)
        && !isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.numberOfEmpTerminatedInvo1YearAgo;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['50k'];
        nbrErrors++;
      } else if (!UtilMethodsService.isEmpty(numberOfEmpTerminatedInvo1YearAgo) &&
        (Number(limitOfInsurance) > customValidation.EPLI_numberOfEmployees_TerminatedInvo1YearAgo.newYorkMasLimit) &&
        customValidation.EPLI_numberOfEmployees_TerminatedInvo1YearAgo.invalidAnswer < Number(numberOfEmpTerminatedInvo1YearAgo)
        && isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.newYorkNumberOfEmpTerminatedInvo1YearAgo;
        nbrErrors++;
      } else if (!UtilMethodsService.isEmpty(numberOfEmpTerminatedInvoCurrentYear) &&
        (Number(limitOfInsurance) > customValidation.EPLI_numberOfEmployees_TerminatedInvoCurrentYear.maxLimit) &&
        customValidation.EPLI_numberOfEmployees_TerminatedInvoCurrentYear.invalidAnswer < Number(numberOfEmpTerminatedInvoCurrentYear)
        && !isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.numberOfEmpTerminatedInvo1YearAgo;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['50k'];
        nbrErrors++;
      } else if (!UtilMethodsService.isEmpty(numberOfEmpTerminatedInvoCurrentYear) &&
        (Number(limitOfInsurance) > customValidation.EPLI_numberOfEmployees_TerminatedInvoCurrentYear.newYorkMaxLimit) &&
        customValidation.EPLI_numberOfEmployees_TerminatedInvoCurrentYear.invalidAnswer < Number(numberOfEmpTerminatedInvoCurrentYear)
        && isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.newYorkNumberOfEmpTerminatedInvo1YearAgo;
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_trainingForAntiDiscrimination.maxLimit)
        && trainingForAntiDiscrimination === customValidation.EPLI_trainingForAntiDiscrimination.invalidAnswer
        && !isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.antiDiscrimination;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['50k'];
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_trainingForAntiDiscrimination.newYorkMaxLimit)
        && trainingForAntiDiscrimination === customValidation.EPLI_trainingForAntiDiscrimination.invalidAnswer
        && isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.newYorkAntiDiscrimination;
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_furtherReviewConclude.maxLimit)
        && furtherReviewConclude === customValidation.EPLI_furtherReviewConclude.invalidAnswer
        && !isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.max50kLimit;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['50k'];
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_furtherReviewConclude.newYorkMaxLimit)
        && furtherReviewConclude === customValidation.EPLI_furtherReviewConclude.invalidAnswer
        && isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.newYorkMax100kLimit;
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_twelvemonthsCircumstances.maxLimit)
        && twelvemonthsCircumstances === customValidation.EPLI_twelvemonthsCircumstances.invalidAnswer
        && !isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.max50kLimit;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['50k'];
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_twelvemonthsCircumstances.newYorkMaxLimit)
        && twelvemonthsCircumstances === customValidation.EPLI_twelvemonthsCircumstances.invalidAnswer
        && isNewYork) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.newYorkMax100kLimit;
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_civilOrCriminal_ClaimsOpenMoreThan2k.maxLimit)
        && criminalClaimsOpenMoreThan2k === customValidation.EPLI_civilOrCriminal_ClaimsOpenMoreThan2k.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.maxLimit250k;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['250k'];
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_lossesLawsuits_ClaimsOpenMoreThan2k.maxLimit)
        && lawClaimsOpenMoreThan2k === customValidation.EPLI_lossesLawsuits_ClaimsOpenMoreThan2k.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.maxLimit250k;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['250k'];
        nbrErrors++;
      } else if ((Number(limitOfInsurance) > customValidation.EPLI_applicantPredecessors_ClaimsOpenMoreThan2k.maxLimit)
        && applicantClaimsOpenMoreThan2k === customValidation.EPLI_applicantPredecessors_ClaimsOpenMoreThan2k.invalidAnswer) {
        stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.maxLimit250k;
        _limitOfInsuranceMaxLimit = ComparativeConstants.EPLI_LIMIT_OF_INSURANCE_MAX_LIMIT['250k'];
        nbrErrors++;
      }
      //  else if ((Number(limitOfInsurance) > customValidation.EPLI_deductibleAmount.maxLimit)
      //   && deductibleAmount === customValidation.EPLI_deductibleAmount.invalidAnswer) {
      //   stateService.SECTIONS[_parentSectionName]['msg'] = StringConstants.CUSTOM_VALIDATION_MSG.deductibleAmount;
      //   nbrErrors++;
      // }
    }
    stateService.limitOfInsuranceMaxLimit = _limitOfInsuranceMaxLimit;
    return nbrErrors;
  }

  getInsuranceLimit(_profession) {

  }
}
