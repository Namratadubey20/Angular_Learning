import { TestBed, async, inject } from '@angular/core/testing';
import { InsuranceDetailsModel } from './insurance-details.model';
import { UtilMethodsService } from '../services/util-method.service';
import { StateService } from '../services/state.service';

describe('Model: Insurance Details', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InsuranceDetailsModel, UtilMethodsService, StateService],
    });
  });

  it('should create an instance', inject([InsuranceDetailsModel], (service: InsuranceDetailsModel) => {
    expect(service).toBeTruthy();
  }));

});
