import { Injectable } from '@angular/core';
import { UtilMethodsService } from '../services/util-method.service';

@Injectable({
  providedIn: 'root',
})

export class AgreementModel {

  public static getCustomPageValidation(_insuranceType, _parentSectionName, stateService): number {
    return this.customeYourQuotePageValidation(_parentSectionName, stateService);
  }

  public static customeYourQuotePageValidation(_parentSectionName, stateService): number {
    let nbrErrors = 0;
    // check for null first
    // to compare email make string into lower case and trim it if user accidently type space
    if (!UtilMethodsService.isEmpty(stateService.insuranceDetails.questionAnswers['emailSignature'])
      && !UtilMethodsService.isEmpty(stateService.insuranceDetails.questionAnswers['applicantEmail'])
      && (stateService.insuranceDetails.questionAnswers['emailSignature'].toLowerCase().trim()
        !== stateService.insuranceDetails.questionAnswers['applicantEmail'].toLowerCase().trim())) {
      stateService.SECTIONS[_parentSectionName]['msg'] = 'E-Signature must match applicant email.';
      nbrErrors++;
    }
    return nbrErrors;
  }
}
