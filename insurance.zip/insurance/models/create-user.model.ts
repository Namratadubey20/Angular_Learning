import { Injectable } from '@angular/core';
import { UtilMethodsService } from '../services/util-method.service';

@Injectable({
  providedIn: 'root',
})

export class CreateUserModel {

  public static getCustomPageValidation(_insuranceType, _parentSectionName, stateService): number {
    return this.customeYourQuotePageValidation(stateService);
  }

  public static customeYourQuotePageValidation(stateService): number {
    let nbrErrors = 0;
    console.log('customeYourQuotePageValidation-->', stateService.insuranceDetails.questionAnswers);
    if (stateService.insuranceDetails.questionAnswers.application_passWord !==
      stateService.insuranceDetails.questionAnswers.application_confirmPassword) {
      nbrErrors++;
    }
    return nbrErrors;
  }
}
