import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InsuranceRoutingModule } from './insurance-routing.module';
import { MaterialModule } from '../material.module';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonComponentsModule } from '../common/common-components.module';
import { InsuranceComponent } from './component/insurance.component';
import { InsuranceHeadingPanelComponent } from './component/common/insurance-heading-panel/insurance-heading-panel.component';
import { InsuranceGetQuotesComponent } from './component/screens/get-quotes/get-quotes.component';
// import { InsuranceSearchComponent } from './component/screens/search/search.component';
import { InsuranceYourQuotesComponent } from './component/screens/your-quotes/your-quotes.component';
import { InsuranceYourProductDetailsComponent } from './component/screens/your-quotes/your-product-details/your-product-details.component';
import { InsuranceDetailsComponent } from './component/screens/insurance-details/insurance-details.component';
import { ApplicantDetailsComponent } from './component/screens/insurance-details/applicant-details/applicant-details.component';
import { KOPanel1QuestionComponent } from './component/screens/insurance-details/knockout-questions/knockout-panel-1-question.component';
import { KOPanel2QuestionComponent } from './component/screens/insurance-details/knockout-panel-2-questions/knockout-panel-2-question.component';
import { KOPanel3QuestionComponent } from './component/screens/insurance-details/knockout-panel-3-questions/knockout-panel-3-question.component';
import { EPLIApplicantDetailComponent } from './component/screens/insurance-details/epli-applicant-details/epli-applicant-details.component';
import { BaseFormComponent } from './component/base-form.component';
import { FormInsuranceComponentModule } from '../form-insurance-components/form-insurance-components.module';
import { ConfirmationComponent } from './component/screens/confirmation/confirmation.component';
import { SummaryPanelComponent } from './component/common/summary-panel/summary-panel.component';
import { StepsComponent } from './component/common/steps-panel/steps.component';
import { InsuranceAgreementComponent } from './component/screens/agreement/agreement.component';
import { InsurancePaymentComponent } from './component/screens/payment/payment.component';
import { InsurancePaymentMethodComponent } from './component/shared/insurance-payment-method/insurance-payment-method.component';
import { ProductDescriptionComponent } from './component/screens/get-quotes/product-description/product-description.component';
import { MatSnackBarComponent } from './component/common/banner/banner.component';
import { ProgressSpinnerDialogComponent } from './component/common/modal/modal.component';
import { StringConstantPipe } from './pipe/string-constant.pipe';
import { PurchaseSummaryPanelComponent } from './component/common/purchase-summary-panel/purchase-summary-panel.component';
import { GetLabelPipe } from './pipe/get-label.pipe';
import { AuthGuardLoginService as LoginAccessGuard } from './security/auth-guard-login.service';
import { AuthGuardInsuranceDetailsService as InsuranceDetailsAccessGuard } from './security/auth-guard-insurance-details.service';
import { AuthGuardInsuranceConfirmationService as ConfirmationAccessGuard } from './security/auth-guard-insurance-confirmation.service';
import { AuthGuardInsuranceYourQuotesService as YourQuotesAccessGuard } from './security/auth-guard-insurance-your-quotes.service';
import { AuthGuardInsuranceAgreementService as AgreementAccessGuard } from './security/auth-guard-insurance-agreement.service';
import { AuthGuardInsuranceCreateUserService as CreateUserAccessGuard } from './security/auth-guard-insurance-create-user.service';
import { AuthGuardPageRefreshService as PageRefreshAccessGuard } from './security/auth-guard-page-refresh.service';
import { EvaluatorComponent } from './component/common/evaluator/evaluator.component';
import { PaymentModule } from '../payment/payment.module';
import { SecurityModule } from 'src/app/security/security.module';
import { InsuranceSignUpComponent } from './component/screens/sign-up/sign-up.component';
import { AccountService } from 'src/app/user/account.service';
import { EmailPopupComponent } from './component/common/email-popup/email-popup.component';
import { AuthGuardLoadUserService as LoadUserAccessGuard } from './security/auth-guard-load-user';
import { ProductConfigPipe } from './pipe/product-config.pipe';
import { EvaluateExpressionPipe } from './pipe/evaluate-expression.pipe';

@NgModule({
  imports: [
    CommonModule,
    InsuranceRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CommonComponentsModule,
    FormInsuranceComponentModule,
    PaymentModule,
    SecurityModule,
    MatDialogModule,
  ],
  declarations: [
    InsuranceComponent,
    InsuranceHeadingPanelComponent,
    InsuranceGetQuotesComponent,
    InsuranceYourQuotesComponent,
    InsuranceYourProductDetailsComponent,
    InsuranceDetailsComponent,
    ApplicantDetailsComponent,
    KOPanel1QuestionComponent,
    KOPanel2QuestionComponent,
    EPLIApplicantDetailComponent,
    KOPanel3QuestionComponent,
    SummaryPanelComponent,
    PurchaseSummaryPanelComponent,
    StepsComponent,
    InsurancePaymentComponent,
    InsurancePaymentMethodComponent,
    ProgressSpinnerDialogComponent,
    MatSnackBarComponent,
    BaseFormComponent,
    ConfirmationComponent,
    InsuranceAgreementComponent,
    ProductDescriptionComponent,
    StringConstantPipe,
    GetLabelPipe,
    EvaluatorComponent,
    InsuranceSignUpComponent,
    EmailPopupComponent,
    ProductConfigPipe,
    EvaluateExpressionPipe,
  ],
  exports: [],
  entryComponents: [
    ProgressSpinnerDialogComponent,
    EmailPopupComponent,
  ],
  providers: [
    {
      provide: MatDialogRef,
      useValue: [],
    },
    MatSnackBarComponent,
    LoginAccessGuard,
    InsuranceDetailsAccessGuard,
    ConfirmationAccessGuard,
    YourQuotesAccessGuard,
    AgreementAccessGuard,
    PageRefreshAccessGuard,
    LoadUserAccessGuard,
    AccountService,
    CreateUserAccessGuard,
  ],
})
export class InsuranceModule { }
