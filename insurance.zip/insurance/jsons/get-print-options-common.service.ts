import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class GetPrintOptionsFieldJsonService {
  public data = {
    'data': [{
      'name': 'Print Options',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [
        {
          'id': 68,
          'name': 'applicationFile',
          'label': 'Print Application',
          'type': 'singlecheckbox',
          'allowedproduct': ['pnl', 'cyber'],
        },
        {
          'id': 67,
          'name': 'insuranceDeclarationFile',
          'label': 'Print Declaration Page',
          'type': 'singlecheckbox',
          'allowedproduct': ['pnl', 'cyber'],
        },
        {
          'id': 66,
          'name': 'insurancePolicyFile',
          'label': 'Print the complete Policy document',
          'type': 'singlecheckbox',
          'allowedproduct': ['pnl', 'cyber'],
        },
        {
          'id': 65,
          'name': 'insuranceCOIFile',
          'label': 'ACORD certificate of Insurance',
          'type': 'singlecheckbox',
          'allowedproduct': ['pnl', 'cyber'],
        },
        {
          'id': 66,
          'name': 'insuranceEOFile',
          'label': 'PL Program EO Policy',
          'type': 'singlecheckbox',
          'allowedproduct': ['pnl', 'cyber'],
        }],
    }],
  };

  getData() {
    return this.data;
  }
}
