import { TestBed, async, inject } from '@angular/core/testing';
import { GetAgreementFieldJsonService } from './get-agreement-common.service';

describe('Service: Agreement Field Json Common Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetAgreementFieldJsonService],
    });
  });

  it('should create an instance', inject([GetAgreementFieldJsonService], (service: GetAgreementFieldJsonService) => {
    expect(service).toBeTruthy();
  }));
});
