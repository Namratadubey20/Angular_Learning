import { TestBed, async, inject } from '@angular/core/testing';
import { GetQuoteFieldJsonService } from './get-quotes-common.service';

describe('Service: Get Quotes Json Common Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetQuoteFieldJsonService],
    });
  });

  it('should create an instance', inject([GetQuoteFieldJsonService], (service: GetQuoteFieldJsonService) => {
    expect(service).toBeTruthy();
  }));
});
