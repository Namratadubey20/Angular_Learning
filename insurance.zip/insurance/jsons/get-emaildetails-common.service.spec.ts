import { TestBed, inject } from '@angular/core/testing';
import { GetEmailFieldJsonService } from './get-emaildetails-common.service';

describe('Service: Get Email details Common Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetEmailFieldJsonService],
    });
  });

  it('should create an instance', inject([GetEmailFieldJsonService], (service: GetEmailFieldJsonService) => {
    expect(service).toBeTruthy();
  }));
});
