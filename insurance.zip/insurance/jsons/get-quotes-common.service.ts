import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class GetQuoteFieldJsonService {
  public data = {
    'data': [{
      'name': 'Personal Details',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [{
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'First Name',
        'name': 'firstName',
        'type': 'textbasic',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'Your First Name',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'pattern',
          // tslint:disable-next-line:quotemark
          'value': "^[a-zA-Z0-9 '-]*$",
          'message': 'Please enter valid values',
        },
        {
          'name': 'maxlength',
          'value': 100,
          'message': '',
        }],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Last Name',
        'name': 'lastName',
        'type': 'textbasic',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'Your Last Name',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'pattern',
          // tslint:disable-next-line:quotemark
          'value': "^[a-zA-Z0-9 '-]*$",
          'message': 'Please enter valid values',
        },
        {
          'name': 'maxlength',
          'value': 100,
          'message': '',
        }],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Phone',
        'name': 'applicantPhone',
        'type': 'textphone',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'Phone Number',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'pattern',
          'value': '^[0-9-]{12}',
          'message': 'Please enter valid values',
        },
        ],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Email Address',
        'name': 'applicantEmail',
        'type': 'textbasic',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'example@email.com',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'pattern',
          // 'value': '[a-zA-Z0-9.@,_&-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{3,}',
          'value': '^([A-Za-z0-9@,_&-])+\@([A-Za-z0-9])+([\.]{1})([A-Za-z]{3})$',
          'message': 'Please enter valid values',
        },
        {
          'name': 'maxlength',
          'value': 45,
          'message': '',
        }],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'State',
        'name': 'state',
        'type': 'selectwithsearch',
        'value': '',
        'event': 'true',
        'optionReference': 'state',
        'visible_by_default': 1,
        'tooltip': 'State deatils',
        'validations': [
          {
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
        ],
        'options': [],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Profession',
        'name': 'profession',
        'type': 'selectwithsearch',
        'value': '',
        'event': 'true',
        'optionReference': 'profession',
        'visible_by_default': 1,
        'tooltip': 'Country deatils',
        'validations': [
          {
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
        ],
        'options': [],
      }],
    }],
  };

  getData() {
    return this.data;
  }
}
