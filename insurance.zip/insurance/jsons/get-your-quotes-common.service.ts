import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class GetYourQuoteFieldJsonService {
  public data = {
    'data': [{
      'name': 'Personal Details',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [{
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Aggregate Limit',
        'name': 'amount',
        'type': 'select',
        'value': '',
        'visible_by_default': 1,
        'placeholder': '$',
        'tooltip': 'Aggregate Limit',
        'validations': [
          {
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 1,
            'name': '1,000,000',
            'label': '$ 1,000,000',
          },
          {
            'id': 2,
            'name': '2,000,000',
            'label': '$ 2,000,000',
          },
          {
            'id': 3,
            'name': '3,000,000',
            'label': '$ 3,000,000',
          },
        ],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Deductible',
        'name': 'deductible',
        'type': 'select',
        'value': '',
        'visible_by_default': 1,
        'placeholder': '$',
        'tooltip': 'Deductiblet',
        'validations': [
          {
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 1,
            'name': '500',
            'label': '$ 500',
          },
          {
            'id': 2,
            'name': '1,000',
            'label': '$ 1,000',
          },
          {
            'id': 3,
            'name': '2,000',
            'label': '$ 2,000',
          },
        ],
      }],
    }],
  };

  getData() {
    return this.data;
  }
}
