import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class GetCreateUserFieldJsonService {
  public data = {
    'data': [{
      'name': 'Personal Details',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [{
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Username',
        'name': 'application_userName',
        'type': 'textbasic',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'User Name',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'pattern',
          // tslint:disable-next-line:quotemark
          'value': "[^ ]*",
          'message': 'Please enter valid values',
        },
        {
          'name': 'maxlength',
          'value': 50,
          'message': '',
        }],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Password',
        'name': 'application_passWord',
        'type': 'password',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'Password',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'pattern',
          // tslint:disable-next-line:quotemark
          'value': "^[a-zA-Z0-9 $&+,:;=?@#|'<>.^*()%!-]*$",
          'message': 'Please enter valid values',
        },
        {
          'name': 'minlength',
          'value': 10,
          'message': '',
        },
        {
          'name': 'maxlength',
          'value': 62,
          'message': '',
        }],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Confirm Password',
        'name': 'application_confirmPassword',
        'type': 'password',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'Confirm Password',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'pattern',
          // tslint:disable-next-line:quotemark
          'value': "^[a-zA-Z0-9 $&+,:;=?@#|'<>.^*()%!-]*$",
          'message': 'Please enter valid values',
        },
        {
          'name': 'minlength',
          'value': 10,
          'message': '',
        },
        {
          'name': 'maxlength',
          'value': 62,
          'message': '',
        }],
      }],
    }],
  };

  getData() {
    return this.data;
  }
}
