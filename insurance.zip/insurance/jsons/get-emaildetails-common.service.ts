import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class GetEmailFieldJsonService {

  public data = {
    'data': [{
      'name': 'Email Details',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': '',
          'name': 'recipient',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'example@email.com',
          'validations': [],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': '',
          'name': 'optionalMessage',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'placeholder': 'example@email.com',
          'validations': [],
        },
        // {
        //   'question_reference_id': 1,
        //   'sequence_number': 1,
        //   'label': '',
        //   'name': 'emailRefCode',
        //   'type': 'textbasic',
        //   'value': '',
        //   'visible_by_default': 1,
        //   'validations': [],
        // },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'label': '',
          'name': 'subject',
          'type': 'textbasic',
          'value': '',
          'visible_by_default': 1,
          'validations': [],
        },
        // {
        //   'question_reference_id': 1,
        //   'sequence_number': 1,
        //   'label': '',
        //   'name': 'body',
        //   'type': 'text',
        //   'value': '',
        //   'visible_by_default': 1,
        //   'validations': [],
        // },
      ],
    }],
  };

  getData() {
    return this.data;
  }
}
