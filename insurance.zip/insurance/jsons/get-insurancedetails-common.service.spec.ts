import { TestBed, async, inject } from '@angular/core/testing';
import { GetInsuranceFieldJsonService } from './get-insurancedetails-common.service';

describe('Service: Insurance Details Json Common Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetInsuranceFieldJsonService],
    });
  });

  it('should create an instance', inject([GetInsuranceFieldJsonService], (service: GetInsuranceFieldJsonService) => {
    expect(service).toBeTruthy();
  }));
});
