import { TestBed, async, inject } from '@angular/core/testing';
import { GetYourQuoteFieldJsonService } from './get-your-quotes-common.service';

describe('Service: Agreement Field Json Common Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetYourQuoteFieldJsonService],
    });
  });

  it('should create an instance', inject([GetYourQuoteFieldJsonService], (service: GetYourQuoteFieldJsonService) => {
    expect(service).toBeTruthy();
  }));
});
