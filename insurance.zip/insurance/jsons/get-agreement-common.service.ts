import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class GetAgreementFieldJsonService {
  public data = {
    'data': [{
      'name': 'Personal Details',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [{
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': '',
        'name': 'aggrementTermsYes',
        'type': 'checkbox',
        'value': '',
        'visible_by_default': 1,
        'options': [
          {
            'id': 1,
            'code': 'yes',
            'label': '',
          },
        ],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': '',
        'name': 'aggrementYes',
        'type': 'checkbox',
        'value': '',
        'visible_by_default': 1,
        'options': [
          {
            'id': 1,
            'code': 'yes',
            'label': 'Yes, I have read & agree with the terms and conditions of this agreement.*',
          },
        ],
      },
      {
        'id': 68,
        'name': 'readAndAgreeToTerms',
        'label': 'Yes, I have read & agree with the terms and conditions of this agreement.*',
        'type': 'singlecheckbox',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
      },
      /* {
        'id': 64,
        'name': 'acknowledgeFraudWarning',
        'label': 'Yes, I have read & I agree',
        'type': 'singlecheckbox',
        'parentObject': 'data.termsAndConditions',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
      },
      {
        'id': 63,
        'name': 'acknowledgeTerms',
        'label': 'Yes, I acknowledge the above.',
        'type': 'singlecheckbox',
        'parentObject': 'data.termsAndConditions',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
      }, */
      {
        'id': 91,
        'name': 'reviewAgentApplication',
        'label': 'I have reviewed the attached application to ensure that all the information is correct.',
        'type': 'singlecheckbox',
        'parentObject': 'data.termsAndConditions',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
      },
      {
        'id': 98,
        'name': 'agreeToRenewPolicy',
        'label': '-',
        'type': 'radio',
        'parentObject': 'data',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
        ],
        'options': [
          {
            'id': 68,
            'name': 'yes',
            // tslint:disable-next-line: max-line-length
            'label': 'YES, I want to sign up for automatic renewal to ensure that there will not be a lapse in coverage. I, {APPLICANT_NAME} understand that Colonial will automatically renew upon the expiration date unless otherwise cancelled by Colonial. Prior to expiration, I will be offered the opportunity to change or elect not to renew the policy. I, {APPLICANT_NAME}, authorize Colonial to automatically charge the credit card account I have provided for all renewal policy premium. I represent that I am the owner and/or authorized signer of the account.',
          },
          {
            'id': 69,
            'name': 'no',
            'label': 'NO, I do not want to sign up for automatic renewal to ensure that there will not be a lapse in coverage.',
          },
        ],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Signature Email',
        'name': 'emailSignature',
        'type': 'textbasic',
        'visible_by_default': 1,
        'placeholder': 'example@email.com',
        'validations': [
          {
            'name': 'required',
            'message': 'This field is required',
          },
          {
            'name': 'pattern',
            // tslint:disable-next-line:quotemark
            // tslint:disable-next-line: max-line-length
            'value': '^([A-Z|a-z|0-9](\.|_|\-|\+|\&){0,1})+[A-Z|a-z|0-9]\@([A-Z|a-z|0-9](\-){0,1})+[A-Z|a-z|0-9]((\.){0,1}[A-Z|a-z|0-9]){2,3}\.[a-z]{2,3}$',
            'message': 'E-Signature must match applicant email',
          },
        ],
      }],
    }],
  };

  getData() {
    return this.data;
  }
}
