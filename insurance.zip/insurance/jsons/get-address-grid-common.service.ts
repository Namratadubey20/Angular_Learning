import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class GetAddressGridFieldJsonService {
  public data = {
    'data': [{
      'name': 'Address grid',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [{
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'Address',
        'name': 'street',
        'type': 'textgoogle',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'street..',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'maxlength',
          'value': 250,
          'message': '',
        }],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'address line 1',
        'name': 'street1',
        'type': 'textbasic',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'street1...',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        {
          'name': 'maxlength',
          'value': 250,
          'message': '',
        }],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'city',
        'name': 'city',
        'type': 'textbasic',
        'value': '',
        'visible_by_default': 1,
        'placeholder': 'City',
        'validations': [{
          'name': 'required',
          'value': '',
          'message': 'This field is required',
        },
        ],
      },
      {
        'question_reference_id': 1,
        'sequence_number': 1,
        'label': 'State',
        'name': 'state',
        'type': 'selectwithsearch',
        'value': '',
        'event': 'true',
        'optionReference': 'state',
        'visible_by_default': 1,
        'tooltip': 'State deatils',
        'validations': [
          {
            'name': 'required',
            'value': '',
            'message': 'This field is required',
          },
        ],
        'options': [],
      },
      ],
    }],
  };

  getData() {
    return this.data;
  }
}
