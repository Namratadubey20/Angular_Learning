import { Injectable } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})

export class GetPaymentFieldJsonService {
  public data = {
    'data': [{
      'name': 'Personal Details',
      'label': '',
      'section_type': 'BLOCK',
      'questions_per_row': 3,
      'questions_alignment': null,
      'visible_by_default': 1,
      'fields': [
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'name': 'attachDetails',
          // tslint:disable-next-line:max-line-length
          'label': 'For implementing an affirmative action plan and complying with equal employment opportunity guidelines, please attach review details if any',
          'type': 'fileinput',
          'validations': [
          ],
        },
        {
          'question_reference_id': 1,
          'sequence_number': 1,
          'name': 'attachDetails',
          'label': 'Please attach a copy of your most recently audited annual financial statement.',
          'type': 'fileinput',
          'validations': [
          ],
        },
      ],
    }],
  };

  getData() {
    return this.data;
  }
}
