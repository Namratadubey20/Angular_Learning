import { Pipe, PipeTransform } from '@angular/core';
import { StateService } from '../services/state.service';

@Pipe({
  name: 'getLabel',
  pure: true,
})
export class GetLabelPipe implements PipeTransform {
  constructor(private stateService: StateService) { }

  transform(_name: any, key?: string): String {
    switch (key) {
      case 'state':
        return this.getStateLabel(_name);
        break;
      case 'profession':
        return this.getProfessionLabel(_name);
        break;
      default:
        console.log('deafult label');
    }
  }

  private getStateLabel(_name): String {
    for (const { name, label } of this.stateService.preloadData['allStates']) {
      if (_name === name) { return label; }
    }
  }

  private getProfessionLabel(_name): String {
    for (const { name, label } of this.stateService.preloadData['profession']) {
      if (_name === name) { return label; }
    }
  }
}
