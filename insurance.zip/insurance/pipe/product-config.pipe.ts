import { Pipe, PipeTransform } from '@angular/core';
import { StateService } from '../services/state.service';
import { ProductConfigService } from '../services/product-config.service';
import { UtilMethodsService } from '../services/util-method.service';
@Pipe({
  name: 'sortProductVisibility',
})
export class ProductConfigPipe implements PipeTransform {
  constructor(private stateService: StateService, private productService: ProductConfigService) { }

  transform(s: any, prodAllocated?: any): String {
    if (!UtilMethodsService.isEmpty(prodAllocated)) {
      const _allowedProducts = s['allowed_products'];
      return _allowedProducts.includes(prodAllocated);
    } else {
      if (s && this.stateService.insuranceSelected && this.stateService.insuranceSelected.length <= 1) {
        const _allowedProducts = s['allowed_products'];
        return _allowedProducts.includes(this.stateService.insuranceSelected[0]);
      }
    }
  }

}
