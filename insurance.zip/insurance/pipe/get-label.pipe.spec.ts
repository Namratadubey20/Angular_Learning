import { async, inject, TestBed } from '@angular/core/testing';
import { StringConstantPipe } from './string-constant.pipe';
import { StateService } from '../services/state.service';
import { GetLabelPipe } from './get-label.pipe';

describe('Pipe: Get Label', () => {
  let pipe: any;
  let stateService: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [],
      declarations: [],
      providers: [
        GetLabelPipe,
      ],
    });
  }));

  beforeEach(inject([GetLabelPipe, StateService], (getLabelpipe, _stateService) => {
    pipe = getLabelpipe;
    stateService = _stateService;
  }));


  it('should return state label if key is state', inject([StateService], (service: StateService) => {
    service.preloadData['allStates'] = [{ 'id': 1, 'name': 'AL', 'label': 'Alabama' }];
    const result = pipe.transform('AL', 'state');
    expect(result).toBe('Alabama');
  }));

  it('should return Profession label if key is profession', inject([StateService], (service: StateService) => {
    service.preloadData['profession'] = [{ id: 1, name: 'accountants', label: 'Accountants' }];
    const result = pipe.transform('accountants', 'profession');
    expect(result).toBe('Accountants');
  }));

  it('should return default case if key does not match', inject([StateService], (service: StateService) => {
    const result = pipe.transform('', '');
    expect(result).toBe(undefined);
  }));

});
