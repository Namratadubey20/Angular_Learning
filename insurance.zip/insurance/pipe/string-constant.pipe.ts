import { Pipe, PipeTransform } from '@angular/core';
import { StateService } from '../services/state.service';
import { UtilMethodsService } from '../services/util-method.service';

@Pipe({
  name: 'sortProductText',
})
export class StringConstantPipe implements PipeTransform {
  constructor(private stateService: StateService) { }

  transform(s: any, prodAllocated?: any): String {
    if (!UtilMethodsService.isEmpty(prodAllocated)) {
      return s[prodAllocated];
    } else {
      if (s && this.stateService.insuranceSelected && this.stateService.insuranceSelected.length <= 1) {
        return s[this.stateService.insuranceSelected[0]];
      }
    }
  }
}
