import { TestBed } from '@angular/core/testing';
import { StateService } from '../services/state.service';
import { EvaluateExpressionPipe } from './evaluate-expression.pipe';

describe('EvaluateExpressionPipe', () => {
  beforeEach(() => {
    TestBed
      .configureTestingModule({
        providers: [
          StateService,
        ],
      });
  });

  it('create an instance', () => {
    const fields = { 'displyCritera': '' };
    const stateService: StateService = TestBed.get(StateService);
    const pipe = new EvaluateExpressionPipe(stateService);
    expect(pipe).toBeTruthy();
  });

  it('should not display question as criteria is not match', () => {
    const fields = {
      'displayCriteria': `({CYBER_acquiredAnyTrademarks} == \"Yes\"
    && {CYBER_violationOfPrivacyLaw} == \"B\" || {CYBER_dataBreachIncident} == \"C\"
    || {CYBER_attemptedExtortionDemand} == \"yes\")` };
    const stateService: StateService = TestBed.get(StateService);
    stateService.screenMapObject = { 'CYBER_acquiredAnyTrademarks': 'Yes' };
    const pipe = new EvaluateExpressionPipe(stateService);
    expect(pipe.transform(fields)).toBe(false);
  });

  it('should display question as criteria is matching', () => {
    const fields = { 'displayCriteria': `({CYBER_acquiredAnyTrademarks} == \"Yes\")` };
    const stateService: StateService = TestBed.get(StateService);
    stateService.screenMapObject = { 'CYBER_acquiredAnyTrademarks': 'Yes' };
    const pipe = new EvaluateExpressionPipe(stateService);
    expect(pipe.transform(fields)).toBe(true);
  });

});
