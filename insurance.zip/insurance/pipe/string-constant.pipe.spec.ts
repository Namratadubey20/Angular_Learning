import { async, inject, TestBed } from '@angular/core/testing';
import { StringConstantPipe } from './string-constant.pipe';
import { StateService } from '../services/state.service';

describe('Pipe: String Constant', () => {
  let pipe;
  let ss;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [],
      declarations: [],
      providers: [
        StringConstantPipe,
      ],
    });
  }));

  beforeEach(inject([StringConstantPipe, StateService], (p, s) => {
    pipe = p;
    ss = s;
  }));


  it('should work with single product selected', inject([StateService], (service: StateService) => {
    service.insuranceSelected = ['pnl'];
    const GET_QUOTE_HEADING = {
      'pnl': 'Professional Liability',
    };
    expect(pipe.transform(GET_QUOTE_HEADING)).toEqual('Professional Liability');
  }));

});
