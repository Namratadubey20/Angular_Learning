import { Pipe, PipeTransform } from '@angular/core';
import { StateService } from '../services/state.service';
import { UtilMethodsService } from '../services/util-method.service';
import { ComparativeConstants } from 'src/app/insurance/constants/comparative-constants';

@Pipe({
  name: 'evaluateExpression',
})
export class EvaluateExpressionPipe implements PipeTransform {
  constructor(private stateService: StateService) { }

  transform(fields: any, form?: any): any {
    let displayCriteria = fields.displayCriteria;
    if (!displayCriteria) {
      return true;
    }
    displayCriteria = displayCriteria.split(/[{}]/);
    displayCriteria.forEach((elementData, index) => {
      if (!UtilMethodsService.isEmpty(this.stateService.screenMapObject[elementData])) {
        displayCriteria[index] = this.stateService.screenMapObject[elementData];
      }
      // tslint:disable-next-line:max-line-length
      if (ComparativeConstants.KO_QUESTION_ON_FREE_TEXT.includes(elementData) && UtilMethodsService.isEmpty(this.stateService.screenMapObject[elementData])) {
        displayCriteria[index] = '';
      }
    });

    displayCriteria.forEach((element, index) => {
      if (Array.isArray(element)) {
        const replacedAnswer = element;
        const stringToTest = displayCriteria[index + 1];
        const _result = replacedAnswer.includes(stringToTest.split('"')[1]);
        if (_result) {
          displayCriteria[index] = stringToTest.split('"')[1];
        }

      }
    });

    const result = UtilMethodsService.evaluateFn(displayCriteria.join('"'));
    if (!result) {
      if (this.stateService.fieldError[fields.name]) {
        delete this.stateService.fieldError[fields.name];
      }
      if (this.stateService.screenMapObject[fields.name]) {
        delete this.stateService.screenMapObject[fields.name];
      }
      if (form && form.get([fields.name])) {
        form.get([fields.name]).reset();
      }
    }
    return result;
  }
}
