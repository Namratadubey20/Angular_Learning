import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';
import { Router } from '@angular/router';
import { IbondBaseService } from 'src/app/ibond/service/ibond-base.service';
import { ProfessionalLiabilityBondType, CourtBondType } from 'src/app/enrollment/application/common/bond-types';
import { DOCUMENT } from '@angular/common';
import { DashboardService } from '../dashboard.service';
import { SecurityService } from 'src/app/security/security.service';
import { UserImpl } from 'src/app/security/user';
import { MatTabChangeEvent } from '@angular/material';
import { AppConfigService } from 'src/app/app-config-service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-select-bond-tab',
  templateUrl: './select-bond-tab.component.html',
  styleUrls: ['./select-bond-tab.component.scss'],
})
export class SelectBondTabComponent implements OnInit, OnDestroy {

  _heading = '';
  insuranceProductList: any;
  bondListInsurance = [
    {
      name: 'Pension Professional Insurance',
      type: 'insurence',
      value: 'pensionProfessional',
      url: 'https://www.colonialsurety.com/tpa',
      isActive: true, attorney: false,
      imgUrl: '../../../assets/icons/pli.svg',
      hasPermission: true,
    },
    {
      name: 'General Liability Insurance',
      type: 'insurence',
      value: 'planSponsorInsurance',
      url: 'https://www.colonialsurety.com/tpa',
      isActive: true,
      attorney: false,
      imgUrl: '../../../assets/icons/gli.svg',
      hasPermission: true,
    },
    {
      name: 'Cyber Liability Insurance',
      type: 'insurence',
      value: 'tpa',
      url: 'https://www.colonialsurety.com/tpa',
      isActive: true,
      attorney: false,
      imgUrl: '../../../assets/icons/bop.svg',
      hasPermission: true,
    },
    {
      name: 'Business Owner\'s Policy (BOP)',
      type: 'insurence',
      value: 'tpa',
      url: 'https://www.colonialsurety.com/tpa',
      isActive: true,
      attorney: false,
      imgUrl: '../../../assets/icons/cuber_liability_insurance.svg',
      hasPermission: true,
    },
    {
      name: 'Employment Practices Liability Insurance (EPLI)',
      type: 'insurence',
      value: 'tpa',
      url: 'https://www.colonialsurety.com/tpa',
      isActive: true,
      attorney: false,
      imgUrl: '../../../assets/icons/epli.svg',
      hasPermission: true,
    },
  ];
  activeBondList = [];
  bondListLandp = [];
  bondListSurety = [];
  bondListFidelity = [];
  bondListMiscellaneous = [];
  user: UserImpl = null;
  attorneyBondList = GlobalConstants.ATTORNEY_FLOW_BOND_TYPE_IBOND;
  appConfig: any;
  bondList: any;
  constructor(
    private router: Router,
    private lpService: IbondBaseService,
    private dashboardService: DashboardService,
    private securityService: SecurityService,
    private appConfigService: AppConfigService,
    @Inject(DOCUMENT) private document
  ) {
    this.user = this.securityService.user;
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
      this.bondList = [
        {
          name: 'ERISA',
          type: 'fidelity',
          value: 'ERISA',
          url: `${this.appConfig.colonial_erisa_url}erisa_quote`,
          isActive: true,
          attorney: false,
          hasPermission: true,
        },
        {
          name: 'License and Permit',
          type: 'landp', value: 'landp',
          url: '/ibond/getquotes/landp',
          isActive: true,
          attorney: false,
          hasPermission: true,
        },
        // {
        //   name: 'Miscellaneous', type: 'miscellaneous',
        //   value: 'miscellaneous',
        //   url: '', isActive: true, attorney: true,
        // },
        {
          name: 'RIA Bond',
          type: 'miscellaneous',
          value: 'RIA Bond',
          url: '/ibond/getquotes/ria',
          isActive: false,
          attorney: false,
          hasPermission: true,
        },
        {
          name: 'Airport Security Bond',
          type: 'miscellaneous',
          value: 'Airport Security Bond',
          url: '/ibond/getquotes/airport_security',
          isActive: false,
          attorney: false,
          hasPermission: true,
        },
        {
          name: 'Notary Bond',
          type: 'miscellaneous',
          value: 'Notary Bond',
          url: '/ibond/getquotes/notary',
          isActive: true,
          attorney: false,
          hasPermission: true,
        },
        {
          name: 'Public Official',
          type: 'surety',
          value: 'Public Official',
          url: '/ibond/getquotes/po',
          isActive: true,
          attorney: false,
          hasPermission: true,
        },
        {
          name: 'Lost Instrument',
          type: 'miscellaneous',
          value: 'Lost Instrument',
          url: '/ibond/getquotes/lost_instrument',
          isActive: true,
          attorney: true,
          hasPermission: true,
        },
        {
          name: 'Lost Car/Defective Vehicle Title (Incl. Donated Vehicle)',
          type: 'miscellaneous',
          value: 'Lost Car/Defective Vehicle Title (Incl. Donated Vehicle)',
          url: '/ibond/getquotes/lost_car_title',
          isActive: false,
          attorney: false,
          hasPermission: true,
        },
        {
          name: 'Employee Dishonesty',
          type: 'fidelity',
          value: 'Employee Dishonesty',
          url: '/ibond/getquotes/employee_dishonesty',
          isActive: true,
          attorney: false,
          hasPermission: true,
        },
        {
          name: 'Janitorial Home Service',
          type: 'fidelity',
          value: 'Janitorial Home Service',
          url: '/ibond/getquotes/janitorial',
          isActive: true,
          attorney: false,
          hasPermission: true,
        },
      ];
    });
  }



  ngOnInit() {
    this._heading = this.isAgent() ? 'Select the product your client needs' : 'Select a bond/policy to begin!';
    this.document.body.classList.add('general-theme');
    this.bondsNotHavingAgentPermission();
    this.activeBondList = this.bondList.filter(list => list.isActive === true);
    this.bondListLandp = this.activeBondList.filter(list => list.type === 'landp');
    this.bondListSurety = this.activeBondList.filter(list => list.type === 'surety');
    this.bondListFidelity = this.activeBondList.filter(list => list.type === 'fidelity');
    this.bondListMiscellaneous = this.activeBondList.filter(list => list.type === 'miscellaneous');
    this.getInsuranceProductList();
  }

  ngOnDestroy(): void {
    this.document.body.classList.remove('general-theme');
  }

  getInsuranceProductList() {
    this.lpService.getProductTypesByLob().subscribe((_insuranceProductList) => {
      for (const [iconKey, iconValue] of Object.entries(GlobalConstants.INSURANCE_PRODUCT_ICON_KEY_MAPPER)) {
        _insuranceProductList['list'].forEach(_key => {
          if (iconKey === _key.name) {
            _key['imgUrl'] = iconValue;
            return;
          }
        });
      }
      this.insuranceProductList = _insuranceProductList['list'];
    });
  }

  getActionInsurance() {
    let temp;
    temp = this.insuranceProductList && this.insuranceProductList.filter(insurancePro => {
      return environment.insuranceShowProductList.indexOf(insurancePro.name) > -1;
    });
    return temp;
  }

  onSelectInsurance(_productCode) {
    // this.close();
    if (this.isAgent()) {
      this.router.navigate(['/user/clients'], { queryParams: { product_code: [_productCode] } });
    } else {
      this.router.navigate(['/insurance'], { queryParams: { product_code: [_productCode] } });
    }
  }

  // close(): void {
  //   this.dialogRef.close();
  // }

  onSelectBond(navigateTo) {
    // this.close();
    if (navigateTo.includes('https')) {
      // window.location.href = navigateTo;
      window.open(navigateTo, '_blank');
    } else {
      this.router.navigate([navigateTo]);
    }
  }
  routeToPNLApplication() {
    this.routeTo(ProfessionalLiabilityBondType.Pnl);
  }

  routeToSupersedeas() {
    this.routeTo(CourtBondType.Supersedeas);
  }

  routeToReplevin() {
    this.routeTo(CourtBondType.Replevin);
  }

  routeToAttachment() {
    this.routeTo(CourtBondType.Attachment);
  }

  routeToInjunction() {
    this.routeTo(CourtBondType.Injunction);
  }

  routeToGuardianship() {
    this.routeTo(CourtBondType.Guardianship);
  }

  routeToConservatorship() {
    this.routeTo(CourtBondType.Conservatorship);
  }

  routeToEstate() {
    this.routeTo(CourtBondType.Estate);
  }

  routeToTrustee() {
    this.routeTo(CourtBondType.Trustee);
  }

  routeToReceiver() {
    this.routeTo(CourtBondType.Receiver);
  }

  routeToReferee() {
    this.routeTo(CourtBondType.Referee);
  }
  routeToVa() {
    // this.close();
    this.router.navigateByUrl('/ibond/getquotes/vafiduciary');
  }
  private routeTo(bondType: string) {
    // this.close();
    this.router.navigateByUrl(`/enrollment/application/${bondType}`);
  }

  isAgent() {
    return this.user && this.user.hasAgentRole;
  }

  isAttorney() {
    return this.user && this.user.hasAttorneyRole;
  }

  isEmployee() {
    return this.user && this.user.hasEmployeePermissions;
  }

  bondsNotHavingAgentPermission() {
    const arrBondsNotHasAgentAccess = [];
    this.bondList.map(x => {
      if (arrBondsNotHasAgentAccess.includes(x.value)) {
        x.hasPermission = !this.isAgent();
      }
    });
    console.log(this.bondList);
  }

  tabChanged(event: MatTabChangeEvent) {
    const selectedIndex = event.index;
    if (selectedIndex === 0) {
      if (this.isAgent()) {
        this._heading = 'Select the product your client needs';
      } else {
        this._heading = 'Select a bond/policy to begin!';
      }
    } else if (selectedIndex === 1) {
      this._heading = 'Select your Fidelity Bond to start!';
    } else if (selectedIndex === 2) {
      this._heading = 'Select your Insurance Policy to start!';
    }
  }

  get heading() {
    return this._heading;
  }
}
