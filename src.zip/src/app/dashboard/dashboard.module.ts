import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnrollmentRoutingModule } from '../enrollment/enrollment-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonComponentsModule } from '../common/common-components.module';
import { FormComponentsModule } from '../form-components/form-components.module';
import { UserModule } from '../user/user.module';
import {
  CalendarModule,
  CheckboxModule,
  DataListModule,
  EditorModule,
  PaginatorModule,
  TabViewModule,
} from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatProgressBarModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatPaginatorModule,
  MatSortModule,
  MatExpansionModule,
  MatProgressSpinnerModule,
  MatTooltipModule,
} from '@angular/material';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { DashboardComponent } from './dashboard.component';
import { AgentDashboardComponent } from './agent-dashboard/agent-dashboard.component';
import { ClientDashboardComponent } from './client-dashboard/client-dashboard.component';
import { ProductModule } from '../product/product.module';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { ColonialTableModule } from '../colonial-table/colonial-table.module';
import { ClientsApplicationsListComponent } from './client-dashboard/clients-applications-list/clients-applications-list.component';
import { AttorneyDashboardComponent } from './agent-dashboard/attorney-dashboard/attorney-dashboard.component';
import { CtaSvgComponent } from './cta-svg/cta-svg.component';
import { ClientsActiveProductsListComponent } from './client-dashboard/clients-products-list-active/clients-active-products-list.component';
import { ClientsHistoryProductsListComponent } from './client-dashboard/clients-products-list-history/clients-history-products-list.component';
import { ManageAlertComponent } from './manage-alert/manage-alert.component';
import { SelectBondTabComponent } from './select-bond-tab/select-bond-tab.component';
import { BackToRailsComponent } from './back-torails/back-torails.component';
import { InsuranceSearchComponent } from '../insurance/component/screens/search/search.component';

@NgModule({
  imports: [
    CommonModule,
    EnrollmentRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    CommonComponentsModule,
    FormComponentsModule,
    UserModule,
    ProductModule,
    ColonialTableModule,
    FlexLayoutModule,
    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,
    TableModule,
    PaginatorModule,
    TabViewModule,
    EditorModule,

    // Material Stuff
    MatAutocompleteModule,
    MatFormFieldModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDividerModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatStepperModule,
    MatSlideToggleModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatExpansionModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
  ],
  declarations: [
    DashboardComponent,
    AgentDashboardComponent,
    ClientDashboardComponent,
    EmployeeDashboardComponent,
    ClientsApplicationsListComponent,
    AttorneyDashboardComponent,
    CtaSvgComponent,
    ClientsActiveProductsListComponent,
    ClientsHistoryProductsListComponent,
    ManageAlertComponent,
    SelectBondTabComponent,
    BackToRailsComponent,
    InsuranceSearchComponent,
  ],
  providers: [],
  exports: [
  ],
})
export class DashboardModule {
}
