import { Component, OnInit, Output, EventEmitter, Inject, OnDestroy } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';
import { ApplicationService } from 'src/app/enrollment/application/application.service';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-manage-alert',
  templateUrl: './manage-alert.component.html',
  styleUrls: ['./manage-alert.component.scss'],
})
export class ManageAlertComponent implements OnInit, OnDestroy {
  user: UserImpl = null;
  status = {};
  inProgressApplications = 0;
  onHoldApplications = 0;
  onSoftHoldApplications = 0;
  declinedApplications = 0;
  awaitingPaymentApplications = 0;
  submittedApplications = 0;
  pendingReviewApplications = 0;
  closedApplications = 0;
  completedApplications = 0;
  upForRenewalBond = 0;
  recentlyExpiredBond = 0;
  pendingRenewalBond = 0;
  openProducts = 0;
  pendingApplications = 0;
  filterStatus = '';
  @Output() filterList = new EventEmitter<object>();
  pendingUnderwritingApplications = 0;
  panelOpenStateForApplication: boolean;
  panelOpenStateForProduct: boolean;
  constructor(
    private dashboardService: DashboardService,
    private securityService: SecurityService,
    private applicationService: ApplicationService,
    public spinnerService: SpinnerService,
    @Inject(DOCUMENT) private document
  ) { }
  async ngOnInit() {
    this.document.body.classList.add('general-theme');
    this.spinnerService.show();
    this.user = await this.securityService.user;
    this.status = await this.dashboardService.getApplicationStatuses();
    this.spinnerService.hide();
    this.inProgressApplications = this.toNumber(this.status['applications']['In Progress']);
    this.onHoldApplications = this.toNumber(this.status['applications']['Hold']);
    this.onSoftHoldApplications = this.toNumber(this.status['applications']['Soft Hold']);
    this.declinedApplications = this.toNumber(this.status['applications']['Declined']);
    this.awaitingPaymentApplications = this.toNumber(this.status['applications']['Awaiting Payment']);
    this.submittedApplications = this.toNumber(this.status['applications']['Submitted']);
    this.pendingUnderwritingApplications = this.submittedApplications + this.onHoldApplications;
    this.closedApplications = this.toNumber(this.status['applications']['Closed']);
    this.completedApplications = this.toNumber(this.status['applications']['Completed']);
    this.pendingApplications = this.toNumber(this.status['applications']['Pending']);
    this.pendingReviewApplications = this.toNumber(this.status['applications']['Pending Review']);
    this.upForRenewalBond = this.toNumber(this.status['products']['Up For Renewal']);
    this.recentlyExpiredBond = this.toNumber(this.status['products']['Recently Expired']);
    this.openProducts = this.toNumber(this.status['products']['Open']);
    this.applicationService.clearSearch.subscribe(async status => {
      if (status) {
        this.filterStatus = '';
      }
    });
  }

  ngOnDestroy(): void {
    this.document.body.classList.remove('general-theme');
  }

  toNumber(num): number {
    return num ? Number(num) : 0;
  }
  filterByStatus(status, tab) {
    this.filterStatus = this.filterStatus === status ? '' : status;
    const obj = {
      tab: tab,
      filter: this.filterStatus,
    };
    this.filterList.emit(obj);
  }
}
