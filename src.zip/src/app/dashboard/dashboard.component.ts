import {
  Component,
  Inject,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import { SecurityService } from '../security/security.service';
import { UserImpl } from '../security/user';
import { MatPaginator, MatTableDataSource, MatSort } from '../../../node_modules/@angular/material';
import { ApplicationService } from '../enrollment/application/application.service';
import { DOCUMENT } from '@angular/common';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

export type ConfirmationMessageType = 'info' | 'warn';

export interface ConfirmationMessageData {
  type: ConfirmationMessageType;
  message: string;
}

@Component({
  selector: 'app-colonial-common-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit, OnDestroy {
  initialized = false;
  user: UserImpl = null;
  confirmationMessage: string;
  confirmationMessageType: ConfirmationMessageType = 'info';
  userFromOtherApplication = true;
  unsubscribe$ = new Subject();
  constructor(
    @Inject(DOCUMENT) private document,
    private securityService: SecurityService,
    private applicationService: ApplicationService
  ) { }
  displayedColumns: string[] = ['id', 'code', 'createdAt', 'status', 'action'];
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  async ngOnInit() {
    this.document.body.classList.remove('mat-app-background');
    this.document.body.classList.add('main-body-background');
    this.dataSource.paginator = this.paginator;
    this.user = this.securityService.user;
    const maybeJson = localStorage.getItem('confirmationMessage');
    localStorage.removeItem('confirmationMessage');
    this.userFromOtherApplication = false;
    try {
      const confirmationMessageData: ConfirmationMessageData = JSON.parse(maybeJson);
      const { type: confirmationMessageType, message: confirmationMessage } = confirmationMessageData;
      this.confirmationMessageType = confirmationMessageType;
      this.confirmationMessage = confirmationMessage;
    } catch {
      this.confirmationMessage = maybeJson;
    }

    this.initialized = true;
    // const status1 = await this.applicationService.getApplicationListForPerson({ page: 0, size: 500, sort: null });
    // console.log('status1 :: ', status1);
    // this.dataSource.data = status1.content;
    // this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;
    this.securityService.isUserFromThirdPartyApplication()
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(val => {
        this.userFromOtherApplication = val;
      });
  }

  isAgent() {
    return this.user && this.user.hasAgentRole;
  }

  isAttorney() {
    return this.user && this.user.hasAttorneyRole;
  }

  hasEmployeeAuthority(): boolean {
    return this.user && this.user.hasEmployeePermissions;
  }

  hasSuperEmployeeAuthority(): boolean {
    return this.user && this.user.hasSuperEmployeePermissions;
  }

  isSteward() {
    return this.isAgent() || this.isAttorney();
  }

  userName() {
    return this.user ? this.user.person.firstName : null;
  }

  displayConfirmation(): boolean {
    return !!this.confirmationMessage && this.confirmationMessage.length > 1;
  }

  get confirmationClass(): string {
    return `confirmation-card-${this.confirmationMessageType}`;
  }

  removeConfirmationMessage() {
    this.confirmationMessage = '';
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
    this.securityService._userFromThirdPartyApplication.unsubscribe();
  }

 /* isSupportUser() {
    console.log('isSupportUser');
    this.user.hasRole('support');
  }*/
  isSupportUser(): boolean {
    console.log('Super user....');
    return this.user.hasRole('support');
  }
}

// export interface PeriodicElement {
//   product: string;
//   applicationId: string;
//   createdDate: string;
//   status: string;
// }

// const ELEMENT_DATA: PeriodicElement[] = [
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Conservatorship', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Conservatorship', createdDate: '12/08/2019 | 07:39 PM', status: 'On Hold' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'On Hold' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'On Hold' },
//   { applicationId: '000001AS', product: 'Conservatorship', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'On Hold' },
//   { applicationId: '000001AS', product: 'Conservatorship', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'On Hold' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'On Hold' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'On Hold' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
//   { applicationId: '000001AS', product: 'Appeal/Supersedeas', createdDate: '12/08/2019 | 07:39 PM', status: 'In Progress' },
// ];
