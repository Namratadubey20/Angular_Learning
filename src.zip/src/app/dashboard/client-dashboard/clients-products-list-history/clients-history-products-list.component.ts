import { Component, OnInit } from '@angular/core';
import { Page, Pageable, PageImpl } from '../../../common/pagination';
import { ClientsActiveProductsListComponent } from '../clients-products-list-active/clients-active-products-list.component';
import { ProductListService } from '../../../colonial-table/product-list-common/product-list.service';
import { ClientProductImpl } from '../client-product';
import { Router } from '@angular/router';
import { CourtProductSummary } from '../../../colonial-table/product-list-common/court-product-summary';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

@Component({
  selector: 'app-clients-history-products-list',
  templateUrl: './clients-history-products-list.component.html',
  styleUrls: ['./clients-history-products-list.component.css'],
})
export class ClientsHistoryProductsListComponent extends ClientsActiveProductsListComponent implements OnInit {

  constructor(
    public productListService: ProductListService,
    public router: Router,
    public spinnerService: SpinnerService
  ) {
    super(productListService, router, spinnerService);
  }

  ngOnInit() {
    this.page = new PageImpl<CourtProductSummary>();
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }) {
    this.loading = true;
    const searchParams = {
      status: 'Closed',
    };
    this.page = await this.productListService.getProductListForClients(pageable, searchParams);
    this.page.content = this.page.content.filter(product => product.status !== 'Open');
    this.loading = false;
  }

  hasProductsHistory() {
    return !!this.page && this.page.content.length > 0;
  }
}
