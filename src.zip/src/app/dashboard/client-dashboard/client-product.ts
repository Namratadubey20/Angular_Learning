import { JsonObject, JsonProperty } from 'json2typescript';
import { ProductType, ProductTypeImpl } from '../../product/product-type';
import { Auditable, AuditableProfile } from '../../common/auditable-object';
import { DateStringOnlyConverter } from '../../common/utils/date-string-only-converter';


export interface ClientProduct extends Auditable {
  id: number;
  productType: ProductType;
  applicant: string;
  productTypeName: string;
  status: string;
  displayStatus: string;
  productNo?: string;
  applicationId: number;
  toDate: Date;
  fromDate: Date;
}

@JsonObject('ProductImpl')
export class ClientProductImpl extends AuditableProfile implements ClientProduct {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('applicant', String, true)
  applicant: string = null;

  @JsonProperty('productType', ProductTypeImpl, true)
  productType: ProductType = new ProductTypeImpl();

  @JsonProperty('productTypeName', String, true)
  productTypeName: string = null;

  @JsonProperty('status', String, true)
  status: string = null;

  @JsonProperty('displayStatus', String, true)
  displayStatus: string = null;

  @JsonProperty('court', String, true)
  court: string = null;

  @JsonProperty('primaryService', String, true)
  primaryService: string = null;

  @JsonProperty('productNo', String, true)
  productNo: string = null;

  @JsonProperty('applicationId', Number, true)
  applicationId: number = null;

  @JsonProperty('createdAt', DateStringOnlyConverter, true)
  createdAt: Date = null;

}
