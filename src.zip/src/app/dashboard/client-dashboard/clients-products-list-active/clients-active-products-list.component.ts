import { Component, OnInit } from '@angular/core';
import { Column } from '../../../form-components/generic-pageable-list/column';
import { Page, Pageable, PageImpl } from '../../../common/pagination';
import { Router } from '@angular/router';
import { ProductListService } from '../../../colonial-table/product-list-common/product-list.service';
import { ListLinkClickEvent } from '../../../form-components/generic-pageable-list/list-link-click-event';
import { Product, ProductImpl } from '../../../product/product';
import { ClientProduct, ClientProductImpl } from '../client-product';
import {
  CourtProductSummary,
  CourtProductSummaryImpl
} from '../../../colonial-table/product-list-common/court-product-summary';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';

@Component({
  selector: 'app-clients-active-products-list',
  templateUrl: './clients-active-products-list.component.html',
  styleUrls: ['./clients-active-products-list.component.css'],
})
export class ClientsActiveProductsListComponent implements OnInit {

  loading = false;

  cols: Column[] = [
    {
      field: 'productNo',
      header: 'Bond/Policy Number',
      link: true,
    },
    {
      field: 'productTypeName',
      header: 'Product Type',
      link: false,
    },
    {
      field: 'clientName',
      header: 'Insured/Bonded',
      link: false,
    },
    {
      field: 'fromDate',
      header: 'Created',
      link: false,
    },
    {
      field: 'status',
      header: 'Status',
      link: false,
    },
  ];

  page: Page<CourtProductSummary>;

  constructor(
    public productListService: ProductListService,
    public router: Router,
    public spinnerService: SpinnerService
  ) { }

  ngOnInit() {
    this.page = new PageImpl<CourtProductSummaryImpl>();
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }, dateRange = []) {
    this.spinnerService.show();
    this.loading = true;
    const searchParams = {
      status: 'Open',
    };
    if (dateRange.length === 2) {
      searchParams['startDate'] = dateRange[0];
      searchParams['endDate'] = dateRange[1];
    }
    this.page = await this.productListService.getProductListForClients(pageable, searchParams);
    this.page.content = this.page.content.filter(product => product.status === 'Open');
    this.spinnerService.hide();
    this.loading = false;
  }

  listLinkClickEvent(event: ListLinkClickEvent) {
    const data: ClientProduct = event.data as ClientProduct;
    let url = '';
    const isInsuranceProduct = GlobalConstants.INSURANCE_CODE_ARRAY.indexOf(data['productTypeCode']) > -1 ? true : false;
    if (this.ifIbondCode(data['productTypeCode'])) {
      url = `ibond/confirm/${data['productTypeCode']}/${data.applicationId}`;
    } else if (isInsuranceProduct) {
      url = `/insurance/evaluator?applicationId=${data.applicationId}`;
    } else {
      url = `enrollment/product-overview?formId=${data.id}`;
    }
    this.router.navigateByUrl(url);
  }

  ifIbondCode(code): boolean {
    return GlobalConstants.IBOND_CODE_ARRAY.indexOf(code) > -1 ? true : false;
  }

  hasActiveProducts() {
    return !!this.page && this.page.content.length > 0;
  }

}
