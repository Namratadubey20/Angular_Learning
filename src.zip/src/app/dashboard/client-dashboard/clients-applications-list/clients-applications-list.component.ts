import { Component, OnInit, Input } from '@angular/core';
import { Column } from '../../../form-components/generic-pageable-list/column';
import { MatSnackBar } from '@angular/material';
import { Page, Pageable, PageableConverter, PageImpl } from '../../../common/pagination';
import { ListLinkClickEvent } from '../../../form-components/generic-pageable-list/list-link-click-event';
import { Router } from '@angular/router';
import { ApplicationService } from '../../../enrollment/application/application.service';
import {
  ClientCourtApplicationSummary,
  ClientCourtApplicationSummaryImpl
} from '../../../enrollment/application/court/model/client-court-application-summary';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

@Component({
  selector: 'app-clients-applications-list',
  templateUrl: './clients-applications-list.component.html',
  styleUrls: ['./clients-applications-list.component.css'],
})
export class ClientsApplicationsListComponent implements OnInit {

  loading = false;

  cols: Column[] = [
    {
      field: 'id',
      header: 'App ID',
      link: true,
    },
    {
      field: 'productTypeName',
      header: 'Product Type',
      link: false,
    },
    {
      field: 'createdAt',
      header: 'Effective Date',
      link: false,
    },
    {
      field: 'status',
      header: 'Status',
      link: false,
    },
  ];


  page: Page<ClientCourtApplicationSummary>;
  searchBystatus = '';
  constructor(
    private applicationService: ApplicationService,
    private router: Router,
    public spinnerService: SpinnerService,
    public _snackBar: MatSnackBar
  ) {
  }

  ngOnInit() {
    this.page = new PageImpl<ClientCourtApplicationSummaryImpl>();
    this.applicationService.searchByStatus.subscribe(async status => {
      this.searchBystatus = status;
    });
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }, dateRange = []) {
    this.loading = true;
    try {
      const searchParams = {
        status: this.searchBystatus,
      };
      if (dateRange.length === 2) {
        searchParams['startDate'] = dateRange[0];
        searchParams['endDate'] = dateRange[1];
      }
      this.spinnerService.show();
      this.page = await this.applicationService.getApplicationListForPerson(pageable, searchParams);
      this.spinnerService.hide();
    } catch {
      const errorPage = PageableConverter.fromData([]);
      errorPage.error = true;
      this.page = errorPage;
      this.spinnerService.hide();
    }

    this.loading = false;
  }

  listLinkClickEvent(event: ListLinkClickEvent, _snackBar) {
    const data: ClientCourtApplicationSummary = event.data as ClientCourtApplicationSummary;
    let url = '';
    const me = this;
    if (this.ifIbondCode(data.productTypeCode)) {
      if (data.status === 'Pending Review' || data.status === 'Hold' || data.status === 'Declined'
        || data.status === 'Completed' || data.status === 'Pending' || data.status === 'Submitted') {
        url = `ibond/confirm/${data.productTypeCode}/${data.id}`;
      } else {
        url = `ibond/application/${data.productTypeCode}/${data.id}`;
      }
    } else if (this.ifInsuranceCode(data.productTypeCode)) {
      url = `insurance/evaluator?applicationId=${data.id}`;
    } else {
      url = data.status === 'In Progress' || data.status === 'Hold' ?
        `enrollment/application/${data.productTypeCode}/${data.id}` :
        `enrollment/application-overview?formId=${data.id}`;
    }
    if (url) {
      this.router.navigateByUrl(url);
    }
  }

  ifIbondCode(code): boolean {
    return GlobalConstants.IBOND_CODE_ARRAY.indexOf(code) > -1 ? true : false;
  }

  ifInsuranceCode(code: string): boolean {
    return GlobalConstants.INSURANCE_CODE_ARRAY.indexOf(code) > -1 ? true : false;
  }

  hasActiveApplications() {
    return !!this.page && this.page.content.length > 0;
  }
}
