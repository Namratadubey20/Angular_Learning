import { Component, OnInit, AfterViewInit } from '@angular/core';
import { UtilMethodsService } from 'src/app/insurance/services/util-method.service';
import { AppConfigService } from 'src/app/app-config-service';
import { SecurityService } from 'src/app/security/security.service';
import { StringConstants } from 'src/app/insurance/constants/string-constants';

@Component({
  selector: 'app-back-torails',
  templateUrl: './back-torails.component.html',
  styleUrls: ['./back-torails.component.scss'],
})
export class BackToRailsComponent implements OnInit, AfterViewInit {
  appConfig;
  constructor(public appConfigService: AppConfigService,
    public securityService: SecurityService,
    public stringConstant: StringConstants) {
    this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
    });
  }
  ngOnInit() {
  }
  ngAfterViewInit() {
    /* this.setDelay(() => {
      this.navigateToRails();
    }, 10000); */
  }

  navigateToRails() {
    sessionStorage.removeItem('originState');
    let railsUrl = this.appConfig.colonial_erisa_NoN_TPA_url;
    if (UtilMethodsService.userRoleType(this.securityService.user.userRoles, this.stringConstant.ROLE_TPA)) {
      railsUrl = this.appConfig.colonial_erisa_TPA_url;
    }
    this.securityService.getAccessToken().then(response => {
      console.log(this.securityService.requestURL(`?sutoken=${response}`));
      window.open(`${railsUrl}?sutoken=${response}`, '_self');
    });
  }
  setDelay(callback: Function, milliseconds?: number) {
    if (callback) {
      const delay = milliseconds || 250;
      setTimeout(() => {
        callback();
      }, delay);
    }
  }
}
