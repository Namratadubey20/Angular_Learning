import { Component } from '@angular/core';
import { AgentDashboardComponent } from '../agent-dashboard.component';
import { SecurityService } from '../../../security/security.service';
import { AppConfigService } from '../../../app-config-service';
import { IbondBaseService } from 'src/app/ibond/service/ibond-base.service';
import { Router } from '@angular/router';
import { DashboardService } from '../../dashboard.service';
import { ApplicationService } from 'src/app/enrollment/application/application.service';
import { FormBuilder } from '@angular/forms';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';

@Component({
  selector: 'app-attorney-dashboard',
  templateUrl: './attorney-dashboard.component.html',
  styleUrls: ['./attorney-dashboard.component.scss'],
})
export class AttorneyDashboardComponent extends AgentDashboardComponent {

  constructor(securityService: SecurityService,
    router: Router,
    dashboardService: DashboardService,
    appConfigService: AppConfigService,
    lpService: IbondBaseService,
    public applicationService: ApplicationService,
    public fb: FormBuilder,
    public serviceHandler: ServiceHandler
  ) {
    super(securityService, router, dashboardService, appConfigService, lpService, applicationService, fb, serviceHandler);
  }
}
