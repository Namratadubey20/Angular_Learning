import { Component, OnInit, ViewChild } from '@angular/core';
import { UserImpl } from '../../security/user';
import { SecurityService } from '../../security/security.service';
import { Router } from '@angular/router';
import { Client } from '../../common/client';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';
import { AppConfigService } from '../../app-config-service';
import { IbondBaseService } from 'src/app/ibond/service/ibond-base.service';
import { DashboardService } from '../dashboard.service';
import { CourtBondType, ProfessionalLiabilityBondType } from '../../enrollment/application/common/bond-types';
import { ApplicationService } from '../../enrollment/application/application.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort, MatDialog } from '@angular/material';
import * as moment from 'moment';
import { Pageable } from 'src/app/common/pagination';
import { ClientsApplicationsListComponent } from '../client-dashboard/clients-applications-list/clients-applications-list.component';
import { ClientsActiveProductsListComponent } from '../client-dashboard/clients-products-list-active/clients-active-products-list.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { TableDefaultDetails } from 'src/app/form-components/generic-table-search/table-default-details';
import { AgentCourtApplicationsComponent } from 'src/app/colonial-table/agent-application-list/agent-court-applications/agent-court-applications.component';
import { AgentCourtProductsComponent } from 'src/app/colonial-table/agent-product-list/agent-court-products/agent-court-products.component';
import { AgentApplicationListComponent } from 'src/app/colonial-table/agent-application-list/agent-application-list.component';
import { AgentProductListComponent } from 'src/app/colonial-table/agent-product-list/agent-product-list.component';


@Component({
  selector: 'app-agent-dashboard',
  templateUrl: './agent-dashboard.component.html',
  styleUrls: ['./agent-dashboard.component.scss'],
})
export class AgentDashboardComponent implements OnInit {
  isSearchEnable = false;
  isPendingList = false;
  isActiveList = false;
  isHistoryList = false;
  filterByStatus = '';
  searchForm: FormGroup;
  today = new Date();
  validStartDate = this.today;
  validEndDate = this.today;
  pendingProductList = [];
  pendingProductCount = 0;
  activeProductListCount = 0;
  historyProductList = [];
  historyProductListCount = 0;
  dashboardCount = 0;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(ClientsApplicationsListComponent) clientsApplicationsListComponent: ClientsApplicationsListComponent;
  @ViewChild(ClientsActiveProductsListComponent) clientsActiveProductsListComponent: ClientsActiveProductsListComponent;
  @ViewChild(AgentApplicationListComponent) agentApplicationListComponent: AgentApplicationListComponent;
  @ViewChild(AgentProductListComponent) agentProductListComponent: AgentProductListComponent;

  initialized = false;
  user: UserImpl = null;
  clients: Array<Client>;
  bondType: string;
  public hostName: any;
  showCourtLinks: boolean;
  showInsuranceLinks: boolean;
  showAlerts: boolean;
  inProgressApplications: number;
  onHoldApplications: number;
  submittedApplications: number;
  onSoftHoldApplications: number;
  insuranceProductList: any;
  declinedApplications: number;
  awaitingPaymentApplications: number;
  pendingReviewApplications: number;
  upForRenewalBond: number;
  recentlyExpiredBond: number;
  pendingRenewalBond: number;
  totalAlerts: number;
  bondList = [
    {
      name: 'License and Permit', type: 'landp', value: 'landp', url: '/ibond/getquotes/landp', isActive: true, attorney: false,
      agent: true,
    },
    {
      name: 'RIA Bond', type: 'miscellaneous', value: 'RIA Bond', url: '/ibond/getquotes/ria', isActive: false, attorney: false,
      agent: true,
    },
    {
      name: 'Airport Security Bond', type: 'miscellaneous', value: 'Airport Security Bond',
      url: '/ibond/getquotes/airport_security', isActive: false, attorney: false, agent: true,
    },
    {
      name: 'Notary Bond', type: 'miscellaneous', value: 'Notary Bond', url: '/ibond/getquotes/notary', isActive: true, attorney: false,
      agent: true,
    },
    {
      name: 'Public Official', type: 'surety', value: 'Public Official', url: '/ibond/getquotes/po', isActive: true, attorney: false,
      agent: true,
    },
    {
      name: 'Lost Instrument', type: 'miscellaneous', value: 'Lost Instrument', url: '/ibond/getquotes/lost_instrument',
      isActive: true, attorney: true, agent: true,
    },
    {
      name: 'VA Fiduciary', type: 'surety', value: 'VA Fiduciary', url: '/ibond/getquotes/vafiduciary', isActive: false, attorney: true,
      agent: true,
    },
    {
      name: 'Lost Car/Defective Vehicle Title (Incl. Donated Vehicle)', type: 'miscellaneous',
      value: 'Lost Car/Defective Vehicle Title (Incl. Donated Vehicle)',
      url: '/ibond/getquotes/lost_car_title', isActive: false, attorney: false, agent: true,
    },
    {
      name: 'Employee Dishonesty', type: 'fidelity', value: 'Employee Dishonesty',
      url: '/ibond/getquotes/employee_dishonesty', isActive: true, attorney: false, agent: true,
    },
    {
      name: 'Janitorial Home Service', type: 'fidelity', value: 'Janitorial Home Service',
      url: '/ibond/getquotes/janitorial', isActive: true, attorney: false, agent: true,
    },
  ];
  activeBondList = [];
  tableDefaultDetails: TableDefaultDetails;
  constructor(
    private securityService: SecurityService,
    private router: Router,
    private dashboardService: DashboardService,
    appConfigService: AppConfigService,
    private lpService: IbondBaseService,
    public applicationService: ApplicationService,
    public fb: FormBuilder,
    public serviceHandler: ServiceHandler
  ) {
    appConfigService.getConfig().subscribe(config => this.hostName = config.colonial_web_app_url);
    if (!this.filterByStatus) {
      this.applicationService.searchApplication('');
    }
    this.initializeDateFilter();
    this.getDasboardCount();
    this.searchForm.controls['startDate'].valueChanges.subscribe((value) => {
      this.validEndDate = new Date(value);
    });
  }

  async ngOnInit() {
    this.activeBondList = this.bondList.filter(list => list.isActive === true);
    this.isPendingList = true;
    this.tableDefaultDetails = {
      defaultStatus: 'All',
      bondClassification: 'Court', // default to court cause it's the only one for now
    };
    // this.activeBondList = this.bond_list.filter(list => list.isActive === true);
    this.user = this.securityService.user;
    this.initialized = true;
    this.showCourtLinks = true;
    this.showInsuranceLinks = true;
    const status = await this.dashboardService.getApplicationStatuses();
    this.inProgressApplications = status['applications']['In Progress'];
    this.onHoldApplications = status['applications']['Hold'];
    this.onSoftHoldApplications = status['applications']['Soft Hold'];
    this.declinedApplications = status['applications']['Declined'];
    this.awaitingPaymentApplications = status['applications']['Awaiting Payment'];
    this.submittedApplications = this.toNumber(status['applications']['Submitted']);
    this.pendingReviewApplications = this.submittedApplications + (this.onHoldApplications || 0);
    this.upForRenewalBond = status['products']['Up For Renewal'];
    this.recentlyExpiredBond = status['products']['Recently Expired'];
    this.pendingRenewalBond = status['products']['Pending Renewal'];
    this.totalAlerts = 0;
    this.totalAlerts += this.inProgressApplications || 0;
    this.totalAlerts += this.onHoldApplications || 0;
    this.totalAlerts += this.onSoftHoldApplications || 0;
    this.totalAlerts += this.declinedApplications || 0;
    this.totalAlerts += this.awaitingPaymentApplications || 0;
    this.totalAlerts += this.pendingReviewApplications || 0;
    this.totalAlerts += this.upForRenewalBond || 0;
    this.totalAlerts += this.recentlyExpiredBond || 0;
    this.totalAlerts += this.pendingRenewalBond || 0;
    if (this.totalAlerts > 0) {
      this.showAlerts = true;
    } else {
      this.showAlerts = false;
    }
  }

  getInsuranceProductList() {
    this.lpService.getProductTypesByLob().subscribe((_insuranceProductList) => {
      for (const [iconKey, iconValue] of Object.entries(GlobalConstants.INSURANCE_PRODUCT_ICON_KEY_MAPPER)) {
        _insuranceProductList['list'].forEach(_key => {
          if (iconKey === _key.name) {
            _key['imgUrl'] = iconValue;
            return;
          }
        });
      }
      this.insuranceProductList = _insuranceProductList['list'];
      console.log('insuranceProductList >>> ', this.insuranceProductList);
    });
  }

  getActionInsurance() {
    return this.insuranceProductList;
  }

  onSelectInsurance(_productCode) {
    // this.close();
    this.router.navigate(['/insurance'], { queryParams: { product_code: [_productCode] } });
  }


  toNumber(num): number {
    return num ? Number(num) : 0;
  }

  onSelectBond(navigateTo) {
    this.router.navigate([navigateTo]);
  }
  routeToPNLApplication() {
    this.routeTo(ProfessionalLiabilityBondType.Pnl);
  }

  routeToSupersedeas() {
    this.routeTo(CourtBondType.Supersedeas);
  }

  routeToReplevin() {
    this.routeTo(CourtBondType.Replevin);
  }

  routeToAttachment() {
    this.routeTo(CourtBondType.Attachment);
  }

  routeToInjunction() {
    this.routeTo(CourtBondType.Injunction);
  }

  routeToGuardianship() {
    this.routeTo(CourtBondType.Guardianship);
  }

  routeToConservatorship() {
    this.routeTo(CourtBondType.Conservatorship);
  }

  routeToEstate() {
    this.routeTo(CourtBondType.Estate);
  }

  routeToTrustee() {
    this.routeTo(CourtBondType.Trustee);
  }

  routeToReceiver() {
    this.routeTo(CourtBondType.Receiver);
  }

  routeToReferee() {
    this.routeTo(CourtBondType.Referee);
  }

  routeToVa() {
    this.router.navigateByUrl('/ibond/getquotes/vafiduciary');
  }

  private routeTo(bondType: string) {
    this.router.navigateByUrl(`/enrollment/application/${bondType}`);
  }

  isCompany(): boolean {
    return this.user && this.user.isCompany;
  }

  isAgent() {
    return this.user && this.user.hasAgentRole;
  }

  isAttorney() {
    return this.user && this.user.hasAttorneyRole;
  }

  hasEmployeePermissions() {
    return this.user && this.user.hasEmployeePermissions;
  }

  toggleCourt() {
    this.showCourtLinks = !this.showCourtLinks;
  }

  toggleInsurance() {
    this.showInsuranceLinks = !this.showInsuranceLinks;
  }

  toggleAlerts() {
    this.showAlerts = !this.showAlerts;
  }

  async selectFilteredList(number: number, url: string, status: string) {
    await this.router.navigateByUrl(`${url}/${status}`);
  }

  showProductList(val, enableFilter) {
    this.searchForm.reset();
    this.isPendingList = false;
    this.isActiveList = false;
    this.isHistoryList = false;
    if (!enableFilter) {
      this.applicationService.searchApplication('');
      if (val === 'Application') {
        this.applicationService.clearApplicationSearch(true);
      }
    }
    if (val === 'Application') {
      setTimeout(() => {
        this.isPendingList = true;
        this.isActiveList = false;
        this.isHistoryList = false;
      }, 500);
    } else if (val === 'Products') {
      this.isPendingList = false;
      this.isActiveList = true;
      this.isHistoryList = false;
    } else if (val === 'History') {
      this.isPendingList = false;
      this.isActiveList = false;
      this.isHistoryList = true;
    }
  }

  filterListByStatus(val) {
    this.isPendingList = false;
    this.isActiveList = false;
    this.isHistoryList = false;
    this.filterByStatus = val.filter;
    this.applicationService.searchApplication(val.filter);
    setTimeout(() => {
      this.showProductList(val.tab, 1);
    }, 500);
  }

  getDateRange(): string[] {
    let startDate: string;
    let endDate: string;
    startDate = moment(this.startDate.value).format('MM/DD/YYYY');
    endDate = moment(this.endDate.value).add(1, 'day').format('MM/DD/YYYY');
    return [startDate, endDate];
  }

  get isStartDateValid() {
    return this.startDate.value !== '';
  }

  get startDate() {
    return this.searchForm.controls['startDate'];
  }

  get endDate() {
    return this.searchForm.controls['endDate'];
  }

  initializeDateFilter() {
    this.searchForm = this.fb.group({
      startDate: [''],
      endDate: [''],
    });
  }

  checkDateRange(): boolean {
    const startDate = this.startDate.value;
    const endDate = this.endDate.value;
    if (startDate === '' || endDate === '' || !(moment(startDate).isBefore(moment(endDate)) || moment(startDate).isSame(moment(endDate)))) {
      return false;
    }
    return true;
  }

  searchInDateRange() {
    if (this.checkDateRange()) {
      this.isSearchEnable = true;
      const pageable: Pageable = {
        page: 0,
        size: 20,
        sort: ['id', 'desc'],
      };
      if (this.isPendingList) {
        this.agentApplicationListComponent.agentCourtApplicationsComponent.pageableEvent(pageable, this.getDateRange());
      } else if (this.isActiveList) {
        this.agentProductListComponent.agentCourtProductsComponent.pageableEvent(pageable, this.getDateRange());
      }
    } else {
      this.serviceHandler.showErrorMessage('Please enter valid date range');
    }
  }

  async getDasboardCount() {
    const countResponse = await this.dashboardService.getApplicationStatuses();
    this.pendingProductCount = this.getApplicationCount(countResponse);
    this.activeProductListCount = this.toNumber(countResponse['products']['Open']);
    this.dashboardCount = Number(this.pendingProductCount) + Number(this.activeProductListCount);
    this.historyProductListCount = this.toNumber(countResponse['products']['Closed']);
  }

  getApplicationCount(countResponse): number {
    return this.toNumber(countResponse['applications']['In Progress']) +
      this.toNumber(countResponse['applications']['Pending Review']) +
      this.toNumber(countResponse['applications']['Hold']) +
      this.toNumber(countResponse['applications']['Submitted']) +
      this.toNumber(countResponse['applications']['Pending']) +
      this.toNumber(countResponse['applications']['Completed']);
  }

  clearDateInput() {
    this.searchForm.get('startDate').reset();
    this.searchForm.get('endDate').reset();
    if (this.isSearchEnable) {
      this.isSearchEnable = false;
      if (this.isPendingList) {
        this.agentApplicationListComponent.agentCourtApplicationsComponent.pageableEvent({
          page: 0,
          size: 20,
          sort: ['id', 'desc'],
        }, []);
      } else if (this.isActiveList) {
        this.agentProductListComponent.agentCourtProductsComponent.pageableEvent({
          page: 0,
          size: 20,
          sort: ['id', 'desc'],
        }, []);
      }
    }
  }

  downloadReport() {
    if (this.checkDateRange()) {
      const startDate = moment(this.startDate.value).format('YYYY-MM-DD');
      const endDate = moment(this.endDate.value).format('YYYY-MM-DD');
      this.dashboardService.downloadReports(this.user.agent.id, startDate, endDate);
    } else {
      this.serviceHandler.showErrorMessage('Please enter valid date range');
    }
  }
}
