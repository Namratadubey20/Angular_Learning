import { Component, OnInit, OnChanges, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceHandler } from '../utils/service-handler.service';
import { Subscription } from 'rxjs';
import { AppConfigService } from '../../app-config-service';

@Component({
  selector: 'app-knockout-dialog',
  templateUrl: './knockout-dialog.component.html',
})
export class KnockoutDialogComponent implements OnInit, OnChanges, OnDestroy {
  reason: string;
  reasonSub: Subscription;
  public reasonSentence: string;
  colonialPhoneNumber: string;

  constructor(public router: Router, public activatedRoute: ActivatedRoute, public dialog: MatDialog,
    public serviceHandler: ServiceHandler, appConfigService: AppConfigService) {
    appConfigService.getConfig().subscribe(config => this.colonialPhoneNumber = config.colonialPhoneNumber);
  }

  ngOnInit(): void {
    this.reasonSub = this.activatedRoute.queryParams.subscribe((queryParams) => {
      if (queryParams.reason) {
        this.reason = queryParams.reason;
        this.checkLocks();
      }
    });
  }

  ngOnDestroy(): void {
    this.reasonSub.unsubscribe();
  }


  ngOnChanges(): void {
    this.checkLocks();
  }

  checkLocks(): void {
    switch (this.reason) {
      case 'knockedOut':
        this.reasonSentence = 'We are unable to provide a bond due to your answers to our preliminary questions';
        break;
      case 'creditScore':
        this.reasonSentence = 'We are unable to provide a bond due to your credit score';
        break;
      case 'both':
        this.reasonSentence =
          'We are unable to provide a bond due to your answers to our preliminary questions and your credit score';
        break;
      case 'technicalError':
        this.reasonSentence =
          'We are unable to check your credit score at this time';
        break;
      default:
        this.serviceHandler.handleError('unknown lock out reason');
    }
  }
}
