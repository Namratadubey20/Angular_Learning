import { AuditableObject } from './auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject('Agency')
export class Agency extends AuditableObject {
  @JsonProperty('clientsId', Number, true)
  clientsId: number = null;

  @JsonProperty('colonial', Boolean, true)
  colonial: boolean = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('email', String, true)
  email: string = null;

  @JsonProperty('website', String, true)
  website: string = null;

  @JsonProperty('phone', String, true)
  phone: string = null;

  @JsonProperty('fax', String, true)
  fax: string = null;
}
