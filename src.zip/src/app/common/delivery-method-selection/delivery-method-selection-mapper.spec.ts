import { DeliveryMethodImpl } from '../../enrollment/application/court/model/common/delivery-method';
import { DeliveryMethodSelectionMapper } from './delivery-method-selection-mapper';
import { AddressImpl } from '../../enrollment/application/court/model/common/address';
import { SpecHelpers } from '../utils/spec-helpers';



describe('DeliveryMethodSelectionMapper.deliveryMethod', () => {
  it('should set fields to null when deliveryMethodRawValues is null ', () => {
    const deliveryMethod = new DeliveryMethodImpl();
    {
      deliveryMethod.deliveryMethod = 'ABC';
      deliveryMethod.deliveryName = 'abc';
      deliveryMethod.deliveryPhone = '111';
      deliveryMethod.deliveryAddress = new AddressImpl();
      deliveryMethod.deliveryAddress.street1 = 'wert';
      deliveryMethod.deliveryAddress.street2 = 'dfdf';
      deliveryMethod.deliveryAddress.city = 'asasa';
      deliveryMethod.deliveryAddress.state = 'dfewef';
      deliveryMethod.deliveryAddress.zipCode = 'wewe';
      deliveryMethod.copyViaEmail = true;
    }

    const expectedModelProperties = [
      'deliveryMethod',
      'deliveryName',
      'deliveryPhone',
      'deliveryAddress.street1',
      'deliveryAddress.street2',
      'deliveryAddress.city',
      'deliveryAddress.state',
      'deliveryAddress.zipCode',
      'copyViaEmail',
    ];

    expectedModelProperties.forEach(ep => {
      const property = SpecHelpers.getPropertyFromPath(deliveryMethod, ep);
      expect(property)
        .withContext(`for property: ${ep}`)
        .toBeDefined();
      expect(property)
        .withContext(`for property: ${ep}`)
        .toBeTruthy();
    });


    DeliveryMethodSelectionMapper.populateDeliveryMethod(deliveryMethod, null);

    expectedModelProperties.forEach(ep => {
      const property = SpecHelpers.getPropertyFromPath(deliveryMethod, ep);
      expect(property)
        .withContext(`for property: ${ep}`)
        .toBeDefined();
      expect(property)
        .withContext(`for property: ${ep}`)
        .toBeNull();
    });
  });
});

describe('DeliveryMethodSelectionMapper.createDeliveryMethodFormGroupPatchValues', () => {
  it('should create a matching patchValues object', () => {
    const deliveryMethod = new DeliveryMethodImpl();
    {
      deliveryMethod.deliveryMethod = 'ABC';
      deliveryMethod.deliveryName = 'abc';
      deliveryMethod.deliveryPhone = '111';
      deliveryMethod.deliveryAddress = new AddressImpl();
      deliveryMethod.deliveryAddress.street1 = 'wert';
      deliveryMethod.deliveryAddress.street2 = 'dfdf';
      deliveryMethod.deliveryAddress.city = 'asasa';
      deliveryMethod.deliveryAddress.state = 'dfewef';
      deliveryMethod.deliveryAddress.zipCode = 'wewe';
      deliveryMethod.copyViaEmail = true;
    }
    const mappings = [
      { model: 'deliveryMethod', patch: 'deliveryMethod' },
      { model: 'deliveryName', patch: 'deliveryName' },
      { model: 'deliveryPhone', patch: 'deliveryPhone' },
      { model: 'deliveryAddress.street1', patch: 'deliveryAddress.street1' },
      { model: 'deliveryAddress.street2', patch: 'deliveryAddress.street2' },
      { model: 'deliveryAddress.city', patch: 'deliveryAddress.city' },
      { model: 'deliveryAddress.state', patch: 'deliveryAddress.state' },
      { model: 'deliveryAddress.zipCode', patch: 'deliveryAddress.zipCode' },
      { model: 'copyViaEmail', patch: 'copyViaEmail' },
    ];

    const patchValues = DeliveryMethodSelectionMapper.createDeliveryMethodFormGroupPatchValues(deliveryMethod);

    mappings.forEach(mapping => {
      const modelProp = SpecHelpers.getPropertyFromPath(deliveryMethod, mapping.model);
      const patchValue = SpecHelpers.getPropertyFromPath(patchValues, mapping.patch);
      expect(modelProp)
        .withContext(`for model property: ${mapping.model}`)
        .toBeDefined();
      expect(patchValue)
        .withContext(`for patchValues property: ${mapping.patch}`)
        .toBeDefined();
      expect(patchValue)
        .withContext(`patchValue [${mapping.patch}]:${patchValue}`
          + `, model property [${mapping.model}]:${modelProp}`)
        .toBe(modelProp);
    });
  });
});

