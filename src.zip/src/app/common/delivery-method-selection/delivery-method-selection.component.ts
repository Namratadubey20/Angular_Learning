import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { deliveryMethods } from '../utils/constants';
import { ApplicationDataImpl } from '../../enrollment/application/court/model/application-data';
import { ApplicationImpl } from '../../enrollment/application/application';

@Component({
  selector: 'app-delivery-method-selection',
  templateUrl: './delivery-method-selection.component.html',
  styleUrls: ['./delivery-method-selection.component.css'],
})
export class DeliveryMethodSelectionComponent {

  @Input() deliveryMethodFormGroup: FormGroup;
  // An optional source of prepopulation payment info.
  @Input() initialNameAddressValuesSource?: ApplicationImpl | ApplicationDataImpl | any;

  deliveryMethods = deliveryMethods;

  constructor() { }

  deliveryMethodChanged(event) {
    if (this.deliveryMethodSelected()) {
      if (this.isEmail()) {
        this.clearNameAddress();
      } else {
        this.prepopulateNameAddress();
      }
    } else {
      this.clearNameAddress();
    }
  }


  /**
   * Prepopulate Delivery fields with initialNameAddressValues.
   */
  prepopulateNameAddress() {
    const initialNameAddressValues = this.getInitialNameAddressValues();
    if (initialNameAddressValues) {
      const initialName = initialNameAddressValues.applicantName;
      if (initialName) {
        this.deliveryName.patchValue(initialName);
      }
      const initialPhone = initialNameAddressValues.applicantPhone;
      if (initialPhone) {
        this.deliveryPhone.patchValue(initialPhone);
      }
      const initialAddress = initialNameAddressValues.applicantAddress;
      if (initialAddress) {
        this.deliveryAddress.patchValue(initialAddress);
      }
    }
  }

  clearNameAddress() {
    this.deliveryName.reset(null, { onlySelf: true });
    this.deliveryPhone.reset(null, { onlySelf: true });
    this.deliveryAddress.reset({}, { onlySelf: true });
  }

  getInitialNameAddressValues() {
    let initialNameAddressValues;
    if (this.initialNameAddressValuesSource) {
      if (this.initialNameAddressValuesSource instanceof ApplicationImpl) {
        const application = this.initialNameAddressValuesSource;
        initialNameAddressValues = application.data;
      } else if (this.initialNameAddressValuesSource instanceof ApplicationDataImpl) {
        initialNameAddressValues = this.initialNameAddressValuesSource;
      }
    }
    return initialNameAddressValues;
  }

  trackByDeliveryMethod(index: number, deliveryMethod: any): string {
    return deliveryMethod ? deliveryMethod.value : deliveryMethod;
  }

  get deliveryMethod(): FormControl {
    return this.deliveryMethodFormGroup.get('deliveryMethod') as FormControl;
  }

  get copyViaEmail(): FormControl {
    return this.deliveryMethodFormGroup.get('copyViaEmail') as FormControl;
  }

  get deliveryName(): FormControl {
    return this.deliveryMethodFormGroup.get('deliveryName') as FormControl;
  }

  get deliveryPhone(): FormControl {
    return this.deliveryMethodFormGroup.get('deliveryPhone') as FormControl;
  }

  get deliveryAddress(): FormGroup {
    return this.deliveryMethodFormGroup.get('deliveryAddress') as FormGroup;
  }

  deliveryMethodSelected(): boolean {
    return !!this.deliveryMethod.value;
  }

  isEmail() {
    return this.deliveryMethodFormGroup.get('deliveryMethod').value === 'Email';
  }

  isUSPS() {
    return this.deliveryMethodFormGroup.get('deliveryMethod').value === 'USPS';
  }

  isUPS() {
    return this.deliveryMethodFormGroup.get('deliveryMethod').value === 'UPS';
  }

  isFedex() {
    return this.deliveryMethodFormGroup.get('deliveryMethod').value === 'FedEx';
  }
}
