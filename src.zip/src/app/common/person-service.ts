import { Injectable } from '@angular/core';
import { PersonSummary, PersonSummaryImpl } from './person-summary';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { JsonConvert } from 'json2typescript';
import { AgentSummary, AgentSummaryImpl } from '../user/profile/readonly-referral-information/agent-summary';
import { JsonConvertService } from './utils/json-convert.service';
import { catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export class PersonService {
  private readonly companyOfficeIdToResponsiblePersonURL = 'api/company-office-person/company-office/{companyOfficeId}/responsible-person';
  private readonly applicationIdToAgentSummaryURL = 'api/person/application/{applicationId}/agent';
  private readonly jsonConvert: JsonConvert;

  constructor(
    private http: HttpClient,
    jsc: JsonConvertService
  ) {
    this.jsonConvert = jsc.getJsonConvert();
  }

  async getCompanyOfficeResponsiblePersonByCompanyOfficeId(companyOfficeId: number): Promise<PersonSummary> {
    const url = this.companyOfficeIdToResponsiblePersonURL.replace('{companyOfficeId}', companyOfficeId.toString());
    const response =
      await this.http.get(url).toPromise();
    return this.jsonConvert.deserialize(response, PersonSummaryImpl) as PersonSummaryImpl;
  }

  async getAgentOfApplication(applicationId: number): Promise<AgentSummary | null> {
    const url = this.applicationIdToAgentSummaryURL.replace('{applicationId}', applicationId.toString());
    return this.http.get<AgentSummary>(url).pipe(
      map(as => this.jsonConvert.deserialize(as, AgentSummaryImpl)),
      catchError(() => of(null))
    ).toPromise();
  }
}
