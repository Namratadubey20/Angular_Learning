import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../utils/date-converter';

export interface RefundModel {
  id: number;
  paymentId: number;
  processedTimestamp: Date;
  transactionNumber: string;
}

@JsonObject('RefundModelImpl')
export class RefundModelImpl implements RefundModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('paymentId', Number, true)
  paymentId: number = null;

  @JsonProperty('processedTimestamp', DateConverter, true)
  processedTimestamp: Date = null;

  @JsonProperty('transactionNumber', String, true)
  transactionNumber: string = null;
}
