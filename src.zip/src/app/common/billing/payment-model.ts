import { JsonObject, JsonProperty } from 'json2typescript';
import { BillingProfileModel, BillingProfileModelImpl } from '../payment-method-selection/billing-profile-model';
import { RefundModel, RefundModelImpl } from './refund-model';
import { DateConverter } from '../utils/date-converter';

export interface PaymentModel {
  id: number;
  amount: number;
  paymentPlanId: number;
  billingProfileModel: BillingProfileModel | null; // No BillingProfileModel for non-electronic payment methods.
  processedTimestamp: Date;
  paymentTransactionNumber: string;
  refundModel: RefundModel;

  readonly isRefunded: boolean;
}

@JsonObject('PaymentModelImpl')
export class PaymentModelImpl implements PaymentModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('amount', Number, true)
  amount: number = null;

  @JsonProperty('paymentPlanId', Number, true)
  paymentPlanId: number = null;

  @JsonProperty('billingProfileModel', BillingProfileModelImpl, true)
  billingProfileModel: BillingProfileModel = null;

  @JsonProperty('processedTimestamp', DateConverter, true)
  processedTimestamp: Date = null;

  @JsonProperty('paymentTransactionNumber', String, true)
  paymentTransactionNumber: string = null;

  @JsonProperty('refundModel', RefundModelImpl, true)
  refundModel: RefundModel = null;

  get isRefunded(): boolean {
    return !!this.refundModel;
  }
}
