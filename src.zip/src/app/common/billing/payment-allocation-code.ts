/**
 * Enum implemented as class.
 */
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

@JsonObject('PaymentAllocationCode')
export class PaymentAllocationCode extends AbstractIdentifierEnum {
  private static _values: Map<string, PaymentAllocationCode> = new Map<string, PaymentAllocationCode>();
  public static FRONT_LOADED = new PaymentAllocationCode('front-loaded', 'Front Loaded');
  public static SPREAD = new PaymentAllocationCode('spread', 'Spread');

  private constructor(
    persistenceId: string, // Relates the enum with server representation.
    private _defaultDisplayText: string
  ) {
    super(persistenceId);
  }

  public static valueOf(persistenceId: string | undefined): PaymentAllocationCode {
    return PaymentAllocationCode._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): PaymentAllocationCode[] {
    return Array.from(PaymentAllocationCode._values.values());
  }

  protected registerEnum(): void {
    if (PaymentAllocationCode._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid PaymentAllocationCode 'enum' identifier: ${this.persistenceId}`);
    }
    PaymentAllocationCode._values.set(this.persistenceId, this);
  }
}

@JsonConverter
export class PaymentAllocationCodeConverter extends AbstractIdentifierEnumConverter<PaymentAllocationCode> {
  deserialize(enumObject: any): PaymentAllocationCode {
    let enumInstance: PaymentAllocationCode;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = PaymentAllocationCode.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}

