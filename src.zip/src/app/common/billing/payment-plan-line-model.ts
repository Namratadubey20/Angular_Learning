import { JsonObject, JsonProperty } from 'json2typescript';
import { PaymentPlanLineTypeCode, PaymentPlanLineTypeCodeConverter } from './payment-plan-line-type-code';
import { PaymentAllocationCode, PaymentAllocationCodeConverter } from './payment-allocation-code';

export interface PaymentPlanLineModel {
  id: number;
  paymentPlanLineTypeCode: PaymentPlanLineTypeCode;
  amount: number;
  otherDetail: string;
  paymentAllocationCode: PaymentAllocationCode;
  paymentPlanId: number;
}

@JsonObject('PaymentPlanLineModelImpl')
export class PaymentPlanLineModelImpl implements PaymentPlanLineModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('paymentPlanLineTypeCode', PaymentPlanLineTypeCodeConverter, true)
  paymentPlanLineTypeCode: PaymentPlanLineTypeCode = null;

  @JsonProperty('amount', Number, true)
  amount: number = null;

  @JsonProperty('otherDetail', String, true)
  otherDetail: string = null;

  @JsonProperty('paymentAllocationCode', PaymentAllocationCodeConverter, true)
  paymentAllocationCode: PaymentAllocationCode = null;

  @JsonProperty('paymentPlanId', Number, true)
  paymentPlanId: number = null;
}
