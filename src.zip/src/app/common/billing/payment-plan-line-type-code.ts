/**
 * Enum implemented as class.
 */
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

@JsonObject('PaymentPlanLineTypeCode')
export class PaymentPlanLineTypeCode extends AbstractIdentifierEnum {
  private static _values: Map<string, PaymentPlanLineTypeCode> = new Map<string, PaymentPlanLineTypeCode>();
  public static PREMIUM = new PaymentPlanLineTypeCode('premium', 'Premium');
  public static DELIVERY = new PaymentPlanLineTypeCode('delivery', 'Delivery Fee');
  public static OTHER = new PaymentPlanLineTypeCode('other', 'Other');

  private constructor(
    persistenceId: string, // Relates the enum with server representation.
    private _defaultDisplayText: string
  ) {
    super(persistenceId);
  }

  public static valueOf(persistenceId: string | undefined): PaymentPlanLineTypeCode {
    return PaymentPlanLineTypeCode._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): PaymentPlanLineTypeCode[] {
    return Array.from(PaymentPlanLineTypeCode._values.values());
  }

  protected registerEnum(): void {
    if (PaymentPlanLineTypeCode._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid PaymentPlanLineTypeCode 'enum' identifier: ${this.persistenceId}`);
    }
    PaymentPlanLineTypeCode._values.set(this.persistenceId, this);
  }
}

@JsonConverter
export class PaymentPlanLineTypeCodeConverter extends AbstractIdentifierEnumConverter<PaymentPlanLineTypeCode> {
  deserialize(enumObject: any): PaymentPlanLineTypeCode {
    let enumInstance: PaymentPlanLineTypeCode;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = PaymentPlanLineTypeCode.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}

