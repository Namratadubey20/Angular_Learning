import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../utils/date-converter';
import { LocalDateConverter } from '../utils/local-date-converter';

export interface PaymentPlanInstallmentModel {
  id: number;
  scheduledDueDate: Date;
  scheduledDueAmount: number;
  paidTimestamp: Date;
  paymentPlanId: number;
  paid: boolean;
}

@JsonObject('PaymentPlanInstallmentModelImpl')
export class PaymentPlanInstallmentModelImpl implements PaymentPlanInstallmentModel {
  @JsonProperty('id', Number, true)
  id: number = null;
  @JsonProperty('scheduledDueDate', LocalDateConverter, true)
  scheduledDueDate: Date = null;
  @JsonProperty('scheduledDueAmount', Number, true)
  scheduledDueAmount: number = null;
  @JsonProperty('paidTimestamp', DateConverter, true)
  paidTimestamp: Date = null;
  @JsonProperty('paymentPlanId', Number, true)
  paymentPlanId: number = null;
  @JsonProperty('paid', Boolean, true)
  paid: boolean = null;
}
