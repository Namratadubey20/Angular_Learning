import { JsonConverter, JsonCustomConvert } from 'json2typescript';
import * as moment_ from 'moment';

@JsonConverter
export class DateConverter implements JsonCustomConvert<Date> {
  moment = moment_;

  serialize(date: Date): any {
    if (date) {
      return this.moment(date).toISOString();
    }
    return null;
  }
  deserialize(date: any): Date {
    if (date) {
      return this.moment(date).toDate();
    }
    return null;
  }
}
