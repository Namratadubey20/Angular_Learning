import { AbstractControl, FormArray, FormControl, FormGroup } from '@angular/forms';

export class CommonUtilities {

  /**
   * Recursively 'marks-as-touched' the control and any children (including FormGroup and FormArray).
   * Unlike AbstractControl.markAsTouched which only affects itself (and parents) but not any children.
   * @param {AbstractControl} control
   */
  static markAllTouched(control: AbstractControl) {
    control.markAsTouched(); // mark control, be it a FormControl, FormGroup, or FormArray.

    if (control instanceof FormGroup) {
      Object.keys((<FormGroup>control).controls).forEach(field => {
        this.markAllTouched(control.get(field));
      });
    } else if (control instanceof FormArray) {
      (<FormArray>control).controls.forEach((childControl) => {
        this.markAllTouched(childControl);
      });
    }
  }

  /**
   * Recursively 'clone' the control and any children (including FormGroup and FormArray).
   * 'Clone' only clones validators, not value.
   * @param {AbstractControl} srcAbstractControl
   */
  static cloneAbstractControl(srcAbstractControl: AbstractControl): AbstractControl | null {
    let newAbstractControl: AbstractControl;

    if (srcAbstractControl instanceof FormGroup) {
      const srcFormGroup = <FormGroup>srcAbstractControl;
      const newFormGroup = new FormGroup({}, srcFormGroup.validator, srcFormGroup.asyncValidator);
      const srcChildAbstractControls = srcFormGroup.controls;
      Object.keys(srcChildAbstractControls).forEach(key => {
        const srcChildAbstractControl = srcChildAbstractControls[key];
        const newChildAbstractControl = this.cloneAbstractControl(srcChildAbstractControl);
        if (newChildAbstractControl !== null) {
          newFormGroup.addControl(key, newChildAbstractControl);
        }
      });
      newAbstractControl = newFormGroup;
    } else if (srcAbstractControl instanceof FormArray) {
      const srcFormArray = <FormArray>srcAbstractControl;
      const newFormArray = new FormArray([], srcFormArray.validator, srcFormArray.asyncValidator);
      const srcChildAbstractControls = srcFormArray.controls;
      srcChildAbstractControls.forEach(srcChildAbstractControl => {
        const newChildAbstractControl = this.cloneAbstractControl(srcChildAbstractControl);
        if (newChildAbstractControl !== null) {
          newFormArray.push(newChildAbstractControl);
        }
      });
      newAbstractControl = newFormArray;
    } else if (srcAbstractControl instanceof FormControl) {
      const srcFormControl = <FormControl>srcAbstractControl;
      const newFormControl = new FormControl(null, srcFormControl.validator, srcFormControl.asyncValidator);
      newAbstractControl = newFormControl;
    } else {
      // Don't do anything (silently).
      newAbstractControl = null;
    }
    return newAbstractControl;
  }
}
