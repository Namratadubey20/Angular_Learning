import { ErrorHandler, Injectable, Injector, isDevMode } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SecurityService } from '../../security/security.service';

@Injectable()
export class CustomErrorHandler implements ErrorHandler {
  requestUrl = '/api/notification';
  private readonly isDevMode: boolean;

  constructor(
    private http: HttpClient,
    private injector: Injector
  ) { this.isDevMode = isDevMode(); }


  handleError(error: any): void {
    if (this.isDevMode) {
      console.error(error);
    } else {
      this.sendError(error).then(resp => console.log(`Message sent to server. Received response: ${resp}`));
    }
  }

  private getLoggedInUserName(): string {
    const securityService: SecurityService = this.injector.get(SecurityService);
    return securityService.user ? securityService.user.username : 'No logged in user';
  }

  private async sendError(error: any) {
    const responseBody = {
      userName: this.getLoggedInUserName(),
      dateTime: new Date(),
      message: error.message || 'No error message',
      stackTrace: error.stack || 'No stack trace',
    };
    return await this.http.post(this.requestUrl, responseBody).toPromise();
  }
}
