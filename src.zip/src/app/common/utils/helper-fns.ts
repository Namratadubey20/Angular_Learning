export function toTitleCase(s: string): string {
  return s
    .split(/\s/)
    .map(w => w.charAt(0).toLocaleUpperCase() + w.slice(1))
    .join(' ');
}

export function splitIntoWords(camelCaseWord: string): string[] {
  return camelCaseWord
    .split('')
    .reduce((acc: string[], letter: string) => {
      const lastWord = acc.pop();
      return (!!lastWord)
        ? (acc.concat((letter === letter.toUpperCase()) ? [lastWord, letter] : lastWord + letter))
        : [letter];
    }, [])
    .map(toTitleCase);
}
