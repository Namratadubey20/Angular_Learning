import { AbstractIdentifierEnum } from './abstract-identifier-enum';
import { IdentifierEnumUtils } from './identifier-enum-utils';

class TestIdentifierEnum extends AbstractIdentifierEnum {
  private static _values: Map<string, TestIdentifierEnum> = new Map<string, TestIdentifierEnum>();
  public static TEST_1 = new TestIdentifierEnum('test_1');
  public static TEST_3 = new TestIdentifierEnum('test_3');
  public static TEST_2 = new TestIdentifierEnum('test_2');

  protected registerEnum(): void {
    if (TestIdentifierEnum._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid TestIdentifierEnum 'enum' identifier: ${this.persistenceId}`);
    }
    TestIdentifierEnum._values.set(this.persistenceId, this);
  }
}

describe('IdentifierEnumUtils', () => {

  describe('::orderByDisplayPrecedence', () => {

    it(`should sort set when all enums are specified in order-by param`, () => {
      const orderSpec = [TestIdentifierEnum.TEST_1, TestIdentifierEnum.TEST_2, TestIdentifierEnum.TEST_3];
      const toOrderSet = [TestIdentifierEnum.TEST_3, TestIdentifierEnum.TEST_2, TestIdentifierEnum.TEST_1];
      const expectedOrderedSet = [TestIdentifierEnum.TEST_1, TestIdentifierEnum.TEST_2, TestIdentifierEnum.TEST_3];
      expect(IdentifierEnumUtils.orderByDisplayPrecedence(orderSpec, toOrderSet)).toEqual(expectedOrderedSet);
    });

    it(`should sort set even if all enums are not specified in order-by param`, () => {
      const orderSpec = [TestIdentifierEnum.TEST_2];
      const toOrderSet = [TestIdentifierEnum.TEST_3, TestIdentifierEnum.TEST_1, TestIdentifierEnum.TEST_2];
      const expectedOrderedSet = [TestIdentifierEnum.TEST_2, TestIdentifierEnum.TEST_3, TestIdentifierEnum.TEST_1];
      expect(IdentifierEnumUtils.orderByDisplayPrecedence(orderSpec, toOrderSet)).toEqual(expectedOrderedSet);
    });
  });
});
