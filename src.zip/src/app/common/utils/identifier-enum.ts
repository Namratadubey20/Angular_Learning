/**
 * Interface of enum-as-a-class with a 'persistenceId' that allows it to be associated with a servers-side enum.
 * The only field that needs to be exchanged with the server is the persistenceId.
 * All other fields are probably present in both client and server enum representations. If not, expose via @JsonProperty.
 */
export interface IdentifierEnum {
  persistenceId: String;
}
