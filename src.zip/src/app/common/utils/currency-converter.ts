import { JsonConverter, JsonCustomConvert } from 'json2typescript';
import { CurrencyFormatter } from './currency-formatter';

@JsonConverter
export class CurrencyConverter implements JsonCustomConvert<String> {

  serialize(data: String): Number {
    return CurrencyFormatter.toRawNumber(data);
  }

  deserialize(data: Number): String {
    return CurrencyFormatter.formatMoney(data);
  }

}
