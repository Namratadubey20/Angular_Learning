import { JsonConverter } from 'json2typescript';
import { CurrencyConverter } from './currency-converter';


@JsonConverter
export class DollarSignCurrencyConverter extends CurrencyConverter {

  serialize(data: String): Number {
    return super.serialize(data.substring(1));
  }

  deserialize(data: Number): String {
    const moneyString: String = super.deserialize(data);
    return `$${moneyString}`;
  }
}
