import { SpecHelpers } from './spec-helpers';

describe('SpecHelpers.someRandomNumber', () => {
  it('should return a number ', () => {
    const random = SpecHelpers.someRandomNumber();

    expect(random)
      .withContext(`with number: ${random}`)
      .toEqual(jasmine.any(Number));

    expect(random)
      .withContext(`with number: ${random}`)
      .not.toBeNaN();
  });
});

describe('SpecHelpers.someRandomElementFrom', () => {
  it('should return an element from non-empty array ', () => {
    const array = ['3', '2', '1'];

    const randomArrayElement = SpecHelpers.someRandomElementFrom(array);
    expect(array)
      .toContain(randomArrayElement);
  });

  it('should return undefined for empty array ', () => {
    const array = [];

    const randomArrayElement = SpecHelpers.someRandomElementFrom(array);
    expect(randomArrayElement)
      .withContext(`with randomArrayElement: ${randomArrayElement}`)
      .toBeUndefined();
  });
});

describe('SpecHelpers.getPropertyFromPath', () => {
  it('should retrieve value of defined property ', () => {
    const source = {
      prop_1: 'some value',
    };

    const propPath = 'prop_1';
    expect(SpecHelpers.getPropertyFromPath(source, propPath))
      .withContext(`with propertyPath: ${propPath}`)
      .toBe(source.prop_1);
  });

  it('should return undefined for unknown property ', () => {
    const source = {
      prop_1: 'some value',
    };

    const propPath = 'prop_2';
    expect(SpecHelpers.getPropertyFromPath(source, propPath))
      .withContext(`with propertyPath: ${propPath}`)
      .toBeUndefined();
  });

  it('should retrieve value of defined nested property ', () => {
    const source = {
      prop_1: {
        nestedProp: 'some value',
      },
    };

    const propPath = 'prop_1.nestedProp';
    expect(SpecHelpers.getPropertyFromPath(source, propPath))
      .withContext(`with propertyPath: ${propPath}`)
      .toBe(source.prop_1.nestedProp);
  });

  it('should return undefined for unknown nested property ', () => {
    const source = {
      prop_1: {
        nestedProp: 'some value',
      },
    };

    const propPath = 'nestedProp_2';
    expect(SpecHelpers.getPropertyFromPath(source, propPath))
      .withContext(`with propertyPath: ${propPath}`)
      .toBeUndefined();
  });
});
