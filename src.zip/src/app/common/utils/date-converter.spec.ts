import { DateConverter } from './date-converter';
import { generate, Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';

describe('DateConverter', () => {
  let dc: DateConverter;
  const epoch = new Date(1970, 1, 1);

  // Server dates are emitted in UTC, but instead of ending in 'Z' as the browser would display them,
  // they end in '+0000', which is a longer way of saying 'UTC plus 0 hours; these are equivalent'
  const serverDates: Observable<string[]> = generate({
    initialState: epoch,
    iterate: () => randomDate(epoch, new Date()),
  }).pipe(
    map(d => [d.toISOString().replace('Z', '+0000'), d.toISOString()])
  );

  beforeEach(() => {
    dc = new DateConverter();
  });

  serverDates.pipe(take(10)).subscribe(([serverDate, frontendDate]) => {
    it(`.should round-trip [de]serialize from '${serverDate}' to '${frontendDate}' and back`, () => {
      const date = dc.deserialize(serverDate);
      const serialized = dc.serialize(date);
      // @ts-ignore: exists at runtime, added by jasmine custom matcher
      expect(serialized).toBeDefined();
    });
  });

  beforeEach(() => {
    jasmine.addMatchers({
      toBeTheEquivalentDate: (): jasmine.CustomMatcher => ({
        compare: (actual: any, expected: any): jasmine.CustomMatcherResult => {
          const iso8601minusTzStringLength = 23; // e.g. '1970-01-01T00:00:00.000'.length()
          const [expectedDt, expectedTz] = splitAt(expected, iso8601minusTzStringLength);
          const [actualDt, actualTz] = splitAt(actual, iso8601minusTzStringLength);
          const dateTimesMatch = expectedDt === actualDt;

          const equivalentTzs = ['Z', '+0000'];
          const timeZonesMatch = (
            expectedTz === actualTz ||
            (equivalentTzs.includes(expectedTz) && equivalentTzs.includes(actualTz))
          );

          const pass = dateTimesMatch && timeZonesMatch;
          const message = (pass ? 'Did not expect' : 'Expected') + ` '${actual}' to be an equivalent date to ${expected}`;

          return { pass, message };
        },
      }),
    });
  });

  // Get a random Date between the start and end Dates
  // https://gist.github.com/miguelmota/5b67e03845d840c949c4
  function randomDate(start: Date, end: Date): Date {
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
  }

  // e.g. splitAt('12345', 3) => ['123', '45']
  // https://stackoverflow.com/a/16441885/114359
  function splitAt(str: string, idx: number): [string, string] {
    return [str.substring(0, idx), str.substring(idx)];
  }
});
