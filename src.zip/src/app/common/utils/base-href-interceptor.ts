import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Location } from '@angular/common';

/**
 * Intercepts all calls from HttpClient and prepends the base_href to them.
 *
 * @see http://www.projectcodify.com/angular-set-base-url-dynamically
 */
@Injectable()
export class BaseHrefInterceptor implements HttpInterceptor {

  constructor(private location: Location) { }

  /**
   * Intercepts! Pulls the base href from the tag in the document head directly.
   *
   * @param {HttpRequest<any>} req
   * @param {HttpHandler} next
   * @returns {Observable<HttpEvent<any>>}
   * @memberof BaseHrefInterceptor
   */
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const baseUrl = document.getElementsByTagName('base')[0].href;
    // const apiReq = req.clone({ url: `${baseUrl}${req.url}` });
    const apiReq = req.clone({ url: this.location.prepareExternalUrl(req.url) });
    // console.log(`BASE URL: ${baseUrl}`);
    // console.log(`prepared: ${this.location.prepareExternalUrl(req.url)}`);
    // console.log(req);
    // console.log(apiReq);
    return next.handle(apiReq);
  }
}
