import { LocalDateConverter } from './local-date-converter';
import * as moment_ from 'moment';

describe('LocalDateConverter', () => {
  const moment = moment_;
  let converter: LocalDateConverter;

  beforeEach(() => {
    converter = new LocalDateConverter();
  });

  describe('::deserialize', () => {
    describe('happy path', () => {
      const someLocalDates = [
        { localDate: [2019, 1, 1], formattedDate: '2019/01/01' },
        { localDate: [2019, 1, 31], formattedDate: '2019/01/31' },
        { localDate: [2019, 2, 1], formattedDate: '2019/02/01' },
        { localDate: [2019, 12, 1], formattedDate: '2019/12/01' },
        { localDate: [2019, 12, 31], formattedDate: '2019/12/31' },
        { localDate: [2020, 2, 29], formattedDate: '2020/02/29' }, // leap year
      ];

      someLocalDates.forEach((entry) => {
        it(`should convert ${entry.localDate} to ${entry.formattedDate}`, () => {
          const actual = converter.deserialize(entry.localDate);
          const expected = moment(entry.formattedDate, 'YYYY/MM/DD').toDate();
          expect(actual).toEqual(expected);
        });
      });
    });

    it('should not blow up when passed null', () => {
      expect(converter.deserialize.bind(converter, null)).not.toThrow();
    });

    describe('incomplete dates', () => {
      const someLocalDates = [
        [2019, 1],
        [2019],
        [],
      ];
      someLocalDates.forEach((entry) => {
        it(`will blow up on incomplete date: ${entry}`, () => {
          expect(converter.deserialize.bind(converter, entry)).toThrow();
        });
      });
    });
  });

  describe('::serialize', () => {
    describe('happy path', () => {
      const someLocalDates = [
        { localDate: [2019, 1, 1], formattedDate: '2019/01/01' },
        { localDate: [2019, 1, 31], formattedDate: '2019/01/31' },
        { localDate: [2019, 2, 1], formattedDate: '2019/02/01' },
        { localDate: [2019, 12, 1], formattedDate: '2019/12/01' },
        { localDate: [2019, 12, 31], formattedDate: '2019/12/31' },
        { localDate: [2020, 2, 29], formattedDate: '2020/02/29' }, // leap year
      ];

      someLocalDates.forEach((entry) => {
        it(`should convert ${entry.formattedDate} to ${entry.localDate}`, () => {
          const actual = converter.serialize(moment(entry.formattedDate, 'YYYY/MM/DD').toDate());
          const expected = entry.localDate;
          expect(actual).toEqual(expected);
        });
      });
    });

    it('should not blow up when passed null', () => {
      expect(converter.serialize.bind(converter, null)).not.toThrow();
    });
  });

});
