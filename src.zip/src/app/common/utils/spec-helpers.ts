import * as moment from 'moment';

export class SpecHelpers {
  public static someRandomPhoneNumber(): string {
    let randomNumberString = Math.random().toString();
    const phoneNumberLength = 10;
    randomNumberString = randomNumberString.padEnd(phoneNumberLength + 2, '0');
    return randomNumberString.slice(2, phoneNumberLength + 2);
  }

  public static someRandomNumber(): number {
    return Math.floor(Math.random() * Number.MAX_SAFE_INTEGER) + 1;
  }

  /**
   * This example returns a random integer between the specified values.
   * The value is no lower than min (or the next integer greater than min if min isn't an integer), and is less than (but not equal to) max.
   * from https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/random
   * @param min
   * @param max
   */
  public static someRandomInt(min, max): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min; // The maximum is exclusive and the minimum is inclusive
  }

  public static someRandomElementFrom<T>(arr: Array<T>): T {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  public static someRandomDate(): Date {
    const start = new Date(1970, 1, 1);
    const end = new Date();
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
  }

  public static someRandomStartOfDayDate(): Date {
    let startOfDayDate: Date;
    const randomDate = SpecHelpers.someRandomDate();
    startOfDayDate = moment(randomDate).startOf('day').toDate();
    return startOfDayDate;
  }

  /**
   * Retrieve a property given a property path and root object it should be applied to.
   * Returns undefined if property is not found.
   * @param root object that is the root of objects to be examined.
   * @param path '.' delimited path to property to be retrieved.
   */
  public static getPropertyFromPath(root: any, path: string): any | undefined {
    const pathComponents = path.split('.');
    let object = root;
    pathComponents.map(objectName => {
      if (object !== undefined) {
        object = object[objectName];
      }
    });
    return object;
  }
}
