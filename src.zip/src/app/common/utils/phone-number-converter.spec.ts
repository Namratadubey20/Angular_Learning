import { PhoneNumberConverter } from './phone-number-converter';
import { generate, Observable } from 'rxjs';
import { bufferCount, map, take } from 'rxjs/operators';

describe('PhoneNumberConverter', () => {
  let pnc: PhoneNumberConverter;

  beforeEach(() => {
    pnc = new PhoneNumberConverter();
  });

  const someNumbers = {
    '0123456789': '012-345-6789',
    '0987654321': '098-765-4321',
    '5555555555': '555-555-5555',
    '2155551212': '215-555-1212',
  };

  describe('::deserialize', () => {
    describe('happy path', () => {
      Object.entries(someNumbers).forEach(([k, v]: [string, string]) => {
        it(`should convert ${k} to ${v}`, () => {
          expect(pnc.deserialize(k)).toEqual(v);
        });
      });
    });
    describe('should only transform completely numeric strings', () => {
      const stringsWithNoDashesInThem = [
        '(123)5551212',
        'ABCDEFGHIJKL',
        'NOTAPHONE###',
        'HAHA1234HAHA',
      ];
      stringsWithNoDashesInThem.forEach(s => {
        it(`should return exactly what was passed in when its value is ${s}`, () => {
          expect(pnc.deserialize(s)).toEqual(s);
        });
      });
    });
    it('should not blow up when passed null', () => {
      expect(pnc.deserialize.bind(pnc, null)).not.toThrow();
    });
  });

  describe('::serialize', () => {
    describe('happy path', () => {
      Object.entries(someNumbers).forEach(([k, v]: [string, string]) => {
        it(`should convert ${v} to ${k}`, () => {
          expect(pnc.serialize(v)).toEqual(k);
        });
      });
    });
    describe('knows about parentheses', () => {
      const withParens = {
        '(012)-345-6789': '0123456789',
        '(098)-765-4321': '0987654321',
        '(555)-555-5555': '5555555555',
        '(215)-555-1212': '2155551212',
      };

      Object.entries(withParens).forEach(([k, v]: [string, string]) => {
        it(`should convert ${k} to ${v}`, () => {
          expect(pnc.serialize(k)).toEqual(v);
        });
      });
    });
    it('should not blow up when passed null', () => {
      expect(pnc.serialize.bind(pnc, null)).not.toThrow();
    });
  });

  const randomDigit = () => Math.floor(Math.random() * 10);
  const randomDigits = generate({ initialState: randomDigit(), iterate: randomDigit });

  const randomPhoneNumbers: Observable<string> = randomDigits.pipe(
    bufferCount(10),
    map(s => s.join(''))
  );

  randomPhoneNumbers.pipe(take(10)).subscribe(number => {
    it(`should round-trip [de]serialize from ${number} and back`, () => {
      const formatted = pnc.deserialize(number);
      const serialized = pnc.serialize(formatted);
      expect(serialized).toEqual(number);
    });
  });
});
