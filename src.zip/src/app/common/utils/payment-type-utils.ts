import { paymentTypes } from './constants';

interface PaymentType {
  pretty: string | null;
  code: string | null;
  type: string | null;
}

export class PaymentTypeUtils {
  static getCodeFromPrettyName(prettyName: string): string | null {
    return PaymentTypeUtils.find(pt => pt.pretty === prettyName).code;
  }

  static getPrettyNameFromCode(code: string): string | null {
    return PaymentTypeUtils.find(pt => pt.code === code).pretty;
  }

  static getTypeFromFromCode(code: string): string | null {
    return PaymentTypeUtils.find(pt => pt.code === code).type;
  }

  private static find(predicate: (PaymentType) => boolean): PaymentType {
    return (paymentTypes.find(predicate) || { pretty: null, code: null, type: null });
  }
}
