import { JsonConverter, JsonCustomConvert } from 'json2typescript';

@JsonConverter
export class PhoneNumberConverter implements JsonCustomConvert<string> {
  deserialize(data: string): string {
    return data && data.replace(/(\d{3})(\d{3})(\d{4})/g, '$1-$2-$3');
  }

  serialize(data: string): string {
    return data && data.replace(/[^\d]/g, '');
  }
}
