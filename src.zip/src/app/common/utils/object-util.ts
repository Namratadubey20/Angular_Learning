

export class ObjectUtil {
  static isEmpty(obj: any): boolean {
    if (obj != null) {
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          return false;
        }
      }
    }
    return true;
  }
}
