import { JsonConverter, JsonCustomConvert } from 'json2typescript';
import * as moment_ from 'moment';

/**
 * Converts jackson LocalDateDeserializer/LocalDateDeserializer JSON to and from JS Date.
 * Sample JSON (july 12, 2019): "someDate": [2019, 7, 12]
 */
@JsonConverter
export class LocalDateConverter implements JsonCustomConvert<Date> {
  moment = moment_;

  serialize(date: Date): any {
    if (date) {
      const localDate = this.moment(date).toArray().slice(0, 3);
      localDate[1]++; // Convert from 0-based month to 1-based month.
      return localDate;
    }
    return null;
  }

  deserialize(localDate: number[]): Date {
    if (localDate) {
      if (localDate.length < 3) {
        throw new Error(`Expected [YYYY, MM, DD].`);
      }
      // Convert from 1-based month to 0-based month.
      return this.moment(Array.of(localDate[0], (localDate[1] - 1), localDate[2])).toDate();
    }
    return null;
  }
}
