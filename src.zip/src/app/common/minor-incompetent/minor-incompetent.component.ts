import { Component, Input, OnDestroy, OnInit, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ConditionalValidator } from '../validators/conditional-validator';
import { Subscription } from 'rxjs';
import { DateValidators } from '../validators/date-validators';

import * as moment from 'moment';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/common/utils/custom-date-formatter';
@Component({
  selector: 'app-minor-incompetent',
  templateUrl: './minor-incompetent.component.html',
  styleUrls: ['./minor-incompetent.component.css'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})

export class MinorIncompetentComponent implements OnInit, OnDestroy, AfterViewChecked {

  @Input()
  inTheMatterOf: string;

  @Input()
  minorIncompetentFormGroup: FormGroup;

  @Input()
  isSteward: boolean;

  valueChangeSubscription: Subscription;
  today: Date = new Date();

  birthdayValidators = [ConditionalValidator.conditionalRequire(() => this.minor.value === true && !this.isSteward),
  DateValidators.onOrBeforeToday(), DateValidators.datePatternValidator()];

  dateDeclaredIncompetentValidators = [ConditionalValidator.conditionalRequire(() => this.minor.value === false && !this.isSteward)
    , DateValidators.onOrBeforeToday(), DateValidators.datePatternValidator()];

  constructor(private changeDetector: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    this.birthday.setValidators([ConditionalValidator.conditionalRequire(() => this.minor.value === true && !this.isSteward),
    DateValidators.onOrBeforeToday(), DateValidators.datePatternValidator()]);
    this.dateDeclaredIncompetent.setValidators(
      [ConditionalValidator.conditionalRequire(() => this.minor.value === false && !this.isSteward), DateValidators.onOrBeforeToday()
        , DateValidators.datePatternValidator()]);
    this.valueChangeSubscription = this.minor.valueChanges.subscribe(() => {
      this.birthday.updateValueAndValidity();
      this.dateDeclaredIncompetent.updateValueAndValidity();
    });
  }


  ngAfterViewChecked() {
  }

  ngOnDestroy(): void {
    this.birthday.clearValidators();
    this.birthday.updateValueAndValidity();
    this.dateDeclaredIncompetent.clearValidators();
    this.dateDeclaredIncompetent.updateValueAndValidity();
    this.valueChangeSubscription.unsubscribe();
  }

  getErrorMessage(pickerInput: string, formValue: string): string {
    if (!pickerInput || pickerInput === '') {
      return formValue === 'birthday' ? 'Date of Birth is required.' : 'Date Declared Incompetent is required.';
    }
    return this.isMyDateFormat(pickerInput, formValue);
  }

  isMyDateFormat(date: string, formValue: string): string {
    if (date.length !== 10) {
      return 'Date has an invalid format';
    } else {
      const da = date.split('/');

      if (da.length !== 3 || da[0].length !== 2 || da[1].length !== 2 || da[2].length !== 4) {
        return 'Date has an invalid format';
      } else if (new Date(date) > new Date()) {
        return 'Date must be on or before today';
      } else if (!moment(date, 'MM/DD/YYYY', true).isValid()) {
        return 'Please input a valid date.';
      } else {
        const year = this.today.getFullYear();
        if (new Date(date).getFullYear() < year - 100) {
          return 'Please enter a valid date.';
        }
        if (formValue === 'birthday') {
          this.birthday.setValue(new Date(date));
          this.birthday.setErrors({ 'valid': true });
          this.birthday.updateValueAndValidity();
        } else {
          this.dateDeclaredIncompetent.setValue(new Date(date));
          this.dateDeclaredIncompetent.setErrors({ 'valid': true });
          this.dateDeclaredIncompetent.updateValueAndValidity();
        }
        this.changeDetector.detectChanges();
        return;
      }
    }
  }
  get minor(): FormControl {
    return this.minorIncompetentFormGroup.get('minor') as FormControl;
  }

  get birthday(): FormControl {
    return this.minorIncompetentFormGroup.get('birthday') as FormControl;
  }

  get dateDeclaredIncompetent(): FormControl {
    return this.minorIncompetentFormGroup.get('dateDeclaredIncompetent') as FormControl;
  }

  get minorName(): FormControl {
    return this.minorIncompetentFormGroup.get('minorName') as FormControl;
  }

  get relationshipToMinor(): FormControl {
    return this.minorIncompetentFormGroup.get('relationshipToMinor') as FormControl;
  }

  // get residence(): FormControl {
  //   return this.minorIncompetentFormGroup.get('residence') as FormControl;
  // }

  // get health(): FormControl {
  //   return this.minorIncompetentFormGroup.get('health') as FormControl;
  // }


  get minorNamePlaceholder(): string {
    let placeholder = '';
    if (this.minor.value === true) {
      placeholder = 'Name of Minor';
    } else if (this.minor.value === false) {
      placeholder = 'Name of Person';
    } else {
      placeholder = 'Name';
    }
    return placeholder;
  }

  get relationshipToMinorPlaceholder(): string {
    let placeholder = '';
    if (this.minor.value === true) {
      placeholder = 'Relationship to Minor';
    } else if (this.minor.value === false) {
      placeholder = 'Relationship to Person';
    } else {
      placeholder = 'Relationship';
    }
    return placeholder;
  }


}
