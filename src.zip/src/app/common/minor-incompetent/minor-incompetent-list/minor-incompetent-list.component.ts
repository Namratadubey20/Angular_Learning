import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { CommonUtilities } from '../../utils/common-utilities';

@Component({
  selector: 'app-minor-incompetent-list',
  templateUrl: './minor-incompetent-list.component.html',
  styleUrls: ['./minor-incompetent-list.component.css'],
})
export class MinorIncompetentListComponent implements OnInit {

  @Input()
  minorIncompetentFormArray: FormArray;

  @Input()
  minorIncompetentEmptyFormGroup: FormGroup;

  @Input()
  atLeastOneRequired: boolean;

  @Input()
  inTheMatterOf: string;

  @Input()
  isSteward: boolean;

  @Input()
  disableButton: boolean;

  constructor() {
  }

  ngOnInit() {
    if (this.atLeastOneRequired && this.minorIncompetentFormArray.length < 1) {
      this.addEmptyMinorIncompetentFormGroup();
    }
  }

  addEmptyMinorIncompetentFormGroup() {
    // minorIncompetentEmptyFormGroup may already have been allocated so we clone it just to be safe.
    const emptyFormGroup = CommonUtilities.cloneAbstractControl(this.minorIncompetentEmptyFormGroup);
    this.minorIncompetentFormArray.push(emptyFormGroup);
  }

  removeMinorIncompetentFormGroup(index: number) {
    this.minorIncompetentFormArray.removeAt(index);
  }

  disableTrash() {
    return this.atLeastOneRequired ? this.minorIncompetentFormArray.length === 1 : false;
  }

}
