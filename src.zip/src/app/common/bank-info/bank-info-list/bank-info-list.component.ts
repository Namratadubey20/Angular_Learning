import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { CommonUtilities } from '../../utils/common-utilities';

@Component({
  selector: 'app-bank-info-list',
  templateUrl: './bank-info-list.component.html',
  styleUrls: ['./bank-info-list.component.css'],
})
export class BankInfoListComponent implements OnInit {

  @Input()
  banksFormArray: FormArray;

  @Input()
  bankEmptyFormGroup: FormGroup;

  @Input()
  atLeastOneRequired: boolean;

  @Input()
  disableButton: boolean;

  constructor() {
  }

  ngOnInit(): void {
    if (this.atLeastOneRequired && this.banksFormArray.length < 1) {
      this.addEmptyBankFormGroup();
    }
  }

  addEmptyBankFormGroup() {
    // serviceProviderEmptyFormGroup may already have been allocated so we clone it just to be safe.
    const emptyFormGroup = CommonUtilities.cloneAbstractControl(this.bankEmptyFormGroup);
    this.banksFormArray.push(emptyFormGroup);
  }

  removeBankFormGroup(index: number) {
    this.banksFormArray.removeAt(index);
  }

  disableTrash() {
    return this.atLeastOneRequired ? this.banksFormArray.length === 1 : false;
  }
}
