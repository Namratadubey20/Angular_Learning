import { Component, Input, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { states } from '../utils/constants';

import { fromEvent } from 'rxjs';
import { map, filter, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { USPSService } from './usps.service';
import { USPS } from './usps';

import * as _ from 'lodash';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css'],
  providers: [USPSService],
})
export class AddressComponent implements OnInit {
  private static readonly debounceTime = 100;

  @Input() addressFormGroup: FormGroup;
  @Input() prefix: string;
  @Input() header: string;
  @Input() validate: boolean;
  @Input() disabledInput: boolean;

  @ViewChild('zipCodeRef') zipCodeRef: ElementRef;

  states = states;

  // filteredStates: any;

  constructor(public fb: FormBuilder,
    private uspsService: USPSService) {
  }

  /*
   * Create a descriptive label using a prefix if passed by caller.
   * @param label Text of label, will have prefix and space added if present.
   * @returns {string}
   */
  withPrefix(label: string): string {
    if ((this.prefix !== undefined) && (this.prefix.length > 0)) {
      return this.prefix + ' ' + label;
    }
    return label;
  }

  ngOnInit(): void {
    this.setupZipCodeLookup();
    if (this.disabledInput) {
      this.disabledInput = this.disabledInput;
    } else {
      this.disabledInput = false;
    }
  }


  /**
   * Populate Payment fields with AddressValues.
   */
  populateAddress(addressValues) {
    if (addressValues) {
      this.addressFormGroup.patchValue(addressValues);
    }
  }

  clearAddress() {
    this.addressFormGroup.reset({}, { onlySelf: true });
  }

  /*
   * Sets up the event handler->service wiring for the zip to city, state
   * lookups.
   *
   * This *cannot* use formGroup.get().valueChanges() as that gets events
   * from programmatic alterations as well as UI changes, and there's no way
   * to distinguish between them. Thank the ng API group.
   *
   * @private
   * @memberof AddressComponent
   */
  private setupZipCodeLookup(): void {

    /*
     * Record input events. Get the value of the target input box. filter it
     * for length 5 debounce, prevent jitter switchMap to cancel previous
     * calls, if present
     *
     * If there's an error in the service and it's a ZipNotFound, do the
     * right thing. Otherwise barf up a toast.
     *
     * This is actually needed as opposed to a imperative event handler such
     * as (change) because we could potentially receive out of order replies
     * and flood the endpoint without debounce and distinct. Besides, this
     * is a good pattern to learn.
     */
    fromEvent(this.zipCodeRef.nativeElement, 'input')
      .pipe(
        map((e: KeyboardEvent) => (<HTMLInputElement>e.target).value),
        filter((text) => text.length === 5),
        debounceTime(AddressComponent.debounceTime),
        distinctUntilChanged(),
        switchMap((zip) => this.uspsService.zip2CityStateSearch(zip)))
      .subscribe((zipReply: USPS.Zip) => {
        if (zipReply.city !== null) {
          this.city.setValue(_.startCase(_.toLower(zipReply.city)));
          this.city.markAsTouched();
          this.city.markAsDirty();
        }
        if (zipReply.state !== null) {
          this.state.setValue(zipReply.state);
          this.state.markAsTouched();
          this.state.markAsDirty();
        }
        this.zipCode.setValue(zipReply.zip);
      });

  }

  trackByStateAbbrev(index: number, stateAbbreviation: string): string {
    return stateAbbreviation;
  }

  get street1(): FormControl {
    return this.addressFormGroup.get('street1') as FormControl;
  }

  get street2(): FormControl {
    return this.addressFormGroup.get('street2') as FormControl;
  }

  get city(): FormControl {
    return this.addressFormGroup.get('city') as FormControl;
  }

  get state(): FormControl {
    return this.addressFormGroup.get('state') as FormControl;
  }

  get zipCode(): FormControl {
    return this.addressFormGroup.get('zipCode') as FormControl;
  }

}
