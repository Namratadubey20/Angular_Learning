import { AddressMapper } from './address-mapper';
import { AddressImpl } from '../../enrollment/application/court/model/common/address';

describe('AddressMapper.populateAddress', () => {
  it('should set fields to null when addressRawValues is null ', () => {
    const address = new AddressImpl();
    {
      address.street1 = 'abc';
      address.street2 = 'def';
      address.zipCode = 'hij';
      address.city = 'XYZ';
      address.state = 'ABC';
    }

    const expectedModelProperties = [
      'street1',
      'street2',
      'zipCode',
      'city',
      'state',
    ];

    expectedModelProperties.forEach(ep => {
      expect(address.hasOwnProperty(ep))
        .withContext(`property: ${ep}`)
        .toBeTruthy(`instance is missing property: ${ep}`);
    });

    // const addressRawValues: any = null;
    AddressMapper.populateAddress(address, null);

    expectedModelProperties.forEach(ep => {
      expect(address[ep])
        .withContext(`property: ${ep}`)
        .toBeNull(`non-null property: ${ep}`);
    });
  });
});

describe('AddressMapper.createAddressFormGroupPatchValues', () => {
  it('should create a matching patchValues object', () => {
    const address = new AddressImpl();
    {
      address.street1 = 'abc';
      address.street2 = 'def';
      address.zipCode = 'hij';
      address.city = 'XYZ';
      address.state = 'ABC';
    }
    const mappings = [
      { model: 'street1', patch: 'street1' },
      { model: 'street1', patch: 'street1' },
      { model: 'street2', patch: 'street2' },
      { model: 'zipCode', patch: 'zipCode' },
      { model: 'city', patch: 'city' },
      { model: 'state', patch: 'state' },
    ];

    const patchValues = AddressMapper.createAddressFormGroupPatchValues(address);

    mappings.forEach(mapping => {
      expect(patchValues[mapping.patch])
        .withContext(`mapping model property [${mapping.model}]`
          + ` to patchValues property [${mapping.patch}]`)
        .toBe(address[mapping.model]
          , `patchValue [${mapping.patch}]:${patchValues[mapping.patch]}`
          + ` not equal to model property [${mapping.model}]:${address[mapping.model]}`);
    });
  });
});

