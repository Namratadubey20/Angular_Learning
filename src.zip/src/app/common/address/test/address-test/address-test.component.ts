import { Component, OnInit } from '@angular/core';
import { AddressImpl } from '../../address';
import { FormBuilder, FormGroup, PatternValidator, Validators } from '@angular/forms';
import { PatternValidators } from '../../../validators/pattern-validators';

@Component({
  selector: 'app-address-test',
  templateUrl: './address-test.component.html',
  styleUrls: ['./address-test.component.css'],
})
export class AddressTestComponent implements OnInit {
  noPrefixAddressFormGroup: FormGroup;
  prefixAddressFormGroup: FormGroup;
  disabledAddressFormGroup: FormGroup;
  noValidationAddressFormGroup: FormGroup;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit() {
    this.noPrefixAddressFormGroup = this.fb.group({
      street1: [null, [Validators.required, Validators.maxLength(60)]],
      street2: [null, Validators.maxLength(60)],
      city: [null, [Validators.required, Validators.maxLength(30)]],
      state: [null, [Validators.required]],
      zipCode: [null, PatternValidators.zipCode],
    });

    this.prefixAddressFormGroup = this.fb.group({
      street1: [null, [Validators.required, Validators.maxLength(60)]],
      street2: [null, Validators.maxLength(60)],
      city: [null, [Validators.required, Validators.maxLength(30)]],
      state: [null, [Validators.required]],
      zipCode: [null, PatternValidators.zipCode],
    });

    this.disabledAddressFormGroup = this.fb.group({
      street1: [{ value: '123 Street st', disabled: true }, [Validators.required, Validators.maxLength(60)]],
      street2: [{ value: 'Apt 111', disabled: true }, Validators.maxLength(60)],
      city: [{ value: 'Pittsburgh', disabled: true }, [Validators.required, Validators.maxLength(30)]],
      state: [{ value: 'PA', disabled: true }, [Validators.required]],
      zipCode: [{ value: '15203', disabled: true }, PatternValidators.zipCode],
    });

    this.noValidationAddressFormGroup = this.fb.group({
      street1: [null, [Validators.maxLength(60)]],
      street2: [null, Validators.maxLength(60)],
      city: [null, [Validators.maxLength(30)]],
      state: [null, [Validators.required]],
      zipCode: [null, PatternValidators.zipCode],
    });
  }

  printFormValues() {
  }
}
