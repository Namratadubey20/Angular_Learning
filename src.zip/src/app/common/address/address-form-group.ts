import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { PatternValidators } from '../validators/pattern-validators';
import { ConditionalRequireFormControl } from '../../control/form-control/conditional-require-form-control';
import { AddressImpl, AddressModel } from './address';

export class AddressFormGroup extends FormGroup {
  constructor(requiredCondition?: () => boolean, disableInput: Boolean = false) {
    const controls: { [p: string]: AbstractControl } = {
      street1: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, requiredCondition, Validators.maxLength(60)),
      street2: new FormControl({ value: null, disabled: disableInput }, Validators.maxLength(60)),
      city: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, requiredCondition, Validators.maxLength(30)),
      state: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, requiredCondition),
      zipCode: new ConditionalRequireFormControl({ value: null, disabled: disableInput }, requiredCondition, PatternValidators.zipCode()),
    };
    super(controls);
  }

  patchValue(value): void {
    if (value) {
      super.patchValue({
        street1: value.street1,
        street2: value.street2,
        city: value.city,
        state: value.state,
        zipCode: value.zipCode,
      });
    }
  }


  getRawValue(): AddressModel {
    const addr: AddressImpl = new AddressImpl();
    addr.street1 = this.street1.value;
    addr.street2 = this.street2.value;
    addr.city = this.city.value;
    addr.state = this.state.value;
    addr.zipCode = this.zipCode.value;
    return addr;
  }

  get street1(): FormControl {
    return this.get('street1') as FormControl;
  }

  get street2(): FormControl {
    return this.get('street2') as FormControl;
  }

  get city(): FormControl {
    return this.get('city') as FormControl;
  }

  get state(): FormControl {
    return this.get('state') as FormControl;
  }

  get zipCode(): FormControl {
    return this.get('zipCode') as FormControl;
  }
}
