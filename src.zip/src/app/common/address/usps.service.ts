// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

// import { ServiceHandler } from './service-handler.service';
import { USPS } from './usps';
// import { JsonConvert, ValueCheckingMode } from 'json2typescript';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

// oh jesus fucking christ
// https://github.com/Microsoft/TypeScript/issues/13965
export class ZipNotFoundError extends Error {
  __proto__: Error;
  constructor(message?: string) {
    const trueProto = new.target.prototype;
    super(message);

    // Alternatively use Object.setPrototypeOf if you have an ES6 environment.
    this.__proto__ = trueProto;
  }
}

/*
 * Service holder for /api/util/usps.
 *
 * Services:
 * * zip2CityState: USPS CityStateLookupRequest, /api/util/usps/zip
 * * more to come as needed.
 *
 * @export
 * @class USPSService
 */
@Injectable()
export class USPSService {

  /*
   * end URI for USPS service root
   *
   * @private
   * @memberof USPSService
   */
  private requestURL = 'api/util/usps';

  /*
   * Standard HTTP options for HttpClient
   *
   * @private
   * @type {*}
   * @memberof USPSService
   */
  private httpOptions: any = {
    headers: { 'Content-Type': 'application/json' },
    observe: 'body',
    responseType: 'json',
  };

  /*
   * Creates an instance of USPSService.
   *
   * @param {HttpClient} http
   * @param {ServiceHandler} serviceHandler
   * @memberof USPSService
   */
  constructor(private http: HttpClient) { } // private serviceHandler: ServiceHandler) { }

  /*
   * Looks up a city and state from a zip. Also gets the zip in the process
   * (bonus zip!)
   *
   * @param {string} zip
   * @returns {Observable<USPS.Zip>}
   * @memberof USPSService
   */
  public zip2CityStateSearch(zip: string): Observable<USPS.Zip> {
    return this.http
      .get<USPS.Zip>(`${this.requestURL}/zip/${zip}`, {
        headers: { 'Content-Type': 'application/json' },
        observe: 'body',
        responseType: 'json',
      })
      .pipe(
        catchError(() => {
          // On error, generate a JSON response that provides the original zip code but indicates that the other fields are not provided.
          const jsonResponse = { zip: zip, city: null, state: null };
          return of(jsonResponse);
        })
      )
      // Map the server's JSON response to the client's Zip class.
      .map((json: any) => USPS.Zip.fromJSON(json));
  }
}
