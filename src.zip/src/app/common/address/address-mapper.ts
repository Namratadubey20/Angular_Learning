import { Address } from '../../enrollment/application/court/model/common/address';

export class AddressMapper {
  /**
   * Populate an Address instance from an address FormGroup's rawValues.
   * @param address instance to be populated from 'rawValues'.
   * @param addressRawValues 'rawValues' to populate instance.
   */
  static populateAddress(address: Address, addressRawValues: any | null): Address {
    address.street1 = addressRawValues ? addressRawValues.street1 : null;
    address.street2 = addressRawValues ? addressRawValues.street2 : null;
    address.zipCode = addressRawValues ? addressRawValues.zipCode : null;
    address.city = addressRawValues ? addressRawValues.city : null;
    address.state = addressRawValues ? addressRawValues.state : null;
    return address;
  }

  /**
   * Create an object of values to be 'patched' into an Address FormGroup.
   * @param address source of values to be patched.
   */
  static createAddressFormGroupPatchValues(address: Address | null): any {
    const patchValues = {
      street1: address ? address.street1 : null,
      street2: address ? address.street2 : null,
      zipCode: address ? address.zipCode : null,
      city: address ? address.city : null,
      state: address ? address.state : null,
    };
    return patchValues;
  }
}
