import { JsonObject, JsonProperty } from 'json2typescript';

/*
 * USPS namespace to hold all service classes related to /api/util/usps.
 *
 * Currently only implemented with 'zip'.
 *
 * @namespace
 * @see USPSService
 */
export namespace USPS {

  /*
   * POJO encapsulating the return from the USPS zip endpoint.
   *
   * @export
   * @class Zip
   */
  @JsonObject('Zip')
  export class Zip {
    @JsonProperty('city', Number, true)
    city: string = null;

    @JsonProperty('state', Number, true)
    state: string = null;

    @JsonProperty('zip', String, true)
    zip: string = null;

    public static fromJSON(json: any): Zip {
      const foo = new Zip();

      foo.city = json.city;
      foo.state = json.state;
      foo.zip = json.zip;

      return foo;
    }
  }
}

