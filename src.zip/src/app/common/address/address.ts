import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableProfile } from '../auditable-object';

export interface AddressModel {
  street1: string;
  street2?: string;
  city: string;
  state: string;
  zipCode: string;
  countyName?: string;
}

@JsonObject('AddressImpl')
export class AddressImpl extends AuditableProfile implements AddressModel {
  @JsonProperty('street1', String, true)
  street1: string = null;

  @JsonProperty('street2', String, true)
  street2: string = null;

  @JsonProperty('city', String, true)
  city: string = null;

  @JsonProperty('state', String, true)
  state: string = null;

  @JsonProperty('zipCode', String, true)
  zipCode: string = null;

  @JsonProperty('countyName', String, true)
  countyName: string = null;
}
