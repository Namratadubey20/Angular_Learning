import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ApplicationImpl } from 'src/app/enrollment/application/application';

@Component({
  selector: 'app-terms-and-conditions',
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions.component.css'],
})
export class TermsAndConditionsComponent {

  @Input()
  termsAndConditionsFormGroup: FormGroup;

  @Input()
  termsContentName: string;

  @Input()
  bondType: string;

  @Input()
  fraudWarning: string;

  @Input()
  isCompany: boolean;

  @Input()
  application: ApplicationImpl;

  get declareTrue(): FormControl {
    return this.termsAndConditionsFormGroup.get('declareTrue') as FormControl;
  }

  get readAndAgreeToTerms(): FormControl {
    return this.termsAndConditionsFormGroup.get('readAndAgreeToTerms') as FormControl;
  }

  get premiumAcknowledged(): FormControl {
    return this.termsAndConditionsFormGroup.get('premiumAcknowledged') as FormControl;
  }

  get fraudWarningUnescaped(): string {
    return `<strong>Fraud warning:</strong> ${this.fraudWarning}`;
  }

}
