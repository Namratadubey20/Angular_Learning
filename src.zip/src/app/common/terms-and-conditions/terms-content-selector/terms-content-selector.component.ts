import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-terms-content-selector',
  templateUrl: './terms-content-selector.component.html',
  styleUrls: ['./terms-content-selector.component.css'],
})
export class TermsContentSelectorComponent {

  @Input()
  termsContentName: string;

  @Input()
  bondType: string;

  constructor() { }

}
