import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-court-terms-content',
  templateUrl: './court-terms-content.component.html',
  styleUrls: ['./court-terms-content.component.css'],
})
export class CourtTermsContentComponent {

  @Input()
  bondType: string;

  constructor() {
  }

}
