import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-terms-signature',
  templateUrl: './terms-signature.component.html',
  styleUrls: ['./terms-signature.component.css'],
})
export class TermsSignatureComponent {

  @Input()
  termsSignatureFormGroup: FormGroup;

  @Input()
  isCompany: boolean;

  constructor() {
  }

  emailLabel = 'Email Signature';

  nameLabel = 'Signature Name';

  get agreementDate(): FormControl {
    return this.termsSignatureFormGroup.get('agreementDate') as FormControl;
  }

  get nameAndEmailFormGroup(): FormGroup {
    return this.termsSignatureFormGroup.get('termsSignatures') as FormGroup;
  }

  get emailSignature(): FormControl {
    return this.nameAndEmailFormGroup.get('emailSignature') as FormControl;
  }

  get signatureName(): FormControl {
    return this.nameAndEmailFormGroup.get('signatureName') as FormControl;
  }

  get indemnitor(): FormControl {
    return this.termsSignatureFormGroup.get('indemnitor') as FormControl;
  }

  get indemnitorOfficePerson(): FormControl | null {
    return this.termsSignatureFormGroup.get('indemnitorOfficePerson') as FormControl;
  }

  get indemnitorOfficePersonTitle(): FormControl | null {
    return this.termsSignatureFormGroup.get('indemnitorOfficePersonTitle') as FormControl;
  }

  get formattedAgreementDate(): string {
    return;
  }

}
