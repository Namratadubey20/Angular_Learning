import { UtilService } from './utils/util.service';
import { PersonSummaryImpl } from './person-summary';

describe('TypeScriptPersonDomain', () => {
  let incomingJSONString: string;
  let data: any;
  let person: any;

  beforeEach(() => {
    incomingJSONString = `{
      "person":{
      "id":89096,
      "createdBy":"skychap",
      "createdAt":"2018-08-30T20:23:47.275+0000",
      "updatedBy":"skychap","updatedAt":"2018-08-30T20:23:47.275+0000",
      "clientContactsId":null,
      "firstName":"f",
      "lastName":"f",
      "salutation":"Mr.",
      "suffix":null,
      "email":"f@f",
      "phone":"123-123-1234",
      "fax":null,
      "creditScore":null,
      "creditScoreDate":null,
      "ssno":null,
      "deactivated":false,
      "agentId":214,
      "lastPurchasedBondId":null,
      "personAddresses":[
        {"id":5488,"createdBy":"skychap","createdAt":"2018-08-30T20:23:47.355+0000","updatedBy":"skychap",
          "updatedAt":"2018-08-30T20:23:47.355+0000","address":"f","address2":null,"city":"f","state":"CA",
          "zip":"12345","fromDate":null,"toDate":null}
      ],
      "companyOfficePersons":[]},"companyOffice":null}`;
    data = JSON.parse(incomingJSONString);
    person = data.person;
  });

  it('should convert a json object to ClientPerson', (done) => {
    expect(person.personAddresses.length).toBe(1);
    try {
      const parsedObject = UtilService.getJsonConvert().deserialize(data, PersonSummaryImpl);
      expect(parsedObject).toBeDefined('Object is not defined');
      done();
    } catch (e) {
      done.fail(e);
    }
  });
  it('should be something', () => {
    expect(1).toBe(1);
  });
});
