import * as moment from 'moment';

export interface Profile {
  fromDate: Date;
  toDate: Date;

  isOverlap(profile: Profile): boolean;

}

export class Profiles {

  static isOverlap(profile1: Profile, profile2: Profile): boolean {
    const fromDate1 = moment(profile1.fromDate ? profile1.fromDate : Profiles.minDate());
    const toDate1 = moment(profile1.toDate ? profile1.toDate : Profiles.maxDate());
    const fromDate2 = moment(profile2.fromDate ? profile2.fromDate : Profiles.minDate());
    const toDate2 = moment(profile2.toDate ? profile2.toDate : Profiles.maxDate());

    return fromDate1.isBetween(fromDate2, toDate2, 'days', '[]') ||
      fromDate2.isBetween(fromDate1, toDate1, 'days', '[]');
  }

  static getProfileAsOfDate<T extends Profile>(profiles: T[], date: Date): T {
    for (let i = 0; i < profiles.length; i++) {
      if (moment(date).isBetween(
        profiles[i].fromDate ? moment(profiles[i].fromDate) : Profiles.minDate(),
        profiles[i].toDate ? moment(profiles[i].toDate) : Profiles.maxDate(),
        'days', '[]')) {

        return profiles[i];
      }
    }
    return null;
  }

  static getCurrentProfile<T extends Profile>(profiles: T[]): T {
    return Profiles.getProfileAsOfDate(profiles, new Date());
  }

  static minDate(): Date {
    return moment('1900-01-01').toDate();
  }

  static maxDate(): Date {
    return moment('9999-12-31').toDate();
  }
}
