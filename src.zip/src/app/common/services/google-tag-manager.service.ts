import { Injectable } from '@angular/core';

@Injectable()
export class GoogleTagManagerService {

  public sendEvent(eventName: string, eventCategory: string, eventValue: string, userType: string, lpGroup?: string, lpBond?: string,
    quoteId?: string, bondClass?: string, applicationId?: string, paymentType?: string, status?: string) {
    (<any>window).dataLayer.push({
      'event': eventName,
      'bondType': eventCategory || '',
      'premium': eventValue || '',
      'userType': userType || '',
      'lpGroup': lpGroup || '',
      'lpBond': lpBond || '',
      'quoteId': quoteId || '',
      'bondClass': bondClass || '',
      'applicationId': applicationId || '',
      'paymentType': paymentType || '',
      'status': status || '',
    });
  }

  public sendInsuranceEvent(eventName: string, eventCategory: string, userType: string, insuranceClass?: string,
    applicationID?: string, insurancePremium?: string, insurancePremiumType?: string, paymentType?: string, status?: string) {
    (<any>window).dataLayer.push({
      'event': eventName,
      'insuranceType': eventCategory || '',
      'userType': userType || '',
      'insuranceClass': insuranceClass || '',
      'applicationID': applicationID || '',
      'insurancePremium': insurancePremium || '',
      'insurancePremiumType': insurancePremiumType || '',
      'paymentType': paymentType || '',
      'status': status || '',
    });
  }
}
