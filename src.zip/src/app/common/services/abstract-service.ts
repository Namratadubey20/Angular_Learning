export abstract class AbstractService {
  private baseURL = '/api';

  requestURL(path: string): string {
    return `${this.baseURL}${path}`;
  }
}
