import { Injectable } from '@angular/core';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';

type UserPredicate = (u: UserImpl) => boolean;

@Injectable()
export class ApplicationRoleService {
  private readonly employeeRolePredicates: UserPredicate[];

  constructor(private securityService: SecurityService) {
    // I could have specified opaque role name strings instead of UserImpl methods to call,
    // but I wanted to enlist TypeScript's help in keeping this list up to date.
    // If any of these UserImpl methods change or go away on that class,
    // TypeScript will force us to deal with the change here as well.
    this.employeeRolePredicates = [
      u => u.hasSuperuserRole,
      u => u.hasAdminRole,
      u => u.hasSuperEmployeeRole,
      u => u.hasEmployeePlusRole,
      u => u.hasEmployeeDefaultRole,
    ];
  }

  hasEmployeePermissions() {
    return this.employeeRolePredicates.some(this.userHasRole);
  }

  private get userHasRole(): (up: UserPredicate) => boolean {
    return up => (this.securityService.user && up(this.securityService.user)) || false;
  }
}
