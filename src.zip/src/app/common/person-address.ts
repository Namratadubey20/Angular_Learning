import { AddressModel, AddressImpl } from './address/address';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from './utils/date-converter';

export interface PersonAddress {
  id: number;
  personId: number;
  fromDate: Date;
  toDate: Date;
  street1: string;
  street2: string;
  city: string;
  state: string;
  zipCode: string;
  applicantCounty?: string;
}

@JsonObject('PersonAddressImpl')
export class PersonAddressImpl extends AddressImpl implements AddressModel, PersonAddress {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('personId', Number, true)
  personId: number = null;

  @JsonProperty('createdBy', String, true)
  createdBy: string = null;

  @JsonProperty('createdAt', DateConverter, true)
  createdAt: Date = null;

  @JsonProperty('updatedBy', String, true)
  updatedBy: string = null;

  @JsonProperty('updatedAt', DateConverter, true)
  updatedAt: Date = null;
}
