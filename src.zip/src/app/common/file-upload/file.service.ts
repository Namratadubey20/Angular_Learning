import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { FileModel, FileModelImpl } from './file-model';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../utils/util.service';
import { ServiceHandler } from '../utils/service-handler.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class FileService {

  requestUrl = 'api/file';
  jsonConvert: JsonConvert = UtilService.getJsonConvert();

  private fileReader = new FileReader();

  constructor(private http: HttpClient, private serviceHandler: ServiceHandler) { }

  async uploadFile(rawFile: File, fieldName: string, parentObjectId: number, parentObjectTypeName: string,
    isHistoryNeeded?: boolean, description?: string): Promise<FileModel> {
    const file: FileModelImpl = new FileModelImpl();
    file.name = rawFile.name;
    file.fileTypeName = fieldName;
    file.parentObjectId = parentObjectId;
    file.parentObjectTypeName = parentObjectTypeName;
    file.description = description;
    if (isHistoryNeeded !== true || isHistoryNeeded === undefined) {
      file.historyLogged = false;
    }
    file.historyLogged = isHistoryNeeded;
    let response;
    try {
      file.encodedFileContents = await this.getFileContents(rawFile);
      const requestBody = this.jsonConvert.serialize(file);
      response = await this.http.post(this.requestUrl, requestBody).toPromise();
    } catch (error) {
      throw error;
    }
    return this.jsonConvert.deserialize(response, FileModelImpl) as FileModelImpl;
  }

  /**
   * @param fileId
   * @param description
   */
  async updateFileDescription(fileId?: number, description?: string): Promise<FileModel> {
    const url = `${this.requestUrl}/${fileId}`;
    let response;
    try {
      const requestBody = { description: description };
      response = await this.http.patch(url, requestBody).toPromise();
    } catch (error) {
      throw error;
    }
    return response;
  }

  getFileList(parentObjectId: string, parentObjectTypeName: string): Observable<FileModel[]> {
    return this.http.get<FileModel[]>(this.requestUrl, {
      observe: 'body',
      params: new HttpParams({ fromObject: { parentObjectTypeName, parentObjectId } }),
    }).pipe(map(response => this.jsonConvert.deserialize(response, FileModelImpl) as FileModelImpl[]));
  }

  deleteFileById(fileId: number | string, historyLogged: boolean): Observable<any> {
    const url = `${this.requestUrl}/${fileId}/${historyLogged}`;

    return this.http.delete(url)
      .map((res) => {
        if (res === true) {
          this.serviceHandler.handleConfirm('File deleted');
        }
      })
      .catch((error) => this.serviceHandler.handleError(error));
  }

  getFileContents(file: File): Promise<string> {
    // ̨need to return a promise, because were essentially waiting on an event, which is not a promise
    return new Promise<any>((resolve, reject) => {
      this.fileReader.onload = () => {
        const fileContents = this.fileReader.result;
        resolve(fileContents);
      };
      this.fileReader.onerror = () => {
        reject('Error reading file');
      };
      this.fileReader.readAsDataURL(file);
    });
  }
}
