import { Auditable, AuditableObject } from '../auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';

export interface FileModel extends Auditable {
  id: number;
  name: string;
  fileTypeName: string;
  parentObjectId: number;
  parentObjectTypeName: string;
  encodedFileContents: string;
  historyLogged?: boolean;
  description: string;
}

@JsonObject('FileModelImpl')
export class FileModelImpl extends AuditableObject implements FileModel {
  @JsonProperty('encodedFileContents', String, true)
  encodedFileContents: string = null;

  @JsonProperty('fileTypeName', String, true)
  fileTypeName: string = null;

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('parentObjectId', Number, true)
  parentObjectId: number = null;

  @JsonProperty('parentObjectTypeName', String, true)
  parentObjectTypeName: string = null;

  @JsonProperty('historyLogged', Boolean, true)
  historyLogged?: boolean = null;

  @JsonProperty('description', String, true)
  description: string = null;

}
