import { Component, EventEmitter, Input, Output, ElementRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FileService } from './file.service';
import { ServiceHandler } from '../utils/service-handler.service';
import { FileModelImpl } from './file-model';
import { AppConfigService } from '../../app-config-service';
import { FileUploadConfig } from './file-upload-config';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  providers: [FileService],
})
export class FileUploadComponent {

  @Input()
  fileUploadFormGroup: FormGroup;

  @Input()
  fieldName: string;

  @Input()
  applicationId: number;

  @Input()
  fileUploadConfig?: FileUploadConfig;

  @Input()
  isHistoryNeeded?: any;
  /**
   * The fileType-specific text to be appended to the upload button's label.
   */
  @Input()
  fileTypelabel: string;

  @Input()
  disableButton: boolean;

  @Input()
  fileDescription?: string;

  @Output()
  fileUploadEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild('uploader')
  uploaderInputField: ElementRef;

  private appConfig;

  constructor(private fileService: FileService, private serviceHandler: ServiceHandler, appConfigService: AppConfigService) {
    appConfigService.getConfig().subscribe(ac => this.appConfig = ac);
  }

  async uploadFile(event) {
    const file = event.target.files[0];
    if (file.size <= this.appConfig.fileUploadOptions.maxFileSize) {
      try {
        const fileModel: FileModelImpl =
          await this.fileService.uploadFile(file, this.fieldName, this.applicationId, 'Application', this.isHistoryNeeded,
            this.fileDescription);
        this.id.setValue(fileModel.id);
        this.name.setValue(fileModel.name);
        this.serviceHandler.handleConfirm('The document has beeen uploaded successfully');
        this.uploaderInputField.nativeElement.value = '';
        this.fileUploadEvent.emit(true);
      } catch (error) {
        console.error(error);
        this.serviceHandler.showErrorMessage('Document upload failed');
      }
    } else {
      this.serviceHandler.showErrorMessage(`Document size cannot be greater than ${this.appConfig.fileUploadOptions.maxFileSizeDisplay}`);
    }
  }

  get id(): FormControl {
    return this.fileUploadFormGroup.get('id') as FormControl;
  }

  get name(): FormControl {
    return this.fileUploadFormGroup.get('name') as FormControl;
  }

  /*
   * Get the fileUpload 'accepts' FileTypes filter as a CSV.
   * Delegates to the fileUploadConfig if available, otherwise returns an empty string.
   */
  get fileUploadAcceptsFileTypes(): string {
    let fileUploadAcceptsFileTypes = '';
    if (this.fileUploadConfig != null) {
      fileUploadAcceptsFileTypes = this.fileUploadConfig.acceptsFileTypes;
    }
    return fileUploadAcceptsFileTypes;
  }
}
