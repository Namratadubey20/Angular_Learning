// Configuration for a file upload.
export class FileUploadConfig {
  // A CSV of file types to be provided to the file upload as filters.
  _acceptsFileTypes?: string;

  set acceptsFileTypes(acceptsFileTypes: string) {
    this._acceptsFileTypes = acceptsFileTypes;
  }

  // Gets the registered 'accept' file types CSV filter. Returns empty string if none were registered.
  get acceptsFileTypes(): string {
    let acceptsFileTypes = '';
    if (this._acceptsFileTypes != null) {
      acceptsFileTypes = this._acceptsFileTypes;
    }
    return acceptsFileTypes;
  }
}
