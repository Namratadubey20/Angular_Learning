import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmailMessage } from '../email-message';
import { EmailArchive } from '../email-archive';
import { EmailService } from '../email-service';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../../security/security.service';

export interface SendEmailDialogData {
  emailTypeCode: string;
  parentObjectTypeName: string;
  parentObjectId: number;
  customFields: Map<string, string>;
}

@Component({
  selector: 'app-send-email-dialog',
  templateUrl: './send-email-dialog.component.html',
  styleUrls: ['./send-email-dialog.component.scss'],
})
export class SendEmailDialogComponent implements OnInit {

  disabled = true;

  initialized = false;
  formGroup: FormGroup;

  emailTypeCode: String = null;
  parentObjectTypeName: String = null;
  parentObjectId: Number = null;

  emailMessage: EmailMessage = new EmailMessage();
  emailArchive: EmailArchive = new EmailArchive();

  constructor(private emailService: EmailService, private fb: FormBuilder,
    private router: Router, private activatedRoute: ActivatedRoute,
    private dialogRef: MatDialogRef<SendEmailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private dialogData: SendEmailDialogData,
    private securityService: SecurityService) {
  }

  async ngOnInit() {
    /*
    emailTypeCode
    parentObjectTypeName
    parentObjectId
     */
    this.emailTypeCode = this.dialogData.emailTypeCode;
    this.parentObjectTypeName = this.dialogData.parentObjectTypeName;
    this.parentObjectId = this.dialogData.parentObjectId;

    if (this.dialogData.customFields) {
      this.emailArchive = await this.emailService.loadEmailFromTemplate(this.emailTypeCode, this.parentObjectTypeName,
        this.parentObjectId, this.dialogData.customFields).toPromise();
    } else {
      this.emailArchive = await this.emailService.loadEmailFromTemplate(this.emailTypeCode, this.parentObjectTypeName,
        this.parentObjectId).toPromise();
    }
    // check role, if admin or employee then set disabled = false and change endpoint, otherwise leave
    // disabled with standard endpoint
    if (this.securityService.user.hasEmployeePermissions) {
      this.disabled = false;
    }

    this.formGroup = this.fb.group({
      to: [{ value: this.emailArchive.to, disabled: this.disabled }, Validators.required],
      cc: [''],
      bcc: [''],
      subject: [{ value: this.emailArchive.subject, disabled: this.disabled }, Validators.required],
      message: [{ value: this.emailArchive.body, disabled: this.disabled }, Validators.required],
    });

    this.initialized = true;
  }

  async sendEmail() {
    const formVal = this.formGroup.getRawValue();
    this.emailMessage.cc = formVal.cc;
    this.emailMessage.bcc = formVal.bcc;
    this.emailMessage.subject = formVal.subject;
    this.emailMessage.message = formVal.message;
    this.emailMessage.to = formVal.to;

    try {
      if (this.disabled) {
        if (this.dialogData.customFields) {
          await this.emailService.sendEmail(
            this.emailTypeCode, this.parentObjectTypeName, (this.parentObjectId), this.dialogData.customFields).toPromise();
        } else {
          await this.emailService.sendEmail(
            this.emailTypeCode, this.parentObjectTypeName, (this.parentObjectId)).toPromise();
        }
      } else {
        await this.emailService.sendCustomEmail(this.emailMessage).toPromise();
      }
    } catch (e) {
      await this.dialogRef.close(-1);
    }
    await this.dialogRef.close(1);
  }

  async cancel() {
    this.dialogRef.close(0);
  }

}
