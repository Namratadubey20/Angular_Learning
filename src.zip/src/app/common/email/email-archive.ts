import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from '../auditable-object';

@JsonObject
export class EmailArchive extends AuditableObject {

  @JsonProperty('type', String, true)
  type: String = null;

  @JsonProperty('subject', String, true)
  subject: String = null;

  @JsonProperty('templateData', String, true)
  templateData: String = null;

  @JsonProperty('to', String, true)
  to: String = null;

  @JsonProperty('from', String, true)
  from: String = null;

  @JsonProperty('body', String, true)
  body: String = null;

}
