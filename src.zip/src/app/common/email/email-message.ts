import { AuditableObject } from '../auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject
export class EmailMessage extends AuditableObject {

  @JsonProperty('to', String, true)
  to: String = null;

  @JsonProperty('subject', String, true)
  subject: String = null;

  @JsonProperty('message', String, true)
  message: String = null;

  @JsonProperty('sender', String, true)
  sender: String = null;

  @JsonProperty('cc', String, true)
  cc: String = null;

  @JsonProperty('bcc', String, true)
  bcc: String = null;

  @JsonProperty('emailDescription', String, true)
  emailDescription: String = null;

  @JsonProperty('emailGroup', String, true)
  emailGroup: String = null;

  @JsonProperty('emailTypeCode', String, true)
  emailTypeCode: String = null;


}
