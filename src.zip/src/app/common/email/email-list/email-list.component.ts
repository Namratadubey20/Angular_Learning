import { Component, OnInit } from '@angular/core';
import { EmailService } from '../email-service';
import { EmailMessage } from '../email-message';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-email-list',
  templateUrl: './email-list.component.html',
  styleUrls: ['./email-list.component.scss'],
})
export class EmailListComponent implements OnInit {

  initialized = false;
  emailMessages: EmailMessage[] = [];

  cols = [
    { field: 'subject', header: 'Subject' },
    { field: 'message', header: 'Message' },
    { field: 'emailTypeCode', header: 'Email Type Code' },
  ];

  formGroup: FormGroup;

  constructor(private emailService: EmailService, private fb: FormBuilder, private router: Router) { }

  async ngOnInit() {
    this.emailMessages = await this.emailService.getEmailMessages().toPromise();
    // filter out emailMessages without a type code
    this.emailMessages = this.emailMessages.filter((e) => e.emailTypeCode);
    this.formGroup = this.fb.group(
      {
        parentObjectTypeName: ['', Validators.required],
        parentObjectId: ['1', Validators.required],
      }
    );
    this.initialized = true;
  }

  async sendEmail(emailTypeCode: string) {
    const formVal = this.formGroup.getRawValue();

    // route to the send-email component with the information pre-populated
    await this.router.navigateByUrl(
      `/com/send-email?emailTypeCode=${emailTypeCode}&parentObjectTypeName=${formVal.parentObjectTypeName}` +
      `&parentObjectId=${formVal.parentObjectId}`);
  }

  get parentObjectTypeNameCtl() {
    return this.formGroup.get('parentObjectTypeName');
  }
}
