import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SecurityService } from '../../security/security.service';
import { UtilService } from '../utils/util.service';
import { JsonConvert } from 'json2typescript';
import { EmailArchive } from './email-archive';
import { Observable } from 'rxjs';
import { EmailMessage } from './email-message';

@Injectable({
  providedIn: 'root',
})
export class EmailService {

  jsonConvert: JsonConvert;

  constructor(private http: HttpClient,
    private securityService: SecurityService) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  sendEmail(templateName: String, parentObjectTypeName: String, parentObjectId: Number,
    customData?: Map<string, string>): Observable<EmailArchive> {
    return this.http.post(`api/email/${templateName}/${parentObjectTypeName}/${parentObjectId}`, customData ? customData : null)
      .map((e: EmailArchive) => this.jsonConvert.deserializeObject(e, EmailArchive));
  }

  sendCustomEmail(emailMessage: EmailMessage): Observable<EmailArchive> {
    return this.http.post(`api/email/custom`, this.jsonConvert.serializeObject(emailMessage))
      .map((e: EmailArchive) => this.jsonConvert.deserializeObject(e, EmailArchive));
  }

  getEmailById(id: number): Observable<EmailMessage> {
    return this.http.get(`api/email/${id}`)
      .map((e) => this.jsonConvert.deserializeObject(e, EmailMessage));
  }

  getEmailMessages(): Observable<EmailMessage[]> {
    return this.http.get<EmailMessage[]>(`api/email`)
      .map((e) => this.jsonConvert.deserializeArray(e, EmailMessage));
  }

  getArchiveById(id: number): Observable<EmailArchive> {
    return this.http.get<EmailArchive>(`api/email/archive/${id}`)
      .map((e) => this.jsonConvert.deserializeObject(e, EmailArchive));
  }

  loadEmailFromTemplate(templateName: String, parentObjectTypeName: String, parentObjectId: Number,
    customData?: Map<string, string>): Observable<EmailArchive> {
    return this.http.post(`api/email/archive/${templateName}/${parentObjectTypeName}/${parentObjectId}`, customData ? customData : null)
      .map((e) => this.jsonConvert.deserializeObject(e, EmailArchive));
  }
}
