import { Component, OnInit } from '@angular/core';
import { EmailService } from '../email-service';
import { EmailMessage } from '../email-message';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmailArchive } from '../email-archive';

@Component({
  selector: 'app-send-email',
  templateUrl: './send-email.component.html',
  styleUrls: ['./send-email.component.scss'],
})
export class SendEmailComponent implements OnInit {

  initialized = false;
  formGroup: FormGroup;

  emailTypeCode: String = null;
  parentObjectTypeName: String = null;
  parentObjectId: Number = null;

  emailMessage: EmailMessage = new EmailMessage();
  emailArchive: EmailArchive = new EmailArchive();

  constructor(private emailService: EmailService, private fb: FormBuilder,
    private router: Router, private activatedRoute: ActivatedRoute) {
  }

  async ngOnInit() {
    /*
    emailTypeCode
    parentObjectTypeName
    parentObjectId
     */
    this.emailTypeCode = this.activatedRoute.snapshot.queryParams['emailTypeCode'];
    this.parentObjectTypeName = this.activatedRoute.snapshot.queryParams['parentObjectTypeName'];
    this.parentObjectId = this.activatedRoute.snapshot.queryParams['parentObjectId'];

    this.emailArchive = await this.emailService.loadEmailFromTemplate(this.emailTypeCode, this.parentObjectTypeName,
      this.parentObjectId).toPromise();

    this.formGroup = this.fb.group({
      to: [{ value: this.emailArchive.to, disabled: true }, Validators.required],
      cc: [''],
      bcc: [''],
      subject: [{ value: this.emailArchive.subject, disabled: true }, Validators.required],
      message: [{ value: this.emailArchive.body, disabled: true }, Validators.required],
    });

    this.initialized = true;
  }

  async sendEmail() {
    const formVal = this.formGroup.getRawValue();
    this.emailMessage.cc = formVal.cc;
    this.emailMessage.bcc = formVal.bcc;
    this.emailMessage.subject = formVal.subject;
    this.emailMessage.message = formVal.message;
    this.emailMessage.to = formVal.to;
    const emailArchive = await this.emailService.sendEmail(
      this.emailTypeCode, this.parentObjectTypeName, (this.parentObjectId)).toPromise();
    alert('email sent');
    await this.cancel();
  }

  async cancel() {
    await this.router.navigateByUrl('/com/email-list');
  }
}
