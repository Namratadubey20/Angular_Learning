import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { DOCUMENT } from '@angular/platform-browser';

export interface DialogData {
  title?: string;
  chooseProduct?: string;
  confirmationRequestText?: string;
  detailsText?: string;
  subText?: string;
  refundDetails?: string;
  acceptLabel?: string;
  acceptedResult?: any;
  rejectLabel?: string;
  rejectedResult?: any;
  descriptionText?: any;
  cancelDate?: string;
  isIbond?: boolean;
}

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
})
export class ConfirmationDialogComponent implements OnInit {
  formGroup: FormGroup;
  inputReadonly = true;
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: DialogData,
    private fb: FormBuilder,
    // tslint:disable-next-line: deprecation
    @Inject(DOCUMENT) private document) { }

  ngOnInit() {
    this.formGroup = this.fb.group(
      {
        description: ['', Validators.required],
        options: ['', Validators.required],
        selectDate: ['', Validators.required],
      }
    );
    if (this.dialogData.descriptionText) {
      this.formGroup.controls['description'].setValue(this.dialogData.descriptionText);
    }
    if (this.dialogData.chooseProduct) {
      this.formGroup.controls['options'].setValue(this.dialogData.chooseProduct);
    }
    if (this.dialogData.cancelDate) {
      this.formGroup.controls['selectDate'].setValue(this.dialogData.cancelDate);
    }
    if (this.dialogData.isIbond) {
      this.document.body.classList.add('payment-component');
    } else {
      this.document.body.classList.remove('payment-component');
    }
  }

  close(): void {
    this.dialogRef.close();
  }

  onRejectClick(): void {
    this.dialogRef.close(this.dialogData.rejectedResult);
  }

  onAcceptClick() {
    if (this.formGroup.valid) {
      return this.dialogRef.close(this.formGroup.getRawValue());
    }
    this.dialogRef.close(this.dialogData.acceptedResult);
  }
}
