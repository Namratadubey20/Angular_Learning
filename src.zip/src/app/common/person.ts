import { JsonObject, JsonProperty } from 'json2typescript';
import { CompanyOfficePerson, CompanyOfficePersonImpl } from './company-office-person';
import { PersonSummary, PersonSummaryImpl } from './person-summary';

export interface Person extends PersonSummary {
  companyOfficePersons: Array<CompanyOfficePerson>;
}

@JsonObject('PersonImpl')
export class PersonImpl extends PersonSummaryImpl implements Person {
  @JsonProperty('companyOfficePersons', [CompanyOfficePersonImpl], true)
  companyOfficePersons: Array<CompanyOfficePerson> = new Array<CompanyOfficePersonImpl>();
}
