import { JsonObject, JsonProperty } from 'json2typescript';
import { PersonSummary, PersonSummaryImpl } from './person-summary';
import { CompanyOfficePerson, CompanyOfficePersonImpl } from './company-office-person';
import { CompanyOfficeSummary, CompanyOfficeSummaryImpl } from './company-office-summary';

export interface CompanyOffice extends CompanyOfficeSummary {
  companyOfficePersons: Array<CompanyOfficePerson>;
  readonly responsiblePerson: PersonSummary;
}

@JsonObject('CompanyOfficeImpl')
export class CompanyOfficeImpl extends CompanyOfficeSummaryImpl {
  @JsonProperty('companyOfficePersons', [CompanyOfficePersonImpl], true)
  companyOfficePersons: Array<CompanyOfficePerson> = new Array<CompanyOfficePersonImpl>();

  @JsonProperty('responsiblePerson', PersonSummaryImpl, true)
  responsiblePerson: PersonSummary = new PersonSummaryImpl();
}
