import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-appointment-type',
  templateUrl: './appointment-type.component.html',
})
export class AppointmentTypeComponent {
  @Input() appointmentTypeFormGroup: FormGroup;

  appointmentTypes = ['Temporary', 'Permanent', 'Successor', 'Co-Fiduciary'];

  trackByAppointmentType(index: number, appointmentType: string): string {
    return appointmentType;
  }

  get appointmentTypeFormControl(): FormControl {
    return this.appointmentTypeFormGroup.get('appointmentType') as FormControl;
  }
}
