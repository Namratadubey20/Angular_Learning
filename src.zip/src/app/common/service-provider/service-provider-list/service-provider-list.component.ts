import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { CommonUtilities } from '../../utils/common-utilities';

@Component({
  selector: 'app-service-provider-list',
  templateUrl: './service-provider-list.component.html',
  styleUrls: ['./service-provider-list.component.scss'],
})
export class ServiceProviderListComponent implements OnInit {

  @Input()
  serviceProviderFormArray: FormArray;

  @Input()
  serviceProviderEmptyFormGroup: FormGroup;

  @Input()
  atLeastOneRequired: boolean;

  @Input()
  disableButton: boolean;

  constructor() {
  }

  ngOnInit(): void {
    if (this.atLeastOneRequired && this.serviceProviderFormArray.length < 1) {
      this.addEmptyServiceProviderFormGroup();
    }
  }

  addEmptyServiceProviderFormGroup() {
    // serviceProviderEmptyFormGroup may already have been allocated so we clone it just to be safe.
    const emptyFormGroup = CommonUtilities.cloneAbstractControl(this.serviceProviderEmptyFormGroup);
    this.serviceProviderFormArray.push(emptyFormGroup);
  }

  removeServiceProviderFormGroup(index: number) {
    this.serviceProviderFormArray.removeAt(index);
  }

  disableTrash() {
    return this.atLeastOneRequired ? this.serviceProviderFormArray.length === 1 : false;
  }

}
