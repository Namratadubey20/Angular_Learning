import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FileUploadConfig } from '../file-upload/file-upload-config';
import { DocumentUploadComponent } from '../document-upload/document-upload.component';

@Component({
  selector: 'app-court-order',
  templateUrl: './court-order.component.html',
  styleUrls: ['./court-order.component.css'],
})
export class CourtOrderComponent extends DocumentUploadComponent {

  @Input()
  courtOrderFormGroup: FormGroup;

  // FileUploadConfig for uploading the court order file.
  fileUploadConfig: FileUploadConfig;

  @Input()
  disableCourtOrderButton: boolean;

  constructor() {
    super();
    this.fileUploadConfig = new FileUploadConfig();
    this.fileUploadConfig.acceptsFileTypes = '.pdf,.doc,.docx,.jpg,.jpeg';
  }

  get uploadCourtOrder(): FormControl {
    return this.courtOrderFormGroup.get('uploadCourtOrder') as FormControl;
  }

  get courtOrderFileFormGroup(): FormGroup {
    return this.courtOrderFormGroup.get('courtOrderFile') as FormGroup;
  }

}
