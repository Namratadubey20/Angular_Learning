import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-court-information',
  templateUrl: './court-information.component.html',
  styleUrls: ['./court-information.component.css'],
})
export class CourtInformationComponent {

  @Input()
  courtInformationFormGroup: FormGroup;

  constructor() { }

  get caseNumber(): FormControl {
    return this.courtInformationFormGroup.get('caseNumber') as FormControl;
  }

  get courtName(): FormControl {
    return this.courtInformationFormGroup.get('courtName') as FormControl;
  }

  get presidingJudge(): FormControl {
    return this.courtInformationFormGroup.get('presidingJudge') as FormControl;
  }

  get courtCounty(): FormControl {
    return this.courtInformationFormGroup.get('courtCounty') as FormControl;
  }

  get address(): FormGroup {
    return this.courtInformationFormGroup.get('address') as FormGroup;
  }

  get courtPhone(): FormControl {
    return this.courtInformationFormGroup.get('courtPhone') as FormControl;
  }

  get courtDistrict(): FormControl {
    return this.courtInformationFormGroup.get('courtDistrict') as FormControl;
  }

}
