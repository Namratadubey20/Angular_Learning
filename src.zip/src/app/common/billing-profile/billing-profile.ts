import { JsonObject, JsonProperty } from 'json2typescript';
import { AuditableObject } from '../auditable-object';

export interface BillingProfile {
  id: number;
  paymentType: string;
  planType: string;
}

@JsonObject('BillingProfileImpl')
export class BillingProfileImpl extends AuditableObject implements BillingProfile {
  @JsonProperty('paymentType', String, false)
  paymentType: string = null;

  @JsonProperty('planType', String, false)
  planType: string = null;

  @JsonProperty('personId', Number, false)
  personId: number = null;
}
