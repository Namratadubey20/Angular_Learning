import { SpecHelpers } from '../../utils/spec-helpers';

export function someRandomPlanType(): string {
  return SpecHelpers.someRandomElementFrom(['MANUAL', 'RECURRING']);
}

export function someRandomPaymentType(): string {
  return SpecHelpers.someRandomElementFrom(['ACH', 'CREDIT', 'PAPER_CHECK']);
}
