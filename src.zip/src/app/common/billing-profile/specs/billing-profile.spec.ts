import { BillingProfileImpl } from '../billing-profile';
import { someRandomPaymentType, someRandomPlanType } from './spec-helpers';
import { JsonConvertService } from '../../utils/json-convert.service';
import { DateConverter } from '../../utils/date-converter';
import { SpecHelpers } from '../../utils/spec-helpers';

describe('BillingProfileImpl', () => {
  const jsonConvert = new JsonConvertService().getJsonConvert();

  it('should have all its expected properties set when you instantiate it', () => {
    const billingProfile = new BillingProfileImpl();
    const expectedProperties = [
      'id',
      'paymentType',
      'planType',
      'createdAt',
      'createdBy',
      'updatedAt',
      'updatedBy',
      'personId',
    ];

    expectedProperties.forEach(ep => {
      expect(billingProfile.hasOwnProperty(ep)).toBeTruthy(`billingProfile missing property ${ep}`);
    });
  });

  it('should serialize correctly to the expected server shape', () => {
    const id = SpecHelpers.someRandomNumber();
    const createdAt = SpecHelpers.someRandomDate();
    const createdBy = 'felix';
    const paymentType = someRandomPaymentType();
    const planType = someRandomPlanType();
    const updatedAt = SpecHelpers.someRandomDate();
    const updatedBy = 'oscar';
    const personId = 10982;

    const bp = new BillingProfileImpl();
    bp.id = id;
    bp.paymentType = paymentType;
    bp.planType = planType;
    bp.createdBy = createdBy;
    bp.createdAt = createdAt;
    bp.updatedBy = updatedBy;
    bp.updatedAt = updatedAt;
    bp.personId = personId;

    const serialized = jsonConvert.serialize(bp);
    expect(serialized).toBeDefined();
    // expect(serialized).toEqual({
    //   id,
    //   paymentType,
    //   planType,
    //   createdAt: createdAt.toISOString(),
    //   createdBy,
    //   updatedAt: updatedAt.toISOString(),
    //   updatedBy,
    //   personId,
    // });
  });

  it('should deserialize correctly from a given server shape', () => {
    const serverBillingProfile = {
      'id': 1007,
      'paymentType': 'CREDIT',
      'planType': 'MANUAL',
      'createdBy': 'oscar',
      'createdAt': '2018-09-06T04:46:43.363+0000',
      'updatedBy': 'felix',
      'updatedAt': '2018-09-06T04:46:43.363+0000',
      'personId': 109892,
    };

    const dc = new DateConverter();

    const expectedBillingProfile = new BillingProfileImpl();
    expectedBillingProfile.id = serverBillingProfile.id;
    expectedBillingProfile.paymentType = serverBillingProfile.paymentType;
    expectedBillingProfile.planType = serverBillingProfile.planType;
    expectedBillingProfile.createdBy = serverBillingProfile.createdBy;
    expectedBillingProfile.createdAt = dc.deserialize(serverBillingProfile.createdAt);
    expectedBillingProfile.updatedBy = serverBillingProfile.updatedBy;
    expectedBillingProfile.updatedAt = dc.deserialize(serverBillingProfile.updatedAt);
    expectedBillingProfile.personId = serverBillingProfile.personId;

    const actualBillingProfile = jsonConvert.deserialize(serverBillingProfile, BillingProfileImpl);

    expect(actualBillingProfile).toEqual(expectedBillingProfile);
  });
});
