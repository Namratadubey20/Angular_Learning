import { Any, JsonObject, JsonProperty } from 'json2typescript';
import { LazyLoadEvent } from 'primeng/api';

export interface ColumnFieldNameMap {
  [key: string]: string;
}

export interface Pageable {
  page: number;
  size: number;
  sort: [string, string];
}

export interface Page<T> {
  content: Array<T>;
  hasContent: boolean;
  hasNext: boolean;
  hasPrevious: boolean;
  isFirst: boolean;
  isLast: boolean;
  number: number;
  numberOfElements: number;
  size: number;
  totalElements: number;
  totalPages: number;
  error?: boolean;
}

@JsonObject('PageImpl<T>')
export class PageImpl<T> implements Page<T> {
  @JsonProperty('content', [Any], true)
  content: Array<T> = [];

  @JsonProperty('hasContent', Boolean, true)
  hasContent: boolean = null;

  @JsonProperty('hasNext', Boolean, true)
  hasNext: boolean = null;

  @JsonProperty('hasPrevious', Boolean, true)
  hasPrevious: boolean = null;

  @JsonProperty('isFirst', Boolean, true)
  isFirst: boolean = null;

  @JsonProperty('isFirst', Boolean, true)
  isLast: boolean = null;

  @JsonProperty('number', Number, true)
  number: number = null;

  @JsonProperty('numberOfElements', Number, true)
  numberOfElements: number = null;

  @JsonProperty('size', Number, true)
  size: number = null;

  @JsonProperty('totalElements', Number, true)
  totalElements: number = null;

  @JsonProperty('totalPages', Number, true)
  totalPages: number = null;
}

export class PageableConverter {
  static fromLazyLoadEvent(event: LazyLoadEvent, map?: ColumnFieldNameMap): Pageable {
    const pageable: Pageable = {
      page: Math.ceil(event.first / event.rows),
      size: event.rows,
      sort: undefined,
    } as Pageable;
    if (event.sortOrder && event.sortField) {
      let sortOrder, sortField;
      if (map) {
        sortField = map[event.sortField];
      } else {
        sortField = event.sortField;
      }
      sortOrder = event.sortOrder;
      pageable.sort = [sortField, sortOrder > 0 ? 'asc' : 'desc'];
    }
    return pageable;
  }

  static toPageableRequest(pageable: Pageable) {
    const pageableParams = {
      params: {
        page: pageable.page.toString(),
        size: pageable.size.toString(),
        sort: undefined,
      },
    };
    if (pageable.sort) {
      pageableParams.params.sort = `${pageable.sort[0]},${pageable.sort[1]}`;
    } else {
      delete pageableParams.params.sort;
    }
    return pageableParams;
  }

  static fromData<T>(data: T[]): Page<T> {
    const length = data.length;
    return {
      content: data,
      hasContent: true,
      hasNext: false,
      hasPrevious: false,
      isFirst: true,
      isLast: true,
      number: 1,
      numberOfElements: length,
      size: length,
      totalElements: length,
      totalPages: 1,
    };
  }
}
