import { Directive, ElementRef, HostListener, OnInit } from '@angular/core';
import { CurrencyFormatter } from '../utils/currency-formatter';
import { CurrencyPipe } from '@angular/common';

@Directive({
  selector: '[appDecimalFormatCurrency]',
})
export class DecimalFormatCurrencyDirective implements OnInit {

  allowedCharacters = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  allowedActions = ['ArrowRight', 'ArrowLeft', 'Backspace', 'Tab'];

  constructor(
    protected element: ElementRef,
    private currencyPipe: CurrencyPipe
  ) {
  }


  ngOnInit(): void {
    this.formatMoney();
  }

  @HostListener('blur')
  public onBlur() {
    this.formatMoney();
  }

  @HostListener('keydown', ['$event'])
  public onKeydown(event) {
    const key = event.key;
    if (this.allowedCharacters.indexOf(key) < 0 || this.element.nativeElement.value.length === 15) {
      if (this.allowedActions.indexOf(key) < 0) {
        return false;
      }
    }
  }

  formatMoney() {
    if (this.element.nativeElement.value !== null && this.element.nativeElement.value !== '') {
      let amount = this.element.nativeElement.value;
      amount = amount.toString().replace(',', '');
      this.element.nativeElement.value = this.currencyPipe.transform(Number(amount), '', '', '0.0');
    }
  }
}
