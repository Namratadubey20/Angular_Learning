import { Directive, HostListener, Input, ElementRef, OnInit, EventEmitter, Output } from '@angular/core';

const placeholders = {
  'A': '^[a-zA-ZA-z]',
  '0': '\\d',
};

const keys = {
  'TAB': 9,
  'BACKSPACE': 8,
  'LEFT': 37,
  'RIGHT': 39,
  'DEL': 46,
};

interface IState {
  value: string;
}

@Directive({
  selector: '[appInputMask]',
})

export class InputMaskDirective implements OnInit {

  private state: IState;

  @Input() appInputMask: any;
  @Output() ngModelChange = new EventEmitter();

  constructor(private element: ElementRef) {
    this.state = {
      value: this.getValue(),
    };
  }

  @HostListener('input')
  public onChange(): void {
    this.applyMask(this.getClearValue(this.getValue()));
  }

  @HostListener('keypress', ['$event'])
  public onKeyPress(event): void {
    const key = this.getKey(event);
    if (key !== keys.BACKSPACE && key !== keys.LEFT && key !== keys.RIGHT && key !== keys.DEL && key !== keys.TAB) {
      const cursorPosition = this.getCursorPosition();
      const regexp = this.createRegExp(cursorPosition);
      if ((regexp != null && !regexp.test(event.key) || this.getValue().length >= this.appInputMask.length) && cursorPosition !== 0) {
        event.preventDefault();
      } else if (cursorPosition === 0 && this.getValue().length === this.appInputMask.length) {
        this.element.nativeElement.value = '';
        event.preventDefault();
      }
    }
  }

  public ngOnInit(): void {
    this.applyMask(this.getClearValue(this.getValue()));
  }

  private getKey(event) {
    return event.keyCode || event.charCode;
  }

  private applyMask(value): void {
    let newValue = '';
    let maskPosition = 0;
    if (this.getClearValue(value).length > this.getClearValue(this.appInputMask).length) {
      this.setValue(this.state.value);
      return;
    }

    for (let i = 0; i < value.length; i++) {
      const current = value[i];

      const regexp = this.createRegExp(maskPosition);
      if (regexp != null) {
        if (!regexp.test(current)) {
          this.setValue(this.state.value);
          break;
        }
        newValue += current;
      } else if (this.appInputMask[maskPosition] === current) {
        newValue += current;
      } else {
        newValue += this.appInputMask[maskPosition];
        i--;
      }

      maskPosition++;
    }

    const nextMaskElement = !!this.appInputMask ? this.appInputMask[maskPosition] : null;
    if (value.length && nextMaskElement != null && /^[-\/\\^$#&@№:<>_\^!*+?.()|\[\]{}]/.test(nextMaskElement)) {
      newValue += nextMaskElement;
    }

    const oldValue = this.state.value;
    const cursorPosition = this.getCursorPosition();
    this.setValue(newValue);
    this.state.value = newValue;


    if (oldValue && oldValue.length >= cursorPosition) {
      this.setCursorPosition(cursorPosition);
    }
  }

  private createRegExp(position): RegExp | null {
    if (!this.appInputMask || !this.appInputMask[position]) {
      return null;
    }

    const currentSymbol = this.appInputMask[position].toUpperCase();
    const placeholderKeys = Object.keys(placeholders);
    const searchPosition = placeholderKeys.indexOf(currentSymbol);
    if (searchPosition >= 0) {
      return new RegExp(placeholders[placeholderKeys[searchPosition]], 'gi');
    }
    return null;
  }

  private getValue(): string {
    return this.element.nativeElement.value;
  }

  private getClearValue(value): string {
    return !!value ? value.trim().replace(/[-\/\\^$#&@№:<>_\^!*+?.()|\[\]{}]/gi, '') : '';
  }

  private setValue(value: string): void {
    this.element.nativeElement.value = value.trim();
  }

  private getCursorPosition(): number {
    return this.element.nativeElement.selectionStart;
  }

  private setCursorPosition(start: number, end: number = start): void {
    this.element.nativeElement.setSelectionRange(start, end);
  }
}

