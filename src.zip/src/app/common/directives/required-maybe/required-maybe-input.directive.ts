import { NgControl } from '@angular/forms';
import { Directive } from '@angular/core';
import { MatFormFieldControl, MatInput } from '@angular/material';
import { RequiredMaybeDirective, Writeable } from './required-maybe.directive';

@Directive({ selector: '[appRequiredMaybeInput]' })
export class RequiredMaybeInputDirective extends RequiredMaybeDirective {
  constructor(control: NgControl, private matInput: MatInput) {
    super(control);
  }

  protected get formField(): Writeable<MatFormFieldControl<any>> {
    return this.matInput;
  }
}
