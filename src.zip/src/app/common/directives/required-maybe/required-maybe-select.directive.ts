import { RequiredMaybeDirective, Writeable } from './required-maybe.directive';
import { Directive } from '@angular/core';
import { NgControl } from '@angular/forms';
import { MatFormFieldControl, MatSelect } from '@angular/material';

@Directive({ selector: '[appRequiredMaybeSelect]' })
export class RequiredMaybeSelectDirective extends RequiredMaybeDirective {
  constructor(control: NgControl, private matSelect: MatSelect) {
    super(control);
  }

  protected get formField(): Writeable<MatFormFieldControl<any>> {
    return this.matSelect;
  }
}
