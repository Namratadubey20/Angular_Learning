import { AfterContentChecked } from '@angular/core';
import { AbstractControl, NgControl } from '@angular/forms';
import { MatFormFieldControl } from '@angular/material';

// A helpful type wrapper which asserts that you have an instance of an interface with one or more readonly fields,
// but those fields on your instance are writeable
// https://stackoverflow.com/a/43001581/114359
export type Writeable<T> = { -readonly [P in keyof T]: T[P] };

export abstract class RequiredMaybeDirective implements AfterContentChecked {
  // MatInput and MatSelect both implement the MatFormFieldControl interface, which specifies a 'required' field,
  // among others.
  // MatFormFieldControl.required is declared readonly, but they are writeable on MatSelect and MatInput;
  // Wrap MatFormFieldControl in the Writeable type to appease the compiler, allowing us to write to formField.required
  protected abstract get formField(): Writeable<MatFormFieldControl<any>>

  protected constructor(private control: NgControl) { }

  private checkForRequired() {
    if (this.formField && this.control.control && this.control.control.validator) {
      this.formField.required = this.hasRequiredField(this.control.control);
    }/* else { // Uncomment this if you need to debug a missing star on some form field label
      console.warn('Form field not found!?', this.el, this.control);
    }*/
  }

  // Currently the only way to test if a control was set up with a "required" validator is to invoke its validator
  // function, passing in an empty "control" object and observing the result - if it comes back with a "required"
  // property, then we assume the presence of a "required" validator on the control
  // We do it this way because angular the angular team hate us;
  // For more information see: https://github.com/angular/angular/issues/13461
  private hasRequiredField(abstractControl: AbstractControl): boolean {
    if (abstractControl.validator) {
      const validationResult = abstractControl.validator({} as AbstractControl);
      if (validationResult && validationResult.required) {
        return true;
      }
    }

    return false;
  }

  ngAfterContentChecked(): void {
    // Not sure if AfterContentChecked is the ideal lifecycle hook to use for checking required
    // Separating the hook from the action this way should make it easier to change,
    // if it ever becomes necessary
    this.checkForRequired();
  }
}
