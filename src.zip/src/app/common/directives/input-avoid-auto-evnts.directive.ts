import { Directive, HostListener, Input, ElementRef, OnInit, EventEmitter, Output, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appInputFieldPreventAutoEvents]',
})

export class InputPreventAutoEventDirective implements OnInit {
  private autoEvent = 'cut copy paste';
  constructor(private element: ElementRef, private render: Renderer2) {

    this.autoEvent.split(' ').forEach(e =>
      this.render.listen(this.element.nativeElement, e, (evt) => {
        evt.preventDefault();
      })
    );
  }

  public ngOnInit(): void {
  }
}
