import { Directive, ElementRef, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

/**
 * This directive would trim leading and trailing spaces on blur of an input control
 */
@Directive({
  selector: '[appTrimSpaces]',
})

export class TrimSpacesDirective {

  get ctrl() {
    return this.ngControl.control;
  }

  constructor(private element: ElementRef, private ngControl: NgControl) {
  }

  @HostListener('blur', ['$event'])
  public onBlur(event): void {
    const value = this.ctrl.value;
    this.ctrl.setValue(value && value.trim());
  }
}
