import { Directive, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appScrollToTop]',
})
export class ScrollToTopDirective {

  constructor() { }

  @Input() shouldScroll: () => boolean = () => true;

  @HostListener('click')
  public onStepperSelectionChange() {
    if (this.shouldScroll()) {
      this.scrollToSectionHook();
    }
  }

  private scrollToSectionHook() {
    const element = document.querySelector('.topOfWindow');

    if (element) {
      setTimeout(() => {
        element.scrollIntoView({
          behavior: 'instant', block: 'start', inline:
            'nearest',
        });
      }, 150);
    }
  }
}
