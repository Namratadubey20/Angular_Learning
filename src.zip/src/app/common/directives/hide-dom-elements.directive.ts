import { Directive, ElementRef, Input, Renderer2, RendererStyleFlags2, OnChanges } from '@angular/core';

@Directive({
  selector: '[appHideElement]',
})

export class HideDomElementsDirective implements OnChanges {

  constructor(private element: ElementRef, private renderer: Renderer2) { }

  private initialDisplay;

  @Input() appHideElement: boolean;

  ngOnChanges() {
    // Use renderer to render the element with styles
    if (this.appHideElement) {
      // Preserve element initial style
      this.initialDisplay = this.element.nativeElement.style.display;
      this.renderer.setStyle(this.element.nativeElement, 'display', 'none', RendererStyleFlags2.Important);
    } else {
      this.renderer.setStyle(this.element.nativeElement, 'display', this.initialDisplay);
    }
  }

}

