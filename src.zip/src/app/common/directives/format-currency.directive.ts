import { Directive, ElementRef, HostListener, OnInit } from '@angular/core';
import { CurrencyFormatter } from '../utils/currency-formatter';

@Directive({
  selector: '[appFormatCurrency]',
})
export class FormatCurrencyDirective implements OnInit {

  allowedCharacters = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'];
  allowedActions = ['ArrowRight', 'ArrowLeft', 'Backspace', 'Tab'];

  constructor(protected element: ElementRef) {
  }


  ngOnInit(): void {
    this.formatMoney();
  }

  @HostListener('blur')
  public onBlur() {
    this.formatMoney();
  }

  @HostListener('focus')
  public onFocus() {

  }

  @HostListener('keydown', ['$event'])
  public onKeydown(event) {
    const key = event.key;
    if (this.allowedCharacters.indexOf(key) < 0 || this.element.nativeElement.value.length === 15) {
      if (this.allowedActions.indexOf(key) < 0) {
        return false;
      }
    }
  }

  formatMoney() {
    if (this.element.nativeElement.value !== null && this.element.nativeElement.value !== '') {
      const value = this.convertValueToNumber();
      this.element.nativeElement.value = CurrencyFormatter.formatMoney(value);
    }
  }

  convertValueToNumber() {
    return CurrencyFormatter.toRawNumber(this.element.nativeElement.value);
  }

  get value(): number {
    return this.convertValueToNumber();
  }

}
