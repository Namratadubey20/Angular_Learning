import { AbstractControl, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { PatternValidators } from '../validators/pattern-validators';
import { PaymentValidators } from '../validators/payment-validators';
import { PaymentMethod, PaymentMethodImpl } from '../../enrollment/application/court/model/common/payment-method';
import { Address, AddressImpl } from '../../enrollment/application/court/model/common/address';
import { ConditionalValidator } from '../validators/conditional-validator';

import {
  DynamicValidatorConfig,
  ValidatorActivationConfig,
  ValidatorRegistrar,
} from '../validators/dynamic/validator-registrar';
import { PaymentChannelCode } from './payment_channel_code';
import { Subscription } from 'rxjs';
import { PaymentMethodOption } from './payment-method-option';
import { AchAccountHolderType } from './ach_account_holder_type';
import { AchAccountType } from './ach_account_type';
import { AchSecCode } from './ach_sec_code';
import { AddressFormGroup } from '../address/address-form-group';

export interface PaymentMethodSelectionFormGroupConfig {
  isRequired?: boolean; // Indicates whether the overall paymentMethod is required.
  isDisabled?: boolean; // Indicates whether the Form Group should be disabled. Defaults to false.
  // Function that maps 'model' (e.g. PaymentMethod) to key/values suitable for patchValue.
  // The intent is to allow different view models to be mapped to this form group.
  // Potential view models are PaymentMethod and BillingProfileModel.
  modelToPatchValuesMapper?: (model: any) => ({ [key: string]: any; });

  // Function that maps control key/values to 'model' (e.g. PaymentMethod) suitable for getRawValue.
  // The intent is to allow different view models to be mapped to this form group.
  // Potential view models are PaymentMethod and BillingProfileModel.
  valuesToModelMapper?: (group: PaymentMethodSelectionFormGroup) => void;
}

export class ControlNames {
  public static readonly PAYMENT_PLAN_TYPE_ID_CONTROL = 'paymentPlanTypeIdControl';
  public static readonly BILLING_PROFILE_ID_CONTROL = 'billingProfileIdControl';
  public static readonly SECONDARY_BILLING_PROFILE_ID_CONTROL = 'secondaryBillingPersonBillingProfileIdControl';
  public static readonly PAYMENT_CHANNEL_CODE_CONTROL = 'paymentChannelCodeControl';
  public static readonly SAFE_ID_CONTROL = 'safeIdControl';
  // paymentMethodControl groups 'use existing Billing Profile' and 'create new BP via paymentChannelCode' options.
  public static readonly PAYMENT_METHOD_CONTROL = 'paymentMethodControl';
  public static readonly PERSON_CONTROL = 'personControl';
  // public static readonly BILLING_NAME_CONTROL = 'billingNameControl';// We don't collect billingName, we generate it.
  public static readonly BILLING_FIRST_NAME_CONTROL = 'billingFirstNameControl';
  public static readonly BILLING_LAST_NAME_CONTROL = 'billingLastNameControl';
  public static readonly BILLING_PHONE_CONTROL = 'billingPhoneControl';
  public static readonly BILLING_ADDRESS_GROUP = 'billingAddressGroup';
  public static readonly CARD_NUMBER_CONTROL = 'cardNumberControl';
  public static readonly CARD_EXPIRATION_CONTROL = 'cardExpirationControl';
  public static readonly CARD_CVV_CONTROL = 'cardCVVControl';
  public static readonly ACH_ACCOUNT_NUMBER_CONTROL = 'achAccountNumberControl';
  public static readonly CONFIRM_ACH_ACCOUNT_NUMBER_CONTROL = 'confirmAchAccountNumberControl';
  public static readonly ACH_ROUTING_NUMBER_CONTROL = 'achRoutingNumberControl';
  public static readonly CONFIRM_ACH_ROUTING_NUMBER_CONTROL = 'confirmAchRoutingNumberControl';
  public static readonly ACH_ACCOUNT_TYPE_CONTROL = 'achAccountTypeControl';
  public static readonly ACH_ACCOUNT_HOLDER_TYPE_CONTROL = 'achAccountHolderTypeControl';
  public static readonly ACH_AUTHORIZED_BY_ACCOUNT_HOLDER_CONTROL = 'achAuthorizedByAccountHolderControl';
  public static readonly ACH_SEC_CODE_CONTROL = 'achSecCodeControl';
  public static readonly BANK_NAME_CONTROL = 'bankNameControl';
}

export class PaymentMethodSelectionFormGroup extends FormGroup {
  options: PaymentMethodSelectionFormGroupConfig;


  /**
   * Create the values hierarchy appropriate for 'patching' the PaymentMethodSelectionFormGroup from a PaymentMethod instance.
   * @param paymentMethodPartial that is the source of the 'patch values'.
   * @return the values hierarchy appropriate for 'patching' the PaymentMethodSelectionFormGroup.
   */
  public static createPatchValuesFromPaymentMethodPartial(paymentMethodPartial: Partial<PaymentMethod>): { [key: string]: any } {
    const patchValues: { [key: string]: any } = {};
    patchValues[ControlNames.PAYMENT_PLAN_TYPE_ID_CONTROL] = paymentMethodPartial.paymentPlanTypeId;
    patchValues[ControlNames.BILLING_PROFILE_ID_CONTROL] = paymentMethodPartial.billingProfileId;
    patchValues[ControlNames.SECONDARY_BILLING_PROFILE_ID_CONTROL] = paymentMethodPartial.secondaryBillingPersonBillingProfileId;
    const paymentChannelCode = paymentMethodPartial.paymentChannelCode;
    patchValues[ControlNames.PAYMENT_CHANNEL_CODE_CONTROL] = (!!paymentChannelCode) ? paymentChannelCode.persistenceId : null;
    // patchValues[ControlNames.PAYMENT_METHOD_CONTROL] =; // PAYMENT_METHOD_CONTROL is a calculated value.
    patchValues[ControlNames.SAFE_ID_CONTROL] = paymentMethodPartial.safeId;
    patchValues[ControlNames.PERSON_CONTROL] = paymentMethodPartial.personId;
    // patchValues[ControlNames.BILLING_NAME_CONTROL] = paymentMethodPartial.billingName;// We don't collect billingName, we generate it.
    patchValues[ControlNames.BILLING_FIRST_NAME_CONTROL] = paymentMethodPartial.billingFirstName;
    patchValues[ControlNames.BILLING_LAST_NAME_CONTROL] = paymentMethodPartial.billingLastName;
    patchValues[ControlNames.BILLING_PHONE_CONTROL] = paymentMethodPartial.billingPhone;
    patchValues[ControlNames.BANK_NAME_CONTROL] = paymentMethodPartial.bankName;
    patchValues[ControlNames.BILLING_ADDRESS_GROUP] = paymentMethodPartial.billingAddress;
    patchValues[ControlNames.CARD_NUMBER_CONTROL] = paymentMethodPartial.cardNumber;
    patchValues[ControlNames.CARD_EXPIRATION_CONTROL] = paymentMethodPartial.cardExpiration;
    patchValues[ControlNames.CARD_CVV_CONTROL] = paymentMethodPartial.cardCVV;
    patchValues[ControlNames.ACH_ACCOUNT_NUMBER_CONTROL] = paymentMethodPartial.accountNumber;
    patchValues[ControlNames.CONFIRM_ACH_ACCOUNT_NUMBER_CONTROL] = null;
    patchValues[ControlNames.ACH_ROUTING_NUMBER_CONTROL] = paymentMethodPartial.routingNumber;
    patchValues[ControlNames.CONFIRM_ACH_ROUTING_NUMBER_CONTROL] = null;
    patchValues[ControlNames.ACH_ACCOUNT_TYPE_CONTROL]
      = (!!paymentMethodPartial.achAccountType) ? paymentMethodPartial.achAccountType.persistenceId : null;
    patchValues[ControlNames.ACH_ACCOUNT_HOLDER_TYPE_CONTROL]
      = (!!paymentMethodPartial.achAccountHolderType) ? paymentMethodPartial.achAccountHolderType.persistenceId : null;
    patchValues[ControlNames.ACH_AUTHORIZED_BY_ACCOUNT_HOLDER_CONTROL] = paymentMethodPartial.achAuthorizedByAccountHolder;
    patchValues[ControlNames.ACH_SEC_CODE_CONTROL]
      = (!!paymentMethodPartial.achSecCode) ? paymentMethodPartial.achSecCode.persistenceId : null;

    return patchValues;
  }

  /**
   * Create a PaymentMethod instance from a PaymentMethodSelectionFormGroup.
   * @param group the PaymentMethodSelectionFormGroup that is the source of the values.
   * @return a PaymentMethod populated with the groups values.
   */
  public static createPaymentMethodFromGroup(group: PaymentMethodSelectionFormGroup): PaymentMethod {
    const paymentMethod: PaymentMethodImpl = new PaymentMethodImpl();

    paymentMethod.paymentPlanTypeId = group.paymentPlanTypeIdControl.value;
    paymentMethod.billingProfileId = group.billingProfileIdControl.value;
    paymentMethod.secondaryBillingPersonBillingProfileId = group.secondaryBillingPersonBillingProfileIdControl.value;

    paymentMethod.paymentChannelCode = PaymentChannelCode.valueOf(group.paymentChannelCodeControl.value);
    paymentMethod.personId = group.personControl.value;
    paymentMethod.billingFirstName = group.billingFirstNameControl.value;
    paymentMethod.billingLastName = group.billingLastNameControl.value;
    // We don't collect billingName, we generate it.
    // paymentMethod.billingName = group.billingNameControl.value;
    paymentMethod.billingName = `${paymentMethod.billingFirstName} ${paymentMethod.billingLastName}`;
    paymentMethod.billingPhone = group.billingPhoneControl.value;
    paymentMethod.bankName = group.bankNameControl.value;
    paymentMethod.safeId = group.safeIdControl.value;
    paymentMethod.cardNumber = group.cardNumberControl.value;
    paymentMethod.cardCVV = group.cardCVVControl.value;
    paymentMethod.cardExpiration = group.cardExpirationControl.value;
    paymentMethod.routingNumber = group.achRoutingNumberControl.value;
    paymentMethod.accountNumber = group.achAccountNumberControl.value;
    paymentMethod.achAccountType = AchAccountType.valueOf(group.achAccountTypeControl.value);
    paymentMethod.achAccountHolderType = AchAccountHolderType.valueOf(group.achAccountHolderTypeControl.value);
    paymentMethod.achAuthorizedByAccountHolder = group.achAuthorizedByAccountHolderControl.value;
    paymentMethod.achSecCode = AchSecCode.valueOf(group.achSecCodeControl.value);
    paymentMethod.billingAddress = PaymentMethodSelectionFormGroup.createBillingAddressFromGroup(group);
    return paymentMethod;
  }

  /**
   * Create a billing address Address instance from a PaymentMethodSelectionFormGroup.
   * @param group the PaymentMethodSelectionFormGroup that is the source of the values.
   * @return a billing address Address instance with the groups values.
   */
  public static createBillingAddressFromGroup(group: PaymentMethodSelectionFormGroup): Address {
    const billingAddress: Address = new AddressImpl();

    const billingAddressFormGroup: FormGroup = group.billingAddressGroup;
    billingAddress.street1 = billingAddressFormGroup.get('street1').value;
    billingAddress.street2 = billingAddressFormGroup.get('street2').value;
    billingAddress.city = billingAddressFormGroup.get('city').value;
    billingAddress.state = billingAddressFormGroup.get('state').value;
    billingAddress.zipCode = billingAddressFormGroup.get('zipCode').value;

    return billingAddress;
  }

  /**
   *
   * @param rootCleanupSubscription the subscription that will 'host' all of the new validation subscriptions generated for the component.
   * This is to support un-subscribing observables by the invoker, when appropriate.
   * @param options the configuration options for the root FormGroup.
   */
  constructor(rootCleanupSubscription: Subscription, options?: PaymentMethodSelectionFormGroupConfig) {
    options = checkNullsAndSetDefaults(options);

    const requiredValidatorFn = ConditionalValidator.conditionalRequire((() => options.isRequired));

    // A ValidatorActivationConfig that 'activates' validation when the currently selected create payment method requires Credit Card info.
    const creditCardActivationConfig = new ValidatorActivationConfig(
      () => {
        let activateValidation: boolean;
        const paymentMethodControl = this.get(ControlNames.PAYMENT_METHOD_CONTROL);
        activateValidation = PaymentMethodOption.isCreateCreditCardOption(paymentMethodControl.value);
        return activateValidation;
      },
      [ControlNames.PAYMENT_METHOD_CONTROL]
    );

    // A DynamicValidatorConfig that validates creditCard Number against currently selected credit card type.
    const validCreditCardNumberValidatorConfig = new DynamicValidatorConfig(
      (creditCardNumberCtl: FormControl): ValidationErrors | null => {
        let validationErrors: ValidationErrors;
        const paymentMethodControl = this.get(ControlNames.PAYMENT_METHOD_CONTROL);

        const paymentChannelCode = PaymentMethodOption.getCreateCreditCardPaymentChannelCode(paymentMethodControl.value);
        if (!!paymentChannelCode) {
          validationErrors = PaymentValidators.creditCardNumber(paymentChannelCode)(creditCardNumberCtl);
        } else {
          validationErrors = null;
        }
        return validationErrors;
      },
      [ControlNames.PAYMENT_METHOD_CONTROL]
    );

    // A DynamicValidatorConfig that validates creditCard CVV against currently selected credit card type.
    const validCreditCardCVVValidatorConfig = new DynamicValidatorConfig(
      (creditCardCVVCtl: FormControl): ValidationErrors | null => {
        let validationErrors: ValidationErrors;
        const paymentMethodControl = this.get(ControlNames.PAYMENT_METHOD_CONTROL);

        const paymentChannelCode = PaymentMethodOption.getCreateCreditCardPaymentChannelCode(paymentMethodControl.value);
        if (!!paymentChannelCode) {
          validationErrors = PaymentValidators.creditCardCVV(paymentChannelCode)(creditCardCVVCtl);
        } else {
          validationErrors = null;
        }
        return validationErrors;
      },
      [ControlNames.PAYMENT_METHOD_CONTROL]
    );

    // A ValidatorActivationConfig that 'activates' validation when the currently selected create payment method requires ACH info.
    const achActivationConfig = new ValidatorActivationConfig(
      () => {
        let activateValidation: boolean;
        const paymentMethodControl = this.get(ControlNames.PAYMENT_METHOD_CONTROL);
        activateValidation = PaymentMethodOption.isCreateACHOption(paymentMethodControl.value);
        return activateValidation;
      },
      [ControlNames.PAYMENT_METHOD_CONTROL]
    );

    // A ValidatorActivationConfig that 'activates' validation when the currently selected payment method requires Billing Info.
    const billingInfoActivationConfig = new ValidatorActivationConfig(
      () => {
        let activateValidation: boolean;
        const paymentMethodControl = this.get(ControlNames.PAYMENT_METHOD_CONTROL);
        const paymentChannelCode = PaymentMethodOption.getCreatePaymentChannelCode(paymentMethodControl.value);
        if (!!paymentChannelCode) {
          activateValidation = paymentChannelCode.isElectronic();
        } else {
          activateValidation = false;
        }
        return activateValidation;
      },
      [ControlNames.PAYMENT_METHOD_CONTROL]
    );

    const validatorRegistrar = new ValidatorRegistrar();

    const childControls: { [p: string]: AbstractControl } = {
      // hidden
      [ControlNames.PAYMENT_PLAN_TYPE_ID_CONTROL]: new FormControl(null, []),
      // hidden
      [ControlNames.BILLING_PROFILE_ID_CONTROL]: new FormControl(null, []),
      // hidden
      [ControlNames.SECONDARY_BILLING_PROFILE_ID_CONTROL]: new FormControl(null, []),
      // hidden
      [ControlNames.PAYMENT_CHANNEL_CODE_CONTROL]: new FormControl(null, []),
      // PERSON_CONTROL validator is added by the component because it requires information not available to this FormGroup.
      [ControlNames.PERSON_CONTROL]: new FormControl(null, []),
      // hidden
      [ControlNames.SAFE_ID_CONTROL]: new FormControl(null, []),
      // PAYMENT_METHOD_CONTROL validator is added by the component because it requires information not available to this FormGroup.
      [ControlNames.PAYMENT_METHOD_CONTROL]: new FormControl(null, []),
      [ControlNames.BILLING_FIRST_NAME_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        billingInfoActivationConfig,
        [Validators.required],
        []),
      [ControlNames.BILLING_LAST_NAME_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        billingInfoActivationConfig,
        [Validators.required],
        []),
      [ControlNames.BILLING_PHONE_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        billingInfoActivationConfig,
        [Validators.required, PatternValidators.phoneNumber()]
      ),
      [ControlNames.BANK_NAME_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        achActivationConfig,
        [Validators.required],
        []),
      [ControlNames.BILLING_ADDRESS_GROUP]: new AddressFormGroup(() => options.isRequired),
      [ControlNames.CARD_NUMBER_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        creditCardActivationConfig,
        [Validators.required],
        [validCreditCardNumberValidatorConfig]),
      [ControlNames.CARD_EXPIRATION_CONTROL]: (() => {
        const formControl = new FormControl(null);
        validatorRegistrar.registerValidators(formControl,
          creditCardActivationConfig,
          [Validators.required, PaymentValidators.creditCardDate()],
          []);
        return formControl;
      })(),
      [ControlNames.CARD_CVV_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        creditCardActivationConfig,
        [Validators.required],
        [validCreditCardCVVValidatorConfig]),
      [ControlNames.ACH_ROUTING_NUMBER_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        achActivationConfig,
        [Validators.required, PaymentValidators.achRoutingNumber()],
        []),
      // CONFIRM_ACH_ROUTING_NUMBER_CONTROL 'matches' validation is registered by the component.
      [ControlNames.CONFIRM_ACH_ROUTING_NUMBER_CONTROL]: new FormControl(null),

      [ControlNames.ACH_ACCOUNT_NUMBER_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        achActivationConfig,
        [Validators.required, PaymentValidators.achAccountNumber()],
        []),
      // CONFIRM_ACH_ACCOUNT_NUMBER_CONTROL validation is registered by the component.
      [ControlNames.CONFIRM_ACH_ACCOUNT_NUMBER_CONTROL]: new FormControl(null),

      [ControlNames.ACH_ACCOUNT_TYPE_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        achActivationConfig,
        [Validators.required],
        []),
      [ControlNames.ACH_ACCOUNT_HOLDER_TYPE_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        achActivationConfig,
        [Validators.required],
        []),
      // achAuthorizedByAccountHolder validator is added by the component because it requires information not available to this FormGroup.
      [ControlNames.ACH_AUTHORIZED_BY_ACCOUNT_HOLDER_CONTROL]: new FormControl(null),
      [ControlNames.ACH_SEC_CODE_CONTROL]: validatorRegistrar.registerValidators(new FormControl(null),
        achActivationConfig,
        [Validators.required],
        []),
    };

    if (options.isDisabled) {
      Object.values(childControls).forEach(_ => _.disable());
    }

    super(childControls);

    validatorRegistrar.applyRegistrations(this, rootCleanupSubscription);

    this.options = options;
  }

  patchValue(patchValue: { [key: string]: any; }): void {
    // Apply the registered top-level mapper to create the formGroup-appropriate patchValues from the given 'model'.
    const paymentMethodPatchValues = this.options.modelToPatchValuesMapper(patchValue);
    // 'Patch' the FormGroup with the values.
    super.patchValue(paymentMethodPatchValues);
  }

  getRawValue(): any {
    let model: any;
    model = this.options.valuesToModelMapper(this);
    return model;
  }

  get paymentPlanTypeIdControl(): FormControl {
    return this.get(ControlNames.PAYMENT_PLAN_TYPE_ID_CONTROL) as FormControl;
  }

  get billingProfileIdControl(): FormControl {
    return this.get(ControlNames.BILLING_PROFILE_ID_CONTROL) as FormControl;
  }

  get secondaryBillingPersonBillingProfileIdControl(): FormControl {
    return this.get(ControlNames.SECONDARY_BILLING_PROFILE_ID_CONTROL) as FormControl;
  }

  get paymentChannelCodeControl(): FormControl {
    return this.get(ControlNames.PAYMENT_CHANNEL_CODE_CONTROL) as FormControl;
  }
  get safeIdControl(): FormControl {
    return this.get(ControlNames.SAFE_ID_CONTROL) as FormControl;
  }

  /**
   * paymentMethodControl groups 'use existing Billing Profile' and 'create new BP via paymentChannelCode' options.
   */
  get paymentMethodControl(): FormControl {
    return this.get(ControlNames.PAYMENT_METHOD_CONTROL) as FormControl;
  }
  get personControl(): FormControl {
    return this.get(ControlNames.PERSON_CONTROL) as FormControl;
  }
  // get billingNameControl(): FormControl {
  //   return this.get(ControlNames.BILLING_NAME_CONTROL) as FormControl;
  // }
  get billingFirstNameControl(): FormControl {
    return this.get(ControlNames.BILLING_FIRST_NAME_CONTROL) as FormControl;
  }
  get billingLastNameControl(): FormControl {
    return this.get(ControlNames.BILLING_LAST_NAME_CONTROL) as FormControl;
  }
  get billingPhoneControl(): FormControl {
    return this.get(ControlNames.BILLING_PHONE_CONTROL) as FormControl;
  }
  get billingAddressGroup(): FormGroup {
    return this.get(ControlNames.BILLING_ADDRESS_GROUP) as FormGroup;
  }
  get cardNumberControl(): FormControl {
    return this.get(ControlNames.CARD_NUMBER_CONTROL) as FormControl;
  }
  get cardExpirationControl(): FormControl {
    return this.get(ControlNames.CARD_EXPIRATION_CONTROL) as FormControl;
  }
  get cardCVVControl(): FormControl {
    return this.get(ControlNames.CARD_CVV_CONTROL) as FormControl;
  }
  get achRoutingNumberControl(): FormControl {
    return this.get(ControlNames.ACH_ROUTING_NUMBER_CONTROL) as FormControl;
  }
  get confirmAchRoutingNumberControl(): FormControl {
    return this.get(ControlNames.CONFIRM_ACH_ROUTING_NUMBER_CONTROL) as FormControl;
  }
  get achAccountNumberControl(): FormControl {
    return this.get(ControlNames.ACH_ACCOUNT_NUMBER_CONTROL) as FormControl;
  }
  get confirmAchAccountNumberControl(): FormControl {
    return this.get(ControlNames.CONFIRM_ACH_ACCOUNT_NUMBER_CONTROL) as FormControl;
  }
  get achAccountTypeControl(): FormControl {
    return this.get(ControlNames.ACH_ACCOUNT_TYPE_CONTROL) as FormControl;
  }
  get achAccountHolderTypeControl(): FormControl {
    return this.get(ControlNames.ACH_ACCOUNT_HOLDER_TYPE_CONTROL) as FormControl;
  }
  get achAuthorizedByAccountHolderControl(): FormControl {
    return this.get(ControlNames.ACH_AUTHORIZED_BY_ACCOUNT_HOLDER_CONTROL) as FormControl;
  }
  get achSecCodeControl(): FormControl {
    return this.get(ControlNames.ACH_SEC_CODE_CONTROL) as FormControl;
  }
  get bankNameControl(): FormControl {
    return this.get(ControlNames.BANK_NAME_CONTROL) as FormControl;
  }
}

function checkNullsAndSetDefaults(options?: PaymentMethodSelectionFormGroupConfig): PaymentMethodSelectionFormGroupConfig {
  if (options === null || options === undefined) {
    options = {} as PaymentMethodSelectionFormGroupConfig;
  }
  setIfNullOrUndefined(options, 'isRequired', false);
  setIfNullOrUndefined(options, 'isDisabled', false);

  // Default mappers to/from PaymentMethod.
  setIfNullOrUndefined(options, 'modelToPatchValuesMapper', PaymentMethodSelectionFormGroup.createPatchValuesFromPaymentMethodPartial);
  setIfNullOrUndefined(options, 'valuesToModelMapper', PaymentMethodSelectionFormGroup.createPaymentMethodFromGroup);

  return options;
}

function setIfNullOrUndefined(
  options: PaymentMethodSelectionFormGroupConfig,
  key: keyof PaymentMethodSelectionFormGroupConfig,
  defaultValue: any
): void {
  if (options[key] === null || options[key] === undefined) {
    options[key] = defaultValue;
  }
}

