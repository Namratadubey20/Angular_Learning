/**
 * Enum implemented as class.
 */
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

@JsonObject('PaymentChannelType')
export class PaymentChannelType extends AbstractIdentifierEnum {
  private static _values: Map<string, PaymentChannelType> = new Map<string, PaymentChannelType>();
  public static ACH = new PaymentChannelType('ach', true, 'ach');
  public static CREDIT = new PaymentChannelType('credit', true, 'credit');
  public static PAPER_CHECK = new PaymentChannelType('paper_check', false, 'paper check');


  get isElectronic(): boolean {
    return this._electronic;
  }

  // We don't register defaultDisplayText with JSON->TypeScript lib as we don't need the server's value.
  get defaultDisplayText(): string {
    return this._defaultDisplayText;
  }

  private constructor(
    persistenceId: string, // Relates the enum with server representation.
    private _electronic: boolean,
    private _defaultDisplayText: string
  ) {
    super(persistenceId);
  }

  public static valueOf(persistenceId: string | undefined): PaymentChannelType {
    return PaymentChannelType._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): PaymentChannelType[] {
    return Array.from(PaymentChannelType._values.values());
  }

  protected registerEnum(): void {
    if (PaymentChannelType._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid PaymentChannelType 'enum' identifier: ${this.persistenceId}`);
    }
    PaymentChannelType._values.set(this.persistenceId, this);
  }
}

@JsonConverter
export class PaymentChannelTypeConverter extends AbstractIdentifierEnumConverter<PaymentChannelType> {
  deserialize(enumObject: any): PaymentChannelType {
    let enumInstance: PaymentChannelType;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = PaymentChannelType.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}
