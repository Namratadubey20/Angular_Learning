import { PaymentChannelCode } from '../payment_channel_code';
import { PaymentFrequencyType } from '../payment_frequency_type';
import { SpecHelpers } from '../../utils/spec-helpers';

export function someRandomPaymentChannelCode(): PaymentChannelCode {
  return SpecHelpers.someRandomElementFrom(PaymentChannelCode.values());
}

export function someRandomPaymentFrequencyType(): PaymentFrequencyType {
  return SpecHelpers.someRandomElementFrom(PaymentFrequencyType.values());
}
