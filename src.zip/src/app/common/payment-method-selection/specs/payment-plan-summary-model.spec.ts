import { JsonConvertService } from '../../utils/json-convert.service';
import { PaymentPlanSummaryModelImpl } from '../payment-plan-summary-model';
import { createPaymentPlanTypeModelImpl } from './payment-plan-type-model.spec';
import { createCreditCardBillingProfileModelImpl } from './billing-profile-model.spec';
import { SpecHelpers } from '../../utils/spec-helpers';
import moment = require('moment');
import { LocalDateConverter } from '../../utils/local-date-converter';

describe('PaymentPlanSummaryModelImpl', () => {
  const jsonConvert = new JsonConvertService().getJsonConvert();

  it('should have all its expected properties set when you instantiate it', () => {
    const impl = new PaymentPlanSummaryModelImpl();
    const expectedProperties = [
      'id',
      'productId',
      'startDate',
      'endDate',
      'purchaseAmount',
      'surchargeAmount',
      'totalAmount',
      'totalPaidAmount',
      'totalDueAmount',
      'nextPaymentDueAmount',
      'nextPaymentDueDate',
      'paymentPlanTypeModel',
      'billingProfileModel',
    ];

    expectedProperties.forEach(ep => {
      expect(impl.hasOwnProperty(ep)).toBeTruthy(`instance is missing property: ${ep}`);
    });
  });

  it('should serialize correctly to the expected server shape', () => {
    const durationDays = SpecHelpers.someRandomInt(0, 365);
    const startDate = SpecHelpers.someRandomStartOfDayDate();
    const endDate = moment(startDate).add(durationDays, 'day').toDate();
    const nextPaymentDueDate = moment(startDate).add(SpecHelpers.someRandomInt(0, durationDays), 'day').toDate();

    const impl = new PaymentPlanSummaryModelImpl();
    {
      impl.id = SpecHelpers.someRandomNumber();
      impl.startDate = startDate;
      impl.endDate = endDate;
      impl.productId = SpecHelpers.someRandomNumber();
      impl.purchaseAmount = SpecHelpers.someRandomNumber();
      impl.surchargeAmount = SpecHelpers.someRandomNumber();
      impl.totalAmount = SpecHelpers.someRandomNumber();
      impl.totalPaidAmount = SpecHelpers.someRandomNumber();
      impl.totalDueAmount = SpecHelpers.someRandomNumber();
      impl.nextPaymentDueAmount = SpecHelpers.someRandomNumber();
      impl.nextPaymentDueDate = nextPaymentDueDate;
      impl.paymentPlanTypeModel = createPaymentPlanTypeModelImpl();
      impl.billingProfileModel = createCreditCardBillingProfileModelImpl();
    }

    const ldc = new LocalDateConverter();

    const serialized = jsonConvert.serialize(impl);

    expect(serialized).toEqual({
      id: impl.id,
      productId: impl.productId,
      startDate: ldc.serialize(impl.startDate),
      endDate: ldc.serialize(impl.endDate),
      purchaseAmount: impl.purchaseAmount,
      surchargeAmount: impl.surchargeAmount,
      totalAmount: impl.totalAmount,
      totalPaidAmount: impl.totalPaidAmount,
      totalDueAmount: impl.totalDueAmount,
      nextPaymentDueAmount: impl.nextPaymentDueAmount,
      nextPaymentDueDate: ldc.serialize(impl.nextPaymentDueDate),
      paymentPlanTypeModel: jsonConvert.serialize(impl.paymentPlanTypeModel),
      billingProfileModel: jsonConvert.serialize(impl.billingProfileModel),
    });
  });


  it('should deserialize correctly from a given server shape', () => {
    const paymentPlanTypeModel = createPaymentPlanTypeModelImpl();
    const billingProfileModel = createCreditCardBillingProfileModelImpl();
    const durationDays = SpecHelpers.someRandomInt(0, 365);
    const startDate = SpecHelpers.someRandomStartOfDayDate();
    const endDate = moment(startDate).add(durationDays, 'day').toDate();
    const nextPaymentDueDate = moment(startDate).add(SpecHelpers.someRandomInt(0, durationDays), 'day').toDate();

    const ldc = new LocalDateConverter();

    const object = {
      'id': SpecHelpers.someRandomNumber(),
      'productId': SpecHelpers.someRandomNumber(),
      'startDate': ldc.serialize(startDate),
      'endDate': ldc.serialize(endDate),
      'purchaseAmount': SpecHelpers.someRandomNumber(),
      'surchargeAmount': SpecHelpers.someRandomNumber(),
      'totalAmount': SpecHelpers.someRandomNumber(),
      'totalPaidAmount': SpecHelpers.someRandomNumber(),
      'totalDueAmount': SpecHelpers.someRandomNumber(),
      'nextPaymentDueAmount': SpecHelpers.someRandomNumber(),
      'nextPaymentDueDate': ldc.serialize(nextPaymentDueDate),
      'paymentPlanTypeModel': jsonConvert.serialize(paymentPlanTypeModel),
      'billingProfileModel': jsonConvert.serialize(billingProfileModel),
    };

    const expected = new PaymentPlanSummaryModelImpl();
    {
      expected.id = object.id;
      expected.productId = object.productId;
      expected.startDate = startDate;
      expected.endDate = endDate;
      expected.purchaseAmount = object.purchaseAmount;
      expected.surchargeAmount = object.surchargeAmount;
      expected.totalAmount = object.totalAmount;
      expected.totalPaidAmount = object.totalPaidAmount;
      expected.totalDueAmount = object.totalDueAmount;
      expected.nextPaymentDueAmount = object.nextPaymentDueAmount;
      expected.nextPaymentDueDate = nextPaymentDueDate;
      expected.paymentPlanTypeModel = paymentPlanTypeModel;
      expected.billingProfileModel = billingProfileModel;
    }

    const actual = jsonConvert.deserialize(object, PaymentPlanSummaryModelImpl);

    expect(actual).toEqual(expected);
  });
});
