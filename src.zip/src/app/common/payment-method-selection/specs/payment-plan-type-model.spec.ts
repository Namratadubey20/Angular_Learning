import { JsonConvertService } from '../../utils/json-convert.service';
import {
  AppliedPaymentPlanTypeModelImpl,
  PaymentPlanTypeModelImpl,
} from '../payment-plan-type-model';
import { someRandomPaymentChannelCode, someRandomPaymentFrequencyType } from './spec-helpers';
import { SpecHelpers } from '../../utils/spec-helpers';

export function createPaymentPlanTypeModelImpl(): PaymentPlanTypeModelImpl {
  const impl = new PaymentPlanTypeModelImpl();
  populatePaymentPlanTypeModelImpl(impl);
  return impl;
}
export function populatePaymentPlanTypeModelImpl(impl: PaymentPlanTypeModelImpl): PaymentPlanTypeModelImpl {
  impl.id = SpecHelpers.someRandomNumber();
  impl.totalInstallments = SpecHelpers.someRandomNumber();
  impl.initialInstallments = SpecHelpers.someRandomNumber();
  impl.paymentChannelCode = someRandomPaymentChannelCode();
  impl.paymentFrequencyType = someRandomPaymentFrequencyType();
  return impl;
}

export function createAppliedPaymentPlanTypeModelImpl(): AppliedPaymentPlanTypeModelImpl {
  const impl = new AppliedPaymentPlanTypeModelImpl();
  populateAppliedPaymentPlanTypeModelImpl(impl);
  return impl;
}
export function populateAppliedPaymentPlanTypeModelImpl(impl: AppliedPaymentPlanTypeModelImpl): AppliedPaymentPlanTypeModelImpl {
  populatePaymentPlanTypeModelImpl(impl.paymentPlanTypeModel);
  impl.annualPremiumAmount = SpecHelpers.someRandomNumber();
  impl.initialAmount = SpecHelpers.someRandomNumber();
  impl.recurringAmount = SpecHelpers.someRandomNumber();
  impl.totalPlanAmount = SpecHelpers.someRandomNumber();
  return impl;
}

describe('PaymentPlanTypeModelImpl', () => {
  const jsonConvert = new JsonConvertService().getJsonConvert();

  it('should have all its expected properties set when you instantiate it', () => {
    const impl = new PaymentPlanTypeModelImpl();
    const expectedProperties = [
      'id',
      'totalInstallments',
      'initialInstallments',
      'paymentChannelCode',
      'paymentFrequencyType',
    ];

    expectedProperties.forEach(ep => {
      expect(impl.hasOwnProperty(ep)).toBeTruthy(`instance is missing property: ${ep}`);
    });
  });

  it('should serialize correctly to the expected server shape', () => {
    const impl = createPaymentPlanTypeModelImpl();

    const serialized = jsonConvert.serialize(impl);

    expect(serialized).toEqual({
      id: impl.id,
      totalInstallments: impl.totalInstallments,
      initialInstallments: impl.initialInstallments,
      paymentChannelCode: { 'persistenceId': impl.paymentChannelCode.persistenceId },
      paymentFrequencyType: { 'persistenceId': impl.paymentFrequencyType.persistenceId },
    });
  });


  it('should deserialize correctly from a given server shape', () => {
    const paymentChannelCode = someRandomPaymentChannelCode();
    const paymentFrequencyType = someRandomPaymentFrequencyType();
    const object = {
      'id': 1007,
      'totalInstallments': 12,
      'initialInstallments': 1,
      'paymentChannelCode': { 'persistenceId': paymentChannelCode.persistenceId },
      'paymentFrequencyType': { 'persistenceId': paymentFrequencyType.persistenceId },
    };

    const expected = new PaymentPlanTypeModelImpl();
    expected.id = object.id;
    expected.totalInstallments = object.totalInstallments;
    expected.initialInstallments = object.initialInstallments;
    expected.paymentChannelCode = paymentChannelCode;
    expected.paymentFrequencyType = paymentFrequencyType;

    const actual = jsonConvert.deserialize(object, PaymentPlanTypeModelImpl);

    expect(actual).toEqual(expected);
  });
});


describe('AppliedPaymentPlanTypeModelImpl', () => {
  const jsonConvert = new JsonConvertService().getJsonConvert();

  it('should have all its expected properties set when you instantiate it', () => {
    const impl = new AppliedPaymentPlanTypeModelImpl();
    {
      // from PaymentPlanTypeModelImpl
      const expectedProperties = [
        'id',
        'totalInstallments',
        'initialInstallments',
        'paymentChannelCode',
        'paymentFrequencyType',
      ];

      expectedProperties.forEach(ep => {
        expect(impl.paymentPlanTypeModel.hasOwnProperty(ep)).toBeTruthy(`instance is missing property: ${ep}`);
      });
    }
    {
      const expectedProperties = [
        // from AppliedPaymentPlanTypeModelImpl
        'annualPremiumAmount',
        'initialAmount',
        'recurringAmount',
        'totalPlanAmount',
      ];

      expectedProperties.forEach(ep => {
        expect(impl.hasOwnProperty(ep)).toBeTruthy(`instance is missing property: ${ep}`);
      });
    }
  });

  it('should serialize correctly to the expected server shape', () => {
    const impl = createAppliedPaymentPlanTypeModelImpl();

    const serialized = jsonConvert.serialize(impl);

    expect(serialized).toEqual({
      // from PaymentPlanTypeModelImpl
      paymentPlanType: {
        id: impl.paymentPlanTypeModel.id,
        totalInstallments: impl.paymentPlanTypeModel.totalInstallments,
        initialInstallments: impl.paymentPlanTypeModel.initialInstallments,
        paymentChannelCode: { 'persistenceId': impl.paymentPlanTypeModel.paymentChannelCode.persistenceId },
        paymentFrequencyType: { 'persistenceId': impl.paymentPlanTypeModel.paymentFrequencyType.persistenceId },
      },
      // from AppliedPaymentPlanTypeModelImpl
      annualPremiumAmount: impl.annualPremiumAmount,
      initialAmount: impl.initialAmount,
      recurringAmount: impl.recurringAmount,
      totalPlanAmount: impl.totalPlanAmount,
      paymentPlanInstallments: impl.paymentPlanInstallmentModels,
      paymentPlanLines: impl.paymentPlanLineModels,
    });
  });

  it('should deserialize correctly from a given server shape', () => {
    const paymentChannelCode = someRandomPaymentChannelCode();
    const paymentFrequencyType = someRandomPaymentFrequencyType();
    const object = {
      paymentPlanType: {
        'id': 1007,
        'totalInstallments': 12,
        'initialInstallments': 1,
        'paymentChannelCode': { 'persistenceId': paymentChannelCode.persistenceId },
        'paymentFrequencyType': { 'persistenceId': paymentFrequencyType.persistenceId },
      },
      'annualPremiumAmount': 234,
      'initialAmount': 100,
      'recurringAmount': 134,
      'totalPlanAmount': 234,
    };

    const expected = new AppliedPaymentPlanTypeModelImpl();
    {
      // from PaymentPlanTypeModelImpl
      expected.paymentPlanTypeModel.id = object.paymentPlanType.id;
      expected.paymentPlanTypeModel.totalInstallments = object.paymentPlanType.totalInstallments;
      expected.paymentPlanTypeModel.initialInstallments = object.paymentPlanType.initialInstallments;
      expected.paymentPlanTypeModel.paymentChannelCode = paymentChannelCode;
      expected.paymentPlanTypeModel.paymentFrequencyType = paymentFrequencyType;
      // from AppliedPaymentPlanTypeModelImpl
      expected.annualPremiumAmount = object.annualPremiumAmount;
      expected.initialAmount = object.initialAmount;
      expected.recurringAmount = object.recurringAmount;
      expected.totalPlanAmount = object.totalPlanAmount;
    }

    const actual = jsonConvert.deserialize(object, AppliedPaymentPlanTypeModelImpl);

    expect(actual).toEqual(expected);
  });
});
