import { BillingProfileModelImpl } from '../billing-profile-model';
import { AddressImpl } from '../../../enrollment/application/court/model/common/address';
import { AchAccountType } from '../ach_account_type';
import { PaymentChannelCode } from '../payment_channel_code';
import { AchAccountHolderType } from '../ach_account_holder_type';
import { AchSecCode } from '../ach_sec_code';
import { JsonConvertService } from '../../utils/json-convert.service';
import { SpecHelpers } from '../../utils/spec-helpers';

export function createCreditCardBillingProfileModelImpl(): BillingProfileModelImpl {
  const impl = new BillingProfileModelImpl();
  populateCreditCardBillingProfileModelImpl(impl);
  return impl;
}
export function createAchBillingProfileModelImpl(): BillingProfileModelImpl {
  const impl = new BillingProfileModelImpl();
  populateAchBillingProfileModelImpl(impl);
  return impl;
}
export function populateCreditCardBillingProfileModelImpl(impl: BillingProfileModelImpl): BillingProfileModelImpl {
  populateBillingProfileModelImpl(impl);
  impl.paymentChannelCode = PaymentChannelCode.AMEX;
  impl.cardNumber = '378282246310005';
  impl.cardCVV = '1234';
  impl.cardExpiration = '11/21';
  return impl;
}
export function populateAchBillingProfileModelImpl(impl: BillingProfileModelImpl): BillingProfileModelImpl {
  populateBillingProfileModelImpl(impl);
  impl.paymentChannelCode = PaymentChannelCode.ACH;
  impl.achAccountNumber = '666666';
  impl.achRoutingNumber = '123456789';
  impl.achAccountType = SpecHelpers.someRandomElementFrom(AchAccountType.values());
  impl.achAccountHolderType = SpecHelpers.someRandomElementFrom(AchAccountHolderType.values());
  impl.achSecCode = SpecHelpers.someRandomElementFrom(AchSecCode.values());
  impl.bankName = 'Some Bank';
  return impl;
}

export function populateBillingProfileModelImpl(impl: BillingProfileModelImpl): BillingProfileModelImpl {
  impl.billingProfileId = SpecHelpers.someRandomNumber();
  impl.personId = SpecHelpers.someRandomNumber();
  impl.billingFirstName = 'Some First Name';
  impl.billingLastName = 'Some Last Name';
  impl.billingName = impl.billingFirstName + ' ' + impl.billingLastName;
  impl.billingAddress = new AddressImpl();
  impl.billingPhone = SpecHelpers.someRandomPhoneNumber();
  return impl;
}

describe('BillingProfileModelImpl', () => {
  const jsonConvert = new JsonConvertService().getJsonConvert();

  it('should have all its expected properties set when you instantiate it', () => {
    const impl = new BillingProfileModelImpl();
    const expectedProperties = [
      'billingProfileId',
      'personId',
      'paymentChannelCode',
      'billingFirstName',
      'billingLastName',
      'billingName',
      'billingAddress',
      'billingPhone',
      'cardNumber',
      'cardCVV',
      'cardExpiration',
      'achAccountNumber',
      'achRoutingNumber',
      'achAccountType',
      'achAccountHolderType',
      'achSecCode',
      'bankName',
    ];

    expectedProperties.forEach(ep => {
      expect(impl.hasOwnProperty(ep)).toBeTruthy(`instance is missing property: ${ep}`);
    });
  });

  it('CreditCard BillingProfile should serialize correctly to the expected server shape', () => {
    const impl = createCreditCardBillingProfileModelImpl();

    const serialized = jsonConvert.serialize(impl);

    expect(serialized).toEqual({
      id: impl.billingProfileId,
      personId: impl.personId,
      paymentChannelCode: { 'persistenceId': impl.paymentChannelCode.persistenceId },
      billingFirstName: impl.billingFirstName,
      billingLastName: impl.billingLastName,
      billingName: impl.billingName,
      billingAddress: jsonConvert.serialize(impl.billingAddress),
      billingPhone: impl.billingPhone,
      cardNumber: impl.cardNumber,
      cardCVV: impl.cardCVV,
      cardExpiration: impl.cardExpiration,
      achAccountNumber: null,
      achRoutingNumber: null,
      achAccountType: null,
      achAccountHolderType: null,
      achSecCode: null,
      bankName: null,
      deactivationTimestamp: null,
    });
  });

  it('ACH BillingProfile should serialize correctly to the expected server shape', () => {
    const impl = createAchBillingProfileModelImpl();

    const serialized = jsonConvert.serialize(impl);

    expect(serialized).toEqual({
      id: impl.billingProfileId,
      personId: impl.personId,
      paymentChannelCode: { 'persistenceId': impl.paymentChannelCode.persistenceId },
      billingFirstName: impl.billingFirstName,
      billingLastName: impl.billingLastName,
      billingName: impl.billingName,
      billingAddress: jsonConvert.serialize(impl.billingAddress),
      billingPhone: impl.billingPhone,
      cardNumber: null,
      cardCVV: null,
      cardExpiration: null,
      achAccountNumber: impl.achAccountNumber,
      achRoutingNumber: impl.achRoutingNumber,
      achAccountType: { 'persistenceId': impl.achAccountType.persistenceId },
      achAccountHolderType: { 'persistenceId': impl.achAccountHolderType.persistenceId },
      achSecCode: { 'persistenceId': impl.achSecCode.persistenceId },
      bankName: impl.bankName,
      deactivationTimestamp: null,
    });
  });


  it('CreditCard BillingProfile should deserialize correctly from a given server shape', () => {

    const expected = createCreditCardBillingProfileModelImpl();

    const object = {
      'id': expected.billingProfileId,
      'personId': expected.personId,
      'paymentChannelCode': { 'persistenceId': expected.paymentChannelCode.persistenceId },
      'billingFirstName': expected.billingFirstName,
      'billingLastName': expected.billingLastName,
      'billingName': expected.billingName,
      'billingAddress': jsonConvert.serialize(expected.billingAddress),
      'billingPhone': expected.billingPhone,
      'cardNumber': expected.cardNumber,
      'cardCVV': expected.cardCVV,
      'cardExpiration': expected.cardExpiration,
      'achAccountNumber': null,
      'achRoutingNumber': null,
      'achAccountType': null,
      'achAccountHolderType': null,
      'achSecCode': null,
      'bankName': null,
    };

    const actual = jsonConvert.deserialize(object, BillingProfileModelImpl);

    expect(actual).toEqual(expected);
  });

  it('ACH BillingProfile should deserialize correctly from a given server shape', () => {

    const expected = createAchBillingProfileModelImpl();

    const object = {
      'id': expected.billingProfileId,
      'personId': expected.personId,
      'paymentChannelCode': { 'persistenceId': expected.paymentChannelCode.persistenceId },
      'billingFirstName': expected.billingFirstName,
      'billingLastName': expected.billingLastName,
      'billingName': expected.billingName,
      'billingAddress': jsonConvert.serialize(expected.billingAddress),
      'billingPhone': expected.billingPhone,
      'cardNumber': null,
      'cardCVV': null,
      'cardExpiration': null,
      'achAccountNumber': expected.achAccountNumber,
      'achRoutingNumber': expected.achRoutingNumber,
      'achAccountType': { 'persistenceId': expected.achAccountType.persistenceId },
      'achAccountHolderType': { 'persistenceId': expected.achAccountHolderType.persistenceId },
      'achSecCode': { 'persistenceId': expected.achSecCode.persistenceId },
      'bankName': expected.bankName,
    };

    const actual = jsonConvert.deserialize(object, BillingProfileModelImpl);

    expect(actual).toEqual(expected);
  });
});

