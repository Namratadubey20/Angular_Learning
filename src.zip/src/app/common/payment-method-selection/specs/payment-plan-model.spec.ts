import { JsonConvertService } from '../../utils/json-convert.service';
import { createPaymentPlanTypeModelImpl } from './payment-plan-type-model.spec';
import { createCreditCardBillingProfileModelImpl } from './billing-profile-model.spec';
import { DateConverter } from '../../utils/date-converter';
import { PaymentPlanModelImpl } from '../payment-plan-model';
import { SpecHelpers } from '../../utils/spec-helpers';

describe('PaymentPlanModelImpl', () => {
  const jsonConvert = new JsonConvertService().getJsonConvert();

  it('should have all its expected properties set when you instantiate it', () => {
    const impl = new PaymentPlanModelImpl();
    const expectedProperties = [
      'id',
      'productId',
      'purchaseAmount',
      'surchargeAmount',
      'totalAmount',
      'totalPaidAmount',
      'totalDueAmount',
      'nextPaymentDueAmount',
      'nextPaymentDueDate',
      'paymentPlanTypeModel',
      'billingProfileModel',
    ];

    expectedProperties.forEach(ep => {
      expect(impl.hasOwnProperty(ep)).toBeTruthy(`instance is missing property: ${ep}`);
    });
  });

  it('should serialize correctly to the expected server shape', () => {
    const impl = new PaymentPlanModelImpl();
    {
      impl.id = SpecHelpers.someRandomNumber();
      impl.productId = SpecHelpers.someRandomNumber();
      impl.purchaseAmount = SpecHelpers.someRandomNumber();
      impl.surchargeAmount = SpecHelpers.someRandomNumber();
      impl.totalAmount = SpecHelpers.someRandomNumber();
      impl.totalPaidAmount = SpecHelpers.someRandomNumber();
      impl.totalDueAmount = SpecHelpers.someRandomNumber();
      impl.nextPaymentDueAmount = SpecHelpers.someRandomNumber();
      impl.nextPaymentDueDate = SpecHelpers.someRandomDate();
      impl.paymentPlanTypeModel = createPaymentPlanTypeModelImpl();
      impl.billingProfileModel = createCreditCardBillingProfileModelImpl();
    }

    const dc = new DateConverter();

    const serialized = jsonConvert.serialize(impl);

    expect(serialized).toEqual({
      id: impl.id,
      productId: impl.productId,
      startDate: null,
      endDate: null,
      purchaseAmount: impl.purchaseAmount,
      surchargeAmount: impl.surchargeAmount,
      totalAmount: impl.totalAmount,
      totalPaidAmount: impl.totalPaidAmount,
      totalDueAmount: impl.totalDueAmount,
      nextPaymentDueAmount: impl.nextPaymentDueAmount,
      nextPaymentDueDate: dc.serialize(impl.nextPaymentDueDate),
      paymentPlanTypeModel: jsonConvert.serialize(impl.paymentPlanTypeModel),
      billingProfileModel: jsonConvert.serialize(impl.billingProfileModel),
      paymentPlanInstallmentModels: [],
      paymentPlanLineModels: [],
      paymentModels: [],
    });
  });


  it('should deserialize correctly from a given server shape', () => {
    const paymentPlanTypeModel = createPaymentPlanTypeModelImpl();
    const billingProfileModel = createCreditCardBillingProfileModelImpl();
    const nextPaymentDueDate = SpecHelpers.someRandomDate();

    const dc = new DateConverter();

    const object = {
      'id': SpecHelpers.someRandomNumber(),
      'productId': SpecHelpers.someRandomNumber(),
      'startDate': null,
      'endDate': null,
      'purchaseAmount': SpecHelpers.someRandomNumber(),
      'surchargeAmount': SpecHelpers.someRandomNumber(),
      'totalAmount': SpecHelpers.someRandomNumber(),
      'totalPaidAmount': SpecHelpers.someRandomNumber(),
      'totalDueAmount': SpecHelpers.someRandomNumber(),
      'nextPaymentDueAmount': SpecHelpers.someRandomNumber(),
      'nextPaymentDueDate': dc.serialize(nextPaymentDueDate),
      'paymentPlanTypeModel': jsonConvert.serialize(paymentPlanTypeModel),
      'billingProfileModel': jsonConvert.serialize(billingProfileModel),
      'paymentPlanInstallmentModels': [],
      'paymentPlanLineModels': [],
      'paymentModels': [],
    };

    const expected = new PaymentPlanModelImpl();
    {
      expected.id = object.id;
      expected.productId = object.productId;
      expected.startDate = object.startDate;
      expected.endDate = object.endDate;
      expected.purchaseAmount = object.purchaseAmount;
      expected.surchargeAmount = object.surchargeAmount;
      expected.totalAmount = object.totalAmount;
      expected.totalPaidAmount = object.totalPaidAmount;
      expected.totalDueAmount = object.totalDueAmount;
      expected.nextPaymentDueAmount = object.nextPaymentDueAmount;
      expected.nextPaymentDueDate = nextPaymentDueDate;
      expected.paymentPlanTypeModel = paymentPlanTypeModel;
      expected.billingProfileModel = billingProfileModel;
    }

    const actual = jsonConvert.deserialize(object, PaymentPlanModelImpl);

    expect(actual).toBeDefined();
  });
});
