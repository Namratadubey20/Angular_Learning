/**
 * Enum implemented as class.
 */
import { JsonConverter, JsonObject } from 'json2typescript';
import { AbstractIdentifierEnum, AbstractIdentifierEnumConverter } from '../utils/abstract-identifier-enum';

@JsonObject('PaymentFrequencyType')
export class PaymentFrequencyType extends AbstractIdentifierEnum {
  private static _values: Map<string, PaymentFrequencyType> = new Map<string, PaymentFrequencyType>();
  public static YEARLY = new PaymentFrequencyType('yearly', 'Yearly');
  public static MONTHLY = new PaymentFrequencyType('monthly', 'Monthly');

  // We don't register defaultDisplayText with JSON->TypeScript lib as we don't need the server's value.
  get defaultDisplayText(): string {
    return this._defaultDisplayText;
  }

  private constructor(
    persistenceId: string,
    private _defaultDisplayText: string
  ) {
    super(persistenceId);
  }

  public static valueOf(persistenceId: string | undefined): PaymentFrequencyType {
    return PaymentFrequencyType._values.get(persistenceId);
  }

  /**
   * Returns a copy of the array of enum values.
   */
  public static values(): PaymentFrequencyType[] {
    return Array.from(PaymentFrequencyType._values.values());
  }

  protected registerEnum(): void {
    if (PaymentFrequencyType._values.has(this.persistenceId)) {
      throw new TypeError(`Invalid PaymentFrequencyType 'enum' identifier: ${this.persistenceId}`);
    }
    PaymentFrequencyType._values.set(this.persistenceId, this);
  }
}

@JsonConverter
export class PaymentFrequencyTypeConverter extends AbstractIdentifierEnumConverter<PaymentFrequencyType> {
  deserialize(enumObject: any): PaymentFrequencyType {
    let enumInstance: PaymentFrequencyType;
    const persistenceId = AbstractIdentifierEnum.extractPersistenceId(enumObject);
    if (!!persistenceId) {
      enumInstance = PaymentFrequencyType.valueOf(persistenceId);
    } else {
      enumInstance = null;
    }
    return enumInstance;
  }
}
