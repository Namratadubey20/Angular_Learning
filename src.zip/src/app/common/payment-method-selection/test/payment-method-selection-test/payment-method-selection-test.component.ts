import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-payment-method-selection-test',
  templateUrl: './payment-method-selection-test.component.html',
  styleUrls: ['./payment-method-selection-test.component.css'],
})
export class PaymentMethodSelectionTestComponent implements OnInit {

  paymentMethodFormGroup: FormGroup;

  populatedPaymentMethodFormGroup: FormGroup;

  constructor(public fb: FormBuilder) { }

  ngOnInit() {
    this.paymentMethodFormGroup = this.fb.group({
      paymentMethod: [null, Validators.required],
      billingName: [null],
      billingPhone: [null],
      cardNumber: [null],
      cardExpiration: [null],
      cardCVV: [null],
      billingAddress: this.fb.group({
        street1: [null, [Validators.maxLength(60)]],
        street2: [null, [Validators.maxLength(60)]],
        city: [null, [Validators.maxLength(30)]],
        state: [null],
        zipCode: [null],
      }),
    });

    this.populatedPaymentMethodFormGroup = this.fb.group({
      paymentMethod: ['visa', Validators.required],
      billingName: ['Jay El'],
      billingPhone: ['1231231122'],
      cardNumber: ['4111111111111111'],
      cardExpiration: ['10/22'],
      cardCVV: ['1234'],
      billingAddress: this.fb.group({
        street1: ['123 Street St', [Validators.maxLength(60)]],
        street2: ['Apt 213', [Validators.maxLength(60)]],
        city: ['Pittsburgh', [Validators.maxLength(30)]],
        state: ['PA'],
        zipCode: ['15203'],
      }),
    });
  }


  printFormValue() {
  }
}
