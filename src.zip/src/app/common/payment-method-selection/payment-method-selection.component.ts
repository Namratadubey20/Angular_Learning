import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup, ValidationErrors, Validators,
} from '@angular/forms';
import { PaymentMethodSelectionService } from './payment-method-selection.service';
import { AppliedPaymentPlanTypeModel, PaymentPlanTypeModel } from './payment-plan-type-model';
import { BillingProfileModel } from './billing-profile-model';
import { PaymentMethodSelectionFormGroup } from './payment-method-selection-form-group';
import { PaymentChannelType } from './payment_channel_type';
import { PaymentChannelCode } from './payment_channel_code';
import { PaymentFrequencyType } from './payment_frequency_type';
import { PaymentMethodOption } from './payment-method-option';
import { PaymentPlanOption } from './payment-plan-option';
import { AchAccountHolderType } from './ach_account_holder_type';
import { AchAccountType } from './ach_account_type';
import { AchSecCode } from './ach_sec_code';
import { SecurityService } from '../../security/security.service';
import { BillingPerson, BillingPersonImpl, RolePaymentDefinition, RoleTexts } from './billing-person';
import 'rxjs-compat/add/observable/defer';
import { PaymentMethodInitializationData } from './payment-method-initialization-data';
import { Subscription, zip } from 'rxjs';
import { UserService } from '../../security/user.service';
import { ConfirmationDialogComponent, DialogData } from '../confirmation-dialog/confirmation-dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ConditionalValidator } from '../validators/conditional-validator';
import { IdentifierEnumUtils } from '../utils/identifier-enum-utils';
import { ConfirmationFieldValidators } from './confirmation-field-validators';
import { ErrorFieldName } from '../field-errors/error-field-name';

class BillingProfileMode {
  constructor(public canCreate: boolean, public canEdit: boolean, public canSelect: boolean) {
  }

  get isCanCreateOrEditOrSelect(): boolean {
    let isCan;
    isCan = this.isCanCreateOrEdit || this.canSelect;
    return isCan;
  }

  get isCanCreateOrEdit(): boolean {
    let isCan;
    isCan = this.canCreate || this.canEdit;
    return isCan;
  }
}

@Component({
  selector: 'app-payment-method-selection',
  templateUrl: './payment-method-selection.component.html',
  styleUrls: ['./payment-method-selection.component.scss'],
})
/**
 * Used for rendering payment information
 */
export class PaymentMethodSelectionComponent implements OnInit, OnDestroy {
  public static readonly PAYMENT_FREQUENCY_CONTROL = 'paymentFrequencyControl';

  @Input() paymentMethodFormGroup: PaymentMethodSelectionFormGroup;
  @Input() showSchedule = false;
  @Input() required = false;
  @Input() productId?: number; // Available only while 'processing' a product, e.g. renewing a product.
  @Input() applicationId?: number; // Available only while 'processing' an application or product.
  @Input() paymentMethodInitializationData: PaymentMethodInitializationData;

  // Overarching BillingProfile 'modes' independent of current state of component.
  globalBillingProfileMode: BillingProfileMode;

  paymentPlanTypeModels: PaymentPlanTypeModel[]; // Always available, either paymentPlanTypeModels or appliedPaymentPlanTypeModels.
  appliedPaymentPlanTypeModels?: AppliedPaymentPlanTypeModel[]; // Available only in the context of an application.

  activePaymentChannelCodePaymentMethodOptions: PaymentMethodOption[] = []; // available paymentChannelCode-specific PaymentMethodOptions
  allPaymentChannelCodePaymentMethodOptions: PaymentMethodOption[] = []; // all paymentChannelCode-specific PaymentMethodOptions

  activeBillingProfilePaymentMethodOptions: PaymentMethodOption[] = []; // available billingProfile-specific PaymentMethodOptions

  paymentPlanOptions: PaymentPlanOption[] = [];

  // Primary source of billing information once BillingPerson$ have been resolved.
  primaryBillingPerson: BillingPerson | undefined;
  // Secondary source of billing information once BillingPerson$ have been resolved.
  secondaryBillingPerson: BillingPerson | null | undefined;
  // Map of BillingProfile id to BillingProfileModel.
  idToBillingProfile: Map<number, BillingProfileModel> = new Map<number, BillingProfileModel>();

  changeBillingPersonText?: string; // Message to be displayed near billing-person selection.
  // Keeps track of whether the form can be/ should be processed for Billing Profile creation.
  processPaymentInformationValue = false;

  private _rootCleanupSubscription: Subscription = new Subscription();

  readonly achAccountTypes = IdentifierEnumUtils.orderByDisplayPrecedence(
    [
      AchAccountType.CHECKING,
      AchAccountType.SAVINGS,
    ], AchAccountType.values());

  readonly achAccountHolderTypes = IdentifierEnumUtils.orderByDisplayPrecedence(
    [
      AchAccountHolderType.PERSONAL,
      AchAccountHolderType.BUSINESS,
    ], AchAccountHolderType.values());

  constructor(
    private paymentMethodService: PaymentMethodSelectionService,
    private securityService: SecurityService,
    private userService: UserService,
    public confirmChangeBillingPersonDialog: MatDialog
  ) {
  }

  async ngOnInit() {
    // payment frequency
    this.paymentMethodFormGroup.addControl(PaymentMethodSelectionComponent.PAYMENT_FREQUENCY_CONTROL
      , new FormControl(null));

    this.processPaymentInformationValue = false;

    // Get BillingProfile server-updates when selected billingProfileId changes.
    // This ensures that we have the billingProfileModel for the selected billingProfileId
    // which we might not have because it is the result of a server submission of new payment info.
    this._rootCleanupSubscription.add(
      this.billingProfileIdControl.valueChanges.subscribe(billingProfileId => this.onValueChangeBillingProfileId(billingProfileId))
    );
    this._rootCleanupSubscription.add(
      this.paymentMethodFormGroup.valueChanges.subscribe(() => this.onValueChangePaymentMethodFormGroup())
    );

    if (!!this.applicationId && !!this.productId) {
      this.initializeForProductRenewal();
    } else if (!!this.applicationId) {
      this.initializeForApplication();
    } else {
      this.initializeForBillingProfileCRUD();
    }

    this.addConditionalValidation();
  }

  ngOnDestroy(): void {
    this._rootCleanupSubscription.unsubscribe();
  }

  async initializeForApplication() {
    this.globalBillingProfileMode = new BillingProfileMode(true, false, true);
    // Retrieve PaymentPlanType info as applied to this application's premium, etc.
    const appliedPaymentPlanTypeModels: AppliedPaymentPlanTypeModel[] =
      await this.paymentMethodService.getApplicationAppliedPaymentPlanTypes(this.applicationId).toPromise();

    this.initializeForApplicationOrProductRenewal(appliedPaymentPlanTypeModels);
  }

  async initializeForProductRenewal() {
    this.globalBillingProfileMode = new BillingProfileMode(true, false, true);
    // Retrieve PaymentPlanType info as applied to this products's premium, etc.
    const appliedPaymentPlanTypeModels: AppliedPaymentPlanTypeModel[] =
      await this.paymentMethodService.getProductAppliedPaymentPlanTypes(this.productId).toPromise();

    this.initializeForApplicationOrProductRenewal(appliedPaymentPlanTypeModels);
  }

  async initializeForBillingProfileCRUD() {
    this.globalBillingProfileMode = new BillingProfileMode(true, true, false);
    // Retrieve PaymentPlanType info in effect and not specific to an application.
    this.paymentPlanTypeModels =
      await this.paymentMethodService.getPaymentPlanTypes(new Date()).toPromise();

    this.appliedPaymentPlanTypeModels = undefined;

    // Create the PaymentChannel options.
    this.allPaymentChannelCodePaymentMethodOptions = this.createPaymentChannelCodePaymentMethodOptions(this.paymentPlanTypeModels);

    this.paymentPlanOptions = this.createPaymentPlanOptions(this.paymentPlanTypeModels);
  }

  async initializeForApplicationOrProductRenewal(appliedPaymentPlanTypeModels: AppliedPaymentPlanTypeModel[]) {

    this.appliedPaymentPlanTypeModels = appliedPaymentPlanTypeModels;
    this.paymentPlanTypeModels = appliedPaymentPlanTypeModels.map(apptModel => apptModel.paymentPlanTypeModel);

    // Create the (static) PaymentChannelCode-based options.
    this.allPaymentChannelCodePaymentMethodOptions = this.createPaymentChannelCodePaymentMethodOptions(this.paymentPlanTypeModels);

    // Create the PaymentPlan options.
    this.paymentPlanOptions = this.createPaymentPlanOptions(this.paymentPlanTypeModels);

    // if there's a paymentPlanTypeId then we should populate the paymentFrequencyControl.
    if (!!this.paymentPlanTypeIdControl.value) {
      const currentPaymentPlanTypeId = +this.paymentPlanTypeIdControl.value;
      const toSelectAppliedPaymentPlanTypeModel = this.paymentPlanTypeModels
        .find((pptModel) => pptModel.id === currentPaymentPlanTypeId);
      const toSelectOptionValue = PaymentPlanOption.createPaymentPlanOptionOptionValue(toSelectAppliedPaymentPlanTypeModel);
      this.paymentFrequencyControl.setValue(toSelectOptionValue);
    }

    // We have an application or product, therefore we need to manage BillingPersons/BillingProfiles.
    {
      // Fetch the relevant BillingPersons.
      await this.fetchBillingPersons();

      let loadedSecondaryBillingProfiles = false;

      if (!!this.secondaryBillingPerson) {
        // We have an explicit secondaryBillingPerson so remove implicit secondaryBillingPersonBillingProfileId, if any.
        this.secondaryBillingPersonBillingProfileIdControl.setValue(null, { onlySelf: true, emitEvent: false });
      } else {
        if (!!this.secondaryBillingPersonBillingProfileId) {
          // We don't have an explicit secondaryBillingPerson but rather one implied by the secondaryBillingPersonBillingProfileId.
          this.secondaryBillingPerson = undefined; // For now...

          const secondaryBillingPersonBillingProfile =
            await this.paymentMethodService.getApplicationPaymentBillingProfile(this.applicationId,
              this.secondaryBillingPersonBillingProfileId).toPromise();
          loadedSecondaryBillingProfiles = true; // Fetched the only BillingProfile we need for the secondary BillingPerson.
          this.registerBillingProfileModels(secondaryBillingPersonBillingProfile);

          const secondaryBillingPersonUser =
            await this.userService.getUserByPersonId(secondaryBillingPersonBillingProfile.personId);

          this.secondaryBillingPerson = BillingPersonImpl.createBillingPersonFromUser(secondaryBillingPersonUser);
        } else {
          // No secondary billingPerson, implicit or explicit.
          this.secondaryBillingPerson = null;
          this.personControl.setValue(this.primaryBillingPersonId);
          loadedSecondaryBillingProfiles = true;
        }
      }

      if (!!this.primaryBillingPerson && !!this.secondaryBillingPerson) {
        if (this.primaryBillingPerson.personId === this.secondaryBillingPerson.personId) {
          this.secondaryBillingPerson = null;
        }
      }

      // Fetch Primary Person BillingProfiles
      if (!!this.primaryBillingPersonId) {
        const primaryBillingPersonBillingProfiles =
          await this.paymentMethodService.getOptionBillingProfilesForPerson(this.primaryBillingPersonId).toPromise();
        this.registerBillingProfileModels(primaryBillingPersonBillingProfiles);
      }

      // Fetch Secondary Person BillingProfiles
      if (!loadedSecondaryBillingProfiles) {
        if (!!this.secondaryBillingPersonId) {
          const secondaryBillingPersonBillingProfiles =
            await this.paymentMethodService.getOptionBillingProfilesForPerson(this.secondaryBillingPersonId).toPromise();
          this.registerBillingProfileModels(secondaryBillingPersonBillingProfiles);
          loadedSecondaryBillingProfiles = true;
        }
      }

      // At this point we have all of the valid option BillingProfiles for both billing persons.
      // However, we might not have the currently selected BillingProfile if it is no longer a valid option.
      // If so, we'll get it later.
    }

    // Don't set 'determineDefault' option to true. DefaultPaymentMethodOption must be processed after initial 'evaluate' completes.
    this.evaluate({ determineDefault: false });

    this.selectDefaultPaymentMethodOption();
  }

  addConditionalValidation(): void {
    {
      // Billing Person is required when there are several billing persons.
      // Validation is not based on the value of any control.
      this.personControl.setValidators(
        ConditionalValidator.conditionalRequire(
          () => this.required && this.haveSecondaryBillingPerson)
      );
    }
    {
      // PaymentMethod is required (asConfigured).
      // PaymentMethod option must be 'acceptable'.
      this.paymentMethodControl.setValidators(
        [
          ConditionalValidator.conditionalRequire(() => this.required),
          (): ValidationErrors | null => {
            let validationErrors: ValidationErrors = null;
            const unacceptableOptionMessage = this.getSelectedPaymentMethodUnacceptableOptionMessage();
            if (!!unacceptableOptionMessage) {
              validationErrors = {
                [ErrorFieldName.FormError]: unacceptableOptionMessage,
              };
            }
            return validationErrors;
          },
        ]);
    }
    {
      // ACH Authorization is required if paying by an existing or yet-to-created ACH method.
      // Validation is based on the value of paymentMethodControl.
      this.achAuthorizedByAccountHolderControl.setValidators(
        ConditionalValidator.conditionalValidator(
          () => this.isCollectAchAuthorizedByAccountHolder()
          , Validators.requiredTrue)
      );
      this.paymentMethodControl.valueChanges.subscribe(() => this.achAuthorizedByAccountHolderControl.updateValueAndValidity());
    }

    {
      // confirmAchRoutingNumberControl validation.
      // Validation is based on the value of achRoutingNumberControl.
      // Validation is based on the value of paymentMethodControl.
      const primaryControl = this.achRoutingNumberControl;
      const confirmationControl = this.confirmAchRoutingNumberControl;
      const errorKey = ErrorFieldName.MatchValue;
      const errorValue = 'Routing Number';
      confirmationControl.setValidators([
        ConditionalValidator.conditionalRequire(() => this.isCollectAchInfoOption()),
        ConditionalValidator.conditionalValidator(
          () => this.isCollectAchInfoOption()
          , ConfirmationFieldValidators.confirmationValueMatches(primaryControl, errorKey, errorValue)),
      ]
      );
      primaryControl.valueChanges.subscribe(() => confirmationControl.updateValueAndValidity());
      this.paymentMethodControl.valueChanges.subscribe(() => confirmationControl.updateValueAndValidity());
    }

    {
      // confirmAchAccountNumberControl validation.
      // Validation is based on the value of achAccountNumberControl.
      // Validation is based on the value of paymentMethodControl.
      const primaryControl = this.achAccountNumberControl;
      const confirmationControl = this.confirmAchAccountNumberControl;
      const errorKey = ErrorFieldName.MatchValue;
      const errorValue = 'Account Number';
      confirmationControl.setValidators([
        ConditionalValidator.conditionalRequire(() => this.isCollectAchInfoOption()),
        ConditionalValidator.conditionalValidator(
          () => this.isCollectAchInfoOption()
          , ConfirmationFieldValidators.confirmationValueMatches(primaryControl, errorKey, errorValue)),
      ]
      );
      primaryControl.valueChanges.subscribe(() => confirmationControl.updateValueAndValidity());
      this.paymentMethodControl.valueChanges.subscribe(() => confirmationControl.updateValueAndValidity());
    }
  }

  /**
 * Handles any change, user-initiated or otherwise, on the billingProfileId control.
 * @param billingProfileId
 */
  async onValueChangeBillingProfileId(billingProfileId) {
    // We only handle the case whereby we don't already have the billingProfile.
    // Get BillingProfile server-updates when selected billingProfileId changes.
    // This ensures that we have the billingProfileModel for the newly created/selected billingProfile
    if (!!billingProfileId) {
      const billingProfile = this.findBillingProfileModel(billingProfileId);
      if (!billingProfile) {
        // We don't already have the billingProfile, so retrieve it.
        let retrievedBillingProfile: BillingProfileModel;
        if (!!this.applicationId) {
          // In the case of an application, use the 'broader' BillingProfile retrieval
          // to include retrieval of a BillingProfile that may have been 'loaned' just for this application.
          retrievedBillingProfile =
            await this.paymentMethodService.getApplicationPaymentBillingProfile(this.applicationId, billingProfileId).toPromise();
        } else {
          // Restrict the BillingProfile retrieval to just those defined for the current user.
          retrievedBillingProfile =
            await this.paymentMethodService.getBillingProfile(billingProfileId).toPromise();
        }
        this.registerBillingProfileModels(retrievedBillingProfile);
        this.evaluate({ isNewlyCreatedBillingProfile: true });
      }
    }
  }

  onValueChangePaymentMethodFormGroup() {
    // Evaluate if the form's current state is suitable for processing of payment information.
    const currentProcessPaymentInformationValue = this.processPaymentInformationValue;
    if (this.paymentMethodFormGroup.dirty && this.paymentMethodFormGroup.valid) {
      const paymentMethodOptionValue = this.paymentMethodControl.value;
      if (PaymentMethodOption.isCreatePaymentChannelCodeOption(paymentMethodOptionValue)) {
        this.processPaymentInformationValue = true;
      }
    }

    if (currentProcessPaymentInformationValue !== this.processPaymentInformationValue) {
      this.paymentMethodInitializationData.processPaymentInformation$.next(this.processPaymentInformationValue);
    }
  }

  /**
   * Handles a user-initiated change-event on the person control.
   * @param event
   */
  onUserChangePerson(event: any) {
    // Build the change BillingPerson confirmation alert message.
    if (!!this.secondaryBillingPerson) {
      this.displayChangeBillingPersonConfirmationDialog();
    }
  }

  /**
   * Handles a user-initiated change-event on the payment method control.
   * @param event
   */
  onUserChangePaymentMethodOption(event: any) {
    this.applyPaymentMethodOptionChange(this.paymentMethodControl.value);
  }

  private applyPaymentMethodOptionChange(paymentMethodOptionValue: string) {
    let toSelectPaymentChannelCodeId: string | null;
    let toSelectBillingProfileId: number | null;
    if (PaymentMethodOption.isCreatePaymentChannelCodeOption(paymentMethodOptionValue)) {
      toSelectPaymentChannelCodeId = PaymentMethodOption.extractOptionId(paymentMethodOptionValue);
      toSelectBillingProfileId = null;
    } else if (PaymentMethodOption.isBillingProfileOption(paymentMethodOptionValue)) {
      toSelectPaymentChannelCodeId = null;
      toSelectBillingProfileId = PaymentMethodOption.getBillingProfileId(paymentMethodOptionValue);
    } else {
      toSelectPaymentChannelCodeId = null;
      toSelectBillingProfileId = null;
    }
    this.paymentChannelCodeControl.setValue(toSelectPaymentChannelCodeId, { onlySelf: true, emitEvent: false });
    this.billingProfileIdControl.setValue(toSelectBillingProfileId, { onlySelf: true, emitEvent: false });

    this.evaluate({});
  }

  /**
   * Initializes asynchronous data and updates UI.
   * @param options.
   *
   * * `isNewlyCreatedBillingProfile`: hack to support preserving state for a newly created BillingProfile.
   * When true, some current values are preserved across the submission of a 'create new Billing Profile'.
   * * `determineDefault`: When true, determine a default for the PaymentMethod.
   */
  async evaluate(options?: {
    isNewlyCreatedBillingProfile?: boolean;
    determineDefault?: boolean;

  }) {
    const isNewlyCreatedBillingProfile = !!options && !!options.isNewlyCreatedBillingProfile;
    const determineDefault = !!options && !!options.determineDefault;

    // Resolve the selected BillingProfile.
    let selectedBillingProfile: BillingProfileModel | null;
    {
      const selectedBillingProfileId = this.selectedBillingProfileId;
      if (!!selectedBillingProfileId) {
        selectedBillingProfile = this.findBillingProfileModel(selectedBillingProfileId);
        // Note that the selectedBillingProfile can belong to either of the BillingPersons.
        // Furthermore, it might no longer be an acceptable BillingProfile option.
        if (!selectedBillingProfile) {
          // We won't have the selectedBillingProfile in cache if it is 'unacceptable' and was therefore excluded
          // from the set of acceptable PaymentMethodOptions.
          let retrievedBillingProfile: BillingProfileModel;
          if (!!this.applicationId) {
            // Use the 'broader' BillingProfile retrieval to retrieve a BillingProfile 'loaned' for the application.
            retrievedBillingProfile =
              await this.paymentMethodService.getApplicationPaymentBillingProfile(this.applicationId, selectedBillingProfileId).toPromise();
          } else {
            retrievedBillingProfile =
              await this.paymentMethodService.getBillingProfile(selectedBillingProfileId).toPromise();
          }
          this.registerBillingProfileModels(retrievedBillingProfile);
          this.evaluate(options);
          return;
        } else {
          // We have the selectedBillingProfile, is it 'acceptable'?
          if (!!PaymentMethodOption.getBillingProfileUnacceptableOptionMessage(selectedBillingProfile)) {
            // 'markAsTouched/markAsDirty' so that paymentMethod error is shown immediately.
            this.paymentMethodControl.markAsTouched({ onlySelf: true });
            this.paymentMethodControl.markAsDirty({ onlySelf: true });
          }
        }
      } else {
        selectedBillingProfile = null;
      }
    }

    // Resolve the selected PaymentChannelCode.
    let selectedPaymentChannelCode: PaymentChannelCode | null;
    {
      const selectedPaymentChannelCodeId = this.paymentChannelCodeControl.value;
      if (!!selectedPaymentChannelCodeId) {
        selectedPaymentChannelCode = PaymentChannelCode.valueOf(selectedPaymentChannelCodeId);
      } else {
        selectedPaymentChannelCode = null;
      }
    }

    // Apply any implicit person resolution from selected Billing Profile.
    if (!!selectedBillingProfile) {
      const toSelectPersonId = selectedBillingProfile.personId;
      const selectedPersonId = this.getSelectedBillingPersonId();
      if (selectedPersonId !== toSelectPersonId) {
        this.personControl.setValue(toSelectPersonId);
      }
    }

    // Update the UI...

    // Build the change BillingPerson clarification message.
    this.changeBillingPersonText = this.createChangeBillingPersonText();

    // Build the PaymentMethodOptions.
    this.buildPaymentMethodOptions();

    {
      // Manage secondaryBillingPerson BillingProfile
      if (this.isSecondaryBillingPersonLoggedIn) {
        let toSelectSecondaryBillingPersonBillingProfileId;
        if (this.isPrimaryBillingPersonSelected) {
          toSelectSecondaryBillingPersonBillingProfileId = null;
        } else if (this.isSecondaryBillingPersonSelected) {
          if (!!selectedBillingProfile) {
            toSelectSecondaryBillingPersonBillingProfileId = selectedBillingProfile.billingProfileId;
          } else {
            toSelectSecondaryBillingPersonBillingProfileId = null;
          }
        } else {
          toSelectSecondaryBillingPersonBillingProfileId = null;
        }
        this.secondaryBillingPersonBillingProfileIdControl
          .setValue(toSelectSecondaryBillingPersonBillingProfileId, { onlySelf: true, emitEvent: false });
      }
    }

    // Select the appropriate PaymentMethodOption based on selected BP or PaymentChannelCode.
    {
      let toSelectPaymentMethodOptionValue: string | null = null;
      if (!!selectedBillingProfile) {
        // We have a Billing Profile, use it as selected payment method. Ignore all other values.
        this.populateFromBillingProfile(selectedBillingProfile, isNewlyCreatedBillingProfile);
        toSelectPaymentMethodOptionValue
          = PaymentMethodOption.createBillingProfilePaymentMethodOptionValue(selectedBillingProfile);
      } else if (!!selectedPaymentChannelCode) {
        // We don't have a Billing Profile, but we have PaymentChannelCode. Allow user to create a Billing Profile for PaymentChannelCode.
        this.populateFromPaymentChannelCode(selectedPaymentChannelCode);
        toSelectPaymentMethodOptionValue
          = PaymentMethodOption.createPaymentChannelCodePaymentMethodOptionValue(selectedPaymentChannelCode);
      }

      if (!toSelectPaymentMethodOptionValue) {
        this.clearNameAddress();
        this.clearCreditCardFields();
        this.clearAchFields();
      }

      const currentPaymentMethodOptionValue = this.paymentMethodControl.value;
      if (currentPaymentMethodOptionValue !== toSelectPaymentMethodOptionValue) {
        if (!!toSelectPaymentMethodOptionValue) {
          this.paymentMethodControl.setValue(toSelectPaymentMethodOptionValue);
        } else {
          this.paymentMethodControl.setValue(null);
        }
      }

      if (!toSelectPaymentMethodOptionValue && determineDefault) {
        this.selectDefaultPaymentMethodOption();
        return;
      }
    }

    this.updatePaymentPlanFilterSelection();
    this.filterPaymentMethodOptions();
    this.updatePaymentPlanTypeId();
  }

  private selectDefaultPaymentMethodOption() {
    const currentPaymentMethodOptionValue = this.paymentMethodControl.value;
    if (!currentPaymentMethodOptionValue) {
      // There is no currently selected PaymentMethodOptionValue.
      let toSelectPaymentMethodOptionValue: string | null = null;
      const selectedBillingPerson = this.getSelectedBillingPerson();
      if (!!selectedBillingPerson) {
        // We can only select a PaymentMethodOptionValue if there is a BillingPerson selected.
        const enabledBillingProfilePaymentMethodOptions =
          this.activeBillingProfilePaymentMethodOptions.filter(bpOption => bpOption.enabled);
        if (enabledBillingProfilePaymentMethodOptions.length === 1) {
          toSelectPaymentMethodOptionValue = enabledBillingProfilePaymentMethodOptions[0].optionValue;
        }
        if (!toSelectPaymentMethodOptionValue) {
          const personDefaultBillingProfileId = selectedBillingPerson.defaultBillingProfileId;
          const defaultPersonBillingProfilePaymentMethodOption =
            enabledBillingProfilePaymentMethodOptions.find(bpOption => {
              return +bpOption.getOptionId() === personDefaultBillingProfileId;
            });
          if (!!defaultPersonBillingProfilePaymentMethodOption) {
            toSelectPaymentMethodOptionValue = defaultPersonBillingProfilePaymentMethodOption.optionValue;
          }
        }
        if (!!toSelectPaymentMethodOptionValue) {
          this.applyPaymentMethodOptionChange(toSelectPaymentMethodOptionValue);
        }
      }
    }
  }

  private populateFromBillingProfile(billingProfile: BillingProfileModel, isNewlyCreatedBillingProfile: boolean) {
    const paymentChannelCode = billingProfile.paymentChannelCode;
    const paymentChannelType = paymentChannelCode.paymentChannelType;
    const billingPerson = this.getBillingPerson(billingProfile.personId);

    this.clearNameAddress();
    // Determine if we should preserve the achAuthorizedByAccountHolder for a newly created BP.
    // Presumably, achAuthorizedByAccountHolder was set while creating the BP and so it is safe to preserve it's value.
    const preserveAchAuthorizedByAccountHolder = isNewlyCreatedBillingProfile
      && billingProfile.paymentChannelCode.isACH();
    this.clearAchFields(preserveAchAuthorizedByAccountHolder);
    this.clearCreditCardFields();

    this.paymentChannelCodeControl.setValue(paymentChannelCode.persistenceId);

    if (paymentChannelType.isElectronic) {
      this.billingFirstNameControl.setValue(billingPerson.firstName);
      this.billingLastNameControl.setValue(billingPerson.lastName);
      this.billingPhoneControl.setValue(billingPerson.phone);
      this.billingAddressGroup.patchValue(billingProfile.billingAddress);
    }

    switch (paymentChannelType) {
      case PaymentChannelType.ACH:
        this.bankNameControl.setValue(billingProfile.bankName);
        this.achAccountNumberControl.setValue(billingProfile.achAccountNumber);
        this.achRoutingNumberControl.setValue(billingProfile.achRoutingNumber);
        this.achAccountHolderTypeControl.setValue(billingProfile.achAccountHolderType.persistenceId);
        this.achAccountTypeControl.setValue(billingProfile.achAccountType.persistenceId);
        this.achSecCodeControl.setValue(billingProfile.achSecCode.persistenceId);
        break;
      case PaymentChannelType.CREDIT:
        this.cardNumberControl.setValue(billingProfile.cardNumber);
        this.cardCVVControl.setValue(billingProfile.cardCVV);
        this.cardExpirationControl.setValue(billingProfile.cardExpiration);
        break;
      case PaymentChannelType.PAPER_CHECK:
        break;
      default:
        break;
    }
  }

  private populateFromPaymentChannelCode(paymentChannelCode: PaymentChannelCode) {
    const paymentChannelType = paymentChannelCode.paymentChannelType;
    this.clearCreditCardFields();
    this.clearAchFields();
    switch (paymentChannelType) {
      case PaymentChannelType.ACH:
        this.prepopulateNameAddress();
        this.achSecCodeControl.setValue(AchSecCode.WEB.persistenceId);
        break;
      case PaymentChannelType.CREDIT:
        this.prepopulateNameAddress();
        break;
      default:
        this.clearNameAddress();
        break;
    }
  }

  private fetchBillingPersons(): Promise<void> {
    let billingPersonsPromise;
    billingPersonsPromise = new Promise<void>(resolve => {
      zip(
        this.paymentMethodInitializationData.applicantBillingPerson$,
        this.paymentMethodInitializationData.secondaryBillingPerson$
      ).subscribe(billingPersons => {
        this.primaryBillingPerson = billingPersons[0];
        this.secondaryBillingPerson = billingPersons[1];
        resolve();
      });
    });
    return billingPersonsPromise;
  }

  private createChangeBillingPersonText(): string | undefined {
    let changeBillingPersonText: string;
    if (!!this.secondaryBillingPerson) {
      // There is a secondary billingPerson
      let message: string;
      let roleTexts: RoleTexts;
      if (this.isSecondaryBillingPersonLoggedIn) {
        // We're interacting with the Secondary BillingPerson, no clarification message is displayed.
        const loggedInBillingPerson = this.secondaryBillingPerson;
        roleTexts = loggedInBillingPerson.roleTexts;
        if (this.isPrimaryBillingPersonSelected) {
        } else if (this.isSecondaryBillingPersonSelected) {
        }
      } else if (this.isPrimaryBillingPersonLoggedIn) {
        // We're interacting with the Primary BillingPerson.
        const loggedInBillingPerson = this.primaryBillingPerson;
        roleTexts = loggedInBillingPerson.roleTexts;
        if (this.isPrimaryBillingPersonSelected) {
          // No clarification message when the primary person is logged-in and selected.
          // message = roleTexts.toThisBillingPersonMessageText;
        } else if (this.isSecondaryBillingPersonSelected) {
          // Clarification message when the primary person is logged-in and secondary is selected.
          message = roleTexts.toOtherBillingPersonMessageText;
          const possessiveReplacementText = this.secondaryBillingPerson.roleTexts.possessiveReplacementText;
          if (!!possessiveReplacementText) {
            message = message.replace(RolePaymentDefinition.KEY_REPLACE_WITH_POSSESSIVE_OTHER_ROLE, possessiveReplacementText);
          }
        }
      }
      changeBillingPersonText = message;
    }
    return changeBillingPersonText;
  }

  /**
   * Build the PaymentMethodOptions.
   * PaymentMethodOptions include both 'static' PaymentChannelCode-based options and BillingProfile-based options.
   */
  private buildPaymentMethodOptions() {

    let billingProfileModelsToBeActive: BillingProfileModel[];
    if (this.isPrimaryBillingPersonSelected) {
      if (this.isSecondaryBillingPersonLoggedIn) {
        if (this.excludePrimaryPersonBillingProfilesFromSecondaryPerson) {
          // Prevent selection of any of primary person's Billing Profiles.
          billingProfileModelsToBeActive = [];
        } else {
          // Allow selection of any of primary person's Billing Profiles.
          billingProfileModelsToBeActive = this.primaryBillingProfiles;
        }
        // Allow full payment method creation in the name of the Primary Person.
        this.activePaymentChannelCodePaymentMethodOptions = this.allPaymentChannelCodePaymentMethodOptions;
      } else {
        billingProfileModelsToBeActive = this.primaryBillingProfiles;
        // Allow full payment method creation in the name of the Primary Person.
        this.activePaymentChannelCodePaymentMethodOptions = this.allPaymentChannelCodePaymentMethodOptions;
      }
    } else if (this.isSecondaryBillingPersonSelected) {
      if (this.isSecondaryBillingPersonLoggedIn) {
        // Allow selection of any of secondary person's Billing Profiles.
        billingProfileModelsToBeActive = this.secondaryBillingProfiles;
        // Allow full payment method creation in the name of the Secondary person.
        this.activePaymentChannelCodePaymentMethodOptions = this.allPaymentChannelCodePaymentMethodOptions;
      } else {
        // Only allow selection of the specific specified secondary person's Billing Profile.
        billingProfileModelsToBeActive = [this.secondaryBillingPersonBillingProfile];
        // Disallow any payment method creation in the name of the Secondary Person.
        this.activePaymentChannelCodePaymentMethodOptions = [];
      }
    } else {
      // No options until a billing person has been specified.
      billingProfileModelsToBeActive = [];
      this.activePaymentChannelCodePaymentMethodOptions = [];
    }
    this.activeBillingProfilePaymentMethodOptions = this.createBillingProfilePaymentMethodOptions(billingProfileModelsToBeActive);
  }

  /**
   * Display a dialog that confirms that user wishes to change Billing Person and process the response.
   */
  private async displayChangeBillingPersonConfirmationDialog() {
    // Build the change BillingPerson confirmation alert messages....
    let title: string;
    let confirmationMessage: string;
    const detailsMessage: string = undefined;
    {
      if (this.isSecondaryBillingPersonLoggedIn) {
        // We're interacting with the Secondary BillingPerson.
        const loggedInBillingPerson = this.secondaryBillingPerson;
        const roleTexts = loggedInBillingPerson.roleTexts;
        if (this.isPrimaryBillingPersonSelected) {
          title = roleTexts.toOtherBillingPersonAlertTitle;
          confirmationMessage = roleTexts.toOtherBillingPersonAlertText;
        } else if (this.isSecondaryBillingPersonSelected) {
          title = roleTexts.toThisBillingPersonAlertTitle;
          confirmationMessage = roleTexts.toThisBillingPersonAlertText;
        }
      } else if (this.isPrimaryBillingPersonLoggedIn) {
        // We're interacting with the Primary BillingPerson.
        const loggedInBillingPerson = this.primaryBillingPerson;
        const roleTexts = loggedInBillingPerson.roleTexts;
        if (this.isPrimaryBillingPersonSelected) {
          title = roleTexts.toThisBillingPersonAlertTitle;
          confirmationMessage = roleTexts.toThisBillingPersonAlertText;
        } else if (this.isSecondaryBillingPersonSelected) {
          title = roleTexts.toOtherBillingPersonAlertTitle;
          confirmationMessage = roleTexts.toOtherBillingPersonAlertText;
          const possessiveReplacementText = this.secondaryBillingPerson.roleTexts.possessiveReplacementText;
          if (!!possessiveReplacementText) {
            const titlePossessiveReplacementText = possessiveReplacementText.charAt(0).toUpperCase() + possessiveReplacementText.slice(1);
            title = title
              .replace(RolePaymentDefinition.KEY_REPLACE_WITH_POSSESSIVE_OTHER_ROLE, titlePossessiveReplacementText);
            confirmationMessage = confirmationMessage
              .replace(RolePaymentDefinition.KEY_REPLACE_WITH_POSSESSIVE_OTHER_ROLE, possessiveReplacementText);
          }
        }
      }
    }

    // Display the dialog...
    const changeBillingPersonConfirmed =
      await this.getChangeBillingPersonConfirmation(title, confirmationMessage, detailsMessage);

    // Process the response...
    let determineDefault: boolean;
    if (changeBillingPersonConfirmed) {
      if (this.isSecondaryBillingPersonSelected
        && this.isPrimaryBillingPersonLoggedIn
        && !!this.secondaryBillingPersonBillingProfile) {
        this.billingProfileIdControl.setValue(this.secondaryBillingPersonBillingProfile.billingProfileId
          , { onlySelf: true, emitEvent: false });
        this.paymentChannelCodeControl.setValue(null, { onlySelf: true, emitEvent: false });
        determineDefault = false;
      } else {
        this.billingProfileIdControl.setValue(null, { onlySelf: true, emitEvent: false });
        this.paymentChannelCodeControl.setValue(null, { onlySelf: true, emitEvent: false });
        determineDefault = true;
      }
      this.evaluate({ determineDefault: determineDefault });
    } else {
      // User doesn't want to change Billing Person.
      // Revert by selecting the opposite of what is currently selected.
      // TODO: This is a naive approach as it doesn't handle the case where nothing was selected prior to dialog.
      // if (this.isPrimaryBillingPersonSelected) {
      //   this.personControl.setValue(this.secondaryBillingPersonId);
      // } else if (this.isSecondaryBillingPersonSelected) {
      //   this.personControl.setValue(this.primaryBillingPersonId);
      // }
      this.personControl.setValue('');
    }
  }

  private getChangeBillingPersonConfirmation(title: string, confirmationRequestText: string, detailsText: string): Promise<boolean> {
    let confirmedChangeBillingPerson: Promise<boolean>;
    const dialogData: DialogData = {
      title: title,
      confirmationRequestText: confirmationRequestText,
      detailsText: detailsText,
      acceptLabel: 'Agree',
      rejectLabel: 'Cancel',
      acceptedResult: true,
      rejectedResult: false,
    };

    const matDialogConfig: MatDialogConfig<DialogData> = {
      data: dialogData, // Our data
      // Custom class for the overlay pane. Needs to be defined in the global style sheet.
      panelClass: 'confirmation-dialog-container',
      width: '100vw',
    };

    const dialogRef = this.confirmChangeBillingPersonDialog.open(ConfirmationDialogComponent, matDialogConfig);

    confirmedChangeBillingPerson = dialogRef.afterClosed().toPromise();

    return confirmedChangeBillingPerson;
  }

  get excludePrimaryPersonBillingProfilesFromSecondaryPerson(): boolean {
    return this.paymentMethodInitializationData.excludePrimaryPersonBillingProfilesFromSecondaryPerson;
  }

  get haveSecondaryBillingPerson(): boolean {
    let haveFeature: boolean;
    haveFeature = !!this.secondaryBillingPerson;
    return haveFeature;
  }

  get isPrimaryBillingPersonSelected(): boolean {
    let isSelected: boolean;
    isSelected = this.isBillingPersonSelected(this.primaryBillingPersonId);
    return isSelected;
  }

  get isPrimaryBillingPersonLoggedIn(): boolean {
    let isLoggedIn: boolean;
    isLoggedIn = this.isBillingPersonLoggedIn(this.primaryBillingPersonId);
    return isLoggedIn;
  }

  get isSecondaryBillingPersonSelected(): boolean {
    let isSelected: boolean;
    isSelected = this.isBillingPersonSelected(this.secondaryBillingPersonId);
    return isSelected;
  }

  get isSecondaryBillingPersonLoggedIn(): boolean {
    let isLoggedIn: boolean;
    isLoggedIn = this.isBillingPersonLoggedIn(this.secondaryBillingPersonId);
    return isLoggedIn;
  }

  isBillingPersonLoggedIn(personId: number): boolean {
    let isLoggedIn = false;
    if (!!personId) {
      const loggedInPersonId = this.securityService.user.person.id;
      if (personId === loggedInPersonId) {
        isLoggedIn = true;
      }
    }
    return isLoggedIn;
  }

  isBillingPersonSelected(personId: number): boolean {
    let isSelected: boolean;
    const selectedBillingPerson = this.getSelectedBillingPerson();
    isSelected = (!!selectedBillingPerson)
      && (personId === selectedBillingPerson.personId);
    return isSelected;
  }

  getSelectedBillingPersonId(): number | null {
    let billingPersonId: number | null;
    billingPersonId = (!!this.personControl.value) ? +this.personControl.value : null;
    return billingPersonId;
  }

  getSelectedBillingPerson(): BillingPerson | null {
    let selectedBillingPerson: BillingPerson;
    selectedBillingPerson = this.getBillingPerson(this.getSelectedBillingPersonId());
    return selectedBillingPerson;
  }

  getBillingPerson(personId: number | string): BillingPerson | null {
    let billingPerson: BillingPerson = null;
    if (!!personId) {
      if (personId === this.primaryBillingPersonId) {
        billingPerson = this.primaryBillingPerson;
      } else if (personId === this.secondaryBillingPersonId) {
        billingPerson = this.secondaryBillingPerson;
      }
      return billingPerson;
    }
  }

  get primaryBillingPersonId(): number | undefined {
    let billingPersonId: number;
    if (!!this.primaryBillingPerson) {
      billingPersonId = this.primaryBillingPerson.personId;
    }
    return billingPersonId;
  }

  get secondaryBillingPersonId(): number | undefined {
    let billingPersonId: number;
    if (!!this.secondaryBillingPerson) {
      billingPersonId = this.secondaryBillingPerson.personId;
    }
    return billingPersonId;
  }

  isDisplayPaymentPlanUI(): boolean {
    let isDisplayUI: boolean;
    isDisplayUI = !!this.applicationId
      && this.showSchedule
      && !!this.paymentPlanOptions;
    return isDisplayUI;
  }

  /**
   * Create PaymentChannelCode PaymentMethodOption from PaymentPlanTypeModels.
   * PaymentChannelCode PaymentMethodOptions are options not associated with a Billing Profile.
   * @param paymentPlanTypeModels
   */
  createPaymentChannelCodePaymentMethodOptions(paymentPlanTypeModels: PaymentPlanTypeModel[]): PaymentMethodOption[] {
    // Create the PaymentChannel options.
    const optionPaymentChannelCodes = Array.from(new Set(paymentPlanTypeModels.map(pptModel => pptModel.paymentChannelCode)));

    // Remove the 'special' PaymentChannelCodes that are to be placed at top of options.
    let prependPaymentChannelCodes = new Array<PaymentChannelCode>();
    const paperCheckIndex = optionPaymentChannelCodes.findIndex(pcc => pcc.persistenceId === PaymentChannelCode.CHECK.persistenceId);
    if (paperCheckIndex !== -1) {
      prependPaymentChannelCodes = prependPaymentChannelCodes.concat(optionPaymentChannelCodes.splice(paperCheckIndex, 1));
    }

    // Remove the 'special' PaymentChannelCodes that are to be placed at bottom of options.
    let appendPaymentChannelCodes = new Array<PaymentChannelCode>();
    const eCheckIndex = optionPaymentChannelCodes.findIndex(pcc => pcc.persistenceId === PaymentChannelCode.ACH.persistenceId);
    if (eCheckIndex !== -1) {
      appendPaymentChannelCodes = appendPaymentChannelCodes.concat(optionPaymentChannelCodes.splice(eCheckIndex, 1));
    }

    // Create the core paymentChannelCode options.
    const paymentChannelCodePaymentMethodOptions = optionPaymentChannelCodes.map(
      (paymentChannelCode) => PaymentMethodOption.createPaymentChannelCodePaymentMethodOption(paymentChannelCode))
      .sort((a, b) => a.optionLabel.localeCompare(b.optionLabel));

    // Prepend special paymentChannelCode options.
    prependPaymentChannelCodes.forEach(pcc => {
      paymentChannelCodePaymentMethodOptions.unshift(
        PaymentMethodOption.createPaymentChannelCodePaymentMethodOption(pcc));
    });

    // Append special paymentChannelCode options.
    appendPaymentChannelCodes.forEach(pcc => {
      paymentChannelCodePaymentMethodOptions.push(
        PaymentMethodOption.createPaymentChannelCodePaymentMethodOption(pcc));
    });

    return paymentChannelCodePaymentMethodOptions;
  }

  /**
   * Create the BillingProfile-based PaymentMethodOptions.
   * BillingProfile PaymentMethodOptions are options not directly associated with a PaymentChannelCode.
   * @param billingProfileModels
   */
  createBillingProfilePaymentMethodOptions(billingProfileModels: BillingProfileModel[]): PaymentMethodOption[] {
    let billingProfilePaymentMethodOptions: PaymentMethodOption[];
    // (Re)build the billingProfile options of the paymentMethod select element.
    billingProfilePaymentMethodOptions = billingProfileModels.map(
      (profile) => PaymentMethodOption.createBillingProfilePaymentMethodOption(profile))
      .sort((a, b) => a.optionLabel.localeCompare(b.optionLabel));
    return billingProfilePaymentMethodOptions;
  }

  /**
   * Create the PaymentPlanOptions from the PaymentPlanTypeModels.
   * Only the set of distinct PaymentPlanOptions are returned.
   * Uniqueness is based on PaymentFrequencyType.
   * @param paymentPlanTypeModels
   */
  createPaymentPlanOptions(paymentPlanTypeModels: PaymentPlanTypeModel[]): PaymentPlanOption[] {
    const paymentPlanOptions: PaymentPlanOption[] = [];

    {
      const haveSingleInstallmentPaymentPlanTypeModel = paymentPlanTypeModels.some(ppt => ppt.isSingleInstallment());
      if (haveSingleInstallmentPaymentPlanTypeModel) {
        const singleInstallmentPaymentFrequencyTypePaymentPlanOption
          = PaymentPlanOption.createSingleInstallmentPaymentPlanOption(PaymentFrequencyType.YEARLY);
        paymentPlanOptions.push(singleInstallmentPaymentFrequencyTypePaymentPlanOption);
      }
    }

    let recurringPaymentFrequencyTypePaymentPlanOptions: PaymentPlanOption[];
    {
      const recurringPaymentFrequencyTypes: PaymentFrequencyType[] = Array.from(
        new Set<PaymentFrequencyType>(paymentPlanTypeModels
          .filter(ppt => !ppt.isSingleInstallment())
          .map(ppt => ppt.paymentFrequencyType)));
      recurringPaymentFrequencyTypePaymentPlanOptions = recurringPaymentFrequencyTypes
        .map(pft => PaymentPlanOption.createRecurringPaymentsPaymentPlanOption(pft));
    }

    // Add the recurring PaymentPlanOptions options.
    paymentPlanOptions.push.apply(paymentPlanOptions
      , recurringPaymentFrequencyTypePaymentPlanOptions);

    return paymentPlanOptions;
  }

  registerBillingProfileModels(bpModels: BillingProfileModel | BillingProfileModel[]) {
    if (Array.isArray(bpModels)) {
      bpModels.forEach(bpModel => this.idToBillingProfile.set(bpModel.billingProfileId, bpModel));
    } else {
      this.idToBillingProfile.set(bpModels.billingProfileId, bpModels);
    }
  }

  get billingProfiles() {
    let billingProfileModels: BillingProfileModel[];
    billingProfileModels = Array.from(this.idToBillingProfile.values());
    return billingProfileModels;
  }

  get primaryBillingProfiles(): BillingProfileModel[] {
    let billingProfiles: BillingProfileModel[];
    const personId = this.primaryBillingPersonId;
    if (!!personId) {
      billingProfiles = this.billingProfiles.filter(bp => bp.personId === personId);
    } else {
      billingProfiles = [];
    }
    return billingProfiles;
  }

  get secondaryBillingProfiles(): BillingProfileModel[] {
    let billingProfiles: BillingProfileModel[];
    const personId = this.secondaryBillingPersonId;
    if (!!personId) {
      billingProfiles = this.billingProfiles.filter(bp => bp.personId === personId);
    } else {
      billingProfiles = [];
    }
    return billingProfiles;
  }

  get secondaryBillingPersonBillingProfileId(): number | undefined {
    let billingProfileId: number | undefined;
    if (!!this.secondaryBillingPersonBillingProfileIdControl) {
      billingProfileId = this.secondaryBillingPersonBillingProfileIdControl.value;
      if (!!billingProfileId) {
        billingProfileId = +billingProfileId;
      }
    }
    return billingProfileId;
  }

  get secondaryBillingPersonBillingProfile(): BillingProfileModel | undefined {
    let billingProfile: BillingProfileModel;
    billingProfile = this.findBillingProfileModel(this.secondaryBillingPersonBillingProfileId);
    return billingProfile;
  }

  /**
   * Find the billingProfile by id in the local cache.
   * @param billingProfileId
   */
  findBillingProfileModel?(billingProfileId: number | string): BillingProfileModel {
    let billingProfileModel: BillingProfileModel;
    if (!!billingProfileId) {
      billingProfileId = +billingProfileId;
      billingProfileModel = this.billingProfiles
        .find(profile => profile.billingProfileId === billingProfileId);
    }
    return billingProfileModel;
  }

  /**
   * Select a PaymentPlanFilter option that is compatible with current PaymentMethodOption.
   */
  updatePaymentPlanFilterSelection() {
    if (!!this.paymentFrequencyControl) {
      let singlePaymentPaymentPlanTypeModels: PaymentPlanTypeModel[];
      let recurringPaymentPaymentFrequencyTypes: Set<PaymentFrequencyType>;

      const selectedPaymentMethodOption = this.getSelectedPaymentMethodOption();
      if (!!selectedPaymentMethodOption) {
        // Collect PaymentMethod-appropriate options.
        const selectedPaymentChannelCode = selectedPaymentMethodOption.paymentChannelCode;
        singlePaymentPaymentPlanTypeModels = this.paymentPlanTypeModels
          .filter(pptModel => (pptModel.isSingleInstallment()
            && pptModel.paymentChannelCode === selectedPaymentChannelCode));
        recurringPaymentPaymentFrequencyTypes = new Set(this.paymentPlanTypeModels
          .filter(pptModel => (!pptModel.isSingleInstallment()
            && pptModel.paymentChannelCode === selectedPaymentChannelCode))
          .map(pptModel => pptModel.paymentFrequencyType)
        );
      } else {
        // Collect generally-appropriate options.
        singlePaymentPaymentPlanTypeModels = this.paymentPlanTypeModels
          .filter(pptModel => pptModel.isSingleInstallment());
        recurringPaymentPaymentFrequencyTypes = new Set(this.paymentPlanTypeModels
          .filter(pptModel => !pptModel.isSingleInstallment())
          .map(pptModel => pptModel.paymentFrequencyType)
        );
      }

      const currentPaymentPlanFilterOption = this.getSelectedPaymentPlanOption();

      let isPaymentPlanFilterOptionCompatible: boolean;
      if (!!currentPaymentPlanFilterOption) {
        // Is the currently selected PaymentPlanFilter option compatible with currently selected PaymentMethod option?
        if (!!selectedPaymentMethodOption) {
          if (currentPaymentPlanFilterOption.isSinglePaymentOption()) {
            isPaymentPlanFilterOptionCompatible = singlePaymentPaymentPlanTypeModels.length > 0;
          } else {
            isPaymentPlanFilterOptionCompatible =
              recurringPaymentPaymentFrequencyTypes.has(currentPaymentPlanFilterOption.paymentFrequencyType);
          }
        } else {
          // No PaymentPlanFilter option means we should look for one.
          isPaymentPlanFilterOptionCompatible = false;
        }
      }

      if (isPaymentPlanFilterOptionCompatible) {
        // We're good
      } else {
        // Need to find a compatible PaymentPlanFilter option.
        let toSelectPaymentPlanOptionValue: string = null;
        if (singlePaymentPaymentPlanTypeModels.length > 0) {
          // Prefer singlePayment PaymentPlanType
          toSelectPaymentPlanOptionValue = PaymentPlanOption.createSinglePaymentPlanOptionValue();
        } else {
          if (recurringPaymentPaymentFrequencyTypes.size > 0) {
            // Have at least one acceptable recurring PaymentPlanType, pick the first one.
            const paymentFrequencyType: PaymentFrequencyType = recurringPaymentPaymentFrequencyTypes.values().next().value;
            toSelectPaymentPlanOptionValue = PaymentPlanOption.createRecurringPaymentsPaymentPlanOptionValue(paymentFrequencyType);
          } else {
            // No acceptable recurring PaymentPlanType.
            toSelectPaymentPlanOptionValue = null;
          }
        }
        this.paymentFrequencyControl.setValue(toSelectPaymentPlanOptionValue);
      }
    }
  }

  /**
   * Enable/disable the PaymentMethod Options according to the current PaymentPlanFilter option.
   */
  filterPaymentMethodOptions() {
    if (!!this.paymentMethodControl) {
      const selectedPaymentPlanOption = this.getSelectedPaymentPlanOption();
      if (!!selectedPaymentPlanOption) {
        // A PaymentPlan is selected so review which Payment Method options are allowed by PaymentPlan.

        const selectedPaymentMethodOption = this.getSelectedPaymentMethodOption();
        const isPaymentMethodOptionEnabledInitially = !!selectedPaymentMethodOption && selectedPaymentMethodOption.enabled;

        let paymentPlanAllowedPaymentChannelCodes;
        {
          const selectedPaymentFrequencyType = selectedPaymentPlanOption.paymentFrequencyType;
          paymentPlanAllowedPaymentChannelCodes = new Set(this.paymentPlanTypeModels
            .filter(pptModel => pptModel.paymentFrequencyType === selectedPaymentFrequencyType)
            .map(pptModel => pptModel.paymentChannelCode));
        }

        this.activePaymentChannelCodePaymentMethodOptions.forEach(pmo => {
          if (pmo.enabled) {
            if (!paymentPlanAllowedPaymentChannelCodes.has(pmo.paymentChannelCode)) {
              pmo.enabled = false;
              pmo.unacceptableOptionMessage = 'Payment method is not available for the selected plan.';
            }
          }
        });

        this.activeBillingProfilePaymentMethodOptions.forEach(pmo => {
          if (pmo.enabled) {
            if (!paymentPlanAllowedPaymentChannelCodes.has(pmo.paymentChannelCode)) {
              pmo.enabled = false;
              pmo.unacceptableOptionMessage = 'Payment method is not available for the selected plan.';
            }
          }
        });

        // If PaymentPlan management disabled the current paymentMethod option, then clear the paymentMethod selection.
        // If paymentMethod was already disabled, then let the paymentMethod selection stand.
        const isPaymentMethodOptionEnabledNow = !!selectedPaymentMethodOption && selectedPaymentMethodOption.enabled;
        if (!isPaymentMethodOptionEnabledNow && isPaymentMethodOptionEnabledInitially) {
          // We've disabled the previously selected PaymentMethod option based on PaymentPlan. User needs to find an alternative.
          this.paymentMethodControl.setValue(null);
        }
      } else {
        // No PaymentPlan selected so no additional PaymentMethodOption filtering is required.
      }
    }
  }

  updatePaymentPlanTypeId() {
    let paymentPlanTypeId: number | null;
    if (!!this.paymentMethodControl && !!this.paymentFrequencyControl) {
      const paymentMethodOption = this.getSelectedPaymentMethodOption();
      if (!!paymentMethodOption) {
        // Identify the unique paymentPlanType that satisfies paymentMethod and frequency.
        const paymentPlanTypeModels = this.paymentPlanTypeModels
          .filter((ppt) => PaymentPlanOption.createPaymentPlanOptionOptionValue(ppt) === this.paymentFrequencyControl.value)
          .filter((ppt) => ppt.paymentChannelCode.persistenceId === paymentMethodOption.paymentChannelCode.persistenceId)
          ;
        if (paymentPlanTypeModels.length === 1) {
          paymentPlanTypeId = paymentPlanTypeModels[0].id;
        } else {
          paymentPlanTypeId = null;
        }
      } else {
        // No paymentMethodOption selected, display paymentFrequencyType options.
        paymentPlanTypeId = null;
      }
    } else {
      paymentPlanTypeId = null;
    }
    this.paymentPlanTypeIdControl.setValue(paymentPlanTypeId);
  }

  /**
   * Prepopulate Payment fields with initialNameAddressValues.
   */
  prepopulateNameAddress() {
    const selectedBillingPerson = this.getSelectedBillingPerson();
    if (!!selectedBillingPerson) {
      const initialFirstName = selectedBillingPerson.firstName;
      if (initialFirstName) {
        this.billingFirstNameControl.setValue(initialFirstName);
      } else {
        this.billingFirstNameControl.reset(null);
      }
      const applicantLastName = selectedBillingPerson.lastName;
      if (applicantLastName) {
        this.billingLastNameControl.setValue(applicantLastName);
      } else {
        this.billingLastNameControl.reset(null);
      }
      const initialPhone = selectedBillingPerson.phone;
      if (initialPhone) {
        this.billingPhoneControl.setValue(initialPhone);
      } else {
        this.billingPhoneControl.reset(null);
      }
      const agent = this.securityService.user.hasAgentRole;
      const attorney = this.securityService.user.hasAttorneyRole;
      if (agent || attorney) {
        const initialAddress = selectedBillingPerson.billingAddress;
        if (initialAddress) {
          this.billingAddressGroup.patchValue(initialAddress);
        } else {
          this.billingAddressGroup.reset({});
        }
      }
    }
  }

  clearNameAddress() {
    this.billingFirstNameControl.reset(null);
    this.billingLastNameControl.reset(null);
    this.billingPhoneControl.reset(null);
    this.billingAddressGroup.reset({});
  }

  clearCreditCardFields() {
    this.cardNumberControl.reset(null);
    this.cardCVVControl.reset(null);
    this.cardExpirationControl.reset(null);
  }

  clearAchFields(preserveAchAuthorizedByAccountHolder?: boolean) {
    preserveAchAuthorizedByAccountHolder = !!preserveAchAuthorizedByAccountHolder;
    // Recall that formControl.reset clears 'marks-as-touched' property which is used for 'missing required value' errors.
    this.bankNameControl.reset(null);
    this.achAccountNumberControl.reset(null);
    this.confirmAchAccountNumberControl.reset(null);
    this.achRoutingNumberControl.reset(null);
    this.confirmAchRoutingNumberControl.reset(null);
    this.achAccountTypeControl.reset(null);
    this.achAccountHolderTypeControl.reset(null);
    this.achSecCodeControl.reset(null);
    if (!preserveAchAuthorizedByAccountHolder) {
      // A hack to preserve the value of the achAuthorizedByAccountHolder collected prior to the creation of the Billing Profile.
      this.achAuthorizedByAccountHolderControl.reset(null);
    }
  }

  isCanCreateOrEditOrSelectBillingProfile(): boolean {
    let isCan;
    if (this.isPrimaryBillingPersonLoggedIn
      && !!this.secondaryBillingPersonBillingProfileId
      && this.selectedBillingProfileId === this.secondaryBillingPersonBillingProfileId) {
      // Do not allow any BP operations when primary person is logged-in and is using secondary person's BP.
      isCan = false;
    } else {
      isCan = this.globalBillingProfileMode.isCanCreateOrEditOrSelect;
    }
    return isCan;
  }

  isCanCreateOrEditBillingProfile(): boolean {
    let isCan;
    if (this.isCanCreateOrEditOrSelectBillingProfile()) {
      isCan = this.globalBillingProfileMode.isCanCreateOrEdit;
    } else {
      isCan = false;
    }
    return isCan;
  }

  isCollectCreditCardInfoOption(): boolean {
    let isOption;
    if (this.isCanCreateOrEditBillingProfile()) {
      if (!!this.paymentMethodControl) {
        isOption = PaymentMethodOption.isCreateCreditCardOption(this.paymentMethodControl.value);
      } else {
        // We are in billingProfile CRUD mode where we are editing one-and-only-one billingProfile.
        const billingProfile = this.getSelectedBillingProfile();
        isOption = billingProfile.paymentChannelCode.isCreditCard();
      }
    } else {
      isOption = false;
    }
    return isOption;
  }

  isCollectAchInfoOption(): boolean {
    let isOption;
    if (this.isCanCreateOrEditBillingProfile()) {
      if (!!this.paymentMethodControl) {
        isOption = PaymentMethodOption.isCreateACHOption(this.paymentMethodControl.value);
      } else {
        // We are in billingProfile CRUD mode where we are editing one-and-only-one billingProfile.
        const billingProfile = this.getSelectedBillingProfile();
        isOption = billingProfile.paymentChannelCode.isACH();
      }
    } else {
      isOption = false;
    }
    return isOption;
  }

  /**
   * Returns true if payment method is ACH-based, either because we are:
   * - creating a new ACH
   * - referencing an ACH-based Billing Profile
   */
  isCollectAchAuthorizedByAccountHolder(): boolean {
    let isCollect = false;
    if (this.isCanCreateOrEditOrSelectBillingProfile) {
      if (!!this.paymentMethodControl) {
        if (this.isCollectAchInfoOption()) {
          // Logged-in user is creating an ACH payment method.
          if (this.isSecondaryBillingPersonLoggedIn) {
            if (this.isSecondaryBillingPersonSelected) {
              // Steward is logged in and they are the selected Billing Person.
              // Collect ACH payment method authorization when creating ACH payment method.
              isCollect = true;
            } else {
              // Steward is logged in and Client is the selected Billing Person.
              // Collect ACH payment method authorization if it will be used immediately.
              isCollect = this.paymentMethodInitializationData.paymentMethodToBeUsedImmediately;
            }
          } else {
            // The logged-in primary person must always furnish authorization when creating ACH payment method.
            isCollect = true;
          }
        } else {
          const selectedBillingProfile = this.getSelectedBillingProfile();
          if (!!selectedBillingProfile) {
            if (selectedBillingProfile.paymentChannelCode.isACH()) {
              // Selected PaymentMethod is a Billing Profile, but whose?
              if (this.isPrimaryBillingPersonLoggedIn) {
                if (selectedBillingProfile.billingProfileId === this.secondaryBillingPersonBillingProfileId) {
                  // Logged-in user is using another party's BP and can't authorize to use the BP.
                  isCollect = false;
                } else {
                  // Logged-in user is not using another party's BP and must therefore authorize the use of their BP.
                  isCollect = true;
                }
              } else if (this.isSecondaryBillingPersonLoggedIn) {
                if (this.isPrimaryBillingPersonSelected) {
                  // Logged-in user is entering payment information for another person.
                  // That person will have to authorize the process unless it is used immediately.
                  isCollect = this.paymentMethodInitializationData.paymentMethodToBeUsedImmediately;
                } else {
                  // Logged-in user is entering payment information for themselves, they have to authorize the process.
                  isCollect = true;
                }
              }
            }
          }
        }
      } else {
        // We are in billingProfile CRUD mode where we are editing one-and-only-one billingProfile.
        const billingProfile = this.getSelectedBillingProfile();
        isCollect = billingProfile.paymentChannelCode.isACH();
      }
    } else {
      isCollect = false;
    }
    return isCollect;
  }

  getSelectedPaymentMethodOption?(): PaymentMethodOption | undefined {
    let paymentMethodOption: PaymentMethodOption;
    if (!!this.paymentMethodControl) {
      paymentMethodOption = this.getPaymentMethodOption(this.paymentMethodControl.value);
    } else {
      paymentMethodOption = undefined;
    }
    return paymentMethodOption;
  }

  getSelectedPaymentMethodUnacceptableOptionMessage(): string | undefined {
    let unacceptableOptionMessage: string | undefined;
    const selectedPaymentMethodOption = this.getSelectedPaymentMethodOption();
    if (!!selectedPaymentMethodOption
      && !selectedPaymentMethodOption.enabled
      && !!selectedPaymentMethodOption.unacceptableOptionMessage) {
      unacceptableOptionMessage = selectedPaymentMethodOption.unacceptableOptionMessage;
    }

    return unacceptableOptionMessage;
  }

  getPaymentMethodOption(paymentMethodOptionValue: string): PaymentMethodOption | undefined {
    let paymentMethodOption: PaymentMethodOption;
    paymentMethodOption = this.activePaymentChannelCodePaymentMethodOptions.find(pmo => pmo.optionValue === paymentMethodOptionValue);
    if (!paymentMethodOption) {
      paymentMethodOption = this.activeBillingProfilePaymentMethodOptions.find(pmo => pmo.optionValue === paymentMethodOptionValue);
    }
    return paymentMethodOption;
  }

  get selectedBillingProfileId(): number | undefined {
    let billingProfileId: number | undefined;
    billingProfileId = this.billingProfileIdControl.value;
    if (!!billingProfileId) {
      billingProfileId = +billingProfileId;
    }
    return billingProfileId;
  }

  getSelectedBillingProfile(): BillingProfileModel | undefined {
    let selectedBillingProfile: BillingProfileModel;
    const billingProfileId = this.selectedBillingProfileId;
    if (!!billingProfileId) {
      selectedBillingProfile = this.findBillingProfileModel(billingProfileId);
    }
    return selectedBillingProfile;
  }

  /**
   * Return the BillingProfileModel of the selected BillingProfile for display if it is appropriate to display it to the user.
   */
  getDisplayBillingProfileModel(): BillingProfileModel | undefined {
    let readOnlyBillingProfile: BillingProfileModel;
    const selectedBillingProfile = this.getSelectedBillingProfile();
    if (!!selectedBillingProfile) {
      if (this.isPrimaryBillingPersonLoggedIn) {
        // The primary person is logged-in, we have to hide the details of the selected BP if it is for the secondary Billing Person.
        const secondaryBillingPersonBillingProfile = this.secondaryBillingPersonBillingProfile;
        if (!!secondaryBillingPersonBillingProfile) {
          if (secondaryBillingPersonBillingProfile.billingProfileId !== selectedBillingProfile.billingProfileId) {
            // The selected BP is not the BP made available by the secondary Billing Person. We can display the selected BP.
            readOnlyBillingProfile = selectedBillingProfile;
          } else {
            // The selected BP is the BP made available by the secondary Billing Person.
            // We must not display the details of the secondary Billing Person BP to the primary BillingPerson.
            readOnlyBillingProfile = undefined;
          }
        } else {
          // There is no BP made available by the secondary Billing Person. So this can't be one of those. So display it.
          readOnlyBillingProfile = selectedBillingProfile;
        }
      } else {
        // The secondary person is logged-in, it's safe to display any BP.
        readOnlyBillingProfile = selectedBillingProfile;
      }
    }
    return readOnlyBillingProfile;
  }

  hasCreditCardInfo(): boolean {
    let hasInfo: boolean;
    const paymentMethodOption = this.getSelectedPaymentMethodOption();
    if (!!paymentMethodOption) {
      hasInfo = paymentMethodOption.paymentChannelCode.paymentChannelType === PaymentChannelType.CREDIT;
    } else {
      hasInfo = false;
    }
    return hasInfo;
  }

  hasACHInfo(): boolean {
    let hasInfo: boolean;
    const paymentMethodOption = this.getSelectedPaymentMethodOption();
    if (!!paymentMethodOption) {
      hasInfo = paymentMethodOption.paymentChannelCode.paymentChannelType === PaymentChannelType.ACH;
    } else {
      hasInfo = false;
    }
    return hasInfo;
  }

  trackByPaymentMethodType(index: number, paymentMethodOption: PaymentMethodOption): string {
    if (!!paymentMethodOption) {
      return paymentMethodOption.optionValue;
    }
    return null;
  }

  getPaymentPlanOption(paymentPlanOptionValue: string): PaymentPlanOption | undefined {
    let paymentPlanOption: PaymentPlanOption;
    paymentPlanOption = this.paymentPlanOptions.find(option => option.optionValue === paymentPlanOptionValue);
    return paymentPlanOption;
  }

  getSelectedPaymentPlanOption(): PaymentPlanOption | undefined {
    let paymentPlanOption: PaymentPlanOption;
    if (!!this.paymentFrequencyControl) {
      paymentPlanOption = this.getPaymentPlanOption(this.paymentFrequencyControl.value);
    } else {
      paymentPlanOption = undefined;
    }
    return paymentPlanOption;
  }

  trackByPaymentPlanOption(index: number, paymentPlanOption: PaymentPlanOption): string {
    if (!!paymentPlanOption) {
      return paymentPlanOption.getOptionId();
    }
    return null;
  }

  hasSinglePaymentPaymentPlanOption(): boolean {
    let hasOption: boolean;
    hasOption = this.paymentPlanOptions.some(ppo => ppo.isSinglePaymentOption());
    return hasOption;
  }

  hasRecurringPaymentPaymentPlanOption(paymentFrequencyType: PaymentFrequencyType): boolean {
    let hasOption: boolean;
    hasOption = this.paymentPlanOptions.some(ppo => ppo.paymentFrequencyType === paymentFrequencyType);
    return hasOption;
  }

  get recurringPaymentPlanOptionFrequencyTypes(): PaymentFrequencyType[] {
    let paymentFrequencyTypes: PaymentFrequencyType[];
    paymentFrequencyTypes = Array.from(new Set(this.paymentPlanOptions.filter(ppo => !ppo.isSinglePaymentOption())
      .map(ppo => ppo.paymentFrequencyType)));
    return paymentFrequencyTypes;
  }

  get recurringAppliedPaymentPlanTypeModels(): AppliedPaymentPlanTypeModel[] {
    let appliedPaymentPlanTypeModels: AppliedPaymentPlanTypeModel[];
    if (!!this.appliedPaymentPlanTypeModels) {
      const paymentFrequencyTypeToAppliedPaymentPlanTypeModels = new Map<PaymentFrequencyType, AppliedPaymentPlanTypeModel>();
      // Equating all AppliedPaymentPlanTypeModels of the same PaymentFrequencyType.
      this.appliedPaymentPlanTypeModels.filter(appliedPPTModel => !appliedPPTModel.paymentPlanTypeModel.isSingleInstallment())
        .forEach(appliedPPTModel => {
          paymentFrequencyTypeToAppliedPaymentPlanTypeModels
            .set(appliedPPTModel.paymentPlanTypeModel.paymentFrequencyType, appliedPPTModel);
        });
      appliedPaymentPlanTypeModels = Array.from(paymentFrequencyTypeToAppliedPaymentPlanTypeModels.values());
    }
    return appliedPaymentPlanTypeModels;
  }

  get recurringPaymentPlanTypeModels(): PaymentPlanTypeModel[] {
    let paymentPlanTypeModels: PaymentPlanTypeModel[];
    if (!!this.paymentPlanTypeModels) {
      const paymentFrequencyTypeToPaymentPlanTypeModels = new Map<PaymentFrequencyType, PaymentPlanTypeModel>();
      // Equating all AppliedPaymentPlanTypeModels of the same PaymentFrequencyType.
      this.paymentPlanTypeModels.filter(pptModel => !pptModel.isSingleInstallment())
        .forEach(pptModel => {
          paymentFrequencyTypeToPaymentPlanTypeModels.set(pptModel.paymentFrequencyType, pptModel);
        });
      paymentPlanTypeModels = Array.from(paymentFrequencyTypeToPaymentPlanTypeModels.values());
    }
    return paymentPlanTypeModels;
  }

  get oneTimeAppliedPaymentPlanTypeModel(): AppliedPaymentPlanTypeModel | undefined {
    let appliedPaymentPlanTypeModel: AppliedPaymentPlanTypeModel;
    if (!!this.appliedPaymentPlanTypeModels) {
      // Equating all single payment AppliedPaymentPlanTypeModels.
      appliedPaymentPlanTypeModel = this.appliedPaymentPlanTypeModels
        .find(appliedPPTModel => appliedPPTModel.paymentPlanTypeModel.isSingleInstallment());
    }
    return appliedPaymentPlanTypeModel;
  }

  get oneTimePaymentPlanTypeModel(): PaymentPlanTypeModel | undefined {
    let paymentPlanTypeModel: PaymentPlanTypeModel;
    if (!!this.paymentPlanTypeModels) {
      // Equating all single payment PaymentPlanTypeModels.
      paymentPlanTypeModel = this.paymentPlanTypeModels.find(appliedPPTModel => appliedPPTModel.isSingleInstallment());
    }
    return paymentPlanTypeModel;
  }

  trackByAchAccountType(index: number, achAccountType: AchAccountType): string {
    if (!!achAccountType) {
      return achAccountType.persistenceId;
    }
    return null;
  }

  trackByAchAccountHolderType(index: number, achAccountHolderType: AchAccountHolderType): string {
    if (!!achAccountHolderType) {
      return achAccountHolderType.persistenceId;
    }
    return null;
  }

  get personControl(): FormControl {
    return this.paymentMethodFormGroup.personControl;
  }

  get billingAddressGroup(): FormGroup {
    return this.paymentMethodFormGroup.billingAddressGroup;
  }

  // contains Billing Profiles and PaymentChannels. Not present in BillingProfile CRUD mode.
  get paymentMethodControl(): FormControl {
    return this.paymentMethodFormGroup.paymentMethodControl;
  }

  get billingFirstNameControl(): FormControl {
    return this.paymentMethodFormGroup.billingFirstNameControl;
  }

  get billingLastNameControl(): FormControl {
    return this.paymentMethodFormGroup.billingLastNameControl;
  }

  get billingPhoneControl(): FormControl {
    return this.paymentMethodFormGroup.billingPhoneControl;
  }

  get cardNumberControl(): FormControl {
    return this.paymentMethodFormGroup.cardNumberControl;
  }

  get cardExpirationControl(): FormControl {
    return this.paymentMethodFormGroup.cardExpirationControl;
  }

  get cardCVVControl(): FormControl {
    return this.paymentMethodFormGroup.cardCVVControl;
  }

  get achRoutingNumberControl(): FormControl {
    return this.paymentMethodFormGroup.achRoutingNumberControl;
  }

  get confirmAchRoutingNumberControl(): FormControl {
    return this.paymentMethodFormGroup.confirmAchRoutingNumberControl;
  }

  get achAccountNumberControl(): FormControl {
    return this.paymentMethodFormGroup.achAccountNumberControl;
  }

  get confirmAchAccountNumberControl(): FormControl {
    return this.paymentMethodFormGroup.confirmAchAccountNumberControl;
  }

  get achAccountTypeControl(): FormControl {
    return this.paymentMethodFormGroup.achAccountTypeControl;
  }

  get achAuthorizedByAccountHolderControl(): FormControl {
    return this.paymentMethodFormGroup.achAuthorizedByAccountHolderControl;
  }

  get achAccountHolderTypeControl(): FormControl {
    return this.paymentMethodFormGroup.achAccountHolderTypeControl;
  }

  get bankNameControl(): FormControl {
    return this.paymentMethodFormGroup.bankNameControl;
  }

  // hidden
  get achSecCodeControl(): FormControl {
    return this.paymentMethodFormGroup.achSecCodeControl;
  }

  // hidden
  get paymentPlanTypeIdControl(): FormControl {
    return this.paymentMethodFormGroup.paymentPlanTypeIdControl;
  }

  // hidden
  get billingProfileIdControl(): FormControl {
    return this.paymentMethodFormGroup.billingProfileIdControl;
  }

  // hidden
  get secondaryBillingPersonBillingProfileIdControl(): FormControl {
    return this.paymentMethodFormGroup.secondaryBillingPersonBillingProfileIdControl;
  }

  // hidden
  get paymentChannelCodeControl(): FormControl {
    return this.paymentMethodFormGroup.paymentChannelCodeControl;
  }

  // hidden
  get safeIdControl(): FormControl {
    return this.paymentMethodFormGroup.safeIdControl;
  }

  // Only if in 'application' mode.
  get paymentFrequencyControl(): FormControl {
    // Added dynamically.
    return this.paymentMethodFormGroup.get(PaymentMethodSelectionComponent.PAYMENT_FREQUENCY_CONTROL) as FormControl;
  }
}
