import { PaymentFrequencyType } from './payment_frequency_type';
import { PaymentPlanTypeModel, PaymentPlanTypeModelImpl } from './payment-plan-type-model';
import { BillingProfileModel, BillingProfileModelImpl } from './billing-profile-model';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../utils/date-converter';
import {
  PaymentPlanInstallmentModel,
  PaymentPlanInstallmentModelImpl,
} from '../billing/payment-plan-installment-model';
import { PaymentPlanLineModel, PaymentPlanLineModelImpl } from '../billing/payment-plan-line-model';
import { PaymentModel, PaymentModelImpl } from '../billing/payment-model';
import { PaymentPlanLineTypeCode } from '../billing/payment-plan-line-type-code';

export interface PaymentPlanModel {
  id: number;
  productId: number;
  startDate: Date;
  endDate: Date;
  purchaseAmount: number;
  surchargeAmount: number;
  totalAmount: number;
  totalPaidAmount: number;
  totalDueAmount: number;
  nextPaymentDueAmount: number;
  nextPaymentDueDate: Date;
  paymentPlanTypeModel: PaymentPlanTypeModel;
  billingProfileModel: BillingProfileModel | null; // No BillingProfileModel for non-electronic payment methods.
  paymentPlanInstallmentModels: PaymentPlanInstallmentModel[];
  paymentPlanLineModels: PaymentPlanLineModel[];
  paymentModels: PaymentModel[];

  readonly paymentFrequencyType: PaymentFrequencyType;

  readonly totalPlanAmount: number;

  readonly latestPayment: PaymentModel | undefined;

  readonly premiumAmount: number;

  readonly deliveryFeeAmount: number;

  getPaymentPlanLineModelByTypeCode(typeCode: PaymentPlanLineTypeCode): PaymentPlanLineModel | undefined;
}

@JsonObject('PaymentPlanModelImpl')
export class PaymentPlanModelImpl implements PaymentPlanModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('productId', Number, true)
  productId: number = null;

  @JsonProperty('startDate', DateConverter, true)
  startDate: Date = null;

  @JsonProperty('endDate', DateConverter, true)
  endDate: Date = null;

  @JsonProperty('purchaseAmount', Number, true)
  purchaseAmount: number = null;

  @JsonProperty('surchargeAmount', Number, true)
  surchargeAmount: number = null;

  @JsonProperty('totalAmount', Number, true)
  totalAmount: number = null;

  @JsonProperty('totalPaidAmount', Number, true)
  totalPaidAmount: number = null;

  @JsonProperty('totalDueAmount', Number, true)
  totalDueAmount: number = null;

  @JsonProperty('nextPaymentDueAmount', Number, true)
  nextPaymentDueAmount: number = null;

  @JsonProperty('nextPaymentDueDate', DateConverter, true)
  nextPaymentDueDate: Date = null;

  @JsonProperty('paymentPlanTypeModel', PaymentPlanTypeModelImpl, true)
  paymentPlanTypeModel: PaymentPlanTypeModel = null;

  @JsonProperty('billingProfileModel', BillingProfileModelImpl, true)
  billingProfileModel: BillingProfileModel | null = null; // No BillingProfileModel for non-electronic payment methods.

  @JsonProperty('paymentPlanInstallmentModels', [PaymentPlanInstallmentModelImpl], true)
  paymentPlanInstallmentModels: PaymentPlanInstallmentModel[] = [];

  @JsonProperty('paymentPlanLineModels', [PaymentPlanLineModelImpl], true)
  paymentPlanLineModels: PaymentPlanLineModel[] = [];

  @JsonProperty('paymentModels', [PaymentModelImpl], true)
  paymentModels: PaymentModel[] = [];

  get paymentFrequencyType(): PaymentFrequencyType {
    return this.paymentPlanTypeModel.paymentFrequencyType;
  }

  get totalPlanAmount(): number {
    return this.totalAmount;
  }

  get latestPayment(): PaymentModel | undefined {
    let paymentModel;
    if (this.paymentModels.length > 0) {
      paymentModel = this.paymentModels.reduce((pm_accum, pm_candidate) => {
        return pm_candidate.processedTimestamp > pm_accum.processedTimestamp ? pm_candidate : pm_accum;
      });
    }
    return paymentModel;
  }

  getPaymentPlanLineModelByTypeCode(typeCode: PaymentPlanLineTypeCode): PaymentPlanLineModel | undefined {
    let paymentPlanLineModel: PaymentPlanLineModel;
    paymentPlanLineModel = this.paymentPlanLineModels.find(
      ppl => ppl.paymentPlanLineTypeCode === typeCode);
    return paymentPlanLineModel;
  }

  get premiumAmount(): number {
    let amount = 0;
    const paymentPlanLineModel = this.getPaymentPlanLineModelByTypeCode(PaymentPlanLineTypeCode.PREMIUM);
    if (!!paymentPlanLineModel) {
      amount = paymentPlanLineModel.amount;
    }
    return amount;
  }

  get deliveryFeeAmount(): number {
    let amount = 0;
    const paymentPlanLineModel = this.getPaymentPlanLineModelByTypeCode(PaymentPlanLineTypeCode.DELIVERY);
    if (!!paymentPlanLineModel) {
      amount = paymentPlanLineModel.amount;
    }
    return amount;
  }
}
