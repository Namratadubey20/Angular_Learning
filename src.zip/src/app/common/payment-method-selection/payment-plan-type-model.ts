import { PaymentChannelCode, PaymentChannelCodeConverter } from './payment_channel_code';
import { PaymentFrequencyType, PaymentFrequencyTypeConverter } from './payment_frequency_type';
import { JsonObject, JsonProperty } from 'json2typescript';
import {
  PaymentPlanInstallmentModel,
  PaymentPlanInstallmentModelImpl,
} from '../billing/payment-plan-installment-model';
import { PaymentPlanLineModel, PaymentPlanLineModelImpl } from '../billing/payment-plan-line-model';
import { PaymentPlanLineTypeCode } from '../billing/payment-plan-line-type-code';

export interface PaymentPlanTypeModel {
  id: number;
  totalInstallments: number;
  initialInstallments: number;
  paymentChannelCode: PaymentChannelCode;
  paymentFrequencyType: PaymentFrequencyType;

  isSingleInstallment(): boolean;

  totalPaymentCount(): number;

  recurringPaymentCount(): number;

  isYearly(): boolean;

  isMonthly(): boolean;
}

@JsonObject('PaymentPlanTypeModelImpl')
export class PaymentPlanTypeModelImpl implements PaymentPlanTypeModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('totalInstallments', Number, true)
  totalInstallments: number = null;

  @JsonProperty('initialInstallments', Number, true)
  initialInstallments: number = null;

  @JsonProperty('paymentChannelCode', PaymentChannelCodeConverter, true)
  paymentChannelCode: PaymentChannelCode = null;

  @JsonProperty('paymentFrequencyType', PaymentFrequencyTypeConverter, true)
  paymentFrequencyType: PaymentFrequencyType = null;

  public isSingleInstallment(): boolean {
    return this.totalInstallments === this.initialInstallments;
  }

  public totalPaymentCount(): number {
    return this.totalInstallments;
  }

  public recurringPaymentCount(): number {
    return this.totalInstallments - this.initialInstallments;
  }

  public isYearly(): boolean {
    return this.paymentFrequencyType === PaymentFrequencyType.YEARLY;
  }

  public isMonthly(): boolean {
    return this.paymentFrequencyType === PaymentFrequencyType.MONTHLY;
  }
}


export interface AppliedPaymentPlanTypeModel {
  paymentPlanTypeModel: PaymentPlanTypeModel;
  annualPremiumAmount: number;
  initialAmount: number;
  recurringAmount: number;
  totalPlanAmount: number;
  paymentPlanInstallmentModels: PaymentPlanInstallmentModel[];
  paymentPlanLineModels: PaymentPlanLineModel[];

  readonly premiumAmount: number;

  readonly deliveryFeeAmount: number;

  getPaymentPlanLineModelByTypeCode(typeCode: PaymentPlanLineTypeCode): PaymentPlanLineModel | undefined;
}

@JsonObject('AppliedPaymentPlanTypeModelImpl')
export class AppliedPaymentPlanTypeModelImpl implements AppliedPaymentPlanTypeModel {
  @JsonProperty('paymentPlanType', PaymentPlanTypeModelImpl, true)
  paymentPlanTypeModel: PaymentPlanTypeModelImpl = new PaymentPlanTypeModelImpl();

  @JsonProperty('annualPremiumAmount', Number, true)
  annualPremiumAmount: number = null;

  @JsonProperty('initialAmount', Number, true)
  initialAmount: number = null;

  @JsonProperty('recurringAmount', Number, true)
  recurringAmount: number = null;

  @JsonProperty('totalPlanAmount', Number, true)
  totalPlanAmount: number = null;

  @JsonProperty('paymentPlanInstallments', [PaymentPlanInstallmentModelImpl], true)
  paymentPlanInstallmentModels: PaymentPlanInstallmentModel[] = [];

  @JsonProperty('paymentPlanLines', [PaymentPlanLineModelImpl], true)
  paymentPlanLineModels: PaymentPlanLineModel[] = [];

  getPaymentPlanLineModelByTypeCode(typeCode: PaymentPlanLineTypeCode): PaymentPlanLineModel | undefined {
    let paymentPlanLineModel: PaymentPlanLineModel;
    paymentPlanLineModel = this.paymentPlanLineModels.find(
      ppl => ppl.paymentPlanLineTypeCode === typeCode);
    return paymentPlanLineModel;
  }

  get premiumAmount(): number {
    let amount = 0;
    const paymentPlanLineModel = this.getPaymentPlanLineModelByTypeCode(PaymentPlanLineTypeCode.PREMIUM);
    if (!!paymentPlanLineModel) {
      amount = paymentPlanLineModel.amount;
    }
    return amount;
  }

  get deliveryFeeAmount(): number {
    let amount = 0;
    const paymentPlanLineModel = this.getPaymentPlanLineModelByTypeCode(PaymentPlanLineTypeCode.DELIVERY);
    if (!!paymentPlanLineModel) {
      amount = paymentPlanLineModel.amount;
    }
    return amount;
  }
}
