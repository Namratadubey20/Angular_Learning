import { BehaviorSubject } from 'rxjs';
import { BillingPerson } from './billing-person';

/**
 * Groups read-only 'reference' data used while completing an application.
 */
export class PaymentMethodInitializationData {
  readonly applicantBillingPerson$ = new BehaviorSubject<BillingPerson>(undefined);
  readonly secondaryBillingPerson$ = new BehaviorSubject<BillingPerson>(undefined);
  // processPaymentInformation$ indicates whether server-side application processing should process billing information.
  readonly processPaymentInformation$ = new BehaviorSubject<boolean>(false);

  /**
   *
   * @param agentIsApplicant
   * @param currentUserIsSteward
   * @param excludePrimaryPersonBillingProfilesFromSecondaryPerson If true, exclude the Primary Person's Billing Profiles
   * when the Secondary Person is creating/referencing Billing Profiles.
   * @param paymentMethodToBeUsedImmediately If true, the result of the payment-method-selection process will be used immediately.
   * And so, collect additional information and validate accordingly.
   */
  constructor(public readonly agentIsApplicant: boolean
    , public readonly currentUserIsSteward: boolean
    , public readonly excludePrimaryPersonBillingProfilesFromSecondaryPerson: boolean
    , public readonly paymentMethodToBeUsedImmediately: boolean
  ) {
  }

  /**
   * If true, include in application server request that billing information should be processed.
   */
  isProcessPaymentInformation(): boolean {
    let isProcess;
    isProcess = this.processPaymentInformation$.value;
    return isProcess;
  }
}
