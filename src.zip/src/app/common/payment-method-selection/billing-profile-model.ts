import { Address, AddressImpl } from '../../enrollment/application/court/model/common/address';
import { PaymentChannelCode, PaymentChannelCodeConverter } from './payment_channel_code';
import { PaymentChannelType } from './payment_channel_type';
import { AchAccountType, AchAccountTypeConverter } from './ach_account_type';
import { AchAccountHolderType, AchAccountHolderTypeConverter } from './ach_account_holder_type';
import { AchSecCode, AchSecCodeConverter } from './ach_sec_code';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../utils/date-converter';

export interface BillingProfileModel {
  billingProfileId: number;
  personId: number;
  paymentChannelCode: PaymentChannelCode;
  billingFirstName: string;
  billingLastName: string;
  billingName: string;
  billingAddress: Address;
  billingPhone: string;
  cardNumber?: string;
  cardCVV?: string;
  cardExpiration?: string;
  achAccountNumber?: string;
  achRoutingNumber?: string;
  achAccountType?: AchAccountType;
  achAccountHolderType?: AchAccountHolderType;
  achSecCode?: AchSecCode;
  bankName?: string;
  readonly deactivationTimestamp?: Date;
  readonly paymentChannelType: PaymentChannelType;
}

@JsonObject('BillingProfileModelImpl')
export class BillingProfileModelImpl implements BillingProfileModel {
  @JsonProperty('id', Number, true)
  billingProfileId: number = null;

  @JsonProperty('personId', Number, true)
  personId: number = null;

  @JsonProperty('paymentChannelCode', PaymentChannelCodeConverter, true)
  paymentChannelCode: PaymentChannelCode = null;

  @JsonProperty('billingFirstName', String, true)
  billingFirstName: string = null;

  @JsonProperty('billingLastName', String, true)
  billingLastName: string = null;

  @JsonProperty('billingName', String, true)
  billingName: string = null;

  @JsonProperty('billingAddress', AddressImpl, true)
  billingAddress: Address = new AddressImpl();

  @JsonProperty('billingPhone', String, true)
  billingPhone: string = null;

  @JsonProperty('cardNumber', String, true)
  cardNumber?: string = null;

  @JsonProperty('cardCVV', String, true)
  cardCVV?: string = null;

  @JsonProperty('cardExpiration', String, true)
  cardExpiration?: string = null;

  @JsonProperty('achAccountNumber', String, true)
  achAccountNumber?: string = null;

  @JsonProperty('achRoutingNumber', String, true)
  achRoutingNumber?: string = null;

  @JsonProperty('achAccountType', AchAccountTypeConverter, true)
  achAccountType?: AchAccountType = null;

  @JsonProperty('achAccountHolderType', AchAccountHolderTypeConverter, true)
  achAccountHolderType?: AchAccountHolderType = null;

  @JsonProperty('achSecCode', AchSecCodeConverter, true)
  achSecCode?: AchSecCode = null;

  @JsonProperty('bankName', String, true)
  bankName?: string = null;

  @JsonProperty('deactivationTimestamp', DateConverter, true)
  deactivationTimestamp?: Date = null;

  get paymentChannelType(): PaymentChannelType {
    return this.paymentChannelCode.paymentChannelType;
  }
}
