import { PaymentFrequencyType } from './payment_frequency_type';
import { PaymentChannelCode } from './payment_channel_code';
import { PaymentPlanTypeModel, PaymentPlanTypeModelImpl } from './payment-plan-type-model';
import { BillingProfileModel, BillingProfileModelImpl } from './billing-profile-model';
import { JsonObject, JsonProperty } from 'json2typescript';
import { LocalDateConverter } from '../utils/local-date-converter';

export interface PaymentPlanSummaryModel {
  id: number;
  productId: number;
  startDate: Date;
  endDate: Date;
  purchaseAmount: number;
  surchargeAmount: number;
  totalAmount: number;
  totalPaidAmount: number;
  totalDueAmount: number;
  nextPaymentDueAmount: number;
  nextPaymentDueDate: Date;
  paymentPlanTypeModel: PaymentPlanTypeModel;
  billingProfileModel: BillingProfileModel | null; // No BillingProfileModel for non-electronic payment methods.
}

@JsonObject('PaymentPlanSummaryModelImpl')
export class PaymentPlanSummaryModelImpl implements PaymentPlanSummaryModel {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('productId', Number, true)
  productId: number = null;

  @JsonProperty('startDate', LocalDateConverter, true)
  startDate: Date = null;

  @JsonProperty('endDate', LocalDateConverter, true)
  endDate: Date = null;

  @JsonProperty('purchaseAmount', Number, true)
  purchaseAmount: number = null;

  @JsonProperty('surchargeAmount', Number, true)
  surchargeAmount: number = null;

  @JsonProperty('totalAmount', Number, true)
  totalAmount: number = null;

  @JsonProperty('totalPaidAmount', Number, true)
  totalPaidAmount: number = null;

  @JsonProperty('totalDueAmount', Number, true)
  totalDueAmount: number = null;

  @JsonProperty('nextPaymentDueAmount', Number, true)
  nextPaymentDueAmount: number = null;

  @JsonProperty('nextPaymentDueDate', LocalDateConverter, true)
  nextPaymentDueDate: Date = null;

  @JsonProperty('paymentPlanTypeModel', PaymentPlanTypeModelImpl, true)
  paymentPlanTypeModel: PaymentPlanTypeModel = null;

  @JsonProperty('billingProfileModel', BillingProfileModelImpl, true)
  billingProfileModel: BillingProfileModel | null = null; // No BillingProfileModel for non-electronic payment methods.

  /**
   * Maps to PaymentChannelCode via PaymentChannelCode.valueOf()
   */
  get paymentCode(): string {
    return this.paymentChannelCode.persistenceId;
  }

  get paymentChannelCode(): PaymentChannelCode {
    let paymentChannelCode: PaymentChannelCode;
    if (!!this.billingProfileModel) {
      // There is a billingProfile associated with the payment plan, it will provide info.
      paymentChannelCode = this.billingProfileModel.paymentChannelCode;
    } else {
      // There is no billingProfile associated with the payment plan, fall back to paymentPlanTypeModel.
      paymentChannelCode = this.paymentPlanTypeModel.paymentChannelCode;
    }
    return paymentChannelCode;
  }

  get paymentFrequencyType(): PaymentFrequencyType {
    return this.paymentPlanTypeModel.paymentFrequencyType;
  }
}
