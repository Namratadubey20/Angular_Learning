import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FileUploadConfig } from '../file-upload/file-upload-config';
import { DocumentUploadComponent } from '../document-upload/document-upload.component';
import { MatRadioChange } from '@angular/material';

@Component({
  selector: 'app-special-bond',
  templateUrl: './special-bond.component.html',
  styleUrls: ['./special-bond.component.css'],
})
export class SpecialBondComponent extends DocumentUploadComponent {

  @Input()
  specialBondFileFormGroup: FormGroup;

  // FileUploadConfig for uploading the special bond file.
  fileUploadConfig: FileUploadConfig;

  @Input()
  disableSpecialBondButton: boolean;

  constructor() {
    super();
    this.fileUploadConfig = new FileUploadConfig();
    this.fileUploadConfig.acceptsFileTypes = '.pdf,.doc,.docx,.jpg,.jpeg';
  }

  /**
   * Invoked when the presence of a specialBond Form has changed.
   * @param event radio button Group change event.
   */
  specialBondFormChanged(event: MatRadioChange) {
    const isSpecialBondForm = event.value;
    if (isSpecialBondForm) {
    } else {
      // Clear out the document submission mode UI.
      this.specialBondUpload.reset();
      this.fireFileUploadSubmitModeChanged(false);
    }
  }

  get specialBondForm(): FormControl {
    return this.specialBondFileFormGroup.get('specialBondForm') as FormControl;
  }

  get specialBondUpload(): FormControl {
    return this.specialBondFileFormGroup.get('specialBondUpload') as FormControl;
  }

  get uploadSpecialBondFileFormGroup(): FormGroup {
    return this.specialBondFileFormGroup.get('specialBondFile') as FormGroup;
  }
}
