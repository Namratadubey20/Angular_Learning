import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-client-company-details',
  templateUrl: './client-company-details.component.html',
  styleUrls: ['./client-company-details.component.css'],
})
export class ClientCompanyDetailsComponent {

  @Input() companyFormGroup: FormGroup;

  get name(): FormControl {
    return this.companyFormGroup.get('name') as FormControl;
  }

  get email(): FormControl {
    return this.companyFormGroup.get('email') as FormControl;
  }

  get fax(): FormControl {
    return this.companyFormGroup.get('fax') as FormControl;
  }

  get phone(): FormControl {
    return this.companyFormGroup.get('phone') as FormControl;
  }

  get website(): FormControl {
    return this.companyFormGroup.get('website') as FormControl;
  }

  get companyAddress(): FormGroup {
    return this.companyFormGroup.get('companyAddress') as FormGroup;
  }

}
