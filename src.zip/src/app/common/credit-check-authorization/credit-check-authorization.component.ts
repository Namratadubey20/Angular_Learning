import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CreditCheckAuthorizationService } from './credit-check-authorization.service';
import { states } from '../utils/constants';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-credit-check-authorization',
  templateUrl: './credit-check-authorization.component.html',
  styleUrls: ['./credit-check-authorization.component.css'],
})
export class CreditCheckAuthorizationComponent implements OnDestroy, OnInit {

  @Input()
  creditCheckFormGroup: FormGroup;

  @Input()
  applicantPersonId: number;

  @Input()
  isSteward: boolean;

  @Output()
  creditCheckRequiredEvent: EventEmitter<Boolean> = new EventEmitter<Boolean>();

  showSsn: Boolean;

  @Input()
  applicantInfo: any;

  states = states;
  ssnAddress;
  applicationId: number;
  disabledInput = false;
  ownerName;

  constructor(
    private creditCheckAuthorizationService: CreditCheckAuthorizationService,
    private securityService: SecurityService
  ) {
  }

  ngOnDestroy(): void {
    this.showSsn = null;
  }

  async ngOnInit() {
    if (!this.applicantPersonId || this.isSteward ||
      (this.creditScoreSatisfactory.value === null ? false : (this.creditScoreSatisfactory.value === false ? false : true))) {
      this.showSsn = false;
      this.creditCheckAuthorized.clearValidators();
    } else {
      this.showSsn = await this.creditCheckAuthorizationService.creditCheckRequired(this.applicantPersonId);
      if (this.showSsn) {
        if (this.creditCheckAuthorized) {
          this.creditCheckAuthorized.setValidators([Validators.required]);
          this.creditCheckAuthorized.updateValueAndValidity();
        }
        this.applicantSSNum.setValidators([Validators.required, Validators.pattern(/^\d{3}-\d{2}-\d{4}$/)]);
        this.applicantSSNum.updateValueAndValidity();
        this.applicantSSNum.reset();
        this.creditCheckRequiredEvent.emit(true);
      }
    }

    this.creditCheckAuthorized.updateValueAndValidity();
    this.creditCheckAddressSameAsApplicant.setValue(true);

    const personAddress = this.securityService.user['person'].personAddresses;
    if (personAddress.length && personAddress[0].state) {
      await this.creditCheckAddressFormGroup.patchValue({
        street1: personAddress[0].street1,
        street2: personAddress[0].street2,
        city: personAddress[0].city,
        state: personAddress[0].state,
        zipCode: personAddress[0].zipCode,
      });
      this.creditCheckAddressFormGroup.get('street1').disable();
      this.creditCheckAddressFormGroup.get('street2').disable();
      this.creditCheckAddressFormGroup.get('city').disable();
      this.creditCheckAddressFormGroup.get('zipCode').disable();
      this.disabledInput = true;
    }
    this.ownerName = this.securityService.user['person'] ? this.securityService.user['person'].fullName : '';
  }

  get creditScoreSatisfactory(): FormControl {
    return this.creditCheckFormGroup.get('creditScoreSatisfactory') as FormControl;
  }

  get applicantSSNum(): FormControl {
    return this.creditCheckFormGroup.get('applicantSSNum') as FormControl;
  }

  get creditCheckAuthorized(): FormControl {
    return this.creditCheckFormGroup.get('creditCheckAuthorized') as FormControl;
  }

  get creditCheckSignaturesFormGroup(): FormGroup {
    return this.creditCheckFormGroup.get('creditCheckSignatures') as FormGroup;
  }

  get signatureName(): FormControl {
    return this.creditCheckSignaturesFormGroup.get('signatureName') as FormControl;
  }

  get creditCheckAddressSameAsApplicant(): FormControl {
    return this.creditCheckFormGroup.get('creditCheckAddressSameAsApplicant') as FormControl;
  }

  get creditCheckAddressFormGroup(): FormGroup {
    return this.creditCheckFormGroup.get('applicantCreditCheckAddress') as FormGroup;
  }

  trackByStateAbbrev(index: number, stateAbbreviation: string): string {
    return stateAbbreviation;
  }

  get ssnErrorMessage(): string {
    return this.applicantSSNum.hasError('required') ? 'Social Security Number is required.' :
      this.applicantSSNum.hasError('pattern') ? 'Social Security Number not valid.' : '';
  }

}
