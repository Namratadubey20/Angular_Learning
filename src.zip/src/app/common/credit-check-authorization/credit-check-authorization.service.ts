import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class CreditCheckAuthorizationService {

  requestUrl = 'api/credit';

  constructor(private http: HttpClient) { }

  async creditCheckRequired(personId: number): Promise<Boolean> {
    return await this.http.get(`${this.requestUrl}/required/${personId}`).toPromise() as Promise<Boolean>;
  }

}
