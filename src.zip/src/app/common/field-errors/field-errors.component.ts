import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CurrencyFormatter } from '../utils/currency-formatter';
import { ErrorFieldName } from './error-field-name';

@Component({
  selector: 'app-field-errors',
  templateUrl: './field-errors.component.html',
  styleUrls: ['./field-errors.component.css'],
})

export class FieldErrorsComponent implements OnInit {
  static seenTheseBefore = {};

  @Input() formGroup: FormGroup;
  @Input() fieldName: string;
  @Input() labelName: string;
  @Input() validFormat: string;
  @Input() format: string;
  @Input() minLength: string;

  constructor() {
  }

  ngOnInit() {
  }

  getFieldErrors(): Array<String> {
    try {
      const control = this.formGroup.get(this.fieldName);
      if (control) {
        if ((control.invalid && control.touched)) {
          const errors = control.errors;
          const arr: Array<String> = [];

          for (const errorsKey in errors) {
            if (errors[errorsKey]) {
              switch (errorsKey) {
                case 'required':
                  arr.push(this.labelName + ' is required.');
                  break;
                case 'min':
                  arr.push(this.labelName + ' must be greater than or equal to ' + errors[errorsKey].min);
                  break;
                case 'max':
                  arr.push(this.labelName + ' must be less than or equal to ' + errors[errorsKey].max);
                  break;
                case 'email':
                  arr.push(this.labelName + ' must be a valid email');
                  break;
                case 'pattern':
                  if (this.format) {
                    arr.push(this.labelName + ' must match the format \'' + this.format + '\'');
                  } else if (this.minLength) {
                    arr.push(this.labelName + ' must have ' + this.minLength + ' digits');
                  } else {
                    arr.push(this.labelName + ' has an invalid format');
                  }
                  break;
                case ErrorFieldName.FormError:
                  arr.push(errors[errorsKey]);
                  break;
                case 'minlength':
                  arr.push(this.labelName + ' must have minimum length of ' + errors[errorsKey].requiredLength);
                  break;
                case 'maxlength':
                  arr.push(this.labelName + ' cannot be longer than ' + errors[errorsKey].requiredLength + ' characters');
                  break;
                case ErrorFieldName.CardNumber:
                  arr.push(this.labelName + ' is not a valid card number');
                  break;
                case 'expirationDate':
                  arr.push(this.labelName + ' is not a valid expiration date');
                  break;
                case 'errors':
                  if (errors['errors']['cardExpiration']) {
                    arr.push(this.labelName + ' ' + errors['errors']['cardExpiration'].value);
                  }
                  break;
                case ErrorFieldName.ABARoutingNumber:
                  arr.push(this.labelName + ' is not a valid routing number');
                  break;
                case 'moneyMin':
                  arr.push(this.labelName + ' must be greater than or equal to ' +
                    CurrencyFormatter.formatMoney(errors[errorsKey].min));
                  break;
                case 'moneyMax':
                  arr.push(this.labelName + ' must be less than or equal to ' +
                    CurrencyFormatter.formatMoney(errors[errorsKey].max));
                  break;
                case 'moneyInvalid':
                  arr.push(this.labelName + ' must be a number');
                  break;
                case 'date':
                  arr.push(this.labelName + ' ' + errors[errorsKey].error);
                  break;
                case 'dateMin':
                  arr.push(this.labelName + ' must be after today');
                  break;
                case 'onOrBeforeToday':
                  arr.push(this.labelName + ' must be on or before today');
                  break;
                case 'valueMatch':
                  arr.push(this.labelName + ' must equal ' + errors[errorsKey]);
                  break;
                case ErrorFieldName.MatchValue:
                  arr.push(this.labelName + ' must match ' + errors[errorsKey]);
                  break;
                case 'space':
                  arr.push(this.labelName + ' cannot contain spaces');
                  break;
                case 'fromToday':
                  arr.push('Selected date must be valid');
                  break;
              }
            }

          } return arr;
        }
      } else {
        if (!FieldErrorsComponent.seenTheseBefore[this.fieldName]) {
          console.warn(`warning:  field "${this.fieldName}" not found in formGroup: ${JSON.stringify(this.formGroup.value, undefined, 2)}`);
        }
        FieldErrorsComponent.seenTheseBefore[this.fieldName] = true;
      }
    } catch (Error) {
      console.error('Something went wrong validating a field');
    }
  }
}
