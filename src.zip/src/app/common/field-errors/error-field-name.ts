export enum ErrorFieldName {
  CardNumber = 'cardNumber',
  ABARoutingNumber = 'abaRoutingNumber',
  MatchValue = 'matchValue',
  FormError = 'formError',
}
