import { Component, OnInit, Input } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-debtor-interested-party',
  templateUrl: './debtor-interested-party.component.html',
  styleUrls: ['./debtor-interested-party.component.css'],
})
export class DebtorInterestedPartyComponent {

  @Input()
  debtorInterestedPartyFormGroup: FormGroup;

  constructor() { }

  get name(): FormControl {
    return this.debtorInterestedPartyFormGroup.get('name') as FormControl;
  }

  get age(): FormControl {
    return this.debtorInterestedPartyFormGroup.get('age') as FormControl;
  }

  get relationship(): FormControl {
    return this.debtorInterestedPartyFormGroup.get('relationship') as FormControl;
  }

  get address(): FormGroup {
    return this.debtorInterestedPartyFormGroup.get('address') as FormGroup;
  }

}
