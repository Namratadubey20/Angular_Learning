import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { CommonUtilities } from '../../utils/common-utilities';

@Component({
  selector: 'app-debtor-interested-party-list',
  templateUrl: './debtor-interested-party-list.component.html',
  styleUrls: ['./debtor-interested-party-list.component.css'],
})
export class DebtorInterestedPartyListComponent implements OnInit {
  @Input()
  debtorInterestedPartyFormArray: FormArray;

  @Input()
  debtorInterestedPartyEmptyFormGroup: FormGroup;

  @Input()
  atLeastOneRequired: boolean;

  @Input()
  disableButton: boolean;

  constructor() {
  }

  ngOnInit(): void {
    if (this.atLeastOneRequired && this.debtorInterestedPartyFormArray.length < 1) {
      this.addEmptyDebtorInterestedPartyFormGroup();
    }
  }

  addEmptyDebtorInterestedPartyFormGroup() {
    // debtorInterestedPartyEmptyFormGroup may already have been allocated so we clone it just to be safe.
    const emptyFormGroup = CommonUtilities.cloneAbstractControl(this.debtorInterestedPartyEmptyFormGroup);
    this.debtorInterestedPartyFormArray.push(emptyFormGroup);
  }

  removeDebtorInterestedPartyFormGroup(index: number) {
    this.debtorInterestedPartyFormArray.removeAt(index);
  }

  disableTrash() {
    return this.atLeastOneRequired ? this.debtorInterestedPartyFormArray.length === 1 : false;
  }

}
