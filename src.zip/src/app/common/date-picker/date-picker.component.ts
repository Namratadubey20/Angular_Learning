import { Component, OnInit, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormControl, Validator, ValidatorFn } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/common/utils/custom-date-formatter';

import * as moment from 'moment';
import { InvokeFunctionExpr } from '@angular/compiler';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class DatePickerComponent implements OnInit, OnDestroy {

  @Input()
  control: FormControl;

  @Input()
  validators: ValidatorFn[] = [];

  @Input()
  labelName: String;

  @Input()
  placeholder = 'MM/DD/YYYY';

  @Input()
  setMaxDateToday = true;

  today: Date = new Date();

  constructor(
    private changeDetector: ChangeDetectorRef
  ) { }

  ngOnInit() {
    if (this.validators.length > 0) {
      this.control.setValidators(this.validators);
    }
  }

  ngOnDestroy() {
    this.control.clearValidators();
    this.control.updateValueAndValidity();
  }

  get isDateValid(): Boolean {
    return this.control.valid;
  }

  getErrorMessage(pickerInput: string): string {
    if (!pickerInput || pickerInput === '') {
      return `${this.labelName} is required`;
      // return formValue === 'birthday' ? 'Date of Birth is required.' : 'Date Declared Incompetent is required.';
    }
    return this.isMyDateFormat(pickerInput);
  }

  isMyDateFormat(date: string): string {
    if (date.length !== 10) {
      return 'Date has an invalid format';
    } else {
      const tokenizeDate = date.split('/');

      if (tokenizeDate.length !== 3 || tokenizeDate[0].length !== 2 || tokenizeDate[1].length !== 2 || tokenizeDate[2].length !== 4) {
        return 'Date has an invalid format';
      } else if (new Date(date) > new Date() && this.setMaxDateToday) {
        return 'Date must be on or before today';
      } else if (moment(new Date(date), 'MM/DD/YYYY', true).isValid()) {
        this.control.setValue(new Date(date));
        this.control.setErrors({ 'valid': true });
        this.control.updateValueAndValidity();
        this.changeDetector.detectChanges();
      } else if (!moment(date, 'MM/DD/YYYY', true).isValid()) {
        return 'Please input a valid date.';
      } else {
        const year = this.today.getFullYear();
        if (new Date(date).getFullYear() < year - 100) {
          return 'Please input a valid date.';
        }
        this.control.setValue(new Date(date));
        this.control.setErrors({ 'valid': true });
        this.control.updateValueAndValidity();

        this.changeDetector.detectChanges();
        return;
      }
    }
  }
}
