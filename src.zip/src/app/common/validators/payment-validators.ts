import { FormControl, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import * as CardValidator from 'card-validator';
import * as BankRoutingNumberValidator from 'bank-routing-number-validator';
import * as moment from 'moment';
import { PaymentChannelCode } from '../payment-method-selection/payment_channel_code';
import { ErrorFieldName } from '../field-errors/error-field-name';

export class PaymentValidators {
  static creditCardNumber(paymentChannelCode: PaymentChannelCode | PaymentChannelCode[]): ValidatorFn {
    return (ctl: FormControl): ValidationErrors | null => {
      if (!!ctl) {
        const cardNumber = ctl.value;
        if (!!cardNumber) {
          const cvResult = CardValidator.number(cardNumber);
          let validType = true;
          if (cvResult.card) {
            validType = PaymentValidators.validateCreditCardPaymentMethod(cvResult.card.type, paymentChannelCode);
          }

          if (cvResult.isValid && validType) {
            return null;
          } else {
            return { [ErrorFieldName.CardNumber]: true };
          }
        }
      } else {
        return null;
      }
    };
  }

  static creditCardCVV(paymentChannelCode: PaymentChannelCode): ValidatorFn {
    return (creditCardCVVCtl: FormControl): ValidationErrors | null => {
      let validationErrors: ValidationErrors;
      if (!!creditCardCVVCtl) {
        const creditCardCVV = creditCardCVVCtl.value;
        if (!!creditCardCVV) {
          const cvvPattern = '^\\d{' + paymentChannelCode.cvvLength + '}$';
          validationErrors = Validators.pattern(cvvPattern)(creditCardCVVCtl);
        } else {
          validationErrors = null;
        }
      } else {
        validationErrors = null;
      }
      return validationErrors;
    };
  }

  static creditCardDate(): ValidatorFn {
    return (ctl: FormControl): ValidationErrors | null => {
      const ccDate = ctl.value;
      if (!!ccDate) {
        const parsedDate = moment(ccDate, 'MM/YY', true);
        let error = false;
        if (!parsedDate.isValid()) {
          // Pattern error.
          error = true;
          return { pattern: true };
        }
        if (parsedDate.endOf('month').isBefore(moment())) {
          // CC is expired error.
          error = true;
          return { dateMin: true };
        }
        if (!error) {
          return null;
        }
      } else {
        // No CC exp date, so exp date is valid as far as we're concerned.
        return null;
      }
    };
  }

  static achRoutingNumber(): ValidatorFn {
    return (routingNumberCtl: FormControl): ValidationErrors | null => {
      if (!routingNumberCtl) {
        return null;
      }
      return PaymentValidators.validateAchRoutingNumber(routingNumberCtl.value);
    };
  }

  static validateAchRoutingNumber(candidateValue: string | null | undefined): ValidationErrors | null {
    if (!candidateValue) {
      return null;
    }

    candidateValue = candidateValue.toString();

    const isProperFormat = candidateValue.match('^\\d{9}$');
    if (!isProperFormat) {
      return { [ErrorFieldName.ABARoutingNumber]: true };
    }

    const isValidABARoutingNumber = BankRoutingNumberValidator.ABARoutingNumberIsValid(candidateValue);
    if (!isValidABARoutingNumber) {
      return { [ErrorFieldName.ABARoutingNumber]: true };
    }
    // RoutingNumber is syntactically correct.
    // No check is made to ascertain that it corresponds to a bank. E.G. 000000123 is valid but does not map to a bank.
    return null;
  }

  static achAccountNumber(): ValidatorFn {
    let validatorFn: ValidatorFn;
    // Valid: 4-17 digit value
    validatorFn = Validators.pattern(/^\d{4,17}$/);
    return validatorFn;
  }

  private static validateCreditCardPaymentMethod(cardValidatorType: string
    , paymentChannelCodes: PaymentChannelCode | PaymentChannelCode[]): boolean {
    return (paymentChannelCodes instanceof Array ? paymentChannelCodes : [paymentChannelCodes])
      .some((paymentChannelCode) => paymentChannelCode.cardValidatorType === cardValidatorType);
  }
}
