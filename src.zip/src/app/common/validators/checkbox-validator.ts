import { FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class CheckboxValidator {
  static requireTrue(): ValidatorFn {
    return (control: FormControl): ValidationErrors | null => {
      return control.value !== true ? { requireTrue: true } : null;
    };
  }
}
