import { AbstractControl, ValidatorFn, Validators } from '@angular/forms';


export class ConditionalValidator {

  static conditionalRequire(condition: (() => boolean)): ValidatorFn {
    return this.conditionalValidator(condition, Validators.required);
  }

  static conditionalValidator(condition: (() => boolean), validator: ValidatorFn): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!condition()) {
        return null;
      } else {
        return validator(control);
      }
    };
  }

}
