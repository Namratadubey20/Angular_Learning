import { AbstractControl, FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ConditionalValidator } from './conditional-validator';


export class MultipleFieldValidators {
  static exactlyOneRequired(controlNames: string[]): ValidatorFn | null {
    return (control: AbstractControl): ValidationErrors | null => {
      for (const controlName of controlNames) {
        if (control.get(controlName) && !!control.get(controlName).value) {
          return null;
        }
      }
      return { exactlyOneRequired: true } as ValidationErrors;
    };
  }
}
