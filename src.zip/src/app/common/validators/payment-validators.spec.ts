import { PaymentValidators } from './payment-validators';
import { FormControl } from '@angular/forms';
import { ErrorFieldName } from '../field-errors/error-field-name';
import { PaymentChannelCode } from '../payment-method-selection/payment_channel_code';
import * as moment from 'moment';

describe('PaymentValidators', () => {

  describe('::validateAchRoutingNumber', () => {
    it('should return null for null value', () => {
      const validationErrors = PaymentValidators.validateAchRoutingNumber(null);
      expect(validationErrors).toEqual(null);
    });

    it('should return null for empty value', () => {
      const validationErrors = PaymentValidators.validateAchRoutingNumber('');
      expect(validationErrors).toEqual(null);
    });

    it('should return error for blank value', () => {
      const validationErrors = PaymentValidators.validateAchRoutingNumber('   ');
      expect(validationErrors.hasOwnProperty(ErrorFieldName.ABARoutingNumber)).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.validateAchRoutingNumber('abc');
      expect(validationErrors.hasOwnProperty(ErrorFieldName.ABARoutingNumber)).toBeTruthy();
    });

    it('should return error for invalid value', () => {
      const validationErrors = PaymentValidators.validateAchRoutingNumber('123456789');
      expect(validationErrors.hasOwnProperty(ErrorFieldName.ABARoutingNumber)).toBeTruthy();
    });

    it('should return error for untrimmed valid value', () => {
      const validationErrors = PaymentValidators.validateAchRoutingNumber('  021000021  ');
      expect(validationErrors.hasOwnProperty(ErrorFieldName.ABARoutingNumber)).toBeTruthy();
    });

    it('should return no error for valid value', () => {
      const validationErrors = PaymentValidators.validateAchRoutingNumber('021000021');
      expect(validationErrors).toBeNull();
    });
  });

  describe('::achAccountNumber', () => {
    it('should return null for null value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl(null));
      expect(validationErrors).toEqual(null);
    });

    it('should return null for empty value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl(''));
      expect(validationErrors).toEqual(null);
    });

    it('should return error for blank value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl('   '));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl('abc'));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl('123'));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl('123456789012345678'));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for untrimmed valid value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl('  12345678901234567  '));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return no error for valid value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl('1234'));
      expect(validationErrors).toBeNull();
    });

    it('should return no error for valid value', () => {
      const validationErrors = PaymentValidators.achAccountNumber()(new FormControl('12345678901234567'));
      expect(validationErrors).toBeNull();
    });
  });

  describe('::creditCardNumber for degenerate cases', () => {
    const paymentChannelCode = PaymentChannelCode.AMEX;
    it('should return undefined for null value', () => {
      const validationErrors = PaymentValidators.creditCardNumber(paymentChannelCode)(new FormControl(null));
      expect(validationErrors).toBeUndefined();
    });

    it('should return undefined for empty value', () => {
      const validationErrors = PaymentValidators.creditCardNumber(paymentChannelCode)(new FormControl(''));
      expect(validationErrors).toBeUndefined();
    });

    it('should return error for blank value', () => {
      const validationErrors = PaymentValidators.creditCardNumber(paymentChannelCode)(new FormControl('   '));
      expect(validationErrors.hasOwnProperty(ErrorFieldName.CardNumber)).toBeTruthy();
    });
  });

  describe('::creditCardNumber for invalid numbers', () => {
    const paymentChannelCodeToNumbers: Map<PaymentChannelCode, String[]> = new Map<PaymentChannelCode, String[]>();
    paymentChannelCodeToNumbers.set(PaymentChannelCode.AMEX, ['6011111111111117', 'abc', '123']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.DISCOVER, ['378282246310005', 'abc', '123']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.MASTER_CARD, ['4111111111111111', 'abc', '123']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.VISA, ['5555555555554444', 'abc', '123']);

    paymentChannelCodeToNumbers.forEach((numbers, paymentChannelCode) => {
      numbers.forEach(number => {
        it(`should return error for paymentChannelCode: ${paymentChannelCode.persistenceId}, improper value: '${number}'`, () => {
          const validationErrors = PaymentValidators.creditCardNumber(paymentChannelCode)(new FormControl(number));
          expect(validationErrors.hasOwnProperty(ErrorFieldName.CardNumber)).toBeTruthy();
        });
      });
    });
  });

  describe('::creditCardNumber for valid numbers', () => {
    const paymentChannelCodeToNumbers: Map<PaymentChannelCode, String[]> = new Map<PaymentChannelCode, String[]>();
    // Untrimmed otherwise valid values are valid.
    paymentChannelCodeToNumbers.set(PaymentChannelCode.AMEX, ['378282246310005', '  378282246310005  ']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.DISCOVER, ['6011111111111117', '  6011111111111117  ']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.MASTER_CARD, ['5555555555554444', '  5555555555554444  ']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.VISA, ['4111111111111111', '  4111111111111111  ']);

    paymentChannelCodeToNumbers.forEach((numbers, paymentChannelCode) => {
      numbers.forEach(number => {
        it(`should return no error (null) for paymentChannelCode: ${paymentChannelCode.persistenceId}, value: '${number}'`, () => {
          const validationErrors = PaymentValidators.creditCardNumber(paymentChannelCode)(new FormControl(number));
          expect(validationErrors).toBeNull();
        });
      });
    });
  });

  describe('::creditCardCVV for degenerate cases', () => {
    const paymentChannelCode = PaymentChannelCode.AMEX;
    it('should return null for null value', () => {
      const validationErrors = PaymentValidators.creditCardCVV(paymentChannelCode)(new FormControl(null));
      expect(validationErrors).toBeNull();
    });

    it('should return null for empty value', () => {
      const validationErrors = PaymentValidators.creditCardCVV(paymentChannelCode)(new FormControl(''));
      expect(validationErrors).toBeNull();
    });

    it('should return error for blank value', () => {
      const validationErrors = PaymentValidators.creditCardCVV(paymentChannelCode)(new FormControl('   '));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });
  });

  describe('::creditCardCVV for invalid numbers', () => {
    const paymentChannelCodeToNumbers: Map<PaymentChannelCode, String[]> = new Map<PaymentChannelCode, String[]>();
    paymentChannelCodeToNumbers.set(PaymentChannelCode.AMEX, ['123', 'abc', '12344', '  1234  ']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.DISCOVER, ['12', 'abc', '1234', '  123  ']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.MASTER_CARD, ['12', 'abc', '1234', '  123  ']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.VISA, ['12', 'abc', '1234', '  123  ']);

    paymentChannelCodeToNumbers.forEach((numbers, paymentChannelCode) => {
      numbers.forEach(number => {
        it(`should return error for paymentChannelCode: ${paymentChannelCode.persistenceId}, improper value: '${number}'`, () => {
          const validationErrors = PaymentValidators.creditCardCVV(paymentChannelCode)(new FormControl(number));
          expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
        });
      });
    });
  });

  describe('::creditCardCVV for valid numbers', () => {
    const paymentChannelCodeToNumbers: Map<PaymentChannelCode, String[]> = new Map<PaymentChannelCode, String[]>();
    // Untrimmed otherwise valid values are valid.
    paymentChannelCodeToNumbers.set(PaymentChannelCode.AMEX, ['1234']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.DISCOVER, ['123']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.MASTER_CARD, ['123']);
    paymentChannelCodeToNumbers.set(PaymentChannelCode.VISA, ['123']);

    paymentChannelCodeToNumbers.forEach((numbers, paymentChannelCode) => {
      numbers.forEach(number => {
        it(`should return no error (null) for paymentChannelCode: ${paymentChannelCode.persistenceId}, value: '${number}'`, () => {
          const validationErrors = PaymentValidators.creditCardCVV(paymentChannelCode)(new FormControl(number));
          expect(validationErrors).toBeNull();
        });
      });
    });
  });

  describe('::creditCardDate', () => {
    const now = moment();
    const nowMMYY = now.format('MM/YY');
    const pastMMYY = now.subtract(1, 'month').format('MM/YY');
    const nearFutureMMYY = now.add(1, 'month').format('MM/YY');

    it('should return null for null value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(null));
      expect(validationErrors).toEqual(null);
    });

    it('should return null for empty value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(''));
      expect(validationErrors).toEqual(null);
    });

    it('should return error for blank value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl('   '));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl('abc'));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl('123'));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(now.format('MM/YYYY')));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for improper value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(now.format('YYYY/MM')));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return error for untrimmed valid value', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(`    ${nowMMYY}    `));
      expect(validationErrors.hasOwnProperty('pattern')).toBeTruthy();
    });

    it('should return no error for now', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(nowMMYY));
      expect(validationErrors).toBeNull();
    });

    it('should return no error for near future', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(nearFutureMMYY));
      expect(validationErrors).toBeNull();
    });

    it('should return error for past date', () => {
      const validationErrors = PaymentValidators.creditCardDate()(new FormControl(pastMMYY));
      expect(validationErrors.hasOwnProperty('dateMin')).toBeTruthy();
    });
  });


});
