
import { ValidatorFn, Validators } from '@angular/forms';

// @dynamic
export class RoleBasedValidators {
  static requiredForNonAttorney(isAttorney: boolean): ValidatorFn[] {
    if (!isAttorney) {
      return [Validators.required];
    } else {
      return [];
    }
  }
}
