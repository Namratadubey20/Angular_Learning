import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ConditionalValidator } from '../conditional-validator';
import { Subscription } from 'rxjs';

/**
 * The configuration for the dynamic validation of a FormControl.
 * Dynamic in this case means that the validation logic varies depending on the state/value of another control.
 */
export class DynamicValidatorConfig {
  /**
   *
   * @param validatorFn to be registered with the FormControl. If the validatorFn depends on the state/value of another control
   * then that control's path should be included in valueChangingFormControlPaths.
   * @param valueChangingFormControlPaths the path(s) of the FormControl(s) that need to be observed for
   * 'valueChanges' to support dynamic validatorFn.
   * Paths are relative to the FormGroup that is provided when 'applying' the registrations.
   */
  constructor(validatorFn: ValidatorFn, valueChangingFormControlPaths: string | string[]) {
    this.validatorFn = validatorFn;
    this.valueChangingFormControlPaths = valueChangingFormControlPaths
      instanceof Array ? valueChangingFormControlPaths : [valueChangingFormControlPaths];
  }
  validatorFn: ValidatorFn;
  valueChangingFormControlPaths: string[];
}

/**
 * The configuration for the activation of conditional validation of a FormControl.
 */
export class ValidatorActivationConfig {
  /**
   *
   * @param validationActivationCondition if evaluates to true then the value of the registered
   * ValidatorFns will be returned during validation,
   * otherwise null is returned during validation and the registered ValidatorFns are not evaluated.
   * @param valueChangingFormControlPaths the path(s) of the FormControl(s) that need to be observed for 'valueChanges'
   * for proper triggering of validationActivationCondition evaluation.
   * Paths are relative to the FormGroup that is provided when 'applying' the registrations.
   */
  constructor(validationActivationCondition: (() => boolean), valueChangingFormControlPaths: string | string[]) {
    this.validationActivationCondition = validationActivationCondition;
    this.valueChangingFormControlPaths = valueChangingFormControlPaths
      instanceof Array ? valueChangingFormControlPaths : [valueChangingFormControlPaths];
  }
  validationActivationCondition: (() => boolean);
  valueChangingFormControlPaths: string[];
}

/**
 * Internal representation of an entry.
 */
interface RegistrarEntry {
  formControl: FormControl;
  validationActivationCondition: (() => boolean) | null;
  validatorFns: ValidatorFn[] | null;
  valueChangingFormControlPaths: string[] | null;
}

/**
 * Associates and manages ValidatorConfigs for multiple FormControls (with the same lifespan).
 */
export class ValidatorRegistrar {
  private registry: RegistrarEntry[] = [];
  private registrationsApplied = false;

  /**
   *
   * @param formControl with which validators (fixed or conditional) should be registered.
   * Note that validators already associated with the formControl will be overwritten.
   * @param validatorActivationConfig defines the conditions under which all validators ('static' or otherwise) will be evaluated.
   * @param conditionalValidatorFns the 'conditional' validators to be registered. (nullable).
   * 'static' validators depend only on the value of their associated formControl.
   * Their invocation depends on a varying condition specified via validatorActivationConfig.
   * @param dynamicValidatorConfigs configs of the 'conditional' validators to be registered. (optional).
   * 'dynamic' validators validate based on the value of another control which they have registered an interest in.
   * They are applied only if the validatorActivationConfig indicates that it should.
   */
  public registerValidators(formControl: FormControl
    , validatorActivationConfig: ValidatorActivationConfig
    , conditionalValidatorFns: null | ValidatorFn | ValidatorFn[]
    , dynamicValidatorConfigs?: DynamicValidatorConfig | DynamicValidatorConfig[]): FormControl {

    if (this.registrationsApplied) {
      throw new Error('Validation registrations have already been applied.');
    }

    if (this.registry.some((re) => re.formControl === formControl)) {
      throw new Error('Dynamic validators have already been registered for control.');
    }

    const registrarEntry: RegistrarEntry = {
      formControl: formControl,
      validationActivationCondition: null,
      validatorFns: new Array<ValidatorFn>(),
      valueChangingFormControlPaths: [],
    };

    if (!!validatorActivationConfig) {
      registrarEntry.validationActivationCondition = validatorActivationConfig.validationActivationCondition;
      registrarEntry.valueChangingFormControlPaths = registrarEntry.valueChangingFormControlPaths
        .concat(validatorActivationConfig.valueChangingFormControlPaths);
    }

    if (!!conditionalValidatorFns) {
      registrarEntry.validatorFns = registrarEntry.validatorFns
        .concat(conditionalValidatorFns instanceof Array ? conditionalValidatorFns : [conditionalValidatorFns]);
    }

    if (!!dynamicValidatorConfigs) {
      (dynamicValidatorConfigs
        instanceof Array ? dynamicValidatorConfigs : [dynamicValidatorConfigs])
        .forEach((dynamicValidatorConfig) => {
          registrarEntry.validatorFns.push(dynamicValidatorConfig.validatorFn);
          registrarEntry.valueChangingFormControlPaths = registrarEntry.valueChangingFormControlPaths
            .concat(dynamicValidatorConfig.valueChangingFormControlPaths);
        });
    }

    this.registry.push(registrarEntry);
    return formControl;
  }

  /**
   * Processes the registrations by setting the validators and establishing subscriptions.
   * @param rootFormGroup a parent FormGroup of all of the registered FormControls.
   * Paths within the ValidatorConfigs are relative to this rootFormGroup.
   * @param rootSubscription receives the subscriptions made to support the conditional/dynamic evaluation of validators.
   * It is the responsibility of the invoker to 'unsubscribe' these observables when appropriate.
   */
  public applyRegistrations(rootFormGroup: FormGroup, rootSubscription: Subscription) {
    if (!this.registrationsApplied) {
      this.registrationsApplied = true;
      // Associates the path of a control that needs to be observed with dependent FormControls.
      const observableFormControlPathToListeningFormControls = new Map<string, FormControl[]>();

      // Register the validators for each FormControl and build a list of FormControls to be observed for any conditional validators.
      this.registry.forEach((registration) => {
        // Register the validatorFns.

        if (!!registration.validationActivationCondition) {
          // We have an 'activation' condition. Use a ConditionalValidator to control the evaluation of the validators.
          const validatorFn = ConditionalValidator.conditionalValidator(registration.validationActivationCondition
            , Validators.compose(registration.validatorFns));
          registration.formControl.setValidators(validatorFn);
        } else {
          // No 'activation' condition. Always apply the validators.
          registration.formControl.setValidators(registration.validatorFns);
        }

        // Extract path of controls that need to be observed to support conditional validators.
        registration.valueChangingFormControlPaths.forEach((observableFormControlPath) => {
          let listeningFormControls = observableFormControlPathToListeningFormControls.get(observableFormControlPath);
          if (!listeningFormControls) {
            listeningFormControls = [];
            observableFormControlPathToListeningFormControls.set(observableFormControlPath, listeningFormControls);
          }
          if (!listeningFormControls.includes(registration.formControl)) {
            listeningFormControls.push(registration.formControl);
          }
        });
      }
      );

      // Register the dependent FormControls associated with the conditional validators as listeners
      // of the source-observable FormControls (specified by path).
      observableFormControlPathToListeningFormControls
        .forEach((listeningFormControls: FormControl[], observableFormControlPath: string) => {
          const observableFormControl: AbstractControl = rootFormGroup.get(observableFormControlPath);
          if (!!observableFormControl) {
            listeningFormControls.forEach((listeningFormControl) => {
              const subscription = observableFormControl.valueChanges.subscribe(() => listeningFormControl.updateValueAndValidity());
              rootSubscription.add(subscription);
            });
          }
        });
    }
  }
}
