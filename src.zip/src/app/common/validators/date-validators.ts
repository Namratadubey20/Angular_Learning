import { AbstractControl, ValidationErrors } from '@angular/forms';
import * as moment from 'moment';
// @dynamic
export class DateValidators {
  static afterToday() {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      if (new Date(control.value) < new Date()) {

        return { 'dateMin': true };
      }
    };
  }

  static fromToday() {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      if (new Date(control.value) === new Date()) {
        return { 'fromToday': true };
      }
    };
  }

  static onOrBeforeToday() {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      if (new Date(control.value) > new Date()) {
        return { 'onOrBeforeToday': true };
      }
    };
  }

  static datePatternValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }

      const todayDate = new Date();
      if (new Date(control.value).getFullYear() < todayDate.getFullYear() - 100) {
        return { 'pattern': true };
      }

      const date = moment(control.value).format('MM/DD/YYYY');
      const date_regex = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/;
      if (!date_regex.test(date)) {
        return { 'pattern': true };
      }

    };
  }
}
