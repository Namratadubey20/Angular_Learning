import { ValidatorFn, Validators } from '@angular/forms';

// @dynamic
export class PatternValidators {

  static ssn(): ValidatorFn {
    return Validators.pattern(/^\d{3}-\d{2}-\d{4}$/);
  }

  static phoneNumber(): ValidatorFn {
    return Validators.pattern(/^\d{3}-\d{3}-\d{4}$/);
  }
  static zipCode(): ValidatorFn {
    return Validators.pattern(/^\d{5}(-\d{4})?$/);
  }

  static email(): ValidatorFn {
    // return Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/);

    return Validators.pattern(
      /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9]*(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])+\.([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/
    );
  }

  static referralCode(): ValidatorFn {
    return Validators.pattern(/^[a-zA-z]{2}\d{4}/);
  }

  static alphanumeric(): ValidatorFn {
    return Validators.pattern(/^.*(?=.*\d)(?=.*[a-zA-Z]).*$/);
  }

  static numeric(): ValidatorFn {
    // return Validators.pattern(/^(0|[1-9]\d*)(\.\d+)?$/);
    // return Validators.pattern(/^([0-9]{1,7})+(\.[0-9]{1,2})?$/);
    // return Validators.pattern(/^(\d+(\.\d{0,2})?|\.?\d{1,2})$/);
    // return Validators.pattern(/^(\d{1,6})(\.\d{1,2})?/);
    return Validators.pattern(/^(\d{1,6})(\.\d{1,2})?$/);
  }

  static onlyAlphabet(): ValidatorFn {
    return Validators.pattern(/^[a-zA-Z ]*$/);
  }

  static alphaNumericOnly(): ValidatorFn {
    return Validators.pattern(/^[a-zA-Z0-9]*$/);
  }

}
