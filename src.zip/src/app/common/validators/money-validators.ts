import { AbstractControl, ValidationErrors } from '@angular/forms';

// @dynamic
export class MoneyValidators {
  static moneyMin(min: number) {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      const value = (control.value).toString().split(',').join('');
      if (isNaN(value)) {
        return { 'moneyInvalid': true };
      }
      if (value < min) {
        return {
          'moneyMin': {
            min,
          },
        };
      }
    };
  }

  static moneyMax(max: number) {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }
      const value = (control.value).toString().split(',').join('');
      if (isNaN(value)) {
        return { 'moneyInvalid': true };
      }
      if (value > max) {
        return {
          'moneyMax': {
            max,
          },
        };
      }
    };

  }
}
