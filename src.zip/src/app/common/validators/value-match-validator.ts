import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

// @dynamic
export class ValueMatchValidator {
  static matchingValues(key1: string, key2: string, ignoreWhitespaceAndSpecial: boolean = false,
    ignoreCase: boolean = false): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const key1Input = control.get(key1);
      const key2Input = control.get(key2);

      if (!key1Input || !key2Input) {
        return null;
      }
      if (ignoreWhitespaceAndSpecial) {
        const cleanInput1 = ValueMatchValidator.clean(key1Input.value);
        const cleanInput2 = ValueMatchValidator.clean(key2Input.value);
        const valid = ValueMatchValidator.checkEquality(cleanInput1, cleanInput2, ignoreCase);
        if (!valid) {
          control.get(key2).setErrors({ valueMatch: key1 });
        }
      } else {
        const valid = ValueMatchValidator.checkEquality(key1Input.value, key2Input.value, ignoreCase);
        if (!valid) {
          control.get(key2).setErrors({ valueMatch: key1 });
        }
      }
    };
  }

  static matchValueToField(value: string, key: string, ignoreWhitespaceAndSpecial: boolean = false,
    ignoreCase: boolean = false): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const fieldValue = control.get(key);
      if (!value || !fieldValue) {
        return null;
      }
      if (ignoreWhitespaceAndSpecial) {
        const cleanInput1 = ValueMatchValidator.clean(value);
        const cleanInput2 = ValueMatchValidator.clean(fieldValue.value);
        const valid = ValueMatchValidator.checkEquality(cleanInput1, cleanInput2, ignoreCase);
        if (!valid) {
          control.get(key).setErrors({ valueMatch: true });
        } else {
          return null;
        }

      } else {
        const valid = ValueMatchValidator.checkEquality(value, fieldValue.value, ignoreCase);
        if (!valid) {
          control.get(key).setErrors({ valueMatch: true });
        } else {
          return null;
        }
      }
    };
  }

  static clean(value: string): string {
    if (value) {
      const newValue = value.replace(/\./g, '')
        .replace(/,/g, '')
        .trim();
      return newValue;
    }
    return value;
  }

  static checkEquality(value1: string, value2: string, ignoreCase: boolean) {
    if (ignoreCase && value1 && value2) {
      return value1.toUpperCase() === value2.toUpperCase();
    } else {
      return value1 === value2;
    }
  }

  static noSpaces(key: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const fieldValue = control.get(key);

      if (!fieldValue || !fieldValue.value) {
        return null;
      }

      const invalid = fieldValue.value.includes(' ');
      if (invalid) {
        control.get(key).setErrors({ space: true });
      } else {
        return null;
      }
    };
  }
}

