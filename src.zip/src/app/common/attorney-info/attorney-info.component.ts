import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-attorney-info',
  templateUrl: './attorney-info.component.html',
  styleUrls: ['./attorney-info.component.css'],
})
export class AttorneyInfoComponent {

  @Input()
  attorneyInfoFormGroup: FormGroup;
  @Input() prefix: string;

  @Input()
  validate: boolean;

  constructor() {
  }

  withPrefix(label: string): string {
    if ((this.prefix !== undefined) && (this.prefix.length > 0)) {
      return this.prefix + ' ' + label;
    }
    return label;
  }

  get attorneyName(): FormControl {
    return this.attorneyInfoFormGroup.get('attorneyName') as FormControl;
  }

  get attorneyFirm(): FormControl {
    return this.attorneyInfoFormGroup.get('attorneyFirm') as FormControl;
  }


  get attorneyPhone(): FormControl {
    return this.attorneyInfoFormGroup.get('attorneyPhone') as FormControl;
  }

  get attorneyAddress(): FormGroup {
    return this.attorneyInfoFormGroup.get('attorneyAddress') as FormGroup;
  }

}
