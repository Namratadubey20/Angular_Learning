import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from './utils/date-converter';
import { AuditableObject } from './auditable-object';
import { Agent, AgentImpl } from './agent';
import { PersonAddress, PersonAddressImpl } from './person-address';
import { PhoneNumberConverter } from './utils/phone-number-converter';

export interface PersonSummary {
  id: number;
  agentId: number;
  clientContactsId: number;
  lastPurchaseDate: Date;
  firstName: string;
  initial: string;
  lastName: string;
  salutation: string;
  suffix: string;
  email: string;
  phone: string;
  fax: string;
  website: string;
  creditScore: number;
  creditScoreDate: Date;
  ssno: string;
  deactivated: boolean;
  personAddresses: PersonAddress[];
  agents: Agent[];
  readonly fullName: string;
  readonly isAgent: boolean;
  profession: string;
  defaultBillingProfileId: number;
  registrationNo: number;
}

@JsonObject('PersonSummaryImpl')
export class PersonSummaryImpl extends AuditableObject implements PersonSummary {
  constructor() {
    super();
    this.personAddresses[0] = new PersonAddressImpl();
  }

  @JsonProperty('agentId', Number, true)
  agentId: number = null;

  @JsonProperty('clientContactsId', Number, true)
  clientContactsId: number = null;

  @JsonProperty('lastPurchaseDate', DateConverter, true)
  lastPurchaseDate: Date = null;

  @JsonProperty('firstName', String, true)
  firstName: string = null;

  @JsonProperty('initial', String, true)
  initial: string = null;

  @JsonProperty('lastName', String, true)
  lastName: string = null;

  @JsonProperty('salutation', String, true)
  salutation: string = null;

  @JsonProperty('suffix', String, true)
  suffix: string = null;

  @JsonProperty('email', String, true)
  email: string = null;

  @JsonProperty('phone', PhoneNumberConverter, true)
  phone: string = null;

  @JsonProperty('fax', PhoneNumberConverter, true)
  fax: string = null;

  @JsonProperty('website', String, true)
  website: string = null;

  @JsonProperty('creditScore', Number, true)
  creditScore: number = null;

  @JsonProperty('creditScoreDate', DateConverter, true)
  creditScoreDate: Date = null;

  @JsonProperty('ssno', String, true)
  ssno: string = null;

  @JsonProperty('deactivated', Boolean, true)
  deactivated: boolean = null;

  @JsonProperty('personAddresses', [PersonAddressImpl], true)
  personAddresses: PersonAddress[] = [];

  @JsonProperty('agents', [AgentImpl], true)
  agents: Agent[] = [];

  @JsonProperty('profession', String, true)
  profession: string = null;

  @JsonProperty('defaultBillingProfileId', Number, true)
  defaultBillingProfileId: number = null;

  @JsonProperty('registrationNo', Number, true)
  registrationNo: number = null;

  /**
   * returns true if this person has an agent record
   * @returns {boolean}
   */
  get isAgent(): boolean {
    return this.agents && this.agents.length > 0;
  }

  get fullName(): string {
    return `${this.firstName} ${this.lastName}`;
  }
}
