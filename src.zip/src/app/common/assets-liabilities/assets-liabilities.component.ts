import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { CurrencyFormatter } from '../utils/currency-formatter';

@Component({
  selector: 'app-assets-liabilities',
  templateUrl: './assets-liabilities.component.html',
  styleUrls: ['./assets-liabilities.component.css'],
})
export class AssetsLiabilitiesComponent implements OnInit {

  @Input()
  assetsLiabilitiesFormGroup: FormGroup;
  networthPositive: boolean;
  networthNegative: boolean;

  constructor() {
  }

  ngOnInit(): void {
    this.updateTotalsOnChange();
    this.updateTotals();
  }

  updateTotalsOnChange(): void {
    this.allControlsWithUserInput.forEach((control: FormControl) => this.setOnChangeEvent(control));
  }

  updateTotals(): void {
    const aTotal = this.assetList.reduce((sum, current) => sum + current);
    const lTotal = this.liabilityList.reduce((sum, current) => sum + current);
    this.assetsTotal.setValue(CurrencyFormatter.formatMoney(aTotal));
    this.liabilityTotal.setValue(CurrencyFormatter.formatMoney(lTotal));
    this.networth.setValue(CurrencyFormatter.formatMoney(aTotal - lTotal));
    this.checkNetworth();
  }

  private setOnChangeEvent(formControl: FormControl) {
    formControl.valueChanges.subscribe(() => {
      this.updateTotals();
    });
  }

  get assetList(): Array<number> {
    return [
      CurrencyFormatter.toRawNumber(this.assetsCash.value),
      // CurrencyFormatter.toRawNumber(this.assetsNotes.value),
      CurrencyFormatter.toRawNumber(this.assetsBonds.value),
      CurrencyFormatter.toRawNumber(this.assetsRealEstate.value),
      CurrencyFormatter.toRawNumber(this.assetsOther.value),
    ];
  }

  get liabilityList(): Array<number> {
    return [
      // CurrencyFormatter.toRawNumber(this.liabilityNotes.value),
      CurrencyFormatter.toRawNumber(this.liabilityCreditBalance.value),
      CurrencyFormatter.toRawNumber(this.liabilityTaxes.value),
      CurrencyFormatter.toRawNumber(this.liabilityMortgage.value),
      CurrencyFormatter.toRawNumber(this.liabilityOther.value),
    ];
  }

  get allControlsWithUserInput(): Array<FormControl> {
    return [
      this.assetsCash,
      // this.assetsNotes,
      this.assetsBonds,
      this.assetsRealEstate,
      this.assetsOther,
      // this.liabilityNotes,
      this.liabilityCreditBalance,
      this.liabilityTaxes,
      this.liabilityMortgage,
      this.liabilityOther,
    ];
  }

  get assetsCash(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('assetsCash') as FormControl;
  }

  get assetsNotes(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('assetsNotes') as FormControl;
  }

  get assetsBonds(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('assetsBonds') as FormControl;
  }

  get assetsRealEstate(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('assetsRealEstate') as FormControl;
  }

  get assetsOther(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('assetsOther') as FormControl;
  }

  get liabilityNotes(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('liabilityNotes') as FormControl;
  }

  get liabilityCreditBalance(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('liabilityCreditBalance') as FormControl;
  }

  get liabilityTaxes(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('liabilityTaxes') as FormControl;
  }

  get liabilityMortgage(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('liabilityMortgage') as FormControl;
  }

  get liabilityOther(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('liabilityOther') as FormControl;
  }

  get assetsTotal(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('assetsTotal') as FormControl;
  }

  get liabilityTotal(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('liabilityTotal') as FormControl;
  }

  get networth(): FormControl {
    return this.assetsLiabilitiesFormGroup.get('networth') as FormControl;
  }

  getAbsValueOfNetworth() {
    return CurrencyFormatter.formatMoney(Math.abs(CurrencyFormatter.toRawNumber(this.networth.value)));
  }

  checkNetworth() {
    this.networthPositive = CurrencyFormatter.toRawNumber(this.networth.value) >= 0;
    this.networthNegative = !this.networthPositive;
  }

}
