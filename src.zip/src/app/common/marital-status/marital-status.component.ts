import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-marital-status',
  templateUrl: './marital-status.component.html',
  styleUrls: ['./marital-status.component.css'],
})
export class MaritalStatusComponent implements OnInit {

  @Input()
  maritalStatusFormGroup: FormGroup;

  constructor() { }

  ngOnInit() {
  }

  get maritalStatusList(): string[] {
    return [
      'Married',
      'Single',
      // 'Divorced',
      // 'Widowed',
    ];
  }

  trackByMaritalStatus(index: number, maritalStatus: string): string {
    return maritalStatus;
  }

  get maritalStatus(): FormControl {
    return this.maritalStatusFormGroup.get('maritalStatus') as FormControl;
  }

  get applicantSpouse(): FormControl {
    return this.maritalStatusFormGroup.get('applicantSpouse') as FormControl;
  }

}
