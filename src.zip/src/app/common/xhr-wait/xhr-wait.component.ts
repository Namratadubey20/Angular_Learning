import { Component } from '@angular/core';
import { LoadingHandlerService } from '../utils/loading-handler.service';

@Component({
  selector: 'app-xhr-wait',
  templateUrl: './xhr-wait.component.html',
  styleUrls: ['./xhr-wait.component.css'],
})
export class XhrWaitComponent {

  constructor(public loadingHandlerService: LoadingHandlerService) {
  }

  get waitWhileLoading() {
    return this.loadingHandlerService;
  }

}
