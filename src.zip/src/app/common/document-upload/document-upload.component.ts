import { EventEmitter, Input, Output } from '@angular/core';
import { Subject } from 'rxjs';
import { MatRadioChange } from '@angular/material';

export abstract class DocumentUploadComponent {

  @Input()
  applicationId: number;

  /**
   * If provided, fires when the mode of submitting supporting documentation changes on or off of the file upload option.
   * Subject value indicates whether a fileUpload option is active.
   */
  @Input()
  fileUploadModeActive: Subject<boolean>;

  @Output()
  fileUploadEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  fileUploaded(event) {
    if (event) {
      this.fileUploadEvent.emit(true);
    }
  }

  /**
   * Invoked when the mode of submitting supporting documentation has changed.
   * Fires fileUpload mode change event with value: true if in fileUpload mode. false if not in fileUpload mode.
   * @param event radio button Group change event.
   */
  documentationSubmitModeChanged(event: MatRadioChange) {
    this.fireFileUploadSubmitModeChanged(event.value);
  }

  /**
   *
   * @param fileUploadSubmitMode true if fileUpload mode is selected, false otherwise.
   */
  fireFileUploadSubmitModeChanged(fileUploadSubmitMode: boolean) {
    if (this.fileUploadModeActive) {
      this.fileUploadModeActive.next(fileUploadSubmitMode);
    }
  }
}
