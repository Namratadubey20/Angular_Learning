import {
  ModuleWithProviders,
  NgModule
} from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommonComponentsRoutingModule } from './common-components-routing.module';
import { PaymentMethodSelectionTestComponent } from './payment-method-selection/test/payment-method-selection-test/payment-method-selection-test.component';
import { AddressTestComponent } from './address/test/address-test/address-test.component';
import { ClientService } from '../user/client/client.service';
import { NotFoundComponent } from './not-found/not-found.component';
import { AddressComponent } from './address/address.component';
import { AutofocusDirective } from './directives/autofocus.directive';
import { CalendarMaskDirective } from './directives/calendar-mask.directive';
import { CreditCardMaskDirective } from './directives/credit-card-mask.directive';
import { FormatCurrencyDirective } from './directives/format-currency.directive';
import { HideDomElementsDirective } from './directives/hide-dom-elements.directive';
import { InputMaskDirective } from './directives/input-mask.directive';
import { InputPreventAutoEventDirective } from './directives/input-avoid-auto-evnts.directive';
import { ScrollToTopDirective } from './directives/scroll-to-top.directive';
import { SwitchInputPatternDirective } from './directives/input-pattern-switch.directive';
import { FieldErrorsComponent } from './field-errors/field-errors.component';
import { PaymentMethodSelectionComponent } from './payment-method-selection/payment-method-selection.component';

import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatProgressBarModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatSnackBarModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
} from '@angular/material';

import {
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import {
  CalendarModule,
  CheckboxModule,
  DataListModule,
} from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { CreateInFlightService } from './utils/create-in-flight.service';
import { UtilService } from './utils/util.service';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { TermsContentSelectorComponent } from './terms-and-conditions/terms-content-selector/terms-content-selector.component';
import { CourtTermsContentComponent } from './terms-and-conditions/terms-content-selector/court-terms-content/court-terms-content.component';
import { JsonConvertService } from './utils/json-convert.service';
import { AttorneyInfoComponent } from './attorney-info/attorney-info.component';
import { DeliveryMethodSelectionComponent } from './delivery-method-selection/delivery-method-selection.component';
import { KnockoutDialogComponent } from './knockout-dialog/knockout-dialog.component';
import { ServiceProviderComponent } from './service-provider/service-provider.component';
import { ServiceProviderListComponent } from './service-provider/service-provider-list/service-provider-list.component';
import { DebtorInterestedPartyListComponent } from './debtor-interested-party/debtor-interested-party-list/debtor-interested-party-list.component';
import { DebtorInterestedPartyComponent } from './debtor-interested-party/debtor-interested-party.component';
import { BankInfoComponent } from './bank-info/bank-info.component';
import { BankInfoListComponent } from './bank-info/bank-info-list/bank-info-list.component';
import { MaritalStatusComponent } from './marital-status/marital-status.component';
import { CourtInformationComponent } from './court-information/court-information.component';
import { ApplicantSignatureComponent } from './applicant-signature/applicant-signature.component';
import { CreditCheckAuthorizationComponent } from './credit-check-authorization/credit-check-authorization.component';
import { MinorIncompetentComponent } from './minor-incompetent/minor-incompetent.component';
import { MinorIncompetentListComponent } from './minor-incompetent/minor-incompetent-list/minor-incompetent-list.component';
import { AppointmentDateComponent } from './appointment-date/appointment-date.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { CourtOrderComponent } from './court-order/court-order.component';
import { SpecialBondComponent } from './special-bond/special-bond.component';
import { FiduciaryTypeReadonlyComponent } from './fiduciary-types/fiduciary-type-readonly.component';
import { FiduciaryTypeSelectComponent } from './fiduciary-types/fiduciary-type-select.component';
import { AppointmentTypeComponent } from './appointment-type/appointment-type.component';
import { AssetsLiabilitiesComponent } from './assets-liabilities/assets-liabilities.component';
import { DescribeAssetsComponent } from './describe-assets/describe-assets.component';
import { TermsSignatureComponent } from './terms-and-conditions/terms-signature/terms-signature.component';
import { PnlApplicationService } from '../enrollment/application/pnl-application.service';
import { PnlApplicationQuoteService } from '../enrollment/application/pnl-application/pnl-application-quote/pnl-application-quote.service';
import { ClientCompanyDetailsComponent } from './client/client-company-details/client-company-details.component';
import { RequiredMaybeSelectDirective } from './directives/required-maybe/required-maybe-select.directive';
import { RequiredMaybeInputDirective } from './directives/required-maybe/required-maybe-input.directive';
import { NumbersOnlyDirective } from './directives/numbers-only.directive';
import { XhrWaitComponent } from './xhr-wait/xhr-wait.component';
import { PercentageDirective } from './directives/percentage.directive';
import { ControlModule } from '../control/control.module';
import { GoogleTagManagerService } from './services/google-tag-manager.service';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { EmailListComponent } from './email/email-list/email-list.component';
import { SendEmailComponent } from './email/send-email/send-email.component';
import { SendEmailDialogComponent } from './email/send-email-dialog/send-email-dialog.component';
import { ApplicationRoleService } from './services/application-role-service';
import { IsEllipsisActiveDirective } from './directives/check-for-ellipsis';
import { TrimSpacesDirective } from './directives/trim-spaces.directive';
import { DocumentsComponent } from './documents/documents.component';
import { GooglePlacesDirective } from '../ibond/google-places.directive';
import { CharactersOnlyDirective } from './directives/characters-only.directive';
import { DecimalFormatCurrencyDirective } from './directives/decimal-format-currency.directive';
import { DatePickerComponent } from './date-picker/date-picker.component';
import { AnimatedDigitComponent } from './animated-digit/animated-digit.component';

@NgModule({
  imports: [
    CommonModule,
    CommonComponentsRoutingModule,
    ControlModule,
    FormsModule,
    ReactiveFormsModule,

    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,
    TableModule,

    // Material Stuff
    MatAutocompleteModule,
    MatFormFieldModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatProgressBarModule,
  ],
  declarations: [
    PaymentMethodSelectionTestComponent,
    AddressTestComponent,
    NotFoundComponent,
    AddressComponent,
    AutofocusDirective,
    CalendarMaskDirective,
    CreditCardMaskDirective,
    FormatCurrencyDirective,
    NumbersOnlyDirective,
    HideDomElementsDirective,
    InputMaskDirective,
    InputPreventAutoEventDirective,
    IsEllipsisActiveDirective,
    ScrollToTopDirective,
    FieldErrorsComponent,
    PaymentMethodSelectionComponent,
    TermsAndConditionsComponent,
    TermsContentSelectorComponent,
    CourtTermsContentComponent,
    AttorneyInfoComponent,
    DeliveryMethodSelectionComponent,
    KnockoutDialogComponent,
    ServiceProviderComponent,
    ServiceProviderListComponent,
    DebtorInterestedPartyListComponent,
    DebtorInterestedPartyComponent,
    BankInfoComponent,
    BankInfoListComponent,
    MaritalStatusComponent,
    CourtInformationComponent,
    ApplicantSignatureComponent,
    CreditCheckAuthorizationComponent,
    MinorIncompetentComponent,
    MinorIncompetentListComponent,
    AppointmentDateComponent,
    FileUploadComponent,
    CourtOrderComponent,
    SpecialBondComponent,
    FiduciaryTypeReadonlyComponent,
    FiduciaryTypeSelectComponent,
    AppointmentTypeComponent,
    AssetsLiabilitiesComponent,
    DescribeAssetsComponent,
    TermsSignatureComponent,
    RequiredMaybeInputDirective,
    RequiredMaybeSelectDirective,
    ClientCompanyDetailsComponent,
    XhrWaitComponent,
    PercentageDirective,
    ConfirmationDialogComponent,
    EmailListComponent,
    SendEmailComponent,
    SendEmailDialogComponent,
    TrimSpacesDirective, // added
    SwitchInputPatternDirective,
    DocumentsComponent,
    GooglePlacesDirective,
    CharactersOnlyDirective,
    DecimalFormatCurrencyDirective,
    DatePickerComponent,
    AnimatedDigitComponent,
  ],
  exports: [
    PaymentMethodSelectionTestComponent,
    AddressTestComponent,
    NotFoundComponent,
    AddressComponent,
    AutofocusDirective,
    CalendarMaskDirective,
    CreditCardMaskDirective,
    FormatCurrencyDirective,
    NumbersOnlyDirective,
    HideDomElementsDirective,
    InputMaskDirective,
    InputPreventAutoEventDirective,
    IsEllipsisActiveDirective,
    ScrollToTopDirective,
    FieldErrorsComponent,
    PaymentMethodSelectionComponent,
    TermsAndConditionsComponent,
    TermsContentSelectorComponent,
    CourtTermsContentComponent,
    AttorneyInfoComponent,
    DeliveryMethodSelectionComponent,
    KnockoutDialogComponent,
    ServiceProviderComponent,
    ServiceProviderListComponent,
    DebtorInterestedPartyListComponent,
    DebtorInterestedPartyComponent,
    BankInfoComponent,
    BankInfoListComponent,
    MaritalStatusComponent,
    CourtInformationComponent,
    ApplicantSignatureComponent,
    CreditCheckAuthorizationComponent,
    MinorIncompetentComponent,
    MinorIncompetentListComponent,
    AppointmentDateComponent,
    FileUploadComponent,
    CourtOrderComponent,
    SpecialBondComponent,
    FiduciaryTypeReadonlyComponent,
    FiduciaryTypeSelectComponent,
    AppointmentTypeComponent,
    AssetsLiabilitiesComponent,
    DescribeAssetsComponent,
    TermsSignatureComponent,
    RequiredMaybeInputDirective,
    RequiredMaybeSelectDirective,
    XhrWaitComponent,
    PercentageDirective,
    EmailListComponent,
    SendEmailComponent,
    SendEmailDialogComponent,
    TrimSpacesDirective, // added
    SwitchInputPatternDirective,
    DocumentsComponent,
    GooglePlacesDirective,
    CharactersOnlyDirective,
    DecimalFormatCurrencyDirective,
    DatePickerComponent,
    AnimatedDigitComponent,
  ],
  providers: [
    ClientService,
    CreateInFlightService,
    UtilService,
    JsonConvertService,
    PnlApplicationService,
    PnlApplicationQuoteService,
    GoogleTagManagerService,
    ApplicationRoleService,
  ],
  entryComponents: [ConfirmationDialogComponent, SendEmailDialogComponent],
})

export class CommonComponentsModule { // CommonModule is a reserved word
  // public static forRoot(): ModuleWithProviders {
  //
  //   return {
  //     ngModule: CommonComponentsModule,
  //     providers: [
  //       ClientService,
  //       CreateInFlightService,
  //       UtilService,
  //       JsonConvertService,
  //       BillingProfileService,
  //       // Shared Services go here
  //     ],
  //   };
  // }
}
