import { Component, Inject, ElementRef, OnInit, OnDestroy, ViewChild } from '@angular/core';
import {
  NavigationEnd, Router, RoutesRecognized, RouterEvent, NavigationStart,
  NavigationCancel, NavigationError, ActivatedRoute, Params
} from '@angular/router';
import { AppConfigService } from './app-config-service';
import { DOCUMENT } from '@angular/common';
import { filter, map } from 'rxjs/operators';
import { SpinnerService } from './ibond/service/spinner.service';
import { InsuranceSpinnerService } from './insurance/services/insurance-spinner.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { NavigationDialogComponent } from './main/navigation-dialog/navigation-dialog.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ConfirmLoginDialogComponent } from './main/confirm-login-dialog/confirm-login-dialog.component';
import { SecurityService } from './security/security.service';
import { UserIdleService } from 'angular-user-idle';
import { Subscription } from 'rxjs';
import { StateService } from './insurance/services/state.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit, OnDestroy {
  title = 'app';
  appConfig: any;
  theme = '';
  newlayout: any = false;
  showSpinner: Boolean;
  public showFooter = true;
  public spinnerRef: any;
  public insuranceSpinnerRef: any;
  appLoadedFlag = false;
  isMobileScreenLoading = false;
  dialogRef: MatDialogRef<NavigationDialogComponent, any>;
  confirmLoginDialogRef: MatDialogRef<ConfirmLoginDialogComponent, any>;
  subscriptions: Subscription[] = [];
  token: any;
  returnUrl: any;
  product: any;
  applicationid: any;

  constructor(@Inject(DOCUMENT) private document,
    private elementRef: ElementRef,
    private router: Router,
    public spinnerService: SpinnerService,
    public insuranceSpinnerService: InsuranceSpinnerService,
    public dialog: MatDialog,
    public confirmLoginDialog: MatDialog,
    private deviceService: DeviceDetectorService,
    private securityService: SecurityService,
    private userIdleService: UserIdleService,
    private activatedRoute: ActivatedRoute,
    private appConfigService: AppConfigService,
    public stateService: StateService) {
    const me = this;
    this.subscriptions.push(this.appConfigService.getConfig().subscribe(ac => {
      this.appConfig = ac;
      console.log('Config File Loaded >>> ');
      if (this.appConfig['cookieName']) {
        sessionStorage.setItem('token', this.appConfig['cookieName']);
        localStorage.setItem('tokenName', this.appConfig['cookieName']);
        console.log('CookieName >>> ', this.appConfig['cookieName']);
        this.verifyTokenForSSOLogin();
      }
      console.log('appConfig tokenName', this.appConfig['cookieName']);
      if (this.appConfig.googleAnalytics) {
        this.viewInit();
      }
    }));


    this.subscriptions.push(this.router.events
      .pipe(filter(event => event instanceof RoutesRecognized))
      .pipe(map((event: RoutesRecognized) => {
        return event.state.root.firstChild.data;
      })).subscribe(data => {
        if (this.newlayout !== data.newlayout) {
          this.newlayout = data.newlayout;
          console.log('newlayout >>> ', this.newlayout);
          me.loadTheme();
        }
      }));
    this.subscriptions.push(router.events.subscribe((event: RouterEvent) => {
      this.navigationInterceptor(event);
    }));
    /* me.activatedRoute.queryParams.subscribe(_state => {
      if (me.newlayout) {
        if (_state.returnUrl.indexOf('insurance') > -1) {
          me.newlayout = 'insurance';
        } else {
          me.newlayout = '';
        }
        me.loadTheme();
      }
    }); */
    this.handleSpinner();
  }

  loadTheme() {
    if (this.newlayout === 'ibond') {
      this.insuranceSpinnerService.hide();
      if (this.insuranceSpinnerRef) {
        this.insuranceSpinnerRef.unsubscribe();
      }
      this.document.body.classList.remove('court-bond-theme');
      this.document.body.classList.add('colonial-new-theme');
      this.document.body.classList.add('mat-app-background');
      this.document.body.classList.remove('main-body-background');
      this.document.body.classList.remove('main-insurance-body-background');
      this.document.body.classList.remove('main-insurance-body-background');
      this.document.body.classList.remove('insurance-theme');
      this.handleSpinner();
    } else if (this.newlayout === 'insurance') {
      this.spinnerService.hide();
      if (this.spinnerRef) {
        this.spinnerRef.unsubscribe();
      }
      this.document.body.classList.remove('court-bond-theme');
      this.document.body.classList.remove('mat-app-background');
      this.document.body.classList.remove('main-body-background');
      this.document.body.classList.add('main-insurance-body-background');
      this.document.body.classList.add('main-insurance-app-background');
      this.document.body.classList.add('insurance-theme');
      this.insuranceHandleSpinner();
      this.insuranceHandleFooter();
    } else {
      this.insuranceSpinnerService.hide();
      if (this.insuranceSpinnerRef) {
        this.insuranceSpinnerRef.unsubscribe();
      }
      this.document.body.classList.add('court-bond-theme');
      this.document.body.classList.remove('colonial-new-theme');
      this.document.body.classList.remove('mat-app-background');
      this.document.body.classList.add('main-body-background');
      this.document.body.classList.remove('main-insurance-body-background');
      this.document.body.classList.remove('main-insurance-body-background');
      this.document.body.classList.remove('insurance-theme');
      this.handleSpinner();
    }
  }

  ngOnInit() {
    if (sessionStorage.getItem('originState') === 'rails') {
      this.stateService.originState = 'rails';
    }
  }

  verifyTokenForSSOLogin() {
    this.subscriptions.push(this.activatedRoute.queryParams.subscribe((route: Params) => {
      if (!this.returnUrl) {
        this.returnUrl = route['returnUrl'];
      }
      if (!this.product) {
        this.product = route['product'];
      }
      if (!this.applicationid) {
        this.applicationid = route['applicationId'];
      }
      if (!this.token) {
        this.token = route['sutoken'];
      }
      if (this.token) {
        this.securityService.setUserFromThirdPartyApplication(true);
        this.securityService.verifyToken(this.token).then(response => {
          this.token = null;
          if (response && response['tokenResponse'] === 'SUCCESSFUL') {
            if (this.returnUrl) {
              if (!this.product && !this.applicationid) {
                setTimeout(() => {
                  this.router.navigateByUrl(this.returnUrl);
                }, 1000);
              } else {
                setTimeout(() => {
                  this.navigateToInsuranceQuote();
                }, 1000);
              }
              this.userIdleService.startWatching();
              this.stateService.originState = 'rails';
              sessionStorage.setItem('originState', 'rails');
            } else {
              this.router.navigateByUrl(`/`);
            }
          } else { // for token expired case navigate back to rails
            sessionStorage.removeItem('originState');
            const windowUrl = window.location.hostname;
            if (this.applicationid) {
              // tslint:disable-next-line: max-line-length
              window.open(`${windowUrl}/?sutoken=${response['accessToken']}&applicationId=${this.applicationid}&errMessage=tokenExpired`, '_self');
            } else {
              window.open(`${windowUrl}/?sutoken=${response['accessToken']}&errMessage=tokenExpired`, '_self');
            }
          }
        });
      }
    }));
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  navigateToInsuranceQuote() {
    console.log('Navigated for Insurance >>');
    if (this.product || this.applicationid) {
      if (this.securityService.user && this.securityService.user['person']
        && this.securityService.user['person']['id']) {
        if (this.product) {
          console.log('Navigated for Insurance Logged In Product >>');
          this.router.navigate([this.returnUrl], { queryParams: { product_code: [this.product] } });
        } else {
          console.log('Navigated for Insurance Logged In Application ID >>');
          this.router.navigate([this.returnUrl], { queryParams: { applicationId: this.applicationid } });
        }
      } else {
        if (this.product) {
          console.log('Navigated for Insurance Anonymous Porduct >>');
          this.router.navigate([this.returnUrl], {
            queryParams: {
              product_code: [this.product],
              action: null,
              isAnonymousUser: true,
              bondClassification: this.product,
            },
          });
        } else {
          console.log('Navigated for Insurance Anonymouse Application ID >>');
          this.router.navigate([this.returnUrl], {
            queryParams: {
              applicationId: this.applicationid,
              action: null,
              isAnonymousUser: true,
            },
          });
        }
      }
    }
  }
  navigationInterceptor(event: RouterEvent): void {
    if (event instanceof NavigationStart) {
      if (this.appLoadedFlag) {
        this.showSpinner = true;
      } else {
        if (!this.deviceService.isDesktop()) {
          this.isMobileScreenLoading = true;
          this.openDialog();
        }
      }
    }
    if (event instanceof NavigationEnd) {
      setTimeout(() => {
        if (!this.appLoadedFlag) {
          this.dialog.closeAll();
          this.appLoadedFlag = true;
          this.isMobileScreenLoading = false;
        }
        this.showSpinner = false;
      }, 2000);
    }

    // Set loading state to false in both of the below events to hide the spinner in case a request fails
    if (event instanceof NavigationCancel) {
      setTimeout(() => {
        if (!this.appLoadedFlag) {
          this.dialog.closeAll();
        }
        this.showSpinner = false;
        this.isMobileScreenLoading = false;
      }, 2000);
    }
    if (event instanceof NavigationError) {
      setTimeout(() => {
        if (!this.appLoadedFlag) {
          this.dialog.closeAll();
        }
        this.showSpinner = false;
        this.isMobileScreenLoading = false;
      }, 2000);
    }
  }

  // https://stackoverflow.com/questions/38088996/adding-script-tags-in-angular-component-template
  viewInit() {
    this.showSpinner = true;
    const idleConfig = {
      idle: parseInt(this.appConfig.inactivity_timeout, 10),
      timeout: parseInt(this.appConfig.inactivity_confirmation_timeout, 10),
      ping: null,
    };
    this.userIdleService.setConfigValues(idleConfig);
    const gaStyle = this.document.createElement('style');
    gaStyle.type = 'text/style';
    gaStyle.innerHTML = `
        .async-hide { opacity: 0 !important}
        `;

    const scriptOptimizePageHiding = this.document.createElement('script');
    scriptOptimizePageHiding.type = 'text/javascript';
    scriptOptimizePageHiding.innerHTML = `
        (function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
        h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
        (a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
        })(window,document.documentElement,'async-hide','dataLayer',4000,
        {'${this.appConfig.googleAnalytics.gtm}':true})
        `;

    const scriptOptimizeSnippet = this.document.createElement('script');
    scriptOptimizeSnippet.type = 'text/javascript';
    scriptOptimizeSnippet.innerHTML = `
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
        ga('create', '${this.appConfig.googleAnalytics.id}' , 'auto', {allowLinker: true});
        ga('require', '${this.appConfig.googleAnalytics.gtm}');
        `;

    const scriptTagManager = this.document.createElement('script');
    scriptTagManager.type = 'text/javascript';
    scriptTagManager.innerHTML = `
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl+ '&' +
        '${this.appConfig.googleAnalytics.gtm_auth_and_env_ids}&gtm_cookies_win=x';f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','${this.appConfig.googleAnalytics.gtmn}');
        `;

    this.elementRef.nativeElement.appendChild(gaStyle);
    // this.elementRef.nativeElement.appendChild(scriptOptimizePageHiding);
    // this.elementRef.nativeElement.appendChild(scriptOptimizeSnippet);
    // this.elementRef.nativeElement.appendChild(scriptTagManager);

    const googlePlaceApi = this.document.createElement('script');
    googlePlaceApi.type = 'text/javascript';
    googlePlaceApi.src = `https://maps.googleapis.com/maps/api/js?key=${this.appConfig.google_api_key}&libraries=places`;

    document.getElementsByTagName('head')[0].appendChild(scriptOptimizePageHiding);
    document.getElementsByTagName('head')[0].appendChild(scriptOptimizeSnippet);
    document.getElementsByTagName('head')[0].appendChild(scriptTagManager);
    document.getElementsByTagName('head')[0].appendChild(googlePlaceApi);

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        (<any>window)['ga']('set', 'page', event.urlAfterRedirects);
        (<any>window)['ga']('send', 'pageview');
      }
    });
  }
  private handleSpinner(): void {
    this.spinnerRef = this.spinnerService.spinnerState.subscribe(show => {
      Promise.resolve(null).then(() => this.showSpinner = show);

    });
  }

  private insuranceHandleSpinner(): void {
    this.insuranceSpinnerRef = this.insuranceSpinnerService.insuranceSpinnerState.subscribe(show => {
      Promise.resolve(null).then(() => this.showSpinner = show);

    });
  }

  private insuranceHandleFooter(): void {
    this.insuranceSpinnerRef = this.insuranceSpinnerService.insuranceFooterState.subscribe(show => {
      Promise.resolve(null).then(() => this.showFooter = show);

    });
  }

  openDialog(): void {
    this.dialogRef = this.dialog.open(NavigationDialogComponent, {
      width: '450px',
    });
  }

  openConfirmLoginDialog(): void {
    this.confirmLoginDialogRef = this.confirmLoginDialog.open(ConfirmLoginDialogComponent, {
      width: '450px',
      disableClose: true,
    });

  }

  closeConfirmLoginDialog(): void {
    this.confirmLoginDialog.closeAll();
    this.router.navigateByUrl('/secure/logout');
  }
}
