import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/first';
import { UtilService } from '../../common/utils/util.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { Payment } from '../payment';
import {
  catchError,
  map
} from 'rxjs/operators';

@Injectable()
export class PaymentService {
  requestURL = 'api/payment';
  jsonConvert = UtilService.getJsonConvert();

  constructor(private http: HttpClient,
    private serviceHandler: ServiceHandler) {
  }

  public getPayments(): Observable<Payment[]> {
    return this.http.get(this.requestURL)
      .pipe(
        map((os: any[]) => {
          return os.map((pp: any) => this.jsonConvert.deserialize(pp, Payment) as Payment);
        }),
        catchError((error) => this.serviceHandler.handleError(error))
      );
  }

  public getPaymentById(id: number): Promise<any> {
    return this.http.get(this.requestURL + '/product/' + id).toPromise();
  }

  async savePayment(payment: Payment): Promise<Payment> {
    const json = this.jsonConvert.serialize(payment);
    let response = null;
    if (payment.id) {
      response = await this.http.put<Payment>(`${this.requestURL}/${payment.id}`, json).toPromise();
    } else {
      response = await this.http.post<Payment>(`${this.requestURL}`, json).toPromise();
    }
    this.serviceHandler.handleConfirm('Payment Plan Updated');
    return this.jsonConvert.deserialize(response, Payment) as Payment;
  }
}
