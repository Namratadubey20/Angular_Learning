import {
  Component,
  OnInit
} from '@angular/core';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';
import { PaymentService } from './payment.service';
import {
  ActivatedRoute,
  Router
} from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import { UtilService } from '../../common/utils/util.service';
import { Payment } from '../payment';
import { PaymentPlan } from '../payment-plan';
import { Safe } from '../safe';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
})

export class PaymentComponent implements OnInit {
  initialized = false;
  user: UserImpl = null;
  payment: Payment = null;
  id: number;
  errorMessage: string;
  formGroup: FormGroup;
  returnUrl: string = null;
  jsonConvert = UtilService.getJsonConvert();

  constructor(private securityService: SecurityService, private paymentService: PaymentService,
    private route: ActivatedRoute, private formBuilder: FormBuilder, private router: Router) {
  }

  async ngOnInit() {
    this.user = this.securityService.user;
    const id = this.route.snapshot.params.id;

    if (id) {
      this.payment = await this.paymentService.getPaymentById(id);
    } else {
      this.payment = new Payment();
      this.payment.paymentPlan = new PaymentPlan();
      this.payment.safe = new Safe();
    }

    const dateFormat = 'YYYY-MM-DD';
    this.formGroup = this.formBuilder.group({
      id: [{ value: this.payment.id, disabled: true }],
      amount: [this.payment.amount, Validators.required],
      createdAt: [this.payment.createdAt],
      createdBy: [this.payment.createdBy],
      updatedAt: [this.payment.updatedAt],
      updatedBy: [this.payment.updatedBy],
    });

    this.formGroup.addControl('paymentPlan', this.formBuilder.group({
      id: [{ value: this.payment.paymentPlan.id, disabled: true }],
      nextPaymentDueDate: [this.payment.paymentPlan.nextPaymentDueDate, Validators.required],
      paidThroughDate: [this.payment.paymentPlan.paidThroughDate, Validators.required],
      startDate: [this.payment.paymentPlan.startDate, Validators.required],
      endDate: [this.payment.paymentPlan.endDate, Validators.required],
      createdAt: [this.payment.paymentPlan.createdAt],
      createdBy: [this.payment.paymentPlan.createdBy],
      updatedAt: [this.payment.paymentPlan.updatedAt],
      updatedBy: [this.payment.paymentPlan.updatedBy],
    }));

    this.formGroup.addControl('safe', this.formBuilder.group({
      id: [{ value: this.payment.safe.id, disabled: true }],
      token: [this.payment.safe.token, Validators.required],
      createdAt: [this.payment.safe.createdAt],
      createdBy: [this.payment.safe.createdBy],
      updatedAt: [this.payment.safe.updatedAt],
      updatedBy: [this.payment.safe.updatedBy],
    }));

    this.initialized = true;

  }

  userName() {
    return this.user ? this.user.person.fullName : null;
  }

  async savePayment() {
    this.payment = this.jsonConvert.deserialize(this.formGroup.getRawValue(), Payment) as Payment;
    const pp = await this.paymentService.savePayment(this.payment);
    this.router.navigateByUrl('/billing');
  }

  cancel() {
    this.router.navigateByUrl(this.returnUrl ? this.returnUrl : '/billing');
  }
}
