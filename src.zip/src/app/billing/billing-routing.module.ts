import { NgModule } from '@angular/core';
import {
  RouterModule,
  Routes
} from '@angular/router';
import { AuthGuard } from '../security/app.auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PaymentPlanComponent } from './payment-plan/payment-plan.component';
import { PaymentComponent } from './payment/payment.component';


const routes: Routes = [
  { path: 'payment-plan/:id', component: PaymentPlanComponent, canActivate: [AuthGuard] },
  { path: 'payment-plan', component: PaymentPlanComponent, canActivate: [AuthGuard] },
  { path: 'payment/:id', component: PaymentComponent, canActivate: [AuthGuard] },
  { path: 'payment', component: PaymentComponent, canActivate: [AuthGuard] },
  { path: ':id', component: DashboardComponent, canActivate: [AuthGuard] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BillingRoutingModule { }
