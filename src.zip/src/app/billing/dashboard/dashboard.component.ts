import {
  Component,
  OnInit
} from '@angular/core';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';
import { PaymentPlanService } from '../payment-plan/payment-plan.service';
import {
  ActivatedRoute,
  Router
} from '@angular/router';
import { PaymentService } from '../payment/payment.service';

@Component({
  selector: 'app-colonial-common-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})

export class DashboardComponent implements OnInit {
  initialized = false;
  user: UserImpl = null;
  paymentPlans: any;
  payments: any;
  productId: number;

  constructor(private securityService: SecurityService,
    private paymentPlanService: PaymentPlanService,
    private paymentService: PaymentService,
    private activatedRoute: ActivatedRoute,
    private router: Router) {
  }

  async ngOnInit() {
    this.user = this.securityService.user;
    this.productId = this.activatedRoute.snapshot.params.id;

    this.paymentPlans = await this.paymentPlanService.getPaymentPlanById(this.productId);
    this.payments = await this.paymentService.getPaymentById(this.productId);
    this.initialized = true;
  }

  isSteward() {
    return this.user && this.user.isSteward === true;
  }

  userName() {
    return this.user ? this.user.person.fullName : null;
  }

  selectPaymentPlan(id: number) {
    this.router.navigateByUrl('/billing/payment-plan/' + id);
  }

  newPaymentPlan() {
    this.router.navigateByUrl('/billing/payment-plan');
  }

  newPayment() {
    this.router.navigateByUrl('/billing/payment');
  }

  changePayment() {
    // redirect to my billing info
  }

  selectPayment(id: number) {
    this.router.navigateByUrl('/billing/payment/' + id);
  }
}
