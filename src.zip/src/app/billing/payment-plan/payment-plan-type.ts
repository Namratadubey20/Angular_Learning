import { AuditableObject } from '../../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject('PaymentPlanType')
export class PaymentPlanType extends AuditableObject {
  @JsonProperty('surchargePercent', Number, true)
  surchargePercent: Number = null;

  @JsonProperty('frequencyName', String, true)
  frequencyName: String = null;
}
