import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';
import { PaymentPlanService } from './payment-plan.service';
import { PaymentPlan } from '../payment-plan';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilService } from '../../common/utils/util.service';
import { PaymentPlanType } from './payment-plan-type';


@Component({
  selector: 'app-payment-plan',
  templateUrl: './payment-plan.component.html',
  styleUrls: ['./payment-plan.component.css'],
})

export class PaymentPlanComponent implements OnInit {
  initialized = false;
  user: UserImpl = null;
  paymentPlan: PaymentPlan = null;
  id: number;
  errorMessage: string;
  formGroup: FormGroup;
  returnUrl: string = null;
  jsonConvert = UtilService.getJsonConvert();
  paymentPlanTypes: Array<PaymentPlanType> = null;

  constructor(private securityService: SecurityService, private paymentPlanService: PaymentPlanService,
    private route: ActivatedRoute, private formBuilder: FormBuilder, private router: Router) {
  }

  async ngOnInit() {
    this.user = this.securityService.user;
    const id = this.route.snapshot.params.id;

    if (id) {
      this.paymentPlan = await this.paymentPlanService.getPaymentPlanById(id);
    } else {
      this.paymentPlan = new PaymentPlan();
    }

    this.paymentPlanTypes = await this.paymentPlanService.getPaymentPlanTypes();

    // const this.paymentPlan = this.jsonConvert.serialize(this.paymentPlan);

    this.formGroup = this.formBuilder.group({
      id: [{ value: this.paymentPlan.id, disabled: true }],
      nextPaymentDueDate: [this.paymentPlan.nextPaymentDueDate ?
        this.paymentPlan.nextPaymentDueDate : '', Validators.required],
      paidThroughDate: [
        this.paymentPlan.paidThroughDate ?
          this.paymentPlan.paidThroughDate : '', Validators.required],
      startDate: [
        this.paymentPlan.startDate ?
          this.paymentPlan.startDate : '', Validators.required],
      endDate: [this.paymentPlan.endDate ?
        this.paymentPlan.endDate : '', Validators.required],
      createdAt: [this.paymentPlan.createdAt],
      createdBy: [this.paymentPlan.createdBy],
      updatedAt: [this.paymentPlan.updatedAt],
      updatedBy: [this.paymentPlan.updatedBy],
      paymentPlanTypeId: [this.paymentPlan.paymentPlanTypeId, Validators.required],
      productId: [this.paymentPlan.productId, Validators.required],
      totalDueAmount: [this.paymentPlan.totalDueAmount, Validators.required],
      purchaseAmount: [this.paymentPlan.purchaseAmount, Validators.required],
      surchargeAmount: [this.paymentPlan.surchargeAmount, Validators.required],
      totalAmount: [this.paymentPlan.totalAmount, Validators.required],
      totalPaidAmount: [this.paymentPlan.totalPaidAmount, Validators.required],
      nextPaymentDueAmount: [this.paymentPlan.nextPaymentDueAmount, Validators.required],
    });
    this.initialized = true;

  }

  userName() {
    return this.user ? this.user.person.fullName : null;
  }

  async savePaymentPlan() {
    this.paymentPlan = this.jsonConvert.deserialize(this.formGroup.getRawValue(), PaymentPlan) as PaymentPlan;
    const pp = await this.paymentPlanService.savePaymentPlan(this.paymentPlan);
    this.router.navigateByUrl('/billing');
  }

  cancel() {
    this.router.navigateByUrl(this.returnUrl ? this.returnUrl : '/billing');
  }
}
