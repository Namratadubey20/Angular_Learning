import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/first';
import { UtilService } from '../../common/utils/util.service';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { PaymentPlan } from '../payment-plan';
import { PaymentPlanType } from './payment-plan-type';

@Injectable()
export class PaymentPlanService {
  private static readonly paymentPlanTypesRequestURL
    = 'api/payment-plan-type';
  private static readonly paymentPlansRequestURL
    = 'api/payment-plan';
  private static readonly paymentPlanRequestURL
    = 'api/payment-plan/{paymentPlanId}';
  private static readonly savePaymentPlanURL
    = 'api/payment-plan';

  jsonConvert = UtilService.getJsonConvert();

  constructor(private http: HttpClient,
    private serviceHandler: ServiceHandler) {
  }

  public async getPaymentPlanTypes(): Promise<PaymentPlanType[]> {
    const url = PaymentPlanService.paymentPlanTypesRequestURL;
    return await this.http.get(url).toPromise() as PaymentPlanType[];
  }

  public getPaymentPlans(): Observable<PaymentPlan[]> {
    const url = PaymentPlanService.paymentPlansRequestURL;
    return this.http.get(url)
      .catch((error) => this.serviceHandler.handleError(error))
      .map((os: any[]) => {
        return os.map((pp: any) => this.jsonConvert.deserialize(pp, PaymentPlan) as PaymentPlan);
      });
  }

  public getPaymentPlanById(paymentPlanId: number): Promise<any> {
    const url = PaymentPlanService.paymentPlanRequestURL
      .replace('{paymentPlanId}', paymentPlanId.toString());
    return this.http.get(url).toPromise();
  }

  async savePaymentPlan(paymentPlan: PaymentPlan): Promise<PaymentPlan> {
    const json = this.jsonConvert.serialize(paymentPlan);
    let url;
    if (paymentPlan.id) {
      url = `${PaymentPlanService.savePaymentPlanURL}/${paymentPlan.id}`;
    } else {
      url = `${PaymentPlanService.savePaymentPlanURL}`;
    }
    const response = await this.http.put<PaymentPlan>(url, json).toPromise();
    this.serviceHandler.handleConfirm('Payment Plan Updated');
    return this.jsonConvert.deserialize(response, PaymentPlan) as PaymentPlan;
  }
}
