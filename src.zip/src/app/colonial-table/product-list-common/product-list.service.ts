import { Injectable } from '@angular/core';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../../common/utils/util.service';
import { HttpClient } from '@angular/common/http';
import { CourtProductSummary, CourtProductSummaryImpl } from './court-product-summary';
import { Page, Pageable, PageableConverter, PageImpl } from '../../common/pagination';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';
import { ProductSummary } from '../../product/product-summary';
import { Product, ProductImpl } from '../../product/product';
import { ClientProduct, ClientProductImpl } from '../../dashboard/client-dashboard/client-product';


@Injectable()
export class ProductListService {

  private requestURL = 'api/product/list';
  private jsonConvert: JsonConvert;


  constructor(private http: HttpClient, private securityService: SecurityService) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  async getProductListForEmployee(pageable: Pageable = { page: 0, size: 20, sort: null }, searchParams: any):
    Promise<Page<CourtProductSummary>> {
    const pageableParams = PageableConverter.toPageableRequest(pageable);
    for (const searchParam of Object.keys(searchParams)) {
      if (searchParams[searchParam]) {
        pageableParams.params[searchParam] = searchParams[searchParam];
      }
    }
    const response = await this.http.get(`${this.requestURL}/court/employee`, pageableParams).toPromise();
    const page = this.jsonConvert.deserialize(response, PageImpl) as PageImpl<CourtProductSummaryImpl>;

    // had to do it this way so it would deserialize the array properly
    page.content =
      this.jsonConvert.deserializeArray(page.content, CourtProductSummaryImpl) as Array<CourtProductSummaryImpl>;
    return page;

  }

  async getProductListForAgent(pageable: Pageable = { page: 0, size: 20, sort: null }, searchParams: any):
    Promise<Page<CourtProductSummary>> {
    const pageableParams = PageableConverter.toPageableRequest(pageable);
    for (const searchParam of Object.keys(searchParams)) {
      if (searchParams[searchParam]) {
        pageableParams.params[searchParam] = searchParams[searchParam];
      }
    }
    const response = await this.http.get(`${this.requestURL}/court/agent`, pageableParams).toPromise();
    const page = this.jsonConvert.deserialize(response, PageImpl) as PageImpl<CourtProductSummaryImpl>;

    // had to do it this way so it would deserialize the array properly
    page.content =
      this.jsonConvert.deserializeArray(page.content, CourtProductSummaryImpl) as Array<CourtProductSummaryImpl>;
    return page;

  }

  async getProductListForClients(pageable: Pageable = { page: 0, size: 20, sort: null }, searchParams?):
    Promise<Page<CourtProductSummary>> {
    const pageableParams = PageableConverter.toPageableRequest(pageable);
    for (const searchParam of Object.keys(searchParams)) {
      if (searchParams[searchParam]) {
        pageableParams.params[searchParam] = searchParams[searchParam];
      }
    }
    const user: UserImpl = this.securityService.user;
    const response = await this.http.get(`${this.requestURL}/person`, pageableParams).toPromise();
    const page = this.jsonConvert.deserialize(response, PageImpl) as PageImpl<CourtProductSummaryImpl>;
    page.content = this.jsonConvert.deserializeArray(page.content, CourtProductSummaryImpl) as Array<CourtProductSummaryImpl>;
    return page;
  }

}
