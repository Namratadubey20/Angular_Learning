import { JsonObject, JsonProperty } from 'json2typescript';
import { DollarSignCurrencyConverter } from '../../common/utils/dollar-sign-currency-converter';
import { DateStringOnlyConverter } from '../../common/utils/date-string-only-converter';


export interface CourtProductSummary {
  id: number;
  applicationId: number;
  productNo: string;
  status: string;
  productTypeName: string;
  productTypeCode: string;
  clientName: string;
  clientState: string;
  obligeeName: string;
  obligeeState: string;
  amount: string;
  premium: string;
  fromDate: Date;
}

@JsonObject('CourtProductSummaryImpl')
export class CourtProductSummaryImpl implements CourtProductSummary {

  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('applicationId', Number, true)
  applicationId: number = null;

  @JsonProperty('productNo', String, true)
  productNo: string = null;

  @JsonProperty('status', String, true)
  status: string = null;

  @JsonProperty('productTypeName', String, true)
  productTypeName: string = null;

  @JsonProperty('productTypeCode', String, true)
  productTypeCode: string = null;

  @JsonProperty('clientName', String, true)
  clientName: string = null;

  @JsonProperty('clientState', String, true)
  clientState: string = null;

  @JsonProperty('obligeeName', String, true)
  obligeeName: string = null;

  @JsonProperty('obligeeState', String, true)
  obligeeState: string = null;

  @JsonProperty('amount', DollarSignCurrencyConverter, true)
  amount: string = null;

  @JsonProperty('premium', DollarSignCurrencyConverter, true)
  premium: string = null;

  @JsonProperty('fromDate', DateStringOnlyConverter, true)
  fromDate: Date = null;
}
