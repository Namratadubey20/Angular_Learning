import { Component, Input, OnInit } from '@angular/core';
import { Column } from '../../../form-components/generic-pageable-list/column';
import { SearchObject } from '../../../form-components/searchbox-with-dropdown/search-object';
import { GenericTableSearchFormGroup } from '../../../form-components/generic-table-search/generic-table-search-form-group';
import { Page, Pageable, PageableConverter, PageImpl } from '../../../common/pagination';
import { ApplicationService } from '../../../enrollment/application/application.service';
import { Router } from '@angular/router';
import { ListLinkClickEvent } from '../../../form-components/generic-pageable-list/list-link-click-event';
import {
  AgentCourtApplicationSummary,
  AgentCourtApplicationSummaryImpl
} from '../../../enrollment/application/court/model/agent-court-application-summary';
import { MatDialog } from '@angular/material';
import { MatDialogMobileTableSearchComponent } from '../../../form-components/mat-dialog-mobile-table-search/mat-dialog-mobile-table-search.component';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { applicationStatuses } from '../../product-list-common/application-status';
import * as moment from 'moment';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';

@Component({
  selector: 'app-agent-court-applications',
  templateUrl: './agent-court-applications.component.html',
  styleUrls: ['./agent-court-applications.component.css'],
})
export class AgentCourtApplicationsComponent implements OnInit {
  static OVERVIEW_URL = 'enrollment/application-overview?formId=';

  @Input()
  defaultStatus;

  loading = false;

  cols: Column[] = [
    {
      field: 'id',
      header: 'App Id',
      link: true,
    },
    {
      field: 'productTypeName',
      header: 'Product',
      link: false,
    },
    {
      field: 'applicantName',
      header: 'Applicant',
      link: false,
    },
    {
      field: 'createdAt',
      header: 'Policy Start Date',
      link: false,
    },
    {
      field: 'status',
      header: 'Status',
      link: false,
    },
  ];

  searchObjects: SearchObject[] = [
    {
      controlName: 'applicationId',
      labelName: 'App Id',
    } as SearchObject,
    {
      controlName: 'applicantName',
      labelName: 'Applicant Name',
    } as SearchObject,
  ] as SearchObject[];

  statusList: string[];

  formGroup: GenericTableSearchFormGroup;

  page: Page<AgentCourtApplicationSummary>;
  dialogRefSubscription: Subscription;

  private eventsSubscription: any;
  searchBystatus = '';
  @Input()
  events: Observable<void>;

  constructor(private applicationService: ApplicationService, private router: Router, private matDialog: MatDialog) {
    this.statusList = Array.from(applicationStatuses);
  }

  ngOnInit() {
    this.formGroup = new GenericTableSearchFormGroup(this.defaultStatus || 'All', this.searchObjects);
    if (this.defaultStatus === 'Hold,Submitted') {
      this.formGroup.patchValue({ dateRange: null });
    }

    this.page = new PageImpl<AgentCourtApplicationSummaryImpl>();
    if (this.events) {
      this.eventsSubscription = this.events.subscribe(() => this.openDialog());
    }
    this.applicationService.searchByStatus.subscribe(async status => {
      this.searchBystatus = status;
    });
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }, dateRange = []) {
    this.loading = true;
    const searchParams = {
      status: this.searchBystatus,
    };
    if (dateRange.length === 2) {
      searchParams['startDate'] = dateRange[0];
      searchParams['endDate'] = dateRange[1];
    }
    try {
      // this.page = await this.applicationService.getCourtApplicationsForAgent(pageable, this.formGroup.getRawValue());
      this.page = await this.applicationService.getCourtApplicationsForAgent(pageable, searchParams);
    } catch {
      const errorPage = PageableConverter.fromData([]);
      errorPage.error = true;
      this.page = errorPage;
    }

    this.loading = false;
  }

  listLinkClickEvent(event: ListLinkClickEvent) {
    const data: AgentCourtApplicationSummary = event.data as AgentCourtApplicationSummary;
    const isIbondProduct = GlobalConstants.AGENT_FLOW_BOND_TYPE_IBOND.indexOf(data.productTypeCode) > -1 ? true : false;
    const isInsuranceProduct = GlobalConstants.INSURANCE_CODE_ARRAY.indexOf(data.productTypeCode) > -1 ? true : false;
    let url = '';
    if (isIbondProduct) {
      url = `ibond/application/${data.productTypeCode}/${data.id}`;
    } else if (isInsuranceProduct) {
      url = `/insurance/evaluator?applicationId=${data.id}`;
    } else {
      url = data.status === 'In Progress' || data.status === 'Hold' ?
        `enrollment/application/${data.productTypeCode}/${data.id}` :
        `${AgentCourtApplicationsComponent.OVERVIEW_URL}${data.id}`;
    }
    this.router.navigateByUrl(url);
  }


  openDialog() {
    const dialogRef = this.matDialog.open(MatDialogMobileTableSearchComponent, {
      data: {
        formGroup: this.formGroup,
        searchObjects: this.searchObjects,
        statusList: this.statusList,
      },
      panelClass: 'mobile-table-filters-dialog-container',
    });

    dialogRef.componentInstance.applyFilters.subscribe(applyIsTrue => {
      this.dialogRefSubscription = dialogRef.afterClosed().subscribe(result => {
        if (applyIsTrue) {
          this.pageableEvent();
          this.dialogRefSubscription.unsubscribe();
        } else {
          this.resetFilters();
          this.pageableEvent();
          this.dialogRefSubscription.unsubscribe();
        }
      });
      dialogRef.componentInstance.applyFilters.unsubscribe();
    });
  }

  resetFilters() {
    this.formGroup.statusFormControl.setValue(this.defaultStatus || 'All');
    this.formGroup.dateRange.setValue([
      moment().subtract(1, 'months').toDate(), // a month ago
      moment().add(1, 'months').toDate(), // a month from now
    ]);
    this.formGroup.searchbox.searchInput.setValue(null);
    this.formGroup.searchbox.searchCategory.setValue('applicationId');
  }
}
