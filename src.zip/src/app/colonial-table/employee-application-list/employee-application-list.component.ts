import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';

@Component({
  selector: 'app-employee-application-list',
  templateUrl: './employee-application-list.component.html',
  styleUrls: ['./employee-application-list.component.scss'],
})
export class EmployeeApplicationListComponent {
  mode = 'court';

  constructor() {
  }

  tabChanged = (tabChangeEvent: MatTabChangeEvent): void => {
    this.switchMode(tabChangeEvent.tab.textLabel.toLocaleLowerCase());
  }

  switchMode(modeVal) {
    this.mode = modeVal;
  }
}
