import { Component, OnInit } from '@angular/core';
import { SearchObject } from '../../../form-components/searchbox-with-dropdown/search-object';
import { Page, Pageable, PageableConverter, PageImpl } from '../../../common/pagination';
import {
  EmployeeCourtApplicationSummary,
  EmployeeCourtApplicationSummaryImpl,
} from '../../../enrollment/application/court/model/employee-court-application-summary';
import { ApplicationService } from '../../../enrollment/application/application.service';
import { ListLinkClickEvent } from '../../../form-components/generic-pageable-list/list-link-click-event';
import { Router } from '@angular/router';
import { Column } from '../../../form-components/generic-pageable-list/column';
import { GenericTableSearchFormGroup } from '../../../form-components/generic-table-search/generic-table-search-form-group';
import { applicationStatuses } from '../../product-list-common/application-status';

@Component({
  selector: 'app-employee-court-applications',
  templateUrl: './employee-court-applications.component.html',
  styleUrls: ['./employee-court-applications.component.css'],
})
export class EmployeeCourtApplicationsComponent implements OnInit {
  static ADJUDICATE_URL = 'enrollment/adjudicate?formId=';

  loading = false;

  cols: Column[] = [
    {
      field: 'id',
      header: 'App Id',
      link: false,
    },
    {
      field: 'status',
      header: 'Status',
      link: false,
    },
    {
      field: 'productTypeName',
      header: 'Product',
      link: false,
    },
    {
      field: 'applicantName',
      header: 'Applicant Name',
      link: false,
    },
    {
      field: 'applicantState',
      header: 'Applicant State',
      link: false,
    },
    {
      field: 'obligeeName',
      header: 'Obligee Name',
      link: false,
    },
    {
      field: 'obligeeState',
      header: 'Obligee State',
      link: false,
    },
    {
      field: 'amount',
      header: 'Amount',
      link: false,
    },
    {
      field: 'premium',
      header: 'Premium',
      link: false,
    },
    {
      field: 'createdAt',
      header: 'Created',
      link: false,
    },
  ];

  searchObjects: SearchObject[] = [
    {
      controlName: 'applicationId',
      labelName: 'App Id',
    } as SearchObject,
    {
      controlName: 'applicantName',
      labelName: 'Applicant Name',
    } as SearchObject,
  ] as SearchObject[];

  statusList: string[];

  formGroup: GenericTableSearchFormGroup = new GenericTableSearchFormGroup('All', this.searchObjects);

  page: Page<EmployeeCourtApplicationSummary>;

  constructor(private applicationService: ApplicationService, private router: Router) {
    this.statusList = Array.from(applicationStatuses);
  }

  ngOnInit() {
    this.page = new PageImpl<EmployeeCourtApplicationSummaryImpl>();
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }) {
    this.loading = true;

    try {
      this.page = await this.applicationService.getCourtApplicationsForEmployee(pageable, this.formGroup.getRawValue());
    } catch {
      const errorPage = PageableConverter.fromData([]);
      errorPage.error = true;
      this.page = errorPage;
    }

    this.loading = false;
  }

  listLinkClickEvent(event: ListLinkClickEvent) {
    const data: EmployeeCourtApplicationSummary = event.data as EmployeeCourtApplicationSummary;
    let url = '';
    if (event.columnFieldName === 'id') {
      url = `${EmployeeCourtApplicationsComponent.ADJUDICATE_URL}${data.id}`;
    }
    this.router.navigateByUrl(url);
  }
}
