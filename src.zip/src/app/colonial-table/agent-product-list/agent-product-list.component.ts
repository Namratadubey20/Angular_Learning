import { Component, Input, ViewChild } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';
import { Subject } from 'rxjs/index';
import { TableDefaultDetails } from '../../form-components/generic-table-search/table-default-details';
import { AgentCourtProductsComponent } from './agent-court-products/agent-court-products.component';

@Component({
  selector: 'app-agent-product-list',
  templateUrl: './agent-product-list.component.html',
  styleUrls: ['./agent-product-list.component.scss'],
})
export class AgentProductListComponent {

  @Input()
  tableDefaultDetails: TableDefaultDetails;

  @ViewChild(AgentCourtProductsComponent) agentCourtProductsComponent: AgentCourtProductsComponent;

  mode = 'Court';

  tabs: string[] = [
    'Court',
    'Professional Liability',
  ];

  filtersEventSubject: Subject<any> = new Subject();

  constructor() {
  }

  tabChanged = (tabChangeEvent: MatTabChangeEvent): void => {
    this.switchMode(tabChangeEvent.tab.textLabel.toLocaleLowerCase());
  }

  switchMode(modeVal) {
    this.mode = modeVal;
  }

  emitFiltersSubject() {
    this.filtersEventSubject.next();
  }

}
