import { Component, Input, OnInit } from '@angular/core';
import { Column } from '../../../form-components/generic-pageable-list/column';
import { SearchObject } from '../../../form-components/searchbox-with-dropdown/search-object';
import { GenericTableSearchFormGroup } from '../../../form-components/generic-table-search/generic-table-search-form-group';
import { Page, Pageable, PageableConverter, PageImpl } from '../../../common/pagination';
import { Router } from '@angular/router';
import { ListLinkClickEvent } from '../../../form-components/generic-pageable-list/list-link-click-event';
import { CourtProductSummary, CourtProductSummaryImpl } from '../../product-list-common/court-product-summary';
import { ProductListService } from '../../product-list-common/product-list.service';
import { MatDialogMobileTableSearchComponent } from '../../../form-components/mat-dialog-mobile-table-search/mat-dialog-mobile-table-search.component';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material';
import * as moment from 'moment';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';

@Component({
  selector: 'app-agent-court-products',
  templateUrl: './agent-court-products.component.html',
  styleUrls: ['./agent-court-products.component.scss'],
})
export class AgentCourtProductsComponent implements OnInit {
  static OVERVIEW_URL = 'product/product-overview?formId=';

  @Input()
  defaultStatus;

  loading = false;

  cols: Column[] = [
    {
      field: 'productNo',
      header: 'Product Number',
      link: true,
    },
    {
      field: 'status',
      header: 'Status',
      link: false,
    },
    {
      field: 'productTypeName',
      header: 'Product',
      link: false,
    },
    {
      field: 'clientName',
      header: 'Client',
      link: false,
    },
    // {
    //   field: 'obligeeName',
    //   header: 'Obligee',
    //   link: false,
    // },
    // {
    //   field: 'amount',
    //   header: 'Amount',
    //   link: false,
    // },
    // {
    //   field: 'premium',
    //   header: 'Premium',
    //   link: false,
    // },
    {
      field: 'fromDate',
      header: 'Effective Date',
      link: false,
    },
  ];

  searchObjects: SearchObject[] = [
    {
      controlName: 'productNo',
      labelName: 'Product Number',
    } as SearchObject,
    {
      controlName: 'clientName',
      labelName: 'Client',
    } as SearchObject,
  ] as SearchObject[];

  statusList = [
    'All',
    'Open',
    'Open - Renewal Ready',
    'Closed',
    'Past Due',
    'Pending Renewal',
  ];

  formGroup: GenericTableSearchFormGroup;

  page: Page<CourtProductSummary>;
  dialogRefSubscription: Subscription;

  private eventsSubscription: any;
  @Input()
  events: Observable<void>;

  constructor(private productListService: ProductListService, private router: Router, private matDialog: MatDialog) {
  }

  ngOnInit() {
    this.page = new PageImpl<CourtProductSummaryImpl>();
    this.formGroup = new GenericTableSearchFormGroup(this.defaultStatus || 'All', this.searchObjects);
    if (this.events) {
      this.eventsSubscription = this.events.subscribe(() => this.openDialog());
    }
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }, dateRange = []) {
    this.loading = true;
    const searchParams = {};
    if (dateRange.length === 2) {
      searchParams['startDate'] = dateRange[0];
      searchParams['endDate'] = dateRange[1];
    }
    try {
      this.page = await this.productListService.getProductListForAgent(pageable, searchParams);
    } catch {
      const errorPage = PageableConverter.fromData([]);
      errorPage.error = true;
      this.page = errorPage;
    }

    this.loading = false;
  }

  listLinkClickEvent(event: ListLinkClickEvent) {
    const data: CourtProductSummary = event.data as CourtProductSummary;
    const isIbondProduct = GlobalConstants.AGENT_FLOW_BOND_TYPE_IBOND.indexOf(data.productTypeCode) > -1 ? true : false;
    const isInsuranceProduct = GlobalConstants.INSURANCE_CODE_ARRAY.indexOf(data.productTypeCode) > -1 ? true : false;
    let url = '';
    if (isIbondProduct) {
      url = `/ibond/product/product-overview?formId=${data.id}`;
    } else if (isInsuranceProduct) {
      url = `/insurance/evaluator?applicationId=${data.applicationId}`;
    } else {
      url = `${AgentCourtProductsComponent.OVERVIEW_URL}${data.id}`;
    }
    this.router.navigateByUrl(url);
  }

  openDialog() {
    const dialogRef = this.matDialog.open(MatDialogMobileTableSearchComponent, {
      data: {
        formGroup: this.formGroup,
        searchObjects: this.searchObjects,
        statusList: this.statusList,
      },
      panelClass: 'mobile-table-filters-dialog-container',
    });

    dialogRef.componentInstance.applyFilters.subscribe(applyIsTrue => {
      this.dialogRefSubscription = dialogRef.afterClosed().subscribe(result => {
        if (applyIsTrue) {
          this.pageableEvent();
          this.dialogRefSubscription.unsubscribe();
        } else {
          this.resetFilters();
          this.pageableEvent();
          this.dialogRefSubscription.unsubscribe();
        }
      });
      dialogRef.componentInstance.applyFilters.unsubscribe();
    });
  }

  resetFilters() {
    this.formGroup.statusFormControl.setValue(this.defaultStatus || 'All');
    this.formGroup.dateRange.setValue([
      moment().subtract(1, 'months').toDate(), // a month ago
      moment().add(1, 'months').toDate(), // a month from now
    ]);
    this.formGroup.searchbox.searchInput.setValue(null);
    this.formGroup.searchbox.searchCategory.setValue('productNo');
  }

}
