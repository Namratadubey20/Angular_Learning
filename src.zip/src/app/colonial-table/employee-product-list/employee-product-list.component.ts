import { Component, Input, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';

@Component({
  selector: 'app-employee-product-list',
  templateUrl: './employee-product-list.component.html',
  styleUrls: ['./employee-product-list.component.scss'],
})
export class EmployeeProductListComponent {

  mode = 'court';

  constructor() {
  }

  tabChanged = (tabChangeEvent: MatTabChangeEvent): void => {
    this.switchMode(tabChangeEvent.tab.textLabel.toLocaleLowerCase());
  }

  switchMode(modeVal) {
    this.mode = modeVal;
  }

}
