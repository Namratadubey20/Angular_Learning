import { Component, OnInit } from '@angular/core';
import { Column } from '../../../form-components/generic-pageable-list/column';
import { SearchObject } from '../../../form-components/searchbox-with-dropdown/search-object';
import { GenericTableSearchFormGroup } from '../../../form-components/generic-table-search/generic-table-search-form-group';
import { Page, Pageable, PageableConverter, PageImpl } from '../../../common/pagination';
import { Router } from '@angular/router';
import { ListLinkClickEvent } from '../../../form-components/generic-pageable-list/list-link-click-event';
import { ProductListService } from '../../product-list-common/product-list.service';
import { CourtProductSummary, CourtProductSummaryImpl } from '../../product-list-common/court-product-summary';

@Component({
  selector: 'app-employee-court-products',
  templateUrl: './employee-court-products.component.html',
  styleUrls: ['./employee-court-products.component.scss'],
})
export class EmployeeCourtProductsComponent implements OnInit {
  static OVERVIEW_URL = 'product/product-overview?formId=';

  loading = false;

  cols: Column[] = [
    {
      field: 'productNo',
      header: 'Product Number',
      link: true,
    },
    {
      field: 'status',
      header: 'Status',
      link: false,
    },
    {
      field: 'productTypeName',
      header: 'Product',
      link: false,
    },
    {
      field: 'clientName',
      header: 'Client Name',
      link: false,
    },
    {
      field: 'clientState',
      header: 'Client State',
      link: false,
    },
    {
      field: 'obligeeName',
      header: 'Obligee Name',
      link: false,
    },
    {
      field: 'obligeeState',
      header: 'Obligee State',
      link: false,
    },
    {
      field: 'amount',
      header: 'Amount',
      link: false,
    },
    {
      field: 'premium',
      header: 'Premium',
      link: false,
    },
    {
      field: 'fromDate',
      header: 'Effective Date',
      link: false,
    },
  ];

  searchObjects: SearchObject[] = [
    {
      controlName: 'productNo',
      labelName: 'Product Number',
    } as SearchObject,
    {
      controlName: 'clientName',
      labelName: 'Client Name',
    } as SearchObject,
  ] as SearchObject[];

  statusList = [
    'All',
    'Open',
    'Closed',
    'Past Due',
  ];

  formGroup: GenericTableSearchFormGroup = new GenericTableSearchFormGroup('All', this.searchObjects);

  page: Page<CourtProductSummary>;

  constructor(private productListService: ProductListService, private router: Router) {
  }

  ngOnInit() {
    this.page = new PageImpl<CourtProductSummaryImpl>();
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }) {
    this.loading = true;

    try {
      this.page = await this.productListService.getProductListForEmployee(pageable, this.formGroup.getRawValue());
    } catch {
      const errorPage = PageableConverter.fromData([]);
      errorPage.error = true;
      this.page = errorPage;
    }

    this.loading = false;
  }

  listLinkClickEvent(event: ListLinkClickEvent) {
    const data: CourtProductSummary = event.data as CourtProductSummary;
    let url = '';
    if (event.columnFieldName === 'productNo') {
      url = `${EmployeeCourtProductsComponent.OVERVIEW_URL}${data.id}`;
    }
    this.router.navigateByUrl(url);
  }
}
