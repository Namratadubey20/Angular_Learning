import { Component, Input, OnInit } from '@angular/core';
import { Column } from '../../../form-components/generic-pageable-list/column';
import { SearchObject } from '../../../form-components/searchbox-with-dropdown/search-object';
import { GenericTableSearchFormGroup } from '../../../form-components/generic-table-search/generic-table-search-form-group';
import { Page, Pageable, PageableConverter, PageImpl } from '../../../common/pagination';
import { Router } from '@angular/router';
import { ListLinkClickEvent } from '../../../form-components/generic-pageable-list/list-link-click-event';
import { CourtProductSummary, CourtProductSummaryImpl } from '../../product-list-common/court-product-summary';
import { ProductListService } from '../../product-list-common/product-list.service';
import { MatDialogMobileTableSearchComponent } from '../../../form-components/mat-dialog-mobile-table-search/mat-dialog-mobile-table-search.component';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material';
import * as moment from 'moment';
import { GlobalConstants } from 'src/app/ibond/constant/global.constant';

@Component({
  selector: 'app-attorney-court-products',
  templateUrl: './attorney-court-products.component.html',
  styleUrls: ['./attorney-court-products.component.scss'],
})
export class AttorneyCourtProductsComponent implements OnInit {
  static OVERVIEW_URL = 'product/product-overview?formId=';

  @Input()
  defaultStatus;

  loading = false;

  cols: Column[] = [
    {
      field: 'productNo',
      header: 'Product Number',
      link: true,
    },
    {
      field: 'status',
      header: 'Status',
      link: false,
    },
    {
      field: 'productTypeName',
      header: 'Product',
      link: false,
    },
    {
      field: 'clientName',
      header: 'Client',
      link: false,
    },
    {
      field: 'obligeeName',
      header: 'Obligee',
      link: false,
    },
    {
      field: 'amount',
      header: 'Amount',
      link: false,
    },
    {
      field: 'premium',
      header: 'Premium',
      link: false,
    },
    {
      field: 'fromDate',
      header: 'Effective Date',
      link: false,
    },
  ];

  searchObjects: SearchObject[] = [
    {
      controlName: 'productNo',
      labelName: 'Product Number',
    } as SearchObject,
    {
      controlName: 'clientName',
      labelName: 'Client',
    } as SearchObject,
  ] as SearchObject[];

  statusList = [
    'All',
    'Open',
    'Open - Renewal Ready',
    'Closed',
    'Past Due',
    'Pending Renewal',
  ];

  formGroup: GenericTableSearchFormGroup;

  page: Page<CourtProductSummary>;
  dialogRefSubscription: Subscription;

  private eventsSubscription: any;
  @Input()
  events: Observable<void>;

  constructor(private productListService: ProductListService, private router: Router, private matDialog: MatDialog) {
  }

  ngOnInit() {
    this.page = new PageImpl<CourtProductSummaryImpl>();
    this.formGroup = new GenericTableSearchFormGroup(this.defaultStatus || 'All', this.searchObjects);
    if (this.events) {
      this.eventsSubscription = this.events.subscribe(() => this.openDialog());
    }
  }

  async pageableEvent(pageable: Pageable = { page: 0, size: 20, sort: null }) {
    this.loading = true;

    try {
      this.page = await this.productListService.getProductListForAgent(pageable, this.formGroup.getRawValue());
    } catch {
      const errorPage = PageableConverter.fromData([]);
      errorPage.error = true;
      this.page = errorPage;
    }

    this.loading = false;
  }

  listLinkClickEvent(event: ListLinkClickEvent) {
    const data: CourtProductSummary = event.data as CourtProductSummary;
    const url = (GlobalConstants.ATTORNEY_FLOW_BOND_TYPE_IBOND.indexOf(data.productTypeCode) > -1) ?
      'ibond/product/product-overview?formId=' + data.id : `${AttorneyCourtProductsComponent.OVERVIEW_URL}${data.id}`;
    this.router.navigateByUrl(url);
  }

  openDialog() {
    const dialogRef = this.matDialog.open(MatDialogMobileTableSearchComponent, {
      data: {
        formGroup: this.formGroup,
        searchObjects: this.searchObjects,
        statusList: this.statusList,
      },
      panelClass: 'mobile-table-filters-dialog-container',
    });

    dialogRef.componentInstance.applyFilters.subscribe(applyIsTrue => {
      this.dialogRefSubscription = dialogRef.afterClosed().subscribe(result => {
        if (applyIsTrue) {
          this.pageableEvent();
          this.dialogRefSubscription.unsubscribe();
        } else {
          this.resetFilters();
          this.pageableEvent();
          this.dialogRefSubscription.unsubscribe();
        }
      });
      dialogRef.componentInstance.applyFilters.unsubscribe();
    });
  }

  resetFilters() {
    this.formGroup.statusFormControl.setValue(this.defaultStatus || 'All');
    this.formGroup.dateRange.setValue([
      moment().subtract(1, 'months').toDate(), // a month ago
      moment().add(1, 'months').toDate(), // a month from now
    ]);
    this.formGroup.searchbox.searchInput.setValue(null);
    this.formGroup.searchbox.searchCategory.setValue('productNo');
  }

}
