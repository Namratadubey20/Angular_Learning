import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeCourtApplicationsComponent } from './employee-application-list/employee-court-applications/employee-court-applications.component';
import { EmployeeApplicationListComponent } from './employee-application-list/employee-application-list.component';
import { TableModule } from 'primeng/table';
import { PaginatorModule, TabViewModule } from 'primeng/primeng';
import {
  MAT_DIALOG_DEFAULT_OPTIONS,
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatProgressBarModule,
  MatRadioModule,
  MatSelectModule, MatSidenavModule, MatSnackBarModule, MatStepperModule, MatTableModule, MatTabsModule, MatToolbarModule,
} from '@angular/material';
import { MatSlideToggleModule } from '../../../node_modules/@angular/material/slide-toggle';
import { AgentApplicationListComponent } from './agent-application-list/agent-application-list.component';
import { AgentCourtApplicationsComponent } from './agent-application-list/agent-court-applications/agent-court-applications.component';
import { FormComponentsModule } from '../form-components/form-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CalendarModule, CheckboxModule, DataListModule, EditorModule } from '../../../node_modules/primeng/primeng';
import { EmployeeProductListComponent } from './employee-product-list/employee-product-list.component';
import { EmployeeCourtProductsComponent } from './employee-product-list/employee-court-products/employee-court-products.component';
import { AgentProductListComponent } from './agent-product-list/agent-product-list.component';
import { AgentCourtProductsComponent } from './agent-product-list/agent-court-products/agent-court-products.component';
import { ProductListService } from './product-list-common/product-list.service';
import { MatDialogMobileTableSearchComponent } from '../form-components/mat-dialog-mobile-table-search/mat-dialog-mobile-table-search.component';
import { AttorneyApplicationListComponent } from './attorney-application-list/attorney-application-list.component';
import { AttorneyProductListComponent } from './attorney-product-list/attorney-product-list.component';
import { AttorneyCourtApplicationsComponent } from './attorney-application-list/attorney-court-applications/attorney-court-applications.component';
import { AttorneyCourtProductsComponent } from './attorney-product-list/attorney-court-products/attorney-court-products.component';


@NgModule({
  declarations: [
    EmployeeCourtApplicationsComponent,
    EmployeeApplicationListComponent,
    AgentApplicationListComponent,
    AgentCourtApplicationsComponent,
    EmployeeProductListComponent,
    EmployeeCourtProductsComponent,
    AgentProductListComponent,
    AgentCourtProductsComponent,
    AttorneyApplicationListComponent,
    AttorneyProductListComponent,
    AttorneyCourtApplicationsComponent,
    AttorneyCourtProductsComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    // Prime NG
    CalendarModule,
    DataListModule,
    CheckboxModule,
    TableModule,
    PaginatorModule,
    TabViewModule,
    EditorModule,

    FormComponentsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDividerModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatTabsModule,
    MatToolbarModule,
    MatTableModule,
    MatStepperModule,
    MatSlideToggleModule,

  ],
  providers: [
    ProductListService,
  ],
  exports: [
    EmployeeCourtApplicationsComponent,
    EmployeeApplicationListComponent,
    AgentApplicationListComponent,
    AgentCourtApplicationsComponent,
    EmployeeProductListComponent,
    EmployeeCourtProductsComponent,
    AgentProductListComponent,
    AgentCourtProductsComponent,
    AttorneyApplicationListComponent,
    AttorneyProductListComponent,
    AttorneyCourtApplicationsComponent,
    AttorneyCourtProductsComponent,
  ],
  entryComponents: [MatDialogMobileTableSearchComponent],
})
export class ColonialTableModule {
}
