import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AsyncSubject, Observable } from 'rxjs';

@Injectable()
export class AppConfigService {
  private readonly appConfig: AsyncSubject<any>;

  constructor(private http: HttpClient) {
    this.appConfig = new AsyncSubject();
  }

  loadAppConfig() {
    return this.http.get('assets/config.json')
      .subscribe((data) => {
        this.appConfig.next(data);
        this.appConfig.complete();
      });
  }

  getConfig(): Observable<any> {
    return this.appConfig.asObservable();
  }
}
