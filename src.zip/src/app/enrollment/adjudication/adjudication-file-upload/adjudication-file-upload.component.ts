import { Component, Inject, OnInit } from '@angular/core';
import { MAT_SNACK_BAR_DATA, MatSnackBarRef } from '@angular/material';
import { AdjudicationFile } from '../adjudication-file';

@Component({
  selector: 'app-adjudication-file-upload',
  templateUrl: './adjudication-file-upload.component.html',
  styleUrls: ['./adjudication-file-upload.component.scss'],
})
export class AdjudicationFileUploadComponent implements OnInit {
  fileInfo: AdjudicationFile;
  constructor(@Inject(MAT_SNACK_BAR_DATA) public data: AdjudicationFile,
    public ref: MatSnackBarRef<any>) {
    this.fileInfo = data;
  }

  ngOnInit() {
  }

  okClicked(): void {
    console.log(`Request "${this.fileInfo}" confirmed`);
    this.ref.dismissWithAction();
  }

  cancelClicked(): void {
    console.log(`Request "${this.fileInfo}" canceled`);
    this.ref.dismiss();
  }
}
