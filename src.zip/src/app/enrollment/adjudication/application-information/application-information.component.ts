import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';
import { CurrencyFormatter } from '../../../common/utils/currency-formatter';
import { ApplicationStatus } from '../application-status.enum';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { SelectEmailDialogComponent } from '../select-email-dialog/select-email-dialog.component';
import { ServiceHandler } from '../../../common/utils/service-handler.service';
import { ApplicantAndPurchaserImpl } from '../applicant-and-purchaser';
import { AdjudicationFile } from '../adjudication-file';
import { SecurityService } from '../../../security/security.service';

@Component({
  selector: 'app-application-information',
  templateUrl: './application-information.component.html',
  styleUrls: ['./application-information.component.scss'],
})

export class ApplicationInformationComponent extends AdjudicationControl {
  static REVERT_DISABLED_STATUS = [
    ApplicationStatus.IN_PROGRESS,
    ApplicationStatus.COMPLETED,
    ApplicationStatus.HOLD,
    ApplicationStatus.SOFT_HOLD,
  ].reduce((a, k) => ({ ...a, [k]: true }), {});

  bondClassification: string;
  @Input()
  applicantAndPurchaser: ApplicantAndPurchaserImpl;
  @Input()
  applicationPdfFile: AdjudicationFile;
  @Input()
  role: string;
  @Output()
  applicationReverted = new EventEmitter<any>();

  constructor(
    private router: Router,
    private dialog: MatDialog,
    securityService: SecurityService,
    private serviceHandler: ServiceHandler) {
    super(securityService);
  }

  get applicationStatus(): string {
    if (!this.overviewData) {
      return '';
    }
    return this.overviewData.status;
  }

  get bondAmount(): string {
    return CurrencyFormatter.formatMoney(this.overviewData.amount);
  }
  get bondPremium(): string {
    return CurrencyFormatter.formatMoney(this.overviewData.premium);
  }
  get disableRevert(): boolean {
    const appStatus = this.overviewData.status;
    return ApplicationInformationComponent.REVERT_DISABLED_STATUS[appStatus] || false;
  }

  get showRevert(): boolean {
    return !this.disableRevert;
  }

  async openEmailDialogue() {
    this.dialog.open(SelectEmailDialogComponent, {
      data: {
        applicationId: this.overviewData.id,
        bondType: this.overviewData.data.bondClassification,
      },
    }).afterClosed().subscribe(async response => {
      if (response === 1) {
        this.serviceHandler.handleConfirm('email sent');
      } else if (response === -1) {
        this.serviceHandler.handleError('email failed to send');
      }
    });
  }

  async viewApplicantProfile() {
    let url = `user/view-client`;
    url += (this.overviewData.person === null) ? `/C/${this.overviewData.companyOffice.id}` : `/P/${this.overviewData.person.id}`;
    await this.router.navigateByUrl(url);
  }

  revertApplication(): void {
    this.applicationReverted.emit(null);
  }
}
