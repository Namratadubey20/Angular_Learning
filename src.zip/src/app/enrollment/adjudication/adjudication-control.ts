import { FormGroup } from '@angular/forms';
import { Input } from '@angular/core';
import { ApplicationImpl } from '../application/application';
import { AdjudicationConfigurationImpl } from '../application/adjudication-configuration';
import { SecurityService } from '../../security/security.service';
import { ApplicationStatus } from './application-status.enum';

export class AdjudicationControl {

  constructor(protected securityService: SecurityService) {
  }

  @Input()
  public adjudicationFormGroup: FormGroup;

  @Input()
  public applicationId: number;

  @Input()
  overviewData: ApplicationImpl;

  @Input()
  statusColor: string;

  @Input()
  configuration: AdjudicationConfigurationImpl;

  get userCanAdjudicate(): boolean {
    return !!this.securityService &&
      !!this.securityService.user &&
      this.securityService.user.hasEmployeePlusPermissions;
  }

  protected disableByStatusExceptFor(...statusValues: ApplicationStatus[]): boolean {
    if (!this.overviewData || !this.overviewData.status) {
      return true;
    }
    const status: ApplicationStatus = <ApplicationStatus>this.overviewData.status;
    return !statusValues.includes(status);
  }

  protected disableByStatusIfOneOf(...statusValues: ApplicationStatus[]): boolean {
    if (!this.overviewData || !this.overviewData.status) {
      return true;
    }
    const status: ApplicationStatus = <ApplicationStatus>this.overviewData.status;
    return statusValues.includes(status);
  }
}
