import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AdjudicationFile } from '../../adjudication-file';
import { FileManager } from '../../file-manager';
import { MatSnackBar, MatDialog } from '@angular/material';
import { SecurityService } from '../../../../security/security.service';
import { AdjudicationEvent, AdjudicationEventName } from '../../adjudication-event';
import { FileService } from '../../../../common/file-upload/file.service';
import { ConfirmationDialogComponent } from 'src/app/common/confirmation-dialog/confirmation-dialog.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';

@Component({
  selector: 'app-addl-doc-card',
  templateUrl: './addl-doc-card.component.html',
  styleUrls: ['./addl-doc-card.component.scss'],
})
export class AddlDocCardComponent extends FileManager implements OnInit {

  @Input()
  additionalDocument: AdjudicationFile;
  @Output()
  adjudicationStatusChange = new EventEmitter<AdjudicationEvent>();

  constructor(
    _snackBar: MatSnackBar,
    securityService: SecurityService,
    private fileService: FileService,
    private dialog: MatDialog,
    private serviceHandler: ServiceHandler) {
    super(securityService, _snackBar);
  }

  ngOnInit() {
  }

  get name(): String {
    return this.additionalDocument.applicationFile.name;
  }

  get customDescription(): String {
    return this.additionalDocument.applicationFile.description;
  }

  get description(): String {
    return this.additionalDocument.fileType.description;
  }

  editAction(): void {
    this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Edit Description',
        confirmationRequestText: this.name,
        descriptionText: this.customDescription,
        acceptLabel: 'Save',
        acceptedResult: true,
        rejectLabel: 'Cancel',
        rejectedResult: false,
      },
    }).afterClosed().subscribe(async result => {
      if (result) {
        const response = this.fileService.updateFileDescription(this.additionalDocument.fileId, result.description);
        if (response) {
          this.adjudicationStatusChange.emit({
            eventName: AdjudicationEventName.ONE_FILE_VERIFICATION_CHANGE,
            applicationId: this.applicationId,
            value: result,
          });
          this.serviceHandler.handleConfirm('The document description has been updated');
        }
      }
    });
  }

  viewAction() {
    this.getFileContents();
  }

  deleteAction() {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Delete Document?',
        confirmationRequestText: 'Are you sure you want to delete this file?',
        detailsText: this.name,
        acceptLabel: 'Delete',
        acceptedResult: true,
        rejectLabel: 'Cancel',
        rejectedResult: false,
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteFile(this.additionalDocument.fileId);
        this.serviceHandler.handleConfirm('The document has been deleted');
      }
    });
  }

  getFileContents() {
    window.open(`api/file/view-content/${this.additionalDocument.fileId}`);
  }

  async deleteFile(id: number) {
    // const allVerified = this.allFilesVerified();
    const isHistoryNeeded = true;
    await this.fileService.deleteFileById(id, isHistoryNeeded).toPromise();

    // refresh the list of files after delete
    // await this.loadFiles();

    // send out status change events
    this.adjudicationStatusChange.emit({
      eventName: AdjudicationEventName.FILE_DELETED,
      applicationId: this.applicationId,
      value: id,
    });
  }
}
