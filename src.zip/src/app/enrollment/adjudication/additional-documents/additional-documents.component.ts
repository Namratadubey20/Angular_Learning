import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';
import { FormControl, FormGroup } from '@angular/forms';
import { FileUploadConfig } from '../../../common/file-upload/file-upload-config';
import { AdjudicationFile } from '../adjudication-file';
import { AdjudicationEvent, AdjudicationEventName } from '../adjudication-event';
import { SecurityService } from '../../../security/security.service';
import { FileTypeModel } from '../file-type-model';
import { AdjudicationFileService } from '../adjudication-files/adjudication-file.service';
import { FileTypes } from '../../application-overview/application-overview.component';
import { AdjudicationService } from '../adjudication.service';

@Component({
  selector: 'app-additional-documents',
  templateUrl: './additional-documents.component.html',
  styleUrls: ['./additional-documents.component.scss'],
})
export class AdditionalDocumentsComponent extends AdjudicationControl implements OnInit, OnDestroy, AdjudicationControl {

  constructor(
    securityService: SecurityService,
    private adjudicationFileService: AdjudicationFileService,
    private adjudicationService: AdjudicationService) {
    super(securityService);
    this.additionalDocumentsFormGroup = new FormGroup({
      fileUploadFormGroup: new FormGroup({
        id: new FormControl(null),
        name: new FormControl(null),
        fileTypeName: new FormControl(null),
        description: new FormControl(null),
      }),
    });
  }

  get fileTypeNameControlValue(): string {
    return this.additionalDocumentsFormGroup.get(`${this.FILE_UPLOAD_FORM_GROUP_NAME}.fileTypeName`).value;
  }

  get descriptionControlValue(): string {
    return this.additionalDocumentsFormGroup.get(`${this.FILE_UPLOAD_FORM_GROUP_NAME}.description`).value;
  }

  get addedDocumentFileFormGroup(): FormGroup {
    return this.additionalDocumentsFormGroup.get(this.FILE_UPLOAD_FORM_GROUP_NAME) as FormGroup;
  }
  fileUploadConfig: FileUploadConfig;

  additionalDocumentsFormGroup: FormGroup;
  @Input()
  additionalDocuments: AdjudicationFile[];

  @Output()
  adjudicationStatusChange: EventEmitter<AdjudicationEvent> = new EventEmitter<AdjudicationEvent>();

  private additionalDocumentFileTypes = new Map<string, FileTypeModel>();
  private epvFileTypes: Map<string, string> = new Map<string, string>();
  uploadSectionVisible = false;
  fileTypeName = '';

  private FILE_UPLOAD_FORM_GROUP_NAME = 'fileUploadFormGroup';

  ngOnDestroy(): void {
  }

  async ngOnInit() {
    this.epvFileTypes = this.identifyExpectedFileTypes();
    this.additionalDocumentFileTypes = await this.identifyAdditionalDocumentFileTypes(this.epvFileTypes);
  }


  private async identifyAdditionalDocumentFileTypes(fileTypeMap) {
    const fileTypeModels = await this.adjudicationFileService.getFileTypeNames().toPromise();
    const additionalFileTypes = new Map<string, FileTypeModel>();
    fileTypeModels.forEach(ftModel => {
      if (!fileTypeMap.has(ftModel.name) &&
        ftModel.name !== FileTypes.applicationFile) {
        additionalFileTypes.set(ftModel.name, ftModel);
      }
    });
    return additionalFileTypes;
  }

  private identifyExpectedFileTypes() {
    const fileTypeMap = new Map<string, string>();
    this.configuration.fileTypes.forEach(ft => {
      fileTypeMap.set(ft.name, ft.description);
    });
    return fileTypeMap;
  }
  private emitEvent(eventName: AdjudicationEventName, value: any): void {
    this.adjudicationStatusChange.emit({
      eventName,
      value,
      applicationId: this.applicationId,
    });
  }

  fileUploaded(event) {
    if (event) {
      this.resetUploadFormGroup();
      this.emitEvent(AdjudicationEventName.FILE_UPLOADED, event);
      this.adjudicationService.emitUpdateNotes(true);
    }
  }

  fileTypeNamesNotRequired(): FileTypeModel[] {
    return Array.from(this.additionalDocumentFileTypes.values());
  }

  handleDocumentChange(event: AdjudicationEvent) {
    this.emitEvent(AdjudicationEventName.FILE_DELETED, event);
    this.adjudicationService.emitUpdateNotes(true);
  }

  getApplicationIdNumber() {
    return this.overviewData.id;
  }

  resetUploadFormGroup() {
    const fg = this.addedDocumentFileFormGroup;
    fg.setValue({
      id: 0,
      name: '',
      fileTypeName: '',
      description: '',
    });
  }

  revealUploadSection() {
    this.uploadSectionVisible = true;
  }
  hideUploadSection() {
    this.uploadSectionVisible = false;
  }
}
