import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';
import { MatDialog } from '@angular/material';
import { ApplicationNote } from '../application-note';
import { ApplicationNoteService } from '../application-note.service';
import { ConfirmationDialogComponent } from '../../../common/confirmation-dialog/confirmation-dialog.component';
import { SecurityService } from '../../../security/security.service';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { AdjudicationService } from '../adjudication.service';

@Component({
  selector: 'app-application-activity',
  templateUrl: './application-activity.component.html',
  styleUrls: ['./application-activity.component.scss'],
})
export class ApplicationActivityComponent extends AdjudicationControl implements OnInit, OnDestroy {

  userNotes: ApplicationNote[] = null;
  systemNotes: ApplicationNote[] = null;
  initialized: boolean;

  @Input()
  applicationId: number;

  applicationNote: ApplicationNote = null;

  @Input()
  showEditor = false;

  constructor(
    private applicationNoteService: ApplicationNoteService,
    private adjudicationService: AdjudicationService,
    securityService: SecurityService,
    private matDialog: MatDialog,
    private serviceHandler: ServiceHandler) {
    super(securityService);
  }

  ngOnDestroy(): void {
  }

  async ngOnInit() {
    this.getNotes();
    this.initialized = true;
    this.refreshNotes();
  }

  refreshNotes() {
    this.adjudicationService.getUpdateNotes().subscribe(actionOccured => {
      if (actionOccured) {
        this.getNotes();
      }
    });
  }

  async getNotes() {
    const notes = await this.applicationNoteService.getApplicationNotesByApplicationId(this.applicationId).toPromise();
    this.userNotes = notes.filter((e) => e.systemGenerated === false);
    this.systemNotes = notes.filter((e) => e.systemGenerated === true);
  }


  editNote(applicationNote: ApplicationNote) {
    this.applicationNote = new ApplicationNote();
    this.applicationNote.id = applicationNote.id;
    this.applicationNote.comments = applicationNote.comments;
    this.applicationNote.createdAt = applicationNote.createdAt;
    this.applicationNote.createdBy = applicationNote.createdBy;
    this.applicationNote.updatedAt = applicationNote.updatedAt;
    this.applicationNote.updatedBy = applicationNote.updatedBy;
    this.applicationNote.applicationId = applicationNote.applicationId;
    this.showEditor = true;
  }

  newNote() {
    this.applicationNote = new ApplicationNote();
    this.applicationNote.systemGenerated = false;
    this.applicationNote.applicationId = this.applicationId;
    this.showEditor = true;
  }

  async deleteNote(id: number) {

    const dialogRef = this.matDialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Are you sure you want to delete this note?',
        acceptLabel: 'Yes',
        acceptedResult: true,
        rejectLabel: 'No',
        rejectedResult: false,
      },
    });

    dialogRef
      .afterClosed()
      .subscribe(async e => {
        if (e) {
          await this.applicationNoteService.deleteApplicationNote(id).toPromise();
          this.serviceHandler.handleConfirm('The comment has been deleted.');
          this.userNotes = this.userNotes.filter(n => n.id !== id);

          if (this.showEditor && id === this.applicationNote.id) {
            this.cancelNoteSave();
          }
        }
      });

  }

  cancelNoteSave() {
    this.showEditor = false;
    this.applicationNote = null;
  }

  async saveNote() {
    let note;
    if (this.applicationNote.id) {
      note = await this.applicationNoteService.updateApplicationNote(this.applicationNote).toPromise();
    } else {
      note = await this.applicationNoteService.createApplicationNote(this.applicationNote).toPromise();
    }

    this.showEditor = false;

    // update the note in the list or add to the beginning if new
    let found = false;
    for (let i = 0; i < this.userNotes.length; i++) {
      if (this.userNotes[i].id === note.id) {
        // move this to the front of the list
        this.userNotes.splice(i, 1);
        this.userNotes.unshift(note);
        found = true;
      }
    }
    if (!found) {
      this.userNotes.unshift(note);
    }

    this.applicationNote = null;

    return note;
  }
}
