import { Injectable } from '@angular/core';
import { JsonConvert } from 'json2typescript';
import { HttpClient } from '@angular/common/http';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { JsonConvertService } from '../../common/utils/json-convert.service';
import { Observable } from 'rxjs';
import { ApplicationNote } from './application-note';

@Injectable()
export class ApplicationNoteService {
  jsonConvert: JsonConvert;

  constructor(
    private http: HttpClient,
    private serviceHandler: ServiceHandler,
    jsonConvertService: JsonConvertService
  ) {
    this.jsonConvert = jsonConvertService.getJsonConvert();
  }

  getApplicationNoteById(id: number): Observable<ApplicationNote> {
    return null;
  }

  getApplicationNotesByApplicationId(applicationId: number): Observable<ApplicationNote[]> {
    return this.http.get<ApplicationNote[]>(`/api/colonial/adjudicate/note?applicationId=${applicationId}`)
      .map(e => this.jsonConvert.deserializeArray(e, ApplicationNote));
  }

  updateApplicationNote(applicationNote: ApplicationNote): Observable<ApplicationNote> {
    return this.http.put<ApplicationNote>(`/api/colonial/adjudicate/note/${applicationNote.id}`, applicationNote)
      .map(e => this.jsonConvert.deserialize(e, ApplicationNote) as ApplicationNote);
  }

  createApplicationNote(applicationNote: ApplicationNote): Observable<ApplicationNote> {
    return this.http.post<ApplicationNote>(`/api/colonial/adjudicate/note`, applicationNote)
      .map(e => this.jsonConvert.deserialize(e, ApplicationNote) as ApplicationNote);
  }

  deleteApplicationNote(id: number): Observable<void> {
    return this.http.delete<void>(`/api/colonial/adjudicate/note/${id}`);
  }
}
