import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Application } from '../../../application/application';
import { ReplevinApplication } from '../../../application/court/model/replevin-application';
import { AttachmentApplication } from '../../../application/court/model/attachment-application';
import { AdjudicationService } from '../../adjudication.service';
import { ServiceHandler } from '../../../../common/utils/service-handler.service';
import { ConservatorshipGuardianshipApplication } from '../../../application/court/model/conservatorship-guardianship-application';
import { RefereeReceiverApplication } from '../../../application/court/model/referee-receiver-application';
import { EstateTrusteeApplication } from '../../../application/court/model/estate-trustee-application';
import { CourtBondType } from '../../../application/common/bond-types';
import { InjunctionCourtApplication } from '../../../application/court/model/injunction-court-application';
import { ApplicationStatus } from '../../application-status.enum';

export interface SoftHoldQuestion {
  question: string;
  value: any;
}

export interface SoftHoldQuestionOverrideDialogData {
  application: Application;
}

@Component({
  selector: 'app-knockout-question-dialog',
  styles: [
    'dl {font-family: IBM Plex Sans, Trebuchet MS, Arial, Helvetica, sans-serif;}',
    'dd {font-weight: bold;}',
  ],
  templateUrl: './soft-hold-question-override-dialog.component.html',
})
export class SoftHoldQuestionOverrideDialogComponent {
  application: Application = null;

  constructor(
    public dialogRef: MatDialogRef<SoftHoldQuestionOverrideDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: SoftHoldQuestionOverrideDialogData,
    private adjudicationService: AdjudicationService,
    private serviceHandler: ServiceHandler
  ) {
    this.application = dialogData.application;
  }

  cancel(): void {
    this.dialogRef.close();
  }

  /*
  Note that this information should be moved to the database.  However that requires a larger refactoring effort.
  The soft hold questions as of this writing are stored in java code in a class per bond type.  So both the backend
  and front end require refactoring to move soft holds to the database.
   */
  getSoftHoldQuestions(): SoftHoldQuestion[] {
    const questions: SoftHoldQuestion[] = [];
    switch (this.application.productType.code as CourtBondType) {
      case CourtBondType.Replevin:
        this.addReplevinQuestions(questions);
        break;

      case CourtBondType.Attachment:
        this.addAttachmentQuestions(questions);
        break;

      case CourtBondType.Injunction:
        this.addInjunctionQuestions(questions);
        break;

      case CourtBondType.Referee:
      case CourtBondType.Receiver:
        this.addRefereeReceiverQuestions(questions);
        break;

      case CourtBondType.Conservatorship:
      case CourtBondType.Guardianship:
        this.addConservatorshipGuardianshipQuestions(questions);
        break;

      case CourtBondType.Estate:
      case CourtBondType.Trustee:
        this.addEstateTrusteeQuestions(questions);
        break;
    }

    return questions;
  }

  private addCommonFiduciaryQuestions(questions: SoftHoldQuestion[]) {
    questions.push({
      question: 'Bond Amount',
      value: this.application.data.amount,
    });
  }

  private addReplevinQuestions(questions: SoftHoldQuestion[]) {
    const app = <ReplevinApplication>(this.application.data as any);

    questions.push({
      question: 'Bond Amount',
      value: app.amount,
    });

    if (app.exparteProcedure != null) {
      questions.push({
        question: 'Will the bond be used in an ex-parte procedure?',
        value: app.exparteProcedure ? 'Yes' : 'No',
      });

      // if (!app.exparteProcedure) {
      //   questions.push({
      //     question: 'Why will the bond not be used in an ex-parte procedure?',
      //     value: app.exparteProcedureExplanation,
      //   });
      // }
    }

    // if (app.securedByUcc != null) {
    //   questions.push({
    //     question: 'Is the claim secured by UCC filing or other written agreement?',
    //     value: app.securedByUcc ? 'Yes' : 'No',
    //   });

    //   if (!app.securedByUcc) {
    //     questions.push({
    //       question: 'Why is the claim not secured by UCC filing or other written agreement?',
    //       value: app.securedByUccExplanation,
    //     });
    //   }
    // }
  }

  private addInjunctionQuestions(questions: SoftHoldQuestion[]) {
    const app = this.application.data as InjunctionCourtApplication;

    questions.push({
      question: 'Bond Amount',
      value: app.amount,
    });

    // if (app.usedInExParteProcedure != null) {
    //   questions.push({
    //     question: 'Will the bond be used in an ex-parte procedure?',
    //     value: app.usedInExParteProcedure ? 'Yes' : 'No',
    //   });

    //   if (!app.usedInExParteProcedure) {
    //     questions.push({
    //       question: 'Why will the bond not be used in an ex-parte procedure?',
    //       value: app.whyNotUsedInExParteProcedure,
    //     });
    //   } //check this carefully as this is common soft hold condition
    // }
  }

  private addAttachmentQuestions(questions: SoftHoldQuestion[]) {
    const app = this.application.data as AttachmentApplication;

    questions.push({
      question: 'Bond Amount',
      value: app.amount,
    });

    if (app.exparteProcedure != null) {
      questions.push({
        question: 'Will the bond be used in an ex-parte procedure?',
        value: app.exparteProcedure ? 'Yes' : 'No',
      });

      // if (!app.exparteProcedure) {
      //   questions.push({
      //     question: 'Why will the bond not be used in an ex-parte procedure?',
      //     value: app.exparteProcedureExplanation,
      //   });
      // }

    }

    // if (app.securedByUcc != null) {
    //   questions.push({
    //     question: 'Is the claim secured by UCC filing or other written agreement?',
    //     value: app.securedByUcc ? 'Yes' : 'No',
    //   });

    //   if (!app.securedByUcc) {
    //     questions.push({
    //       question: 'Why is the claim not secured by UCC filing or other written agreement?',
    //       value: app.securedByUccExplanation,
    //     });
    //   }
  }

  // if (app.titleAttachedToSomeoneOther != null) {
  //   questions.push({
  //     question: 'Is the title to the property being attached in the name of someone other than the Defendant?',
  //     value: app.titleAttachedToSomeoneOther ? 'Yes' : 'No',
  //   });

  //   if (app.titleAttachedToSomeoneOther) {
  //     questions.push({
  //       question: 'Give full details including name of title holder',
  //       value: app.titleAttachedToSomeoneOtherExplanation,
  //     });
  //   }
  // }

  private addRefereeReceiverQuestions(questions: SoftHoldQuestion[]) {
    this.addCommonFiduciaryQuestions(questions);
    const app = <RefereeReceiverApplication>(this.application.data as any);

    // if (app.nonRenewed != null) {
    //   questions.push({
    //     question: 'Has an insurer declined, canceled, or non-renewed any similar bond on behalf of any person proposed for this bond?',
    //     value: app.nonRenewed ? 'Yes' : 'No',
    //   });
    // }

    // if (app.serviceProvided != null) {
    //   questions.push({
    //     question: 'Will professional accounting or investment services be provided on an ongoing basis?',
    //     value: app.serviceProvided ? 'Yes' : 'No',
    //   });
    // }
  }


  private addConservatorshipGuardianshipQuestions(questions: SoftHoldQuestion[]) {
    this.addCommonFiduciaryQuestions(questions);
    const app = <ConservatorshipGuardianshipApplication>(this.application.data as any);

    if (app.serviceProvided != null) {
      questions.push({
        question: 'Will professional accounting or investment services be provided on an ongoing basis?',
        value: app.serviceProvided ? 'Yes' : 'No',
      });
    }
  }

  private addEstateTrusteeQuestions(questions: SoftHoldQuestion[]) {
    this.addCommonFiduciaryQuestions(questions);
    const app = <EstateTrusteeApplication>(this.application.data as any);

    // if (app.nonRenewed != null) {
    //   questions.push({
    //     question: 'Has an insurer declined, canceled, or non-renewed any similar bond on behalf of any person proposed for this bond?',
    //     value: app.nonRenewed ? 'Yes' : 'No',
    //   });
    // }

    // if (app.will != null) {
    //   questions.push({
    //     question: 'Is there a will?',
    //     value: app.will ? 'Yes' : 'No',
    //   });

    //   if (app.will) {
    //     questions.push({
    //       question: 'Is the will contested?',
    //       value: app.willContested ? 'Yes' : 'No',
    //     });
    //   }
    // }

    // if (app.hasAttorney != null) {
    //   questions.push({
    //     question: 'Do you have an attorney?',
    //     value: app.hasAttorney ? 'Yes' : 'No',
    //   });
    //   if (app.hasAttorney) {
    //     questions.push({
    //       question: 'Will the attorney be co-fiduciary on the bond?',
    //       value: app.attorneyInvolved ? 'Yes' : 'No',
    //     });
    //   }
    // }

    // if (app.serviceProvided != null) {
    //   questions.push({
    //     question: 'Will professional accounting or investment services be provided on an ongoing basis?',
    //     value: app.serviceProvided ? 'Yes' : 'No',
    //   });
    // }
  }

  async overrideSoftHoldQuestions() {
    try {
      await this.adjudicationService.softHoldOverride(this.application.id).toPromise();
      this.serviceHandler.handleConfirm('Status set to Submitted');
      this.dialogRef.close(true);
    } catch (e) {
      this.serviceHandler.handleError('Failed to override');
      this.dialogRef.close(false);
    }
  }

  get overrideEnabled() {
    return this.application.status === ApplicationStatus.SOFT_HOLD || this.application.status === ApplicationStatus.HOLD;
  }
}
