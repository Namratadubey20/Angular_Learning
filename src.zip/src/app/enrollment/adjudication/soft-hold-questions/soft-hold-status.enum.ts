export enum SoftHoldStatus {
  PASSED = 'Passed',
  FAILED = 'Failed',
  OVERRIDDEN = 'Overridden',
}
