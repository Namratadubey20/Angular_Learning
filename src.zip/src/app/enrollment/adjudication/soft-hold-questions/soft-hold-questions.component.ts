import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';
import { ApplicationStatus } from '../application-status.enum';
import { SoftHoldStatus } from './soft-hold-status.enum';
import { MatDialog } from '@angular/material';
import { SoftHoldQuestionOverrideDialogComponent } from './soft-hold-question-override-dialog/soft-hold-question-override-dialog.component';
import { SecurityService } from '../../../security/security.service';

@Component({
  selector: 'app-soft-hold-questions',
  templateUrl: './soft-hold-questions.component.html',
  styleUrls: ['./soft-hold-questions.component.scss'],
})
export class SoftHoldQuestionsComponent extends AdjudicationControl implements OnInit {
  private wasOverridden = false;
  @Output()
  componentStatus = new EventEmitter<boolean>();

  constructor(
    private matDialog: MatDialog,
    securityService: SecurityService) {
    super(securityService);
  }

  ngOnInit() {
    this.componentStatus.emit(this.softHoldOverallStatus);
  }

  viewSoftHoldQuestions() {
    this.matDialog.open(SoftHoldQuestionOverrideDialogComponent, {
      data: {
        'application': this.overviewData,
      },
    }).afterClosed()
      .subscribe(response => {
        if (response) {
          this.wasOverridden = true;
          this.overviewData.status = SoftHoldStatus.OVERRIDDEN;
          // window.location.reload();
        }
      });
  }

  get softHoldOverallStatus(): boolean {
    return this.softHoldStatus !== SoftHoldStatus.FAILED;
  }

  get softHoldStatus() {
    if (this.overviewData.status === ApplicationStatus.SOFT_HOLD) {
      return SoftHoldStatus.FAILED;
    } else if (this.wasOverridden) {
      return SoftHoldStatus.OVERRIDDEN;
    } else {
      return SoftHoldStatus.PASSED;
    }
  }
  get softHoldClass() {
    switch (this.softHoldStatus) {
      case SoftHoldStatus.FAILED:
        return 'badge-failed';
      case SoftHoldStatus.OVERRIDDEN:
        return 'badge-overridden';
      case SoftHoldStatus.PASSED:
        return 'badge-passed';
    }
  }

  get allConditionsMet() {
    return this.overviewData.status !== ApplicationStatus.SOFT_HOLD;
  }
}
