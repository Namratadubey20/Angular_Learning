import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FileManager } from '../file-manager';
import { MatSnackBar, MatDialog } from '@angular/material';
import { AdjudicationFile } from '../adjudication-file';
import { SecurityService } from '../../../security/security.service';
import { FileUploadConfig } from '../../../common/file-upload/file-upload-config';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ButtonTooltips } from '../button-tooltips.enum';
import { FileTypes } from '../../application-overview/application-overview.component';
import { ApplicationStatus } from '../application-status.enum';
import { FileService } from '../../../common/file-upload/file.service';
import {
  AdjudicationEvent,
  AdjudicationEventName,
} from '../adjudication-event';
import { ConfirmationDialogComponent } from 'src/app/common/confirmation-dialog/confirmation-dialog.component';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';

@Component({
  selector: 'app-file-card',
  templateUrl: './file-card.component.html',
  styleUrls: ['./file-card.component.scss'],
})
export class FileCardComponent extends FileManager implements OnInit {
  @Input()
  adjudicationFile: AdjudicationFile;
  @Input()
  specialFormUploaded = false; // making this optional will help (release/3.0.3)

  @Output()
  fileVerified = new EventEmitter<AdjudicationFile>();
  @Output()
  fileUnverified = new EventEmitter<AdjudicationFile>();
  @Output()
  adjudicationStatusChange: EventEmitter<AdjudicationEvent> = new EventEmitter<AdjudicationEvent>();
  fileUploadConfig: FileUploadConfig;
  disableViewReason = ButtonTooltips.VIEW_NO_FILE;
  private uploadFormGroup: FormGroup;

  constructor(
    _snackBar: MatSnackBar,
    private fb: FormBuilder,
    private fileService: FileService,
    securityService: SecurityService,
    private dialog: MatDialog,
    private serviceHandler: ServiceHandler
  ) {
    super(securityService, _snackBar);
    this.fileUploadConfig = new FileUploadConfig();
    this.fileUploadConfig.acceptsFileTypes = '.pdf,.doc,.docx,.jpg,.jpeg';
  }

  ngOnInit() {
    this.resetUploadFormGroup(this.adjudicationFile);
    // if (this.overviewData.data.specialBondUpload === false && this.adjudicationFile.fileType.name === FileTypes.specialBondFile) {
    //   this.adjudicationFile.required = true;
    // }
    if (
      this.overviewData.data.uploadPersonal === false &&
      this.adjudicationFile.fileType.name === FileTypes.personalFinancialFile
    ) {
      this.adjudicationFile.required = false;
      this.adjudicationFile.filledBy = true;
    }
  }

  toggleVerificationState(adjFile: AdjudicationFile) {
    adjFile.setVerified(!adjFile.verified);
    if (adjFile.verified) {
      this.fileVerified.emit(adjFile);
    } else {
      this.fileUnverified.emit(adjFile);
    }
  }

  displayUploadToast() {
    this.sbAlert(`Please upload a ${this.adjudicationFile.label}`);
  }
  private emitEvent(eventName: AdjudicationEventName, value: any): void {
    this.adjudicationStatusChange.emit({
      eventName,
      value,
      applicationId: this.overviewData.id,
    });
  }

  async uploadFile(event) {
    const adjFile = this.adjudicationFile;
    this.resetUploadFormGroup(adjFile);
    if (event) {
      this.resetUploadFormGroup(this.adjudicationFile);
      this.emitEvent(AdjudicationEventName.FILE_UPLOADED, event);
    }
  }

  resetUploadFormGroup(adjudicationFile: AdjudicationFile) {
    const fileExists = adjudicationFile.existingFile;
    this.uploadFormGroup = this.fb.group({
      id: 0,
      name: '',
      fileTypeName: adjudicationFile.fileType.name,
      verified: fileExists ? adjudicationFile.verified : false,
    });
  }
  // Verify toggle methods
  get disableVerifyReason(): string {
    if (this.fileDoesNotExist) {
      return ButtonTooltips.VERIFY_NO_FILE;
    } else if (this.overviewData.status === ApplicationStatus.CLOSED) {
      return ButtonTooltips.VERIFY_CLOSED_APPLICATION;
    }
    return 'No clue how we got here';
  }
  // View button methods
  disableViewButton(): boolean {
    return this.fileDoesNotExist;
  }

  get fileDoesNotExist(): boolean {
    return !this.adjudicationFile.existingFile;
  }

  viewAction() {
    if (this.disableViewButton()) {
      return;
    }
    this.getFileContents();
  }
  // Upload button methods
  get disableUploadReason(): string {
    if (this.disableUploadWrongStatus) {
      return ButtonTooltips.UPLOAD_CLOSED_APPLICATION;
      // } else if (this.disableUploadCompletedSpecialForm()) {
      //   return ButtonTooltips.UPLOAD_NO_SP_BOND_FORM;
    } else if (this.adjudicationFile.existingFile) {
      return ButtonTooltips.UPLOAD_EXISTING_WARNING;
    } else {
      return 'Not sure why upload is disabled; shouldn\'t be.';
    }
  }

  /**
   * Disable upload of a file to this card if
   * * this file is a completed-special-bond-form AND
   * * (there's no special-bond-form file uploaded)
   *
   * Other checks handle disabling for other reasons
   */
  // disableUploadCompletedSpecialForm(): boolean {
  //   return this.isCompletedSpecialBondForm && !this.specialFormUploaded;
  // }

  // get isCompletedSpecialBondForm(): boolean {
  //   return this.adjudicationFile.fileType.name === FileTypes.completedSpecialBondFile;
  // }
  get disableUploadWrongStatus(): boolean {
    return this.disableByStatusIfOneOf(
      ApplicationStatus.CLOSED,
      ApplicationStatus.COMPLETED
    );
  }

  disableUploadButton(): boolean {
    return (
      this.adjudicationFile.existingFile ||
      // this.disableUploadCompletedSpecialForm() ||
      this.disableUploadWrongStatus ||
      this.adjudicationFile.filledBy
    );
  }

  // Delete button methods
  get disableDeleteReason(): string {
    if (this.fileDoesNotExist) {
      return ButtonTooltips.DELETE_NO_FILE;
    } else if (this.disableDeleteWrongStatus) {
      return ButtonTooltips.DELETE_CLOSED_APPLICATION;
    } else {
      return 'Should not see this';
    }
  }

  get disableDeleteWrongStatus(): boolean {
    return this.disableByStatusIfOneOf(
      ApplicationStatus.COMPLETED,
      ApplicationStatus.CLOSED
    );
  }

  disableDeleteButton(): boolean {
    return this.fileDoesNotExist;
  }

  deleteAction() {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Delete Document ?',
        confirmationRequestText:
          'Are you sure you want to delete this document?',
        detailsText: this.adjudicationFile.applicationFile.name,
        acceptLabel: 'Yes, Delete',
        acceptedResult: true,
        rejectLabel: 'Cancel',
        rejectedResult: false,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (this.disableDeleteButton()) {
          return;
        }
        this.deleteFile(this.adjudicationFile.applicationFile.id);
        this.adjudicationStatusChange.emit({
          eventName: AdjudicationEventName.FILE_DELETED,
          applicationId: this.adjudicationFile.applicationFile.id,
          value: false,
        });
        this.serviceHandler.handleConfirm('The document has been deleted');
      }
    });
  }

  async deleteFile(id: number) {
    // const allVerified = this.allFilesVerified();
    const isHistoryNeeded = false;
    await this.fileService.deleteFileById(id, isHistoryNeeded).toPromise();

    // refresh the list of files after delete
    // await this.loadFiles();

    // send out status change events
    // this.emitEvent(AdjudicationEventName.FILE_DELETED, id);

    // in case we deleted a file when all was approved
    // if (this.adjudicationFile.verified) {
    //   this.emitEvent(AdjudicationEventName.ONE_FILE_VERIFICATION_CHANGE, false);
    // }
  }

  getFileContents() {
    window.open(`api/file/view-content/${this.adjudicationFile.fileId}`);
  }
}
