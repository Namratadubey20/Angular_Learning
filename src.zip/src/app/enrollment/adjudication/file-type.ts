import { JsonObject, JsonProperty } from 'json2typescript';

export interface FileType {
  name: string;
  description: string;
}

@JsonObject('FileTypeImpl')
export class FileTypeImpl implements FileType {
  @JsonProperty('description', String, true)
  description: string = null;
  @JsonProperty('name', String, true)
  name: string = null;
}
