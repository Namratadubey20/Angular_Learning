import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmailService } from '../../../common/email/email-service';
import { CourtBondType } from '../../application/common/bond-types';

export interface DialogData {
  applicationId: number;
  bondType: string;
}

@Component({
  selector: 'app-select-email-dialog',
  templateUrl: './select-email-dialog.component.html',
})
export class SelectEmailDialogComponent implements OnInit {
  applicationId: number;
  formGroup: FormGroup;
  initialized = false;
  submitted = false;
  emailTypeNames = ['General Email', 'Bond Document'];

  constructor(
    public dialogRef: MatDialogRef<SelectEmailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: DialogData,
    public fb: FormBuilder,
    private emailService: EmailService) {

    this.applicationId = dialogData.applicationId;
  }

  ngOnInit() {
    this.formGroup = this.fb.group({
      emailTypeName: ['', Validators.required],
    });

    if (this.dialogData.bondType && this.dialogData.bondType === CourtBondType.Supersedeas) {
      this.emailTypeNames.push('Wire Transfer Instructions');
      this.emailTypeNames.push('Letter of Credit Instructions');
    }

    this.initialized = true;
  }

  async send() {
    this.submitted = true;
    try {
      const templateName = this.templateName(this.formGroup.get('emailTypeName').value);
      await this.emailService.sendEmail(templateName, 'Application', this.applicationId).toPromise();
    } catch (e) {
      this.dialogRef.close(-1);
    }
    this.dialogRef.close(1);
  }

  templateName(emailTypeName): string {
    switch (emailTypeName) {
      case 'General Email':
        return 'general_applicant_email';
      case 'Bond Document':
        return 'bond_document';
      case 'Wire Transfer Instructions':
        return 'wire_transfer_instructions';
      case 'Letter of Credit Instructions':
        return 'letter_of_credit_instructions';
      default:
        throw new Error(`bad emailType Name ${emailTypeName}`);
    }
  }

  cancel() {
    this.dialogRef.close(0);
  }
}
