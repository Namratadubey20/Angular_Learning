import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ApplicationImpl } from '../../../application/application';
import { SecurityService } from '../../../../security/security.service';
import { AdjudicationService } from '../../adjudication.service';

export interface KnockoutQuestionDialogData {
  application: ApplicationImpl;
  koqOverride: boolean;
}

@Component({
  selector: 'app-knockout-question-dialog',
  styles: [
    'dl {font-family: IBM Plex Sans, "Trebuchet MS", Arial, Helvetica, sans-serif;}',
    'dd {font-weight: bold;}',
  ],
  templateUrl: './knockout-question-dialog.component.html',
})
export class KnockoutQuestionDialogComponent implements OnInit {
  private application: ApplicationImpl = null;
  /**
   * This will shortly be removed as impossible, since overriding the
   * Knockout Questions will change the application status to 'In Progress'
   */
  get undoKoQOverridePossible(): boolean {
    return this.applicationIsKnockedOut() && this.isKoqOverride;
  }

  get isKoqOverride() {
    return this.application.koqOverride;
  }

  get overrideKoQPossible(): boolean {
    return this.applicationIsKnockedOut() && !this.isKoqOverride;
  }

  private applicationIsKnockedOut() {
    return this.application.isKnockedOut;
  }

  constructor(
    private securityService: SecurityService,
    private adjudicationService: AdjudicationService,
    public dialogRef: MatDialogRef<KnockoutQuestionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: KnockoutQuestionDialogData) {

    this.application = dialogData.application;
  }

  get userCanAdjudicate(): boolean {
    return this.securityService.user.hasEmployeePlusPermissions;
  }

  ngOnInit() {
  }

  cancel(): void {
    this.dialogRef.close();
  }

  getKnockoutQuestions() {
    if (this.application.data.hasKnockoutQuestions()) {
      const questions = [];
      const knockoutQuestions = this.application.data[this.application.data.knockoutQuestionFieldName()];
      for (const kq of knockoutQuestions) {
        questions.push(kq);
      }
      return questions;
    }
    return null;
  }

  async toggleKoQOverride() {
    const newOverride: boolean = !this.isKoqOverride;
    await this.adjudicationService.koqOverride(this.application.id, newOverride).toPromise();
    this.application.koqOverride = newOverride;
    this.dialogRef.close({
      data: newOverride,
    });
  }
}
