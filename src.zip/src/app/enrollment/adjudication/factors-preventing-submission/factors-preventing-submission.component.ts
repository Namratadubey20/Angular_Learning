import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';
import { CreditScoreDialogComponent } from './credit-score-dialog/credit-score-dialog.component';
import { MatDialog } from '@angular/material';
import { ApplicationImpl } from '../../application/application';
import { KnockoutQuestionDialogComponent } from './knockout-question-dialog/knockout-question-dialog.component';
import { SecurityService } from '../../../security/security.service';
import { AdjudicationEvent, AdjudicationEventName } from '../adjudication-event';

@Component({
  selector: 'app-factors-preventing-submission',
  templateUrl: './factors-preventing-submission.component.html',
  styleUrls: ['./factors-preventing-submission.component.scss'],
})
export class FactorsPreventingSubmissionComponent extends AdjudicationControl implements OnInit, OnDestroy {
  @Output()
  adjudicationChangeEvent = new EventEmitter<AdjudicationEvent>();
  private application: ApplicationImpl;
  private knockedOut: boolean;
  private creditScoreOverride: boolean;
  private creditFail: boolean;
  showKnockoutQuestions = true;
  showCreditScore = true;

  constructor(
    securityService: SecurityService,
    private matDialog: MatDialog) {
    super(securityService);
  }

  private creditScoreIsAboveThreshold = false;

  ngOnDestroy(): void {
  }

  ngOnInit(): void {
    this.showCreditScore = this.configuration.requiresCreditScore;
    this.showKnockoutQuestions = this.configuration.requiresKoQuestions;
    this.application = this.overviewData;
    this.knockedOut = this.application.data.knockedOut;
    this.creditScoreOverride = this.application.creditScoreOverride;
    this.creditFail = !this.checkCreditScore();

    this.creditScoreIsAboveThreshold = this.checkCreditScore();

    this.emitCreditScoreEvent();
    this.emitKnockoutQuestionsEvent();
  }

  private emitKnockoutQuestionsEvent() {
    this.adjudicationChangeEvent.emit({
      applicationId: this.overviewData.id,
      eventName: AdjudicationEventName.KNOCKOUT_QUESTIONS_PASSED,
      value: this.goodKnockoutAnswers,
    });
  }

  private emitCreditScoreEvent() {
    this.adjudicationChangeEvent.emit({
      applicationId: this.overviewData.id,
      eventName: AdjudicationEventName.CREDIT_SCORE_CHECKED,
      value: this.goodCreditScore,
    });
  }

  private checkCreditScore(): boolean {
    const threshold = this.configuration.creditScoreThreshold;
    const score = this.overviewData.applicationResponsiblePerson.creditScore;
    return threshold < score;
  }

  get creditScoreBadgeClass(): string {
    if (this.creditScoreIsAboveThreshold) {
      return 'passed';
    } else if (this.creditScoreOverride) {
      return 'overridden';
    } else if (this.creditFail) {
      return 'failed';
    } else {
      return '';
    }
  }

  get creditScoreText(): string {
    if (this.creditScoreIsAboveThreshold) {
      return 'Passed';
    } else if (this.creditScoreOverride) {
      return 'Overridden';
    } else if (this.creditFail) {
      return 'Failed';
    } else {
      return 'UNKNOWN';
    }
  }

  get creditScoreBoxClass(): string {
    if (this.creditScoreOverride || !this.creditFail) {
      return 'all-verified';
    } else {
      return 'not-all-verified';
    }
  }

  get goodCreditScore(): boolean {
    return this.creditScoreIsAboveThreshold || this.creditScoreOverride;
  }

  viewCreditScore() {
    this.matDialog.open(CreditScoreDialogComponent, {
      data: {
        'application': this.application,
        'creditScoreOverride': this.creditScoreOverride,
        'creditFail': this.creditFail,
        'minCredit': this.configuration.creditScoreThreshold,
      },
      autoFocus: false,
    }).afterClosed()
      .subscribe(response => {
        this.creditScoreOverride = response.data;
        this.emitCreditScoreEvent();
      });
  }

  viewKnockoutQuestions() {
    this.matDialog.open(KnockoutQuestionDialogComponent, {
      data: {
        'application': this.application,
        'koqOverride': this.isKoqOverride,
        'koqFail': this.applicationIsKnockedOut,
      },
    }).afterClosed()
      .subscribe(response => {
        this.application.koqOverride = response.data;
        this.emitKnockoutQuestionsEvent();
      });
  }

  get koqBadgeClass(): string {
    if (!this.applicationIsKnockedOut) {
      return 'passed';
    } else if (this.isKoqOverride) {
      return 'overridden';
    } else if (this.applicationIsKnockedOut) {
      return 'failed';
    } else {
      return '';
    }
  }

  get koqText(): string {
    if (!this.applicationIsKnockedOut) {
      return 'Passed';
    } else if (this.isKoqOverride) {
      return 'Overridden';
    } else if (this.applicationIsKnockedOut) {
      return 'Failed';
    } else {
      return 'UNKNOWN';
    }
  }

  get koqBoxClass(): string {
    if (this.goodKnockoutAnswers) {
      return 'all-verified';
    } else {
      return 'not-all-verified';
    }
  }

  get goodKnockoutAnswers(): boolean {
    return this.isKoqOverride || !this.applicationIsKnockedOut;
  }

  get applicationIsKnockedOut() {
    return this.application.isKnockedOut;
  }

  get isKoqOverride() {
    return this.application.koqOverride;
  }
}
