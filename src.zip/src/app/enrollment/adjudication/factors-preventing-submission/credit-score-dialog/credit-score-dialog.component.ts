import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Application } from '../../../application/application';
import { AdjudicationService } from '../../adjudication.service';
import { SecurityService } from '../../../../security/security.service';

export interface CreditScoreDialogData {
  application: Application;
  creditOverride: boolean;
  creditFail: boolean;
  minCredit: number;
}

@Component({
  selector: 'app-credit-score-dialog',
  templateUrl: './credit-score-dialog.component.html',
  styleUrls: ['./credit-score-dialog.component.scss'],
})
export class CreditScoreDialogComponent implements OnInit {

  creditOverride = false;
  application: Application = null;
  creditFail = false;
  minCredit = 0;

  constructor(
    private dialogRef: MatDialogRef<CreditScoreDialogComponent>,
    private adjudicationService: AdjudicationService,
    private securityService: SecurityService,
    @Inject(MAT_DIALOG_DATA) private dialogData: CreditScoreDialogData) {

    this.creditOverride = this.dialogData.creditOverride;
    this.application = this.dialogData.application;
    this.creditFail = this.dialogData.creditFail;
    this.minCredit = this.dialogData.minCredit;
  }

  get userCanAdjudicate(): boolean {
    return this.securityService.user.hasEmployeePlusPermissions;
  }

  ngOnInit() {
    this.creditOverride = this.application.creditScoreOverride;
  }

  cancel(): void {
    this.dialogRef.close({
      data: this.creditOverride,
    });
  }

  async viewFullCreditReport() {
    const personId = this.application.person.id;
    window.open(`api/person/${personId}/credit-report`);
  }

  async toggleCreditScoreOverride() {
    const newOverride: boolean = !this.application.creditScoreOverride;
    await this.adjudicationService.creditOverride(this.application.id, newOverride).toPromise();
    this.application.creditScoreOverride = newOverride;
    this.creditOverride = newOverride;
    this.dialogRef.close({
      data: newOverride,
    });
  }
}
