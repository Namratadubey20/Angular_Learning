import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdjudicationFileModel } from './adjudication-file-model';
import { JsonConvert } from 'json2typescript';
import { JsonConvertService } from '../../../common/utils/json-convert.service';
import { FileTypeModel } from '../file-type-model';

@Injectable({
  providedIn: 'root',
})
export class AdjudicationFileService {
  private jsonConvert: JsonConvert = null;
  private requestURL = '/api/colonial/adjudicate';

  constructor(private http: HttpClient, private jsonConvertService: JsonConvertService) {
    this.jsonConvert = jsonConvertService.getJsonConvert();
  }

  getRequiredFileTypes(applicationId: number): Observable<String[]> {
    return this.http.get<String[]>(`${this.requestURL}/required-file-types/${applicationId}`);
  }

  getAdjudicationFiles(applicationId: number): Observable<AdjudicationFileModel[]> {
    return this.http.get<AdjudicationFileModel[]>(`${this.requestURL}/adjudication-files/${applicationId}`)
      .map((f) => this.jsonConvert.deserializeArray(f, AdjudicationFileModel));
  }

  unverifyFile(applicationId: number) {
    return this.http.put(`${this.requestURL}/unverify-file/${applicationId}`, null);
  }

  verifyFile(applicationId: number) {
    return this.http.put(`${this.requestURL}/verify-file/${applicationId}`, null);
  }
  verifyFinancials(applicationId: number) {
    return this.http.put(`${this.requestURL}/verify-financial/${applicationId}`, null);
  }
  unverifyFinancials(applicationId: number) {
    return this.http.put(`${this.requestURL}/unverify-financial/${applicationId}`, null);
  }
  getFileTypeNames(): Observable<FileTypeModel[]> {
    return this.http.get<FileTypeModel[]>(`${this.requestURL}/file-types`)
      .map((e) => this.jsonConvert.deserializeArray(e, FileTypeModel));
  }
}
