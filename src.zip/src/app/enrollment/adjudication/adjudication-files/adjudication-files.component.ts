import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FileService } from '../../../common/file-upload/file.service';
import { FileModel } from '../../../common/file-upload/file-model';
import { AdjudicationFileService } from './adjudication-file.service';
import { AdjudicationFileModel } from './adjudication-file-model';
import { FileUploadConfig } from '../../../common/file-upload/file-upload-config';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ServiceHandler } from '../../../common/utils/service-handler.service';
import { AppConfigService } from '../../../app-config-service';
import { FileTypeModel } from '../file-type-model';
import { AdjudicationEvent, AdjudicationEventName } from '../adjudication-event';
import { ButtonTooltips } from '../button-tooltips.enum';
import { Application } from '../../application/application';
import { ApplicationStatus } from '../application-status.enum';
import { FileTypes } from '../../application-overview/application-overview.component';
import { SecurityService } from '../../../security/security.service';

@Component({
  selector: 'app-adjudication-files',
  templateUrl: './adjudication-files.component.html',
  styleUrls: ['./adjudication-files.component.scss'],
})
export class AdjudicationFilesComponent implements OnInit {

  @Input()
  applicationId: number;
  @Input()
  application: Application;

  @Output()
  adjudicationStatusChange: EventEmitter<AdjudicationEvent> = new EventEmitter<AdjudicationEvent>();

  fileModels: FileModel[];
  requiredFileTypes: String[];
  adjudicationFileModels: AdjudicationFileModel[];
  fileUploadConfig: FileUploadConfig;
  formGroup: FormGroup;
  appConfig;
  fileTypeName: string;
  adjudicationFilesByFileTypeName = new Map<string, AdjudicationFileModel>();
  fileTypeNames: FileTypeModel[];
  initialized = false;
  disableViewReason = ButtonTooltips.VIEW_NO_FILE;

  constructor(private fileService: FileService,
    private adjudicationFileService: AdjudicationFileService,
    private securityService: SecurityService,
    private fb: FormBuilder, private serviceHandler: ServiceHandler, appConfigService: AppConfigService) {

    this.fileUploadConfig = new FileUploadConfig();
    this.fileUploadConfig.acceptsFileTypes = '.pdf,.doc,.docx,.jpg,.jpeg';

    appConfigService.getConfig().subscribe(ac => this.appConfig = ac);
  }

  async ngOnInit() {
    this.initialized = false;
    this.requiredFileTypes = await this.adjudicationFileService.getRequiredFileTypes(this.applicationId).toPromise();
    this.fileTypeNames = await this.adjudicationFileService.getFileTypeNames().toPromise();
    this.resetFormGroup();
    await this.loadFiles();
    if (this.allFilesVerified()) {
      // send out an event when init happens if all files are verified
      this.adjudicationStatusChange.emit({
        eventName: AdjudicationEventName.FILES_VERIFIED,
        applicationId: this.applicationId,
        value: true,
      });
    }
    this.initialized = true;
  }

  get userCanAdjudicate(): boolean {
    return this.securityService.user.hasEmployeePlusPermissions;
  }

  resetFormGroup() {
    this.formGroup = this.fb.group({
      id: 0,
      name: '',
      fileTypeName: '',
      verified: false,
    });

    // add a form control for each required file type name
    // this is for the toggle
    this.requiredFileTypes.forEach((ft) => {
      this.formGroup.addControl(ft.toString(), new FormControl(ft.toString(), Validators.required));
    });
  }

  async loadFiles() {
    // this has the verified status of the files
    this.adjudicationFileModels = await this.adjudicationFileService.getAdjudicationFiles(this.applicationId).toPromise();

    // this is the files themselves linked to the application via the parentObjectId
    this.fileModels = await this.fileService.getFileList(this.applicationId + '', 'Application').toPromise();

    this.requiredFileTypes.forEach((ft) => {
      this.adjudicationFilesByFileTypeName.set(ft.toString(), this.adjudicationFileModels.find((m) => m.fileTypeName === ft));
    });
  }

  async deleteFile(id: number) {
    const allVerified = this.allFilesVerified();
    const isHistoryNeeded = false;
    await this.fileService.deleteFileById(id, isHistoryNeeded).toPromise();

    // refresh the list of files after delete
    await this.loadFiles();

    // send out status change events
    this.adjudicationStatusChange.emit({
      eventName: AdjudicationEventName.FILE_DELETED,
      applicationId: this.applicationId,
      value: id,
    });

    // in case we deleted a file when all was approved
    if (allVerified) {
      this.adjudicationStatusChange.emit({
        eventName: AdjudicationEventName.FILES_VERIFIED,
        applicationId: this.applicationId,
        value: false,
      });
    }

    // go to the top of the page
    window.scrollTo(0, 0);
  }

  getFileContents(id: number) {
    window.open(`api/file/view-content/${id}`);
  }

  async verifyFile(id: number) {
    await this.adjudicationFileService.verifyFile(id).toPromise();
    await this.loadFiles();
    this.sendFilesVerifiedEvent(id);
  }

  async unverifyFile(id: number) {
    await this.adjudicationFileService.unverifyFile(id).toPromise();
    await this.loadFiles();
    this.sendFilesVerifiedEvent(id);
  }

  private sendFilesVerifiedEvent(id: number) {
    this.adjudicationStatusChange.emit(
      { eventName: AdjudicationEventName.FILES_VERIFIED, applicationId: id, value: this.allFilesVerified() });
  }

  async uploadFile(event) {
    if (event) {
      await this.loadFiles();
      this.resetFormGroup();
      this.adjudicationStatusChange.emit(
        {
          eventName: AdjudicationEventName.FILE_UPLOADED,
          applicationId: this.applicationId, value: event,
        });
      window.scrollTo(0, 0);
    }
  }

  getApplicationIdNumber() {
    return Number(this.applicationId);
  }

  getApplicationFile(fileTypeName: string) {

    return this.adjudicationFilesByFileTypeName.get(fileTypeName);
  }

  get otherAdjudicationFileModels() {
    return this.adjudicationFileModels.filter((f) => !this.requiredFileTypes.includes(f.fileTypeName));
  }

  get fileTypeNameControlValue(): string {
    return this.formGroup.get('fileTypeName').value;
  }

  getFileTypeNameDescriptionByValue(value: string) {
    return this.fileTypeNames.find((e) => {
      return e.name === value;
    }).description;
  }

  async toggleVerified(fileTypeName: string) {
    const adjFileModel = this.adjudicationFileModels.find((e) => e.fileTypeName === fileTypeName);

    if (adjFileModel) {
      if (adjFileModel.verified) {
        adjFileModel.verified = true;
        await this.unverifyFile(adjFileModel.id);
      } else {
        adjFileModel.verified = false;
        await this.verifyFile(adjFileModel.id);
      }
    } else {
      throw new Error(`Unexpected error, missing adjudication file model for File Type '${fileTypeName}'`);
    }
  }

  isVerified(fileTypeName): boolean {
    const adjFile = this.adjudicationFileModels.find((e) => e.fileTypeName === fileTypeName);

    let ret = false;
    if (adjFile) {
      ret = adjFile.verified;
    }

    return ret;
  }

  // View button methods
  disableViewButton(fileTypeName: string): boolean {
    return !this.fileExistsForType(fileTypeName);
  }

  viewAction(fileType: string) {
    if (this.disableViewButton(fileType)) {
      return;
    }
    this.getFileContents(this.getApplicationFile(fileType).id);
  }
  // Upload button methods
  disableUploadReason(fileTypeName: string): string {
    if (this.disableUploadWrongStatus) {
      return ButtonTooltips.UPLOAD_CLOSED_APPLICATION;
      // } else if (this.disableUploadCompletedSpecialForm(fileTypeName)) {
      //   return ButtonTooltips.UPLOAD_NO_SP_BOND_FORM;
    } else if (this.fileExistsForType(fileTypeName)) {
      return ButtonTooltips.UPLOAD_EXISTING_WARNING;
    } else {
      return 'Not sure why upload is disabled; shouldn\'t be.';
    }
  }

  // disableUploadCompletedSpecialForm(fileTypeName: string): boolean {
  //   if (fileTypeName === FileTypes.completedSpecialBondFile) {
  //     return !this.fileExistsForType(FileTypes.specialBondFile);
  //   } else {
  //     return false;
  //   }
  // }

  get disableUploadWrongStatus(): boolean {
    return this.application.status === ApplicationStatus.CLOSED;
  }

  disableUploadButton(fileTypeName: string): boolean {
    return this.fileExistsForType(fileTypeName) ||
      // this.disableUploadCompletedSpecialForm(fileTypeName) ||
      this.disableUploadWrongStatus;
  }

  // Delete button methods
  disableDeleteReason(fileTypeName: string): string {
    if (!this.fileExistsForType(fileTypeName)) {
      return ButtonTooltips.DELETE_NO_FILE;
    } else if (this.disableDeleteWrongStatus) {
      return ButtonTooltips.DELETE_CLOSED_APPLICATION;
    } else {
      return 'Should not see this';
    }
  }

  get disableDeleteWrongStatus(): boolean {
    return this.application.status === ApplicationStatus.CLOSED;
  }

  disableDeleteButton(fileTypeName: string): boolean {
    return !this.fileExistsForType(fileTypeName);
  }

  deleteAction(fileType: string) {
    if (this.disableDeleteButton(fileType)) {
      return;
    }
    this.deleteFile(this.getApplicationFile(fileType).id);
  }

  fileExistsForType(fileTypeName: string): boolean {
    return this.adjudicationFilesByFileTypeName.get(fileTypeName) !== undefined;
  }

  allFilesVerified() {

    for (let i = 0; i < this.requiredFileTypes.length; i++) {
      if (!this.isVerified(this.requiredFileTypes[i])) {
        return false;
      }
    }
    return true;
  }

  fileTypeNamesNotRequired(): FileTypeModel[] {
    return this.fileTypeNames.filter((e) => {
      return !this.requiredFileTypes.includes(e.name) && e.name !== FileTypes.applicationFile;
    });
  }
}
