import { FileModelImpl } from '../../../common/file-upload/file-model';
import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject('AdjudicationFileModel')
export class AdjudicationFileModel extends FileModelImpl {

  @JsonProperty('verified', Boolean, true)
  verified: boolean = null;

  @JsonProperty('applicationId', Number, true)
  applicationId: number = null;

}
