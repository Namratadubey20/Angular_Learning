import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonUtilities } from '../../../common/utils/common-utilities';

export interface DialogData {
  actionName: string;
}

@Component({
  templateUrl: './application-action-confirmation-dialog.component.html',
})
export class ApplicationActionConfirmationDialogComponent implements OnInit {

  formGroup: FormGroup;
  initialized = false;
  actionName: string;


  constructor(
    public dialogRef: MatDialogRef<ApplicationActionConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: DialogData,
    private fb: FormBuilder) {

    this.actionName = dialogData.actionName;
  }

  ngOnInit() {
    this.formGroup = this.fb.group(
      {
        reasonText: ['', Validators.required],
      }
    );
    this.initialized = true;
  }

  onRejectClick(): void {
    this.dialogRef.close(false);
  }

  onAcceptClick(): void {
    if (this.formGroup.valid) {
      this.dialogRef.close(this.formGroup.getRawValue());
    } else {
      if (this.actionName === 'decline') {
        CommonUtilities.markAllTouched(this.formGroup);
      } else {
        this.dialogRef.close(true);
      }
    }
  }

}
