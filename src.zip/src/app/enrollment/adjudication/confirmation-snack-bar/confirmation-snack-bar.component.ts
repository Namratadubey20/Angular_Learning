import { Component, Inject, OnInit } from '@angular/core';
import { MAT_SNACK_BAR_DATA, MatSnackBarRef } from '@angular/material/snack-bar';

@Component({
  selector: 'app-confirmation-snack-bar',
  templateUrl: './confirmation-snack-bar.component.html',
  styleUrls: ['./confirmation-snack-bar.component.scss'],
})
export class ConfirmationSnackBarComponent implements OnInit {
  message = 'This is a message!';
  constructor(@Inject(MAT_SNACK_BAR_DATA) public data: any,
    public ref: MatSnackBarRef<any>) {
    if (!!data) {
      this.message = data;
    }
  }

  ngOnInit() {
  }

  okClicked(): void {
    this.ref.dismissWithAction();
  }

  cancelClicked(): void {
    this.ref.dismiss();
  }

}
