import { Component, EventEmitter, Output } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';
import { AdjudicationService } from '../adjudication.service';
import { MatSnackBar } from '@angular/material';
import { UserInteraction } from '../user-interaction';
import { ApplicationStatus } from '../application-status.enum';
import { Router } from '@angular/router';
import { ButtonTooltips } from '../button-tooltips.enum';
import { SecurityService } from '../../../security/security.service';

@Component({
  selector: 'app-other-actions',
  templateUrl: './other-actions.component.html',
  styleUrls: ['./other-actions.component.scss'],
})
export class OtherActionsComponent extends AdjudicationControl {

  static CLOSE_DISABLED_STATUS = [
    ApplicationStatus.DECLINED,
    ApplicationStatus.CLOSED,
    ApplicationStatus.COMPLETED,
  ].reduce((a, k) => ({ ...a, [k]: true }), {});
  @Output()
  applicationClosed = new EventEmitter<void>();
  disableView = false;
  private ui: UserInteraction;
  private router: Router;
  disableCloseReason = ButtonTooltips.CLOSE_WRONG_STATUS;

  constructor(
    private adjudicationService: AdjudicationService,
    securityService: SecurityService,
    router: Router,
    _snackBar: MatSnackBar) {
    super(securityService);
    this.router = router;
    this.ui = new UserInteraction(_snackBar);
  }

  get disableClose(): boolean {
    return OtherActionsComponent.CLOSE_DISABLED_STATUS[this.overviewData.status] || false;
  }

  async closeApplication() {
    if (this.disableClose) {
      return;
    }
    this.applicationClosed.emit(null);
  }

  async viewApplicationRO() {
    if (this.disableView) {
      return;
    }
    const url = `enrollment/application-overview?formId=${this.overviewData.id}`;
    await this.router.navigateByUrl(url);
  }
}
