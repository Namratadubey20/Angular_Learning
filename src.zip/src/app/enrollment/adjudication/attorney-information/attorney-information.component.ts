import { Component, Input, OnInit } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';
import { Router } from '@angular/router';
import { SecurityService } from '../../../security/security.service';
import { PersonService } from '../../../common/person-service';
import { AgentSummary } from '../../../user/profile/readonly-referral-information/agent-summary';

@Component({
  selector: 'app-attorney-information',
  templateUrl: './attorney-information.component.html',
  styleUrls: ['./attorney-information.component.scss'],
})
export class AttorneyInformationComponent extends AdjudicationControl implements OnInit {

  @Input()
  isStartedByAttorney: boolean;

  attorney: AgentSummary;

  constructor(
    securityService: SecurityService,
    private personService: PersonService,
    private router: Router
  ) {
    super(securityService);
  }

  async ngOnInit(): Promise<void> {
    if (this.isStartedByAttorney) {
      this.attorney = await this.personService.getAgentOfApplication(this.overviewData.id);
    }
  }

  /**
   * This assumes that the link to visit the attorney's profile will only display when isStartedByAttorney is true
   */
  async viewAttorneyProfile() {
    const url = `user/view-client/P/${this.attorney.personId}`;
    await this.router.navigateByUrl(url);
  }
}
