import { Component, OnDestroy, OnInit } from '@angular/core';
import { AdjudicationControl } from '../adjudication-control';

@Component({
  selector: 'app-obligee-information',
  templateUrl: './obligee-information.component.html',
  styleUrls: ['./obligee-information.component.scss'],
})
export class ObligeeInformationComponent extends AdjudicationControl implements OnInit, OnDestroy {

  ngOnDestroy(): void {
  }

  ngOnInit(): void {
  }




}
