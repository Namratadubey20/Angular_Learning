import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { AdjudicationFile } from '../adjudication-file';
import { FileManager } from '../file-manager';
import { MatSnackBar } from '@angular/material';
import { AdjudicationService } from '../adjudication.service';
import { SecurityService } from '../../../security/security.service';
import { AdjudicationEvent, AdjudicationEventName } from '../adjudication-event';

@Component({
  selector: 'app-collateral',
  templateUrl: './collateral.component.html',
  styleUrls: ['./collateral.component.scss'],
})
export class CollateralComponent extends FileManager implements OnInit, OnDestroy {

  @Input()
  collateral: AdjudicationFile;
  @Output()
  collateralStatus = new EventEmitter<AdjudicationEvent>();

  constructor(
    snackBar: MatSnackBar,
    securityService: SecurityService,
    private adjudicationService: AdjudicationService) {
    super(securityService, snackBar);
  }

  get allVerified(): boolean {
    return this.collateral.verified;
  }

  ngOnInit() {
    this.collateralStatus.emit(this.verifyEvent(this.allVerified));
  }

  private verifyEvent(value: boolean): AdjudicationEvent {
    return {
      eventName: AdjudicationEventName.COLLATERAL_VERIFIED,
      applicationId: this.overviewData.id,
      value: value,
    };
  }

  private emitVerifyEvent(value: boolean): void {
    this.collateralStatus.emit(this.verifyEvent(value));
  }

  ngOnDestroy(): void {
  }

  async verifyFile(adjFile: AdjudicationFile) {
    const fileId = adjFile.fileId;
    await this.adjudicationService.verifyFile(fileId).toPromise();
    this.emitVerifyEvent(true);
  }

  async unverifyFile(adjFile: AdjudicationFile) {
    const fileId = adjFile.fileId;
    await this.adjudicationService.unverifyFile(fileId).toPromise();
    this.emitVerifyEvent(false);
  }

  handleAdjudicationEvent(event: AdjudicationEvent) {
    this.collateralStatus.emit(event);
  }
}
