import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { AdjudicationFile } from '../adjudication-file';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FileManager } from '../file-manager';
import { AdjudicationService } from '../adjudication.service';
import { SecurityService } from '../../../security/security.service';
import { AdjudicationEvent, AdjudicationEventName } from '../adjudication-event';
import { FileTypes } from '../../application-overview/application-overview.component';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-file-verifications',
  templateUrl: './file-verifications.component.html',
  styleUrls: ['./file-verifications.component.scss'],
})

export class FileVerificationsComponent extends FileManager implements OnInit, OnDestroy {

  constructor(
    _snackBar: MatSnackBar,
    securityService: SecurityService,
    public router: ActivatedRoute,
    private adjudicationService: AdjudicationService) {
    super(securityService, _snackBar);
  }

  get allVerified(): boolean {
    return this.extraProductVerifications.reduce((previousValue, currentFile) => {
      return previousValue && currentFile.verificationStatus;
    }, true);
  }

  // get specialBondFormExists(): boolean {
  //   return this.extraProductVerifications.reduce((accum, currentFile) => {
  //     return accum || (currentFile.fileType.name === FileTypes.specialBondFile &&
  //       currentFile.existingFile);
  //   }, false);
  // }

  @Input()
  extraProductVerifications: AdjudicationFile[];

  @Output()
  adjudicationStatusChange: EventEmitter<AdjudicationEvent> = new EventEmitter<AdjudicationEvent>();

  ngOnDestroy(): void {
  }

  ngOnInit(): void {
    this.sendFilesVerifiedEvent();
  }

  async verifyFile(adjFile: AdjudicationFile) {
    const fileId = adjFile.fileId;
    const applicationID = this.router.queryParams['value'].formId;
    if (fileId) {
      await this.adjudicationService.verifyFile(fileId).toPromise();
    } else if (this.extraProductVerifications[1].filledBy && this.extraProductVerifications[1].fileType.description === 'Financials') {
      await this.adjudicationService.verifyFinancials(applicationID).toPromise();
    }
    this.sendFilesVerifiedEvent();
  }

  async unverifyFile(adjFile: AdjudicationFile) {
    const fileId = adjFile.fileId;
    const applicationID = this.router.queryParams['value'].formId;
    if (fileId) {
      await this.adjudicationService.unverifyFile(fileId).toPromise();
    } else if (this.extraProductVerifications[1].filledBy && this.extraProductVerifications[1].fileType.description === 'Financials') {
      await this.adjudicationService.unverifyFinancials(applicationID).toPromise();
    }
    this.sendFilesVerifiedEvent();
  }

  private sendFilesVerifiedEvent() {
    this.adjudicationStatusChange.emit(
      { eventName: AdjudicationEventName.FILES_VERIFIED, applicationId: this.applicationId, value: this.allVerified });
  }

  handleStatusChange(event: AdjudicationEvent) {
    switch (event.eventName) {
      case AdjudicationEventName.ONE_FILE_VERIFICATION_CHANGE:
        this.adjudicationStatusChange.emit(
          {
            eventName: AdjudicationEventName.FILES_VERIFIED,
            applicationId: this.overviewData.id,
            value: this.allVerified,
          });
        break;
      case AdjudicationEventName.FILES_VERIFIED:
      case AdjudicationEventName.FILE_DELETED:
        this.adjudicationStatusChange.emit(event);
        break;
      case AdjudicationEventName.FILE_UPLOADED:
        this.adjudicationStatusChange.emit(event);
        break;
      default:
        throw new Error(`invalid event name '${event.eventName}'`);
    }
  }
}
