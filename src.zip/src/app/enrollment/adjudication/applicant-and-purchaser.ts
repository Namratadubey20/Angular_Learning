import { JsonObject, JsonProperty } from 'json2typescript';

export enum PurchaserRoles {
  EMPLOYEE = 'Employee',
  TPA = 'TPA',
  ATTORNEY = 'Attorney',
  AGENT = 'Agent',
  CLIENT = 'Client',
  UNKNOWN = 'No known role',
}
export interface ApplicantAndPurchaser {
  role: PurchaserRoles;
  applicantName: string;
  companyApplicantName: string;
  purchaserName: string;
}

@JsonObject('ApplicantAndPurchaserImpl')
export class ApplicantAndPurchaserImpl implements ApplicantAndPurchaser {
  @JsonProperty('role', String, true)
  role: PurchaserRoles = undefined;
  @JsonProperty('applicantName', String, true)
  applicantName = '';
  @JsonProperty('companyApplicantName', String, true)
  companyApplicantName = '';
  @JsonProperty('purchaserName', String, true)
  purchaserName = '';
}
