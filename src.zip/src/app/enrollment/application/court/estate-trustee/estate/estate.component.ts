import { Component, ElementRef, Inject } from '@angular/core';
import { EstateTrusteeComponent } from '../estate-trustee.component';
import { ApplicationService } from '../../../application.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../../../../security/security.service';
import { ServiceHandler } from '../../../../../common/utils/service-handler.service';
import { GoogleTagManagerService } from '../../../../../common/services/google-tag-manager.service';
import { ApplicationRoleService } from '../../../../../common/services/application-role-service';
import { MatDialog } from '@angular/material';
import { PersonService } from '../../../../../common/person-service';
import { CourtBondType } from '../../../common/bond-types';
import { DOCUMENT } from '@angular/common';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

@Component({
  selector: 'app-estate',
  templateUrl: '../estate-trustee.component.html',
  styleUrls: ['../estate-trustee.component.css'],
  providers: [ApplicationRoleService],
})
export class EstateComponent extends EstateTrusteeComponent {
  constructor(
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      applicationService,
      securityService,
      activatedRoute,
      router,
      CourtBondType.Estate,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      elementRef,
      document,
      spinnerService
    );
  }
}
