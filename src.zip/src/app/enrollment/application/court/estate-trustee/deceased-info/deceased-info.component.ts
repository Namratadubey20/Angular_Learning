import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DateValidators } from 'src/app/common/validators/date-validators';

@Component({
  selector: 'app-deceased-info',
  templateUrl: './deceased-info.component.html',
  styleUrls: ['./deceased-info.component.css'],
})
export class DeceasedInfoComponent implements OnInit {

  @Input()
  deceasedInfoFormGroup: FormGroup;

  today: Date = new Date();
  dateValidators = [DateValidators.datePatternValidator()];

  constructor() { }

  ngOnInit() {
  }

  get name(): FormControl {
    return this.deceasedInfoFormGroup.get('name') as FormControl;
  }

  get relationship(): FormControl {
    return this.deceasedInfoFormGroup.get('relationship') as FormControl;
  }

  get date(): FormControl {
    return this.deceasedInfoFormGroup.get('date') as FormControl;
  }

}
