import { AbstractFormArrayMapper } from '../../common/abstract-form-array-mapper.service';
import { EstateTrusteeApplicationImpl } from '../model/estate-trustee-application';
import { Injectable } from '@angular/core';
import { Address, AddressImpl } from '../model/common/address';
import { DeceasedInfo, DeceasedInfoImpl } from '../model/common/deceased-info';
import { ServiceProviderImpl } from '../model/common/service-provider';
import { BankInfo, BankInfoImpl } from '../model/common/bank-info';
import { DebtorInterestedPartyImpl } from '../model/common/debtor-interested-party';
import { DeliveryMethodImpl } from '../model/common/delivery-method';
import * as moment from 'moment';
import { PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';

@Injectable()
export class EstateTrusteeFormArrayMapper extends AbstractFormArrayMapper {

  constructor() {
    super();
  }

  public formArrayJsonToObject(formArrayJson: any): EstateTrusteeApplicationImpl {
    const application: EstateTrusteeApplicationImpl = new EstateTrusteeApplicationImpl();
    const [
      preliminaryQuestions,
      bondDetails,
      deliveryAndPaymentInformation,
      termsAndConditions,
    ] = formArrayJson;

    // Page 1: Knockout questions and Applicant info
    application.applicantEmail = preliminaryQuestions.applicantInfo.applicantEmail;
    application.applicantId = preliminaryQuestions.applicantInfo.applicantId;
    application.applicantPhone = preliminaryQuestions.applicantInfo.applicantPhone;
    application.applicantName = preliminaryQuestions.applicantInfo.applicantName;
    application.applicantSalutation = preliminaryQuestions.applicantInfo.applicantSalutation;
    application.applicantSuffix = preliminaryQuestions.applicantInfo.applicantSuffix;
    application.applicantFax = preliminaryQuestions.applicantInfo.applicantFax;
    application.applicantAddress.street1 =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.street1 : null;
    application.applicantAddress.street2 =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.street2 : null;
    application.applicantAddress.city =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.city : null;
    application.applicantAddress.state =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.state : null;
    application.applicantAddress.zipCode =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.zipCode : null;
    application.premiumRateId = preliminaryQuestions.premiumRateId;
    application.knockedOut = preliminaryQuestions.knockedOut;
    application.knockoutQuestions.push(
      // this.createDynamicQuestionForField('guiltyOfCrime', preliminaryQuestions.knockoutQuestions.guiltyOfCrime),
      // this.createDynamicQuestionForField('judgment', preliminaryQuestions.knockoutQuestions.judgment),
      // this.createDynamicQuestionForField('bankruptcy', preliminaryQuestions.knockoutQuestions.bankruptcy),
      // this.createDynamicQuestionForField('priorBondOrSuccessor', preliminaryQuestions.knockoutQuestions.priorBondOrSuccessor),
      // this.createDynamicQuestionForField('interestedParty', preliminaryQuestions.knockoutQuestions.interestedParty),
      // this.createDynamicQuestionForField('objectionToAppointment', preliminaryQuestions.knockoutQuestions.objectionToAppointment),
      // this.createDynamicQuestionForField('indebtedToSubject', preliminaryQuestions.knockoutQuestions.indebtedToSubject),
      // this.createDynamicQuestionForField('knowledgeOfGrounds', preliminaryQuestions.knockoutQuestions.knowledgeOfGrounds)
    );

    // application.creditScoreSatisfactory = preliminaryQuestions.creditScoreSatisfactory;
    // application.applicantSSNum = preliminaryQuestions.applicantSSNum;
    // application.creditCheckAuthorized = preliminaryQuestions.creditCheckAuthorized;
    // application.creditCheckEmail =
    //   preliminaryQuestions.creditCheckSignatures ? preliminaryQuestions.creditCheckSignatures.emailSignature : null;
    // application.creditCheckSignature =
    //   preliminaryQuestions.applicantInfo.applicantName;

    // Page 2: Bond Details
    // application.serviceProvided = bondDetails.serviceProvided;
    // for (const serviceProvider of bondDetails.serviceProviders) {
    //   const serviceProviderImpl: ServiceProviderImpl = new ServiceProviderImpl();
    //   serviceProviderImpl.name = serviceProvider.name;
    //   serviceProviderImpl.email = serviceProvider.email;
    //   serviceProviderImpl.phone = serviceProvider.phone;
    //   serviceProviderImpl.address.street1 = serviceProvider.address.street1;
    //   serviceProviderImpl.address.street2 = serviceProvider.address.street2;
    //   serviceProviderImpl.address.city = serviceProvider.address.city;
    //   serviceProviderImpl.address.state = serviceProvider.address.state;
    //   serviceProviderImpl.address.zipCode = serviceProvider.address.zipCode;
    //   application.serviceProviders.push(serviceProviderImpl);
    // }
    // application.hasAttorney = bondDetails.hasAttorney;
    // application.attorneyInvolved = bondDetails.attorneyInvolved;
    // application.attorneyName = bondDetails.attorneyName;
    // application.attorneyFirm = bondDetails.attorneyFirm;
    // application.attorneyPhone = bondDetails.attorneyPhone;
    // application.attorneyEmail = bondDetails.attorneyEmail;
    // application.attorneyAddress.street1 = bondDetails.attorneyAddress.street1;
    // application.attorneyAddress.street2 = bondDetails.attorneyAddress.street2;
    // application.attorneyAddress.city = bondDetails.attorneyAddress.city;
    // application.attorneyAddress.state = bondDetails.attorneyAddress.state;
    // application.attorneyAddress.zipCode = bondDetails.attorneyAddress.zipCode;
    // application.ongoingBusiness = bondDetails.ongoingBusiness;
    // application.nonRenewed = bondDetails.nonRenewed;
    application.occupation = bondDetails.occupation;
    application.annualIncome = bondDetails.annualIncome;
    application.maritalStatus = bondDetails.maritalStatus;
    application.applicantSpouse = bondDetails.applicantSpouse;

    application.court.caseNumber = bondDetails.courtInformation.caseNumber;
    application.court.courtName = bondDetails.courtInformation.courtName;
    application.court.presidingJudge = bondDetails.courtInformation.presidingJudge;
    application.court.courtCounty = bondDetails.courtInformation.courtCounty;
    application.court.courtPhone = bondDetails.courtInformation.courtPhone;
    application.court.address.street1 = bondDetails.courtInformation.address.street1;
    application.court.address.street2 = bondDetails.courtInformation.address.street2;
    application.court.address.city = bondDetails.courtInformation.address.city;
    application.court.address.state = bondDetails.courtInformation.address.state;
    application.court.address.zipCode = bondDetails.courtInformation.address.zipCode;

    application.appointmentDate = bondDetails.appointment.appointmentDate;
    application.futureAppointmentWillNotify = bondDetails.appointment.futureAppointmentWillNotify;
    application.fiduciaryType = bondDetails.fiduciaryType;
    application.otherFiduciaryType = bondDetails.otherFiduciaryType;
    application.appointmentType = bondDetails.appointmentType;
    application.deceasedInfo = toDeceasedInfoImpl(bondDetails.deceasedInfo);
    // application.bondPurpose = bondDetails.bondPurpose;

    // Page 3: Payment and Delivery
    // application.specialBondForm = deliveryAndPaymentInformation.specialBondForm;
    // application.specialBondUpload = deliveryAndPaymentInformation.specialBondUpload;
    // application.specialBondFile.id = deliveryAndPaymentInformation.specialBondFile.id;
    // application.specialBondFile.name = deliveryAndPaymentInformation.specialBondFile.name;
    application.uploadCourtOrder = deliveryAndPaymentInformation.uploadCourtOrder;
    application.courtOrderFile.id = deliveryAndPaymentInformation.courtOrderFile.id;
    application.courtOrderFile.name = deliveryAndPaymentInformation.courtOrderFile.name;
    // application.will = deliveryAndPaymentInformation.will;
    // application.willContested = deliveryAndPaymentInformation.willContested;
    // application.willContestedExplanation = deliveryAndPaymentInformation.willContestedExplanation;
    // application.principalBeneficiary = deliveryAndPaymentInformation.principalBeneficiary;
    // application.otherBeneficiaries = deliveryAndPaymentInformation.otherBeneficiaries;
    for (const debtorInterestedParty of deliveryAndPaymentInformation.debtorInterestedParties) {
      const debtorInterestedPartyImpl = new DebtorInterestedPartyImpl();
      debtorInterestedPartyImpl.name = debtorInterestedParty.name;
      if (debtorInterestedParty.age) {
        debtorInterestedPartyImpl.age = +debtorInterestedParty.age;
      }
      debtorInterestedPartyImpl.relationship = debtorInterestedParty.relationship;
      debtorInterestedPartyImpl.address.street1 = debtorInterestedParty.address.street1;
      debtorInterestedPartyImpl.address.street2 = debtorInterestedParty.address.street2;
      debtorInterestedPartyImpl.address.city = debtorInterestedParty.address.city;
      debtorInterestedPartyImpl.address.state = debtorInterestedParty.address.state;
      debtorInterestedPartyImpl.address.zipCode = debtorInterestedParty.address.zipCode;
      application.debtorInterestedParties.push(debtorInterestedPartyImpl);
    }

    application.estateCash = deliveryAndPaymentInformation.estateCash;
    application.estateRealEstate = deliveryAndPaymentInformation.estateRealEstate;
    application.estateSecurities = deliveryAndPaymentInformation.estateSecurities;
    application.estateMisc = deliveryAndPaymentInformation.estateMisc;
    for (const bankInfo of deliveryAndPaymentInformation.bankInfoList) {
      const bankInfoImpl: BankInfoImpl = new BankInfoImpl();
      bankInfoImpl.name = bankInfo.name;
      bankInfoImpl.funds = bankInfo.funds;
      bankInfoImpl.address.street1 = bankInfo.address.street1;
      bankInfoImpl.address.street2 = bankInfo.address.street2;
      bankInfoImpl.address.city = bankInfo.address.city;
      bankInfoImpl.address.state = bankInfo.address.state;
      bankInfoImpl.address.zipCode = bankInfo.address.zipCode;
      application.banks.push(bankInfoImpl);
    }

    // Delivery Method
    application.deliveryMethod = new DeliveryMethodImpl();
    this.populateDeliveryMethod(application.deliveryMethod, deliveryAndPaymentInformation.delivery);

    // Payment Method will already have been converted to an instance of PaymentMethod via PaymentMethodSelectionFormGroup.getRawValue().
    application.paymentMethod = deliveryAndPaymentInformation[PAYMENT_INFORMATION_FORM_GROUP_NAME];

    // Terms and Conditions
    application.termsAndConditions.readAndAgreeToTerms = termsAndConditions.readAndAgreeToTerms;
    application.termsAndConditions.declareTrue = termsAndConditions.declareTrue;
    application.termsAndConditions.agreementDate = moment().toDate();
    application.termsAndConditions.indemnitor = preliminaryQuestions.applicantInfo.applicantName;
    application.termsAndConditions.emailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.emailSignature : null;
    application.termsAndConditions.signatureName = preliminaryQuestions.applicantInfo.applicantName;
    application.termsAndConditions.companyEmailSignature = termsAndConditions.termsSignatures.companyEmailSignature;
    application.termsAndConditions.premiumAcknowledged = termsAndConditions.premiumAcknowledged;

    application.creditScoreSatisfactory = termsAndConditions.creditScoreSatisfactory;
    application.applicantSSNum = termsAndConditions.applicantSSNum;
    application.creditCheckAuthorized = termsAndConditions.creditCheckAuthorized;
    application.creditCheckEmail =
      termsAndConditions.creditCheckSignatures ? termsAndConditions.creditCheckSignatures.emailSignature : null;
    application.creditCheckSignature =
      preliminaryQuestions.applicantInfo.applicantName;
    application.applicantCreditCheckAddress = {
      street1: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street1 : null,
      street2: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street2 : null,
      city: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.city : null,
      state: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.state : null,
      zipCode: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.zipCode : null,
    };
    application.creditCheckAddressSameAsApplicant = termsAndConditions.creditCheckAddressSameAsApplicant;

    return application;
  }

  public objectToFormArrayJson(object: EstateTrusteeApplicationImpl): any {
    return [
      // Page 1: Knockout questions and Applicant info
      {
        applicantInfo: {
          applicantId: object.applicantId,
          applicantName: object.applicantName,
          applicantSalutation: object.applicantSalutation,
          applicantSuffix: object.applicantSuffix,
          applicantEmail: object.applicantEmail,
          applicantFax: object.applicantFax,
          applicantPhone: object.applicantPhone,
          applicantAddress: {
            street1: object.applicantAddress ? object.applicantAddress.street1 : null,
            street2: object.applicantAddress ? object.applicantAddress.street2 : null,
            zipCode: object.applicantAddress ? object.applicantAddress.zipCode : null,
            city: object.applicantAddress ? object.applicantAddress.city : null,
            state: object.applicantAddress ? object.applicantAddress.state : null,
          },
        },
        creditScoreSatisfactory: object.creditScoreSatisfactory,
        premiumRateId: object.premiumRateId,
        knockedOut: object.knockedOut,
        knockoutQuestions: {
          // guiltyOfCrime: this.getValueFromDynamicQuestions('guiltyOfCrime', object.knockoutQuestions),
          // judgment: this.getValueFromDynamicQuestions('judgment', object.knockoutQuestions),
          // bankruptcy: this.getValueFromDynamicQuestions('bankruptcy', object.knockoutQuestions),
          // priorBondOrSuccessor: this.getValueFromDynamicQuestions('priorBondOrSuccessor', object.knockoutQuestions),
          // interestedParty: this.getValueFromDynamicQuestions('interestedParty', object.knockoutQuestions),
          // objectionToAppointment: this.getValueFromDynamicQuestions('objectionToAppointment', object.knockoutQuestions),
          // indebtedToSubject: this.getValueFromDynamicQuestions('indebtedToSubject', object.knockoutQuestions),
          // knowledgeOfGrounds: this.getValueFromDynamicQuestions('knowledgeOfGrounds', object.knockoutQuestions),
        },
        // creditScoreSatisfactory: object.creditScoreSatisfactory,
        // applicantSSNum: object.applicantSSNum,
        // creditCheckAuthorized: object.creditCheckAuthorized,
        // creditCheckSignatures: {
        //   signatureName: object.applicantName,
        //   emailSignature: object.creditCheckEmail,
        // },
      },
      // Page 2: Bond Details
      {
        // serviceProvided: object.serviceProvided,
        // serviceProviders: object.serviceProviders,
        // hasAttorney: object.hasAttorney,
        // attorneyInvolved: object.attorneyInvolved,
        // attorneyName: object.attorneyName,
        // attorneyFirm: object.attorneyFirm,
        // attorneyPhone: object.attorneyPhone,
        // attorneyEmail: object.attorneyEmail,
        // attorneyAddress: {
        //   street1: object.attorneyAddress ? object.attorneyAddress.street1 : null,
        //   street2: object.attorneyAddress ? object.attorneyAddress.street2 : null,
        //   zipCode: object.attorneyAddress ? object.attorneyAddress.zipCode : null,
        //   city: object.attorneyAddress ? object.attorneyAddress.city : null,
        //   state: object.attorneyAddress ? object.attorneyAddress.state : null,
        // },
        // ongoingBusiness: object.ongoingBusiness,
        // nonRenewed: object.nonRenewed,
        occupation: object.occupation,
        annualIncome: object.annualIncome,
        maritalStatus: object.maritalStatus,
        applicantSpouse: object.applicantSpouse,
        courtInformation: {
          caseNumber: object.court ? object.court.caseNumber : null,
          courtName: object.court ? object.court.courtName : null,
          presidingJudge: object.court ? object.court.presidingJudge : null,
          courtCounty: object.court ? object.court.courtCounty : null,
          courtPhone: object.court ? object.court.courtPhone : null,
          address: {
            street1: object.court && object.court.address ? object.court.address.street1 : null,
            street2: object.court && object.court.address ? object.court.address.street2 : null,
            city: object.court && object.court.address ? object.court.address.city : null,
            state: object.court && object.court.address ? object.court.address.state : null,
            zipCode: object.court && object.court.address ? object.court.address.zipCode : null,
          },
        },
        appointment: {
          appointmentDate: object.appointmentDate,
          futureAppointmentWillNotify: object.futureAppointmentWillNotify,
        },
        fiduciaryType: object.fiduciaryType,
        otherFiduciaryType: object.otherFiduciaryType,
        appointmentType: object.appointmentType,
        deceasedInfo: {
          name: object.deceasedInfo ? object.deceasedInfo.name : null,
          relationship: object.deceasedInfo ? object.deceasedInfo.relationship : null,
          date: object.deceasedInfo ? object.deceasedInfo.date : null,
        },
        // bondPurpose: object.bondPurpose,
      },
      // Page 3: Payment Method and Delivery Info
      {
        // specialBondForm: object.specialBondForm,
        // specialBondUpload: object.specialBondUpload,
        // specialBondFile: {
        //   id: object.specialBondFile ? object.specialBondFile.id : null,
        //   name: object.specialBondFile ? object.specialBondFile.name : null,
        // },
        uploadCourtOrder: object.uploadCourtOrder,
        courtOrderFile: {
          id: object.courtOrderFile ? object.courtOrderFile.id : null,
          name: object.courtOrderFile ? object.courtOrderFile.name : null,
        },
        // will: object.will,
        // willContested: object.willContested,
        // willContestedExplanation: object.willContestedExplanation,
        // principalBeneficiary: object.principalBeneficiary,
        // otherBeneficiaries: object.otherBeneficiaries,
        debtorInterestedParties: object.debtorInterestedParties,
        estateCash: object.estateCash,
        estateRealEstate: object.estateRealEstate,
        estateSecurities: object.estateSecurities,
        estateMisc: object.estateMisc,
        bankInfoList: object.banks,
        delivery: this.createDeliveryMethodFormGroupPatchValues(object.deliveryMethod),
        // The Payment FormGroup will generate the patchValues itself from the paymentMethod.
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: object.paymentMethod,
      },
      // Terms and Conditions
      {
        readAndAgreeToTerms: object.termsAndConditions ? object.termsAndConditions.readAndAgreeToTerms : false,
        declareTrue: object.termsAndConditions ? object.termsAndConditions.declareTrue : false,
        agreementDate: object.termsAndConditions ? object.termsAndConditions.agreementDate : null,
        indemnitor: object.applicantName,
        creditScoreSatisfactory: object.creditScoreSatisfactory,
        applicantSSNum: object.applicantSSNum,
        creditCheckAuthorized: object.creditCheckAuthorized,
        creditCheckSignatures: {
          signatureName: object.applicantName,
          emailSignature: object.creditCheckEmail,
        },
        premiumAcknowledged: object.termsAndConditions.premiumAcknowledged,
        termsSignatures: {
          companyEmailSignature: object.termsAndConditions.companyEmailSignature,
          signatureName: object.applicantName,
          emailSignature: object.termsAndConditions.emailSignature,
        },
        applicantCreditCheckAddress: {
          street1: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['street1'] : null,
          street2: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['street2'] : null,
          city: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['city'] : null,
          state: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['state'] : null,
          zipCode: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['zipCode'] : null,
        },
        creditCheckAddressSameAsApplicant: object.creditCheckAddressSameAsApplicant,
      },
    ];
  }
}

function toDeceasedInfoImpl(deceasedInfo: DeceasedInfo): DeceasedInfoImpl {
  const impl = new DeceasedInfoImpl();
  impl.name = deceasedInfo.name;
  impl.relationship = deceasedInfo.relationship;
  impl.date = deceasedInfo.date;
  return impl;
}

function toAddressImpl(address: Address): AddressImpl {
  const impl = new AddressImpl();
  impl.street1 = address.street1;
  impl.street2 = address.street2;
  impl.city = address.city;
  impl.state = address.state;
  impl.zipCode = address.zipCode;
  return impl;
}

function toBankInfoImpl(bankInfo: BankInfo): BankInfoImpl {
  const impl = new BankInfoImpl();
  impl.name = bankInfo.name;
  impl.address = toAddressImpl(bankInfo.address);
  impl.funds = bankInfo.funds;
  return impl;
}
