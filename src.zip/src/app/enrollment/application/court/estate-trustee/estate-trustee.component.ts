import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { ApplicationService } from '../../application.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArrayMapper } from '../../common/form-array-mapper';
import { EstateTrusteeFormArrayMapper } from './estate-trustee-form-array-mapper.service';
import { SecurityService } from '../../../../security/security.service';
import { PatternValidators } from '../../../../common/validators/pattern-validators';
import { CheckboxValidator } from '../../../../common/validators/checkbox-validator';
import { ValueMatchValidator } from '../../../../common/validators/value-match-validator';
import { MultipleFieldValidators } from '../../../../common/validators/multiple-field-validators';
import { ControlValidator } from '../../common/control-validator';
import { ConditionalValidator } from '../../../../common/validators/conditional-validator';
import { CommonUtilities } from '../../../../common/utils/common-utilities';
import { DateValidators } from '../../../../common/validators/date-validators';
import { distinctUntilChanged } from 'rxjs/operators';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { ServiceHandler } from '../../../../common/utils/service-handler.service';
import { KnockoutQuestionsBaseComponent } from '../../common/knockout-questions-base.component';
import { GoogleTagManagerService } from '../../../../common/services/google-tag-manager.service';
import { PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';
import { ApplicationRoleService } from '../../../../common/services/application-role-service';
import { MatDialog } from '@angular/material';
import { FiduciaryBondComponent } from '../../common/fiduciary-bond.component';
import { CourtBondType, isFiduciaryBondType } from '../../common/bond-types';
import { PersonService } from '../../../../common/person-service';
import { DOCUMENT } from '@angular/common';
import { Inject, ElementRef, OnInit } from '@angular/core';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

export abstract class EstateTrusteeComponent
  extends KnockoutQuestionsBaseComponent
  implements FiduciaryBondComponent {
  stepperFormArray: FormArray;
  creditCheckWasRequired: boolean;
  protected constructor(
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    bondType: CourtBondType,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      new EstateTrusteeFormArrayMapper(),
      applicationService,
      securityService,
      activatedRoute,
      router,
      bondType,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      elementRef,
      document,
      spinnerService
    );
  }

  // Poor man's TypeScript ”instanceof Interface” type check…
  get instanceofFiduciaryBondComponent(): boolean {
    return isFiduciaryBondType(this.bondType);
  }

  fiduciaryObligeeStateSelectorControl(): FormControl {
    return this.stepperFormArray
      .at(1)
      .get('courtInformation.address.state') as FormControl;
  }

  // specialBondFormControl(): FormControl {
  //   return this.stepperFormArray.at(2).get('specialBondForm') as FormControl;
  // }

  createNewApplication() {
    this.stepperFormArray = new FormArray([
      // Page 1: Knockout questions and Applicant info
      new FormGroup(
        {
          applicantInfo: new FormGroup({
            applicantId: new FormControl(null),
            applicantName: new FormControl(null),
            applicantSalutation: new FormControl(null),
            applicantSuffix: new FormControl(null),
            applicantOfficePerson: new FormControl(null),
            applicantPhone: new FormControl(null),
            applicantFax: new FormControl(null),
            applicantEmail: new FormControl(null),
            applicantWebsite: new FormControl(null),
            applicantAddress: this.createApplicantAddressFormGroup(),
          }),
          knockedOut: new FormControl(null),
          knockoutQuestions: new FormGroup({
            // guiltyOfCrime: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }, this.requiredIfNotAgent),
            // judgment: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }, this.requiredIfNotAgent),
            // bankruptcy: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }, this.requiredIfNotAgent),
            // priorBondOrSuccessor: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
            //   this.requiredIfNotAgent),
            // interestedParty: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }, this.requiredIfNotAgent),
            // objectionToAppointment: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
            //   this.requiredIfNotAgent),
            // indebtedToSubject: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }, this.requiredIfNotAgent),
            // knowledgeOfGrounds: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }, this.requiredIfNotAgent),
          }),
          // creditScoreSatisfactory: new FormControl(null),
          // applicantSSNum: new FormControl({
          //   value: null,
          //   disabled: this.isSteward,
          // }),
          // creditCheckAuthorized: new FormControl(
          //   { value: false, disabled: this.isSteward },
          //   CheckboxValidator.requireTrue()
          // ),
          // creditCheckSignatures: new FormGroup({
          //   signatureName: new FormControl({ disabled: true, value: null }),
          //   emailSignature: new FormControl(
          //     { value: null, disabled: this.isSteward },
          //     [this.requiredIfNotAgent, PatternValidators.email()]
          //   ),
          // }),
        }
        // {
        //   validators: [
        //     ValueMatchValidator.matchingValues(
        //       'applicantInfo.applicantEmail',
        //       'creditCheckSignatures.emailSignature',
        //       false,
        //       true
        //     ),
        //   ],
        // }
      ),
      // Page 2: Bond Details
      new FormGroup({
        // serviceProvided: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // serviceProviders: new FormArray([]),
        // hasAttorney: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // attorneyInvolved: new FormControl({ value: null, disabled: this.isEmployee }),
        // attorneyName: new FormControl({ value: null, disabled: this.isEmployee }),
        // attorneyFirm: new FormControl({ value: null, disabled: this.isEmployee }, Validators.maxLength(60)),
        // attorneyPhone: new FormControl({ value: null, disabled: this.isEmployee }, PatternValidators.phoneNumber()),
        // attorneyEmail: new FormControl(),
        // attorneyAddress: this.createOptionalAddressFormGroup(this.isEmployee),
        // nonRenewed: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // ongoingBusiness: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        occupation: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        annualIncome: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        maritalStatus: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        applicantSpouse: new FormControl({
          value: null,
          disabled: this.isEmployee,
        }),
        courtInformation: new FormGroup({
          caseNumber: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtName: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          presidingJudge: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtCounty: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtPhone: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          address: this.createApplicationAddressFormGroup(),
        }),
        appointment: new FormGroup(
          {
            appointmentDate: new FormControl({
              value: null,
              disabled: this.isEmployee,
            }),
            futureAppointmentWillNotify: new FormControl({
              value: null,
              disabled: this.isEmployee,
            }),
          },
          {
            validators: [
              ConditionalValidator.conditionalValidator(
                () => !this.isSteward,
                MultipleFieldValidators.exactlyOneRequired([
                  'appointmentDate',
                  'futureAppointmentWillNotify',
                ])
              ),
            ],
          }
        ),
        fiduciaryType: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        otherFiduciaryType: new FormControl({
          value: null,
          disabled: this.isEmployee,
        }),
        appointmentType: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        deceasedInfo: new FormGroup({
          name: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          relationship: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          date: new FormControl({ value: null, disabled: this.isEmployee }, [
            DateValidators.onOrBeforeToday(),
            this.requiredIfNotAgent,
          ]),
        }),
        // bondPurpose: new FormControl({ value: null, disabled: this.isEmployee }, [Validators.maxLength(250), this.requiredIfNotAgent]),
      }),
      // Delivery and Payment Information
      new FormGroup({
        // specialBondForm: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // specialBondUpload: new FormControl({ value: null, disabled: this.isEmployee }),
        // specialBondFile: new FormGroup({
        //   id: new FormControl(null),
        //   name: new FormControl(null),
        // }),
        uploadCourtOrder: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        courtOrderFile: new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null),
        }),
        // will: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // willContested: new FormControl({ value: null, disabled: this.isEmployee }),
        // willContestedExplanation: new FormControl({ value: null, disabled: this.isEmployee }),
        // principalBeneficiary: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // otherBeneficiaries: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        debtorInterestedParties: new FormArray([]),
        estateCash: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        estateRealEstate: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        estateSecurities: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        estateMisc: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        bankInfoList: new FormArray([]),
        delivery: this.createDeliveryInformationFormGroup(),
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: this.createPaymentInformationFormGroup(),
      }),
      // Terms and Conditions
      new FormGroup(
        {
          readAndAgreeToTerms: new FormControl(
            { value: false, disabled: this.isSteward || this.isEmployee },
            CheckboxValidator.requireTrue()
          ),
          declareTrue: new FormControl({
            value: false,
            disabled: this.isSteward || this.isEmployee,
          }),
          premiumAcknowledged: new FormControl(
            { value: false, disabled: this.isSteward || this.isEmployee },
            CheckboxValidator.requireTrue()
          ),
          agreementDate: new FormControl({ value: null, disabled: true }),
          indemnitor: new FormControl(null),
          creditScoreSatisfactory: new FormControl(null),
          applicantSSNum: new FormControl({
            value: null,
            disabled: this.isSteward,
          }),
          creditCheckAuthorized: new FormControl(
            { value: false, disabled: this.isSteward }
            // CheckboxValidator.requireTrue()
          ),
          // creditCheckSignatures: new FormGroup({
          //   signatureName: new FormControl({ disabled: true, value: null }),
          //   emailSignature: new FormControl(
          //     { value: null, disabled: this.isSteward },
          //     [this.requiredIfNotAgent, PatternValidators.email()]
          //   ),
          // }),
          termsSignatures: new FormGroup({
            signatureName: new FormControl({ disabled: true, value: null }),
            emailSignature: new FormControl(
              { value: null, disabled: this.isSteward || this.isEmployee },
              [this.requiredIfNotAgent, PatternValidators.email()]
            ),
            companyEmailSignature: new FormControl(
              { value: null, disabled: this.isSteward || this.isEmployee },
              [this.requiredIfCompanyAndNotAgent, PatternValidators.email()]
            ),
          }),
          applicantCreditCheckAddress: new FormGroup({
            street1: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
            street2: new FormControl({ value: null, disabled: this.isEmployee }),
            city: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
            state: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
            zipCode: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
          }),
          creditCheckAddressSameAsApplicant: new FormControl(
            { value: false, disabled: this.isSteward || this.isEmployee }
          ),
        },
        {
          validators: [
            ValueMatchValidator.matchValueToField(
              this.application.data.applicantEmail,
              'termsSignatures.emailSignature',
              false,
              true
            ),
          ],
        }
      ),
    ]);
    this.addConditionalValidation();

    this.registerFileUploadControls();
    this.clearValues();
  }

  otherPrequalificationPageFormFields(): FormControl[] {
    return [
      // this.applicantSSNum,
      // this.creditCheckAuthorization,
      // this.creditCheckEmailSignature,
    ];
  }

  private notSteward(): () => boolean {
    return () => !this.isSteward;
  }

  private notStewardAnd(condFn: () => boolean): () => boolean {
    return () => !this.isSteward && condFn();
  }

  private isSetAndNotEqualTo(value: any, control: FormControl): () => boolean {
    return () => !!control.value && control.value !== value;
  }

  clearValues() {
    // if (this.serviceProvided) {
    //   this.serviceProvided
    //     .valueChanges
    //     .pipe(distinctUntilChanged())
    //     .subscribe(b => {
    //       if (!b) {
    //         while (this.serviceProvidersFormArray.length !== 0) {
    //           this.serviceProvidersFormArray.removeAt(0);
    //         }
    //       }
    //     });
    // }
    // if (this.hasAttorney) {
    //   this.hasAttorney
    //     .valueChanges
    //     .pipe(distinctUntilChanged())
    //     .subscribe(b => {
    //       if (b) {
    //         this.attorneyInvolved.setValue(null);
    //         this.attorneyName.setValue('');
    //         this.attorneyFirm.setValue('');
    //         this.attorneyPhone.setValue('');
    //         this.attorneyAddress.get('street1').setValue('');
    //         this.attorneyAddress.get('street2').setValue('');
    //         this.attorneyAddress.get('city').setValue('');
    //         this.attorneyAddress.get('state').setValue('');
    //         this.attorneyAddress.get('zipCode').setValue('');
    //       }
    //     });
    // }
  }

  /**
   * Indicate that the various file uploads should be managed wrt/ 'obsolete' uploaded files
   * if the FileUploadMode is no longer fileUpload.
   */
  private registerFileUploadControls() {
    // this.registerFileTypeFileUploadActiveSubject('specialBondFile', this.specialBondFile);
    this.registerFileTypeFileUploadActiveSubject(
      'courtOrderFile',
      this.courtOrderFile
    );
  }

  addConditionalValidation(): void {
    // If hasAttorney is true then the attorney information is required
    // const attorneyInvolvedCondition = this.notStewardAnd(() => this.hasAttorney.value);
    // this.setConditionalValidators([
    //   {
    //     formControl: this.attorneyInvolved,
    //     validators: [ConditionalValidator.conditionalRequire(attorneyInvolvedCondition)],
    //   },
    //   {
    //     formControl: this.attorneyName,
    //     validators: [ConditionalValidator.conditionalRequire(attorneyInvolvedCondition)],
    //   },
    //   {
    //     formControl: this.attorneyPhone,
    //     validators: [PatternValidators.phoneNumber(), ConditionalValidator.conditionalRequire(attorneyInvolvedCondition)],
    //   },
    //   {
    //     formControl: this.attorneyAddress.get('street1'),
    //     validators: [Validators.maxLength(60), ConditionalValidator.conditionalRequire(attorneyInvolvedCondition)],
    //   },
    //   {
    //     formControl: this.attorneyAddress.get('city'),
    //     validators: [Validators.maxLength(30), ConditionalValidator.conditionalRequire(attorneyInvolvedCondition)],
    //   },
    //   {
    //     formControl: this.attorneyAddress.get('state'),
    //     validators: [ConditionalValidator.conditionalRequire(attorneyInvolvedCondition)],
    //   },
    //   {
    //     formControl: this.attorneyAddress.get('zipCode'),
    //     validators: [PatternValidators.zipCode(), ConditionalValidator.conditionalRequire(attorneyInvolvedCondition)],
    //   },
    // ] as ControlValidator[]);
    // this.updateOnChangeEvents(this.hasAttorney, [
    //   this.attorneyInvolved,
    //   this.attorneyName,
    //   this.attorneyPhone,
    //   this.attorneyAddress.get('street1') as FormControl,
    //   this.attorneyAddress.get('city') as FormControl,
    //   this.attorneyAddress.get('state') as FormControl,
    //   this.attorneyAddress.get('zipCode') as FormControl,
    // ]);

    // spouse name is required if the person is married
    const isMarriedCondition = this.notStewardAnd(
      () => this.maritalStatus.value === 'Married'
    );
    this.setConditionalValidator(
      this.applicantSpouse,
      ConditionalValidator.conditionalRequire(isMarriedCondition)
    );
    this.updateOnChangeEvents(this.maritalStatus, this.applicantSpouse);

    // court order is required if the user selects upload
    const uploadCourtOrderCondition = this.notStewardAnd(
      () => this.uploadCourtOrder.value
    );
    this.setConditionalValidators([
      {
        formControl: this.courtOrderFile.get('id') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(uploadCourtOrderCondition),
        ],
      },
      {
        formControl: this.courtOrderFile.get('name') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(uploadCourtOrderCondition),
        ],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.uploadCourtOrder, [
      this.courtOrderFile.get('id') as FormControl,
      this.courtOrderFile.get('name') as FormControl,
    ]);

    // will contested is required if there is a will
    // const willContestedCondition = this.notStewardAnd(() => this.will.value === true);
    // this.setConditionalValidator(this.willContested, ConditionalValidator.conditionalRequire(willContestedCondition));
    // this.updateOnChangeEvents(this.will, this.willContested);

    // will contested explanation required if the will is contested
    // const willContestedExplanationCondition = this.notStewardAnd(() => this.willContested.value === true);
    // this.setConditionalValidator(this.willContestedExplanation,
    //   [ConditionalValidator.conditionalRequire(willContestedExplanationCondition), Validators.maxLength(250)]);
    // this.updateOnChangeEvents(this.willContested, this.willContestedExplanation);
    // otherFiduciaryType details is required if FiduciaryType is 'other'
    const isOtherFiduciaryTypeCondition = this.notStewardAnd(
      () => this.fiduciaryType.value === 'Other'
    );
    this.setConditionalValidator(
      this.otherFiduciaryType,
      ConditionalValidator.conditionalRequire(isOtherFiduciaryTypeCondition)
    );
    this.updateOnChangeEvents(this.fiduciaryType, this.otherFiduciaryType);

    // special bond upload is required if special bond form is true
    // const specialBondUploadCondition = this.notStewardAnd(() => this.specialBondForm.value);
    // this.setConditionalValidator(this.specialBondUpload, ConditionalValidator.conditionalRequire(specialBondUploadCondition));
    // this.updateOnChangeEvents(this.specialBondForm, this.specialBondUpload);
    // this.setConditionalValidators([
    //   {
    //     formControl: this.specialBondFile.get('id') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(this.notStewardAnd(() => this.specialBondUpload.value))],
    //   },
    //   {
    //     formControl: this.specialBondFile.get('name') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(this.notStewardAnd(() => this.specialBondUpload.value))],
    //   },
    // ] as ControlValidator[]);

    // delivery method conditional validation
    const deliveryMethodSetAndIsNotEmailCondition = this.notStewardAnd(
      this.isSetAndNotEqualTo('Email', this.deliveryMethod)
    );

    this.setConditionalValidators([
      {
        formControl: this.deliveryName,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
        ],
      },
      {
        formControl: this.deliveryPhone,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
        ],
      },
      {
        formControl: this.deliveryAddressStreet1,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
          Validators.maxLength(60),
        ],
      },
      {
        formControl: this.deliveryAddressZipCode,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
          PatternValidators.zipCode(),
        ],
      },
      {
        formControl: this.deliveryAddressCity,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
          Validators.maxLength(30),
        ],
      },
      {
        formControl: this.deliveryAddressState,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
        ],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.deliveryMethod, [
      this.deliveryName,
      this.deliveryPhone,
      this.deliveryAddressStreet1,
      this.deliveryAddressZipCode,
      this.deliveryAddressCity,
      this.deliveryAddressState,
    ]);
  }

  patchValueForSsnAddress() {
    const updatedApplicantForm = this.preliminaryQuestionsFormGroup.controls['applicantInfo'];
    const ssnAddressUpdate = this.stepperFormArray.controls[3];
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.patchValue({
      street1: updatedApplicantForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedApplicantForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedApplicantForm['controls'].applicantAddress['controls'].city.value,
      state: updatedApplicantForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedApplicantForm['controls'].applicantAddress['controls'].zipCode.value,
    });
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street1').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street2').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('city').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('state').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('zipCode').disable();
  }

  patchValueForBillingAddress() {
    const updatedBillingForm = this.preliminaryQuestionsFormGroup.controls['applicantInfo'];
    const updatedDeliveryAddress: FormGroup = this.stepperFormArray.controls[2]['controls'].delivery.controls.deliveryAddress;
    const updatedBillingAddress: FormGroup = this.stepperFormArray.controls[2]['controls'].paymentInformation.controls.billingAddressGroup;
    updatedBillingAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
    updatedDeliveryAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
  }

  async stepSelectionChange(event: StepperSelectionEvent) {
    this.validatePage(event.selectedIndex);
    if (event.selectedIndex === 3) {
      this.patchValueForSsnAddress();
    }
    if (event.selectedIndex === 2) {
      this.patchValueForBillingAddress();
    }
    // knockout question page change is different from the rest
    if (event.previouslySelectedIndex === 0 && event.selectedIndex === 1) {
      if (this.preliminaryQuestionsFormGroup.valid || this.isSteward) {
        if (this.creditCheckWasRequired) {
          await this.saveApplication('Saving Form...');
          this.creditCheckWasRequired = false;
        } else {
          await this.saveApplication('Saving Form...');
        }
        // this.applicantSSNum.clearValidators();
        this.applicantSSNum.updateValueAndValidity();
        this.creditCheckAuthorization.clearValidators();
        this.creditCheckAuthorization.updateValueAndValidity();
      }

      // ... and mark all of the formControls as touched to 'activate' the validators.
      // Many of the validators are inactive until the controls have been 'touched'.
      CommonUtilities.markAllTouched(this.preliminaryQuestionsFormGroup);
    } else {
      await super.stepSelectionChange(event);
    }
    this.sendCourtBondsAppStepEvent(event);
  }

  sendCourtBondsAppStepEvent(event: StepperSelectionEvent) {
    this.determineTypeOfClient();
    const user = this.securityService.user;
    const userType = user
      ? user.hasAttorneyRole
        ? 'attorney'
        : user.userRoles[0].userRoleRef.role
      : 'anonymous';
    const paymentType = this.application['data'].paymentMethod.paymentChannelCode ?
      this.application['data'].paymentMethod.paymentChannelCode.cardValidatorType : '';
    if (event.selectedIndex === 1) {
      this.bondDetailsPageGtmEvent(
        'court-bond-app-details1',
        this.bondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    } else if (event.selectedIndex === 2) {
      this.PageGtmEvent(
        'court-bond-app-delivery',
        this.bondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    } else if (event.selectedIndex === 3) {
      this.termsAndConditionEvent(
        'court-bond-app-terms',
        this.bondType,
        this.application.premium,
        userType,
        '',
        '',
        this.application.quoteId,
        'new',
        this.application.id,
        paymentType
      );
    }

  }

  creditCheckIsRequiredHandler(event) {
    this.creditCheckWasRequired = event;
  }

  get formArrayMapper(): FormArrayMapper[] {
    // const serviceProviderCondition = this.notSteward();
    const bankInfoCondition = this.notSteward();
    const otherBeneficiariesCondition = this.notSteward();

    return [
      {} as FormArrayMapper, {},
      // {
      //   'serviceProviders': new FormGroup({
      //     name: new FormControl({ value: null, disabled: this.isEmployee },
      //       ConditionalValidator.conditionalRequire(serviceProviderCondition)),
      //     phone: new FormControl({ value: null, disabled: this.isEmployee },
      //       ConditionalValidator.conditionalRequire(serviceProviderCondition)),
      //     email: new FormControl({ value: null, disabled: this.isEmployee },
      //       ConditionalValidator.conditionalRequire(serviceProviderCondition)),
      //     address: this.createRequiredAddressFormGroup(this.isEmployee
      //       , ConditionalValidator.conditionalRequire(serviceProviderCondition)),
      //   }),
      // } as FormArrayMapper,
      {
        'bankInfoList': new FormGroup({
          name: new FormControl(
            { value: null, disabled: this.isEmployee },
            ConditionalValidator.conditionalRequire(bankInfoCondition)
          ),
          funds: new FormControl(
            { value: null, disabled: this.isEmployee },
            ConditionalValidator.conditionalRequire(bankInfoCondition)
          ),
          address: this.createRequiredAddressFormGroup(
            this.isEmployee,
            ConditionalValidator.conditionalRequire(bankInfoCondition)
          ),
        }),
        'debtorInterestedParties': new FormGroup({
          name: new FormControl(
            { value: null, disabled: this.isEmployee },
            ConditionalValidator.conditionalRequire(otherBeneficiariesCondition)
          ),
          age: new FormControl({ value: null, disabled: this.isEmployee }, [
            Validators.min(0),
            ConditionalValidator.conditionalRequire(
              otherBeneficiariesCondition
            ),
          ]),
          relationship: new FormControl(
            { value: null, disabled: this.isEmployee },
            ConditionalValidator.conditionalRequire(otherBeneficiariesCondition)
          ),
          address: this.createRequiredAddressFormGroup(
            this.isEmployee,
            ConditionalValidator.conditionalRequire(otherBeneficiariesCondition)
          ),
        }),
      } as FormArrayMapper,
    ];
  }

  disableFormArrayInputs() {
    if (this.isEmployee) {
      // this.serviceProvidersFormArray.controls.forEach((group: FormGroup) => {
      //   group.disable();
      // });
      this.bankListFormArray.controls.forEach((group: FormGroup) => {
        group.disable();
      });
      this.debtorInterestedParties.controls.forEach((group: FormGroup) => {
        group.disable();
      });
    }
  }

  // region Step Controls
  get preliminaryQuestionsFormGroup(): FormGroup {
    return this.stepperFormArray.at(0) as FormGroup;
  }

  get knockoutQuestionFormGroup(): FormGroup {
    return this.preliminaryQuestionsFormGroup.get(
      'knockoutQuestions'
    ) as FormGroup;
  }

  get bondDetailsFormGroup(): FormGroup {
    return this.stepperFormArray.at(1) as FormGroup;
  }

  get deliveryAndPaymentInformationFormGroup(): FormGroup {
    return this.stepperFormArray.at(2) as FormGroup;
  }

  get termsAndConditionsFormGroup(): FormGroup {
    return this.stepperFormArray.at(3) as FormGroup;
  }

  get termsSignaturesFormGroup(): FormGroup {
    return this.termsAndConditionsFormGroup.get('termsSignatures') as FormGroup;
  }

  get emailSignature(): FormControl {
    return this.termsSignaturesFormGroup.get('emailSignature') as FormControl;
  }

  // get signatureName(): FormControl {
  //   return this.creditCheckSignatureFormGroup.get('signatureName') as FormControl;
  // }

  // endregion

  // region Preliminary Questions: Form Controls
  get applicantInfoFormGroup(): FormGroup {
    return this.preliminaryQuestionsFormGroup.get('applicantInfo') as FormGroup;
  }

  get applicantSSNum(): FormControl {
    return this.termsAndConditionsFormGroup.get(
      'applicantSSNum'
    ) as FormControl;
  }

  // get creditCheckSignatureFormGroup(): FormGroup {
  //   return this.termsAndConditionsFormGroup.get(
  //     'creditCheckSignatures'
  //   ) as FormGroup;
  // }

  get creditCheckAuthorization(): FormControl {
    return this.termsAndConditionsFormGroup.get(
      'creditCheckAuthorized'
    ) as FormControl;
  }

  get creditCheckEmailSignature(): FormControl {
    return this.termsAndConditionsFormGroup.get(
      'emailSignature'
    ) as FormControl;
  }

  // endregion

  // region Bond Details: Form Controls
  // get serviceProvided(): FormControl {
  //   return this.bondDetailsFormGroup.get('serviceProvided') as FormControl;
  // }

  // get serviceProvidersFormArray(): FormArray {
  //   return this.bondDetailsFormGroup.get('serviceProviders') as FormArray;
  // }

  // get hasAttorney(): FormControl {
  //   return this.bondDetailsFormGroup.get('hasAttorney') as FormControl;
  // }

  // get attorneyInvolved(): FormControl {
  //   return this.bondDetailsFormGroup.get('attorneyInvolved') as FormControl;
  // }

  // get attorneyName(): FormControl {
  //   return this.bondDetailsFormGroup.get('attorneyName') as FormControl;
  // }

  // get attorneyFirm(): FormControl {
  //   return this.bondDetailsFormGroup.get('attorneyFirm') as FormControl;
  // }

  // get attorneyPhone(): FormControl {
  //   return this.bondDetailsFormGroup.get('attorneyPhone') as FormControl;
  // }

  // get attorneyAddress(): FormGroup {
  //   return this.bondDetailsFormGroup.get('attorneyAddress') as FormGroup;
  // }

  // get nonRenewed(): FormControl {
  //   return this.bondDetailsFormGroup.get('nonRenewed') as FormControl;
  // }

  // get ongoingBusiness(): FormControl {
  //   return this.bondDetailsFormGroup.get('ongoingBusiness') as FormControl;
  // }

  get occupation(): FormControl {
    return this.bondDetailsFormGroup.get('occupation') as FormControl;
  }

  get annualIncome(): FormControl {
    return this.bondDetailsFormGroup.get('annualIncome') as FormControl;
  }

  get maritalStatus(): FormControl {
    return this.bondDetailsFormGroup.get('maritalStatus') as FormControl;
  }

  get applicantSpouse(): FormControl {
    return this.bondDetailsFormGroup.get('applicantSpouse') as FormControl;
  }

  get courtInformationFormGroup(): FormGroup {
    return this.bondDetailsFormGroup.get('courtInformation') as FormGroup;
  }

  get appointmentFormGroup(): FormGroup {
    return this.bondDetailsFormGroup.get('appointment') as FormGroup;
  }

  get fiduciaryType(): FormControl {
    return this.bondDetailsFormGroup.get('fiduciaryType') as FormControl;
  }

  get otherFiduciaryType(): FormControl {
    return this.bondDetailsFormGroup.get('otherFiduciaryType') as FormControl;
  }

  get appointmentType(): FormControl {
    return this.bondDetailsFormGroup.get('appointmentType') as FormControl;
  }

  get deceasedInfo(): FormGroup {
    return this.bondDetailsFormGroup.get('deceasedInfo') as FormGroup;
  }

  // get bondPurpose(): FormControl {
  //   return this.bondDetailsFormGroup.get('bondPurpose') as FormControl;
  // }

  // endregion

  // region Delivery and Payment Information: Form Controls
  // get specialBondForm(): FormControl {
  //   return this.deliveryAndPaymentInformationFormGroup.get('specialBondForm') as FormControl;
  // }

  // get specialBondUpload(): FormControl {
  //   return this.deliveryAndPaymentInformationFormGroup.get('specialBondUpload') as FormControl;
  // }

  // get specialBondFile(): FormGroup {
  //   return this.deliveryAndPaymentInformationFormGroup.get('specialBondFile') as FormGroup;
  // }

  get uploadCourtOrder(): FormControl {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'uploadCourtOrder'
    ) as FormControl;
  }

  get courtOrderFile(): FormGroup {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'courtOrderFile'
    ) as FormGroup;
  }

  // get will(): FormControl {
  //   return this.deliveryAndPaymentInformationFormGroup.get('will') as FormControl;
  // }

  // get willContested(): FormControl {
  //   return this.deliveryAndPaymentInformationFormGroup.get('willContested') as FormControl;
  // }

  // get willContestedExplanation(): FormControl {
  //   return this.deliveryAndPaymentInformationFormGroup.get('willContestedExplanation') as FormControl;
  // }

  // get principalBeneficiary(): FormControl {
  //   return this.deliveryAndPaymentInformationFormGroup.get('principalBeneficiary') as FormControl;
  // }

  // get otherBeneficiaries(): FormControl {
  //   return this.deliveryAndPaymentInformationFormGroup.get('otherBeneficiaries') as FormControl;
  // }

  get debtorInterestedParties(): FormArray {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'debtorInterestedParties'
    ) as FormArray;
  }

  get estateCash(): FormControl {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'estateCash'
    ) as FormControl;
  }

  get estateRealEstate(): FormControl {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'estateRealEstate'
    ) as FormControl;
  }

  get estateSecurities(): FormControl {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'estateSecurities'
    ) as FormControl;
  }

  get estateMisc(): FormControl {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'estateMisc'
    ) as FormControl;
  }

  get bankListFormArray(): FormArray {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'bankInfoList'
    ) as FormArray;
  }

  get delivery(): FormGroup {
    return this.deliveryAndPaymentInformationFormGroup.get(
      'delivery'
    ) as FormGroup;
  }

  get deliveryMethod(): FormControl {
    return this.delivery.get('deliveryMethod') as FormControl;
  }

  get deliveryName(): FormControl {
    return this.delivery.get('deliveryName') as FormControl;
  }

  get deliveryPhone(): FormControl {
    return this.delivery.get('deliveryPhone') as FormControl;
  }

  get copyViaEmail(): FormControl {
    return this.delivery.get('copyViaEmail') as FormControl;
  }

  get deliveryAddress(): FormGroup {
    return this.delivery.get('deliveryAddress') as FormGroup;
  }

  get deliveryAddressStreet1(): FormControl {
    return this.deliveryAddress.get('street1') as FormControl;
  }

  get deliveryAddressCity(): FormControl {
    return this.deliveryAddress.get('city') as FormControl;
  }

  get deliveryAddressState(): FormControl {
    return this.deliveryAddress.get('state') as FormControl;
  }

  get deliveryAddressZipCode(): FormControl {
    return this.deliveryAddress.get('zipCode') as FormControl;
  }

  get paymentInformationFormGroup(): FormGroup {
    return this.deliveryAndPaymentInformationFormGroup.get(
      PAYMENT_INFORMATION_FORM_GROUP_NAME
    ) as FormGroup;
  }

  bondDetailsPageGtmEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup?,
    lpBond?,
    quoteId?,
    bondClass?,
    applicationID?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }

  PageGtmEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup?,
    lpBond?,
    quoteId?,
    bondClass?,
    applicationID?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }

  termsAndConditionEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup?,
    lpBond?,
    quoteId?,
    bondClass?,
    applicationID?,
    paymentType?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`,
      `${paymentType}`
    );
  }

  validatePage(index) {
    if (index === 0) {
      CommonUtilities.markAllTouched(this.stepperFormArray.at(0));
    }
  }
  // endregion
}
