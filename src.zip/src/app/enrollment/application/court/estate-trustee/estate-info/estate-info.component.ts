import { Component, Input } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-estate-info',
  templateUrl: './estate-info.component.html',
  styleUrls: ['./estate-info.component.css'],
})
export class EstateInfoComponent {

  @Input()
  estateInfoFormGroup: FormGroup;

  @Input()
  emptyDebtorInterestedPartyFormGroup: FormGroup;

  @Input()
  disableDIPButton: boolean;

  constructor() {
  }

  otherBeneficiariesChange(event: any) {
    if (this.otherBeneficiaries.value !== true) {
      // otherBeneficiaries option is not selected.
      // Remove all but first debtorInterestedParty, and clear it.
      const childrenFormArray = this.debtorInterestedPartiesFormArray;
      if (childrenFormArray.length > 0) {
        const firstChild = childrenFormArray.at(0);
        while (childrenFormArray.length > 0) {
          childrenFormArray.removeAt(0);
        }
        firstChild.reset({});
      }
    }
  }

  get will(): FormControl {
    return this.estateInfoFormGroup.get('will') as FormControl;
  }

  get willContested(): FormControl {
    return this.estateInfoFormGroup.get('willContested') as FormControl;
  }

  get willContestedExplanation(): FormControl {
    return this.estateInfoFormGroup.get('willContestedExplanation') as FormControl;
  }

  get principalBeneficiary(): FormControl {
    return this.estateInfoFormGroup.get('principalBeneficiary') as FormControl;
  }

  get otherBeneficiaries(): FormControl {
    return this.estateInfoFormGroup.get('otherBeneficiaries') as FormControl;
  }

  get debtorInterestedPartiesFormArray(): FormArray {
    return this.estateInfoFormGroup.get('debtorInterestedParties') as FormArray;
  }

  get estateCash(): FormControl {
    return this.estateInfoFormGroup.get('estateCash') as FormControl;
  }

  get estateRealEstate(): FormControl {
    return this.estateInfoFormGroup.get('estateRealEstate') as FormControl;
  }

  get estateSecurities(): FormControl {
    return this.estateInfoFormGroup.get('estateSecurities') as FormControl;
  }

  get estateMisc(): FormControl {
    return this.estateInfoFormGroup.get('estateMisc') as FormControl;
  }

}
