import { AbstractFormArrayMapper } from '../../common/abstract-form-array-mapper.service';
import { Injectable } from '@angular/core';
import { AppealsSupersedeasCourtApplicationImpl } from '../model/appeals-supersedeas-court-application';
import { DeliveryMethodImpl } from '../model/common/delivery-method';
import { PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';


@Injectable()
export class AppealsSupersedeasFormArrayMapper extends AbstractFormArrayMapper {

  constructor() {
    super();
  }

  public formArrayJsonToObject(formArrayJson: any): AppealsSupersedeasCourtApplicationImpl {
    const [applicationInformation, termsAndConditions] = formArrayJson;
    const application: AppealsSupersedeasCourtApplicationImpl = new AppealsSupersedeasCourtApplicationImpl();
    const courtInformation = applicationInformation.courtInformation;
    const attorneyInformation = applicationInformation.attorneyInformation;
    const deliveryInformation = applicationInformation.deliveryInformation;
    application.premiumRateId = applicationInformation.premiumRateId;
    application.companyOrIndividual = applicationInformation.companyOrIndividual;
    application.federalOrState = applicationInformation.federalOrState;
    application.applicantEmail = applicationInformation.applicantInfo.applicantEmail;
    application.applicantOfficePerson = applicationInformation.applicantInfo.applicantOfficePerson;
    application.applicantId = applicationInformation.applicantInfo.applicantId;
    application.applicantPhone = applicationInformation.applicantInfo.applicantPhone;
    application.applicantFax = applicationInformation.applicantInfo.applicantFax;
    application.applicantWebsite = applicationInformation.applicantInfo.applicantWebsite;
    application.applicantName = applicationInformation.applicantInfo.applicantName;
    application.applicantSalutation = applicationInformation.applicantInfo.applicantSalutation;
    application.applicantSuffix = applicationInformation.applicantInfo.applicantSuffix;
    application.applicantAddress.street1 =
      applicationInformation.applicantInfo.applicantAddress ? applicationInformation.applicantInfo.applicantAddress.street1 : null;
    application.applicantAddress.street2 =
      applicationInformation.applicantInfo.applicantAddress ? applicationInformation.applicantInfo.applicantAddress.street2 : null;
    application.applicantAddress.city =
      applicationInformation.applicantInfo.applicantAddress ? applicationInformation.applicantInfo.applicantAddress.city : null;
    application.applicantAddress.state =
      applicationInformation.applicantInfo.applicantAddress ? applicationInformation.applicantInfo.applicantAddress.state : null;
    application.applicantAddress.zipCode =
      applicationInformation.applicantInfo.applicantAddress ? applicationInformation.applicantInfo.applicantAddress.zipCode : null;
    application.court.caseNumber = courtInformation.caseNumber;
    application.court.courtName = courtInformation.courtName;
    application.court.presidingJudge = courtInformation.presidingJudge;
    application.court.courtCounty = courtInformation.courtCounty;
    application.court.courtPhone = courtInformation.courtPhone;
    application.court.address.street1 = courtInformation.address ? courtInformation.address.street1 : null;
    application.court.address.street2 = courtInformation.address ? courtInformation.address.street2 : null;
    application.court.address.city = courtInformation.address ? courtInformation.address.city : null;
    application.court.address.state = courtInformation.address ? courtInformation.address.state : null;
    application.court.address.zipCode = courtInformation.address ? courtInformation.address.zipCode : null;
    application.court.courtDistrict = courtInformation.courtDistrict ? courtInformation.courtDistrict : null;
    application.plaintiffs = applicationInformation.plaintiffs;
    application.defendants = applicationInformation.defendants;
    application.appellantName = applicationInformation.appellantName;
    application.appelleeName = applicationInformation.appelleeName;
    application.attorneyName = attorneyInformation.attorneyName;
    application.attorneyFirm = attorneyInformation.attorneyFirm;
    application.attorneyPhone = attorneyInformation.attorneyPhone;
    application.attorneyEmail = attorneyInformation.attorneyEmail;
    application.attorneyAddress.street1 = attorneyInformation.attorneyAddress.street1;
    application.attorneyAddress.street2 = attorneyInformation.attorneyAddress.street2;
    application.attorneyAddress.zipCode = attorneyInformation.attorneyAddress.zipCode;
    application.attorneyAddress.city = attorneyInformation.attorneyAddress.city;
    application.attorneyAddress.state = attorneyInformation.attorneyAddress.state;
    application.typeOfCollateral = applicationInformation.typeOfCollateral;
    application.dateOfJudgmentOrOrder = applicationInformation.dateOfJudgmentOrOrder;
    application.judgmentOrOrder = applicationInformation.judgmentOrOrder;
    // application.typeOfOrderAppealed = applicationInformation.typeOfOrderAppealed;
    // application.hearingScheduled = applicationInformation.hearingScheduled;
    application.dateOfNextHearing = applicationInformation.dateOfNextHearing;
    application.judgmentOrOrderAmount = applicationInformation.judgmentOrOrderAmount;
    application.uploadCourtOrder = application.judgmentOrOrder === 'order' ? applicationInformation.uploadCourtOrder : false;
    application.courtOrderFile.id = applicationInformation.courtOrderFile.id;
    application.courtOrderFile.name = applicationInformation.courtOrderFile.name;
    application.uploadJudgment = application.judgmentOrOrder === 'judgment' ? applicationInformation.uploadJudgment : false;
    application.judgmentFile.id = applicationInformation.judgmentFile.id;
    application.judgmentFile.name = applicationInformation.judgmentFile.name;
    // application.specialBondForm = applicationInformation.specialBondForm;
    // application.specialBondUpload = applicationInformation.specialBondUpload;
    // application.specialBondFile.id = applicationInformation.specialBondFile.id;
    // application.specialBondFile.name = applicationInformation.specialBondFile.name;

    application.deliveryMethod = new DeliveryMethodImpl();
    this.populateDeliveryMethod(application.deliveryMethod, deliveryInformation);

    // Payment Method will already have been converted to an instance of PaymentMethod via PaymentMethodSelectionFormGroup.getRawValue().
    application.paymentMethod = applicationInformation[PAYMENT_INFORMATION_FORM_GROUP_NAME];

    // Page 2
    application.termsAndConditions.readAndAgreeToTerms = termsAndConditions.readAndAgreeToTerms;
    application.termsAndConditions.declareTrue = termsAndConditions.declareTrue;
    application.termsAndConditions.indemnitor = applicationInformation.applicantName;
    application.termsAndConditions.agreementDate = new Date();
    application.termsAndConditions.emailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.emailSignature : null;
    application.termsAndConditions.signatureName = termsAndConditions.termsSignatures.signatureName;
    application.termsAndConditions.companyEmailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.companyEmailSignature : null;
    application.termsAndConditions.premiumAcknowledged = termsAndConditions.premiumAcknowledged;
    application.applicantOfficePersonTitle = termsAndConditions.indemnitorOfficePersonTitle;
    application.applicantOfficePerson = termsAndConditions.indemnitorOfficePerson;
    return application;
  }

  public objectToFormArrayJson(application: AppealsSupersedeasCourtApplicationImpl): any {
    return [
      // Page 1
      {
        applicantInfo: {
          applicantId: application.applicantId,
          applicantName: application.applicantName,
          applicantSalutation: application.applicantSalutation,
          applicantSuffix: application.applicantSuffix,
          applicantOfficePerson: application.applicantOfficePerson,
          applicantEmail: application.applicantEmail,
          applicantPhone: application.applicantPhone,
          applicantFax: application.applicantFax,
          applicantWebsite: application.applicantWebsite,
          applicantAddress: {
            street1: application.applicantAddress ? application.applicantAddress.street1 : null,
            street2: application.applicantAddress ? application.applicantAddress.street2 : null,
            zipCode: application.applicantAddress ? application.applicantAddress.zipCode : null,
            city: application.applicantAddress ? application.applicantAddress.city : null,
            state: application.applicantAddress ? application.applicantAddress.state : null,
          },
        },
        companyOrIndividual: application.companyOrIndividual,
        premiumRateId: application.premiumRateId,
        courtInformation: {
          caseNumber: application.court ? application.court.caseNumber : null,
          courtName: application.court ? application.court.courtName : null,
          presidingJudge: application.court ? application.court.presidingJudge : null,
          courtCounty: application.court ? application.court.courtCounty : null,
          courtPhone: application.court ? application.court.courtPhone : null,
          address: {
            street1: application.court ? application.court.address.street1 : null,
            street2: application.court ? application.court.address.street2 : null,
            city: application.court ? application.court.address.city : null,
            state: application.court ? application.court.address.state : null,
            zipCode: application.court ? application.court.address.zipCode : null,
          },
          courtDistrict: application.court ? application.court.courtDistrict : null,
        },
        attorneyInformation: {
          attorneyName: application.attorneyName,
          attorneyFirm: application.attorneyFirm,
          attorneyPhone: application.attorneyPhone,
          attorneyEmail: application.attorneyEmail,
          attorneyAddress: {
            street1: application.attorneyAddress ? application.attorneyAddress.street1 : null,
            street2: application.attorneyAddress ? application.attorneyAddress.street2 : null,
            city: application.attorneyAddress ? application.attorneyAddress.city : null,
            state: application.attorneyAddress ? application.attorneyAddress.state : null,
            zipCode: application.attorneyAddress ? application.attorneyAddress.zipCode : null,
          },
        },
        federalOrState: application.federalOrState,
        typeOfCollateral: application.typeOfCollateral,
        plaintiffs: application.plaintiffs,
        defendants: application.defendants,
        appellantName: application.appellantName ? application.appellantName : application.applicantName,
        appelleeName: application.appelleeName,

        dateOfJudgmentOrOrder: application.dateOfJudgmentOrOrder,
        judgmentOrOrder: application.judgmentOrOrder,
        // typeOfOrderAppealed: application.typeOfOrderAppealed,
        // hearingScheduled: application.hearingScheduled,
        dateOfNextHearing: application.dateOfNextHearing,
        judgmentOrOrderAmount: application.judgmentOrOrderAmount,
        uploadCourtOrder: application.uploadCourtOrder,
        courtOrderFile: {
          id: application.courtOrderFile ? application.courtOrderFile.id : null,
          name: application.courtOrderFile ? application.courtOrderFile.name : null,
        },
        uploadJudgment: application.uploadJudgment,
        judgmentFile: {
          id: application.judgmentFile ? application.judgmentFile.id : null,
          name: application.judgmentFile ? application.judgmentFile.name : null,
        },
        // specialBondForm: application.specialBondForm,
        // specialBondUpload: application.specialBondUpload,
        // specialBondFile: {
        //   id: application.specialBondFile ? application.specialBondFile.id : null,
        //   name: application.specialBondFile ? application.specialBondFile.name : null,
        // },

        deliveryInformation: this.createDeliveryMethodFormGroupPatchValues(application.deliveryMethod),

        // The Payment FormGroup will generate the patchValues itself from the paymentMethod.
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: application.paymentMethod,
      },
      // Page 2
      {
        readAndAgreeToTerms: application.termsAndConditions ? application.termsAndConditions.readAndAgreeToTerms : false,
        declareTrue: application.termsAndConditions ? application.termsAndConditions.declareTrue : false,
        agreementDate: new Date(),
        indemnitor: application.applicantName,
        indemnitorOfficePerson: application.applicantOfficePerson ? application.applicantOfficePerson : null,
        indemnitorOfficePersonTitle: application.applicantOfficePersonTitle ? application.applicantOfficePersonTitle : null,
        premiumAcknowledged: application.termsAndConditions.premiumAcknowledged,
        termsSignatures: {
          companyEmailSignature: application.termsAndConditions.companyEmailSignature,
          signatureName: application.termsAndConditions.signatureName,
          emailSignature: application.termsAndConditions.emailSignature,
        },
      },
    ];
  }
}
