import { Component, Inject, ElementRef } from '@angular/core';
import { ApplicationBaseComponent, PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { ApplicationService } from '../../application.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppealsSupersedeasFormArrayMapper } from './appeals-supersedeas-form-array-mapper.service';
import { SecurityService } from '../../../../security/security.service';
import { DateValidators } from '../../../../common/validators/date-validators';
import { PatternValidators } from '../../../../common/validators/pattern-validators';
import { ValueMatchValidator } from '../../../../common/validators/value-match-validator';
import { distinctUntilChanged } from 'rxjs/operators';
import { ServiceHandler } from '../../../../common/utils/service-handler.service';
import { ControlValidator } from '../../common/control-validator';
import { ConditionalValidator } from '../../../../common/validators/conditional-validator';
import { CheckboxValidator } from '../../../../common/validators/checkbox-validator';
import { GoogleTagManagerService } from '../../../../common/services/google-tag-manager.service';
import { ApplicationRoleService } from '../../../../common/services/application-role-service';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { MatDialog } from '@angular/material';
import { PersonService } from '../../../../common/person-service';
import { CourtBondType } from '../../common/bond-types';
import { PLAINTIFF_CHAR_LIMIT } from '../../../../common/utils/constants';
import { DOCUMENT } from '@angular/common';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';


@Component({
  selector: 'app-appeals-supersedeas',
  templateUrl: './appeals-supersedeas.component.html',
  styleUrls: ['./appeals-supersedeas.component.css'],
  providers: [ApplicationRoleService],
})
export class AppealsSupersedeasComponent extends ApplicationBaseComponent {
  stepperFormArray: FormArray;
  today: Date = new Date();
  plaintiff_char_limit = PLAINTIFF_CHAR_LIMIT;
  constructor(
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      new AppealsSupersedeasFormArrayMapper(),
      applicationService,
      securityService,
      activatedRoute,
      router,
      CourtBondType.Supersedeas,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      document,
      elementRef,
      spinnerService
    );
  }

  createNewApplication() {
    this.stepperFormArray = new FormArray([
      new FormGroup({
        applicantInfo: new FormGroup({
          applicantId: new FormControl(null),
          applicantName: new FormControl(null),
          applicantSalutation: new FormControl(null),
          applicantSuffix: new FormControl(null),
          applicantOfficePerson: new FormControl(null),
          applicantPhone: new FormControl(null),
          applicantFax: new FormControl(null),
          applicantEmail: new FormControl(null),
          applicantWebsite: new FormControl(null),
          applicantAddress: this.createApplicantAddressFormGroup(),
        }),
        companyOrIndividual: new FormControl(),
        premiumRateId: new FormControl(),
        federalOrState: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        courtInformation: new FormGroup({
          caseNumber: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          courtName: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          presidingJudge: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          courtCounty: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          courtPhone: new FormControl({ value: null, disabled: this.isEmployee }),
          address: this.createApplicationAddressFormGroup(),
          courtDistrict: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        }),
        plaintiffs: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        defendants: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        appellantName: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        appelleeName: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        attorneyInformation: new FormGroup({
          attorneyName: new FormControl({ value: null, disabled: this.isEmployee },
            [Validators.maxLength(50), this.requiredIfNotAgent]),
          attorneyFirm: new FormControl({ value: null, disabled: this.isEmployee },
            [Validators.maxLength(60), this.requiredIfNotAgent]),
          attorneyPhone: new FormControl({ value: null, disabled: this.isEmployee },
            [PatternValidators.phoneNumber(), this.requiredIfNotAgent]),
          attorneyEmail: new FormControl(),
          attorneyAddress: this.createApplicationAddressFormGroup(),
        }),
        typeOfCollateral: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        dateOfJudgmentOrOrder: new FormControl({ value: null, disabled: this.isEmployee },
          [DateValidators.onOrBeforeToday(), this.requiredIfNotAgent, DateValidators.datePatternValidator()]),
        judgmentOrOrder: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        judgmentOrOrderAmount: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // typeOfOrderAppealed: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // hearingScheduled: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        dateOfNextHearing: new FormControl({ value: null, disabled: this.isEmployee }, [DateValidators.afterToday()]),
        uploadCourtOrder: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        courtOrderFile: new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null),
        }),
        uploadJudgment: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        judgmentFile: new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null),
        }),
        // specialBondForm: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // specialBondUpload: new FormControl({ value: null, disabled: this.isEmployee }),
        // specialBondFile: new FormGroup({
        //   id: new FormControl(null),
        //   name: new FormControl(null),
        // }),

        deliveryInformation: this.createDeliveryInformationFormGroup(),
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: this.createPaymentInformationFormGroup(),
      }),

      new FormGroup({
        readAndAgreeToTerms: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) },
          CheckboxValidator.requireTrue()),
        declareTrue: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) }),
        agreementDate: new FormControl({ value: null }),
        premiumAcknowledged: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) },
          CheckboxValidator.requireTrue()),
        indemnitor: new FormControl(null),
        indemnitorOfficePerson: new FormControl(null),
        indemnitorOfficePersonTitle: new FormControl(null),
        termsSignatures: new FormGroup({
          signatureName: new FormControl({ disabled: true, value: null }),
          emailSignature: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
            [this.requiredIfNotAgent, PatternValidators.email()]),
          companyEmailSignature: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
            [this.requiredIfCompanyAndNotAgent, PatternValidators.email()]),
        }),
      }),
    ]);

    if (this.isCompany) {
      this.stepperFormArray.at(1)
        .setValidators([ValueMatchValidator.matchValueToField(this.application.data.applicantEmail, 'termsSignatures.emailSignature',
          false, true),
        ValueMatchValidator.matchValueToField(this.application.data.applicantEmail, 'termsSignatures.companyEmailSignature',
          false, true)]);
    } else {
      this.stepperFormArray.at(1)
        .setValidators([ValueMatchValidator.matchValueToField(this.application.data.applicantEmail, 'termsSignatures.emailSignature',
          false, true)]);
    }

    this.registerFileUploadControls();
    this.clearHearingDate();
    this.addConditionalValidation();
    this.stepperFormArray.disable();

  }

  async stepSelectionChange(event: StepperSelectionEvent) {
    await super.stepSelectionChange(event);

    this.determineTypeOfClient();
    // if (event.selectedIndex !== 0) {
    //   this.googleTagManagerService.sendEvent(
    //     `court-bond-app-step-${event.selectedIndex}`,
    //     `${this.bondType}`,
    //     `${this.premium}`,
    //     `${this.userType}`
    //   );
    // }
    const user = this.securityService.user;
    const userType = user ? (user.hasAttorneyRole ? 'attorney' : user.userRoles[0].userRoleRef.role) : 'anonymous';
    const paymentType = this.application['data'].paymentMethod.paymentChannelCode ?
      this.application['data'].paymentMethod.paymentChannelCode.cardValidatorType : '';
    // if (event.selectedIndex === 1) {
    //   this.PageGtmEvent(
    //     'court-bond-app-delivery',
    //     this.bondType,
    //     this.premium,
    //     userType,
    //     `${this.application['quoteId']}`,
    //     'new',
    //     this.id
    //   );
    // }
    if (event.selectedIndex === 1) {
      this.termsAndConditionEvent(
        'court-bond-app-terms',
        this.bondType,
        this.application.premium,
        userType,
        '',
        '',
        this.application.quoteId,
        'new',
        this.application.id,
        paymentType
      );
    }
  }

  addConditionalValidation(): void {
    const deliveryMethodSetAndIsNotEmailCondition = this.notStewardAnd(
      this.isSetAndNotEqualTo('Email', this.deliveryMethod)
    );

    // this.setConditionalValidator(this.specialBondUpload,
    //   ConditionalValidator.conditionalRequire(() => !this.isSteward && this.specialBondForm.value));
    // this.updateOnChangeEvents(this.specialBondForm, this.specialBondUpload);

    // Special Bond File Validation
    // this.setConditionalValidators([
    //   {
    //     formControl: this.specialBondFileFormGroup.get('id') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.specialBondUpload.value)],
    //   } as ControlValidator,
    //   {
    //     formControl: this.specialBondFileFormGroup.get('name') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.specialBondUpload.value)],
    //   } as ControlValidator,
    // ]);
    // this.updateOnChangeEvents(this.specialBondUpload, [
    //   this.specialBondFileFormGroup.get('id') as FormControl,
    //   this.specialBondFileFormGroup.get('name') as FormControl,
    // ]);


    this.setConditionalValidators([
      {
        formControl: this.deliveryName,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition)],
      },
      {
        formControl: this.deliveryPhone,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition)],
      },
      {
        formControl: this.deliveryAddressStreet1,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition), Validators.maxLength(60)],
      },
      {
        formControl: this.deliveryAddressZipCode,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition), PatternValidators.zipCode()],
      },
      {
        formControl: this.deliveryAddressCity,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition), Validators.maxLength(30)],
      },
      {
        formControl: this.deliveryAddressState,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition)],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.deliveryMethod, [
      this.deliveryName,
      this.deliveryPhone,
      this.deliveryAddressStreet1,
      this.deliveryAddressZipCode,
      this.deliveryAddressCity,
      this.deliveryAddressState,
    ]);


    const whenOrderIsSelected = this.notStewardAnd(
      this.isSetAndEqualTo('order', this.judgmentOrOrder)
    );

    const whenJudgmentIsSelected = this.notStewardAnd(
      this.isSetAndEqualTo('judgment', this.judgmentOrOrder)
    );

    this.setConditionalValidators([
      // {
      //   formControl: this.typeOfOrderAppealed,
      //   validators: [ConditionalValidator.conditionalRequire(whenOrderIsSelected)],
      // },
      {
        formControl: this.uploadCourtOrder,
        validators: [ConditionalValidator.conditionalRequire(whenOrderIsSelected)],
      },
      {
        formControl: this.uploadJudgment,
        validators: [ConditionalValidator.conditionalRequire(whenJudgmentIsSelected)],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.judgmentOrOrder, [
      // this.typeOfOrderAppealed,
      this.uploadJudgment,
      this.uploadCourtOrder,
    ]);

    // Court Order File Validation
    this.setConditionalValidators([
      {
        formControl: this.courtOrderFileFormGroup.get('id') as FormControl,
        validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.uploadCourtOrder.value)],
      } as ControlValidator,
      {
        formControl: this.courtOrderFileFormGroup.get('name') as FormControl,
        validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.uploadCourtOrder.value)],
      } as ControlValidator,
    ]);
    this.updateOnChangeEvents(this.uploadCourtOrder, [
      this.courtOrderFileFormGroup.get('id') as FormControl,
      this.courtOrderFileFormGroup.get('name') as FormControl,
    ]);

    // Judgment Order File Validation
    this.setConditionalValidators([
      {
        formControl: this.judgmentFileFormGroup.get('id') as FormControl,
        validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.uploadJudgment.value)],
      } as ControlValidator,
      {
        formControl: this.judgmentFileFormGroup.get('name') as FormControl,
        validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.uploadJudgment.value)],
      } as ControlValidator,
    ]);
    this.updateOnChangeEvents(this.uploadJudgment, [
      this.judgmentFileFormGroup.get('id') as FormControl,
      this.judgmentFileFormGroup.get('name') as FormControl,
    ]);
  }

  private notStewardAnd(condFn: () => boolean): () => boolean {
    return () => !this.isSteward && condFn();
  }

  private isSetAndEqualTo(value: any, control: FormControl): () => boolean {
    return () => !!control.value && control.value === value;
  }

  private isSetAndNotEqualTo(value: any, control: FormControl): () => boolean {
    return () => !!control.value && control.value !== value;
  }

  /**
   * Indicate that the various file uploads should be managed wrt/ 'obsolete' uploaded files
   * if the FileUploadMode is no longer fileUpload.
   */
  private registerFileUploadControls() {
    // this.registerFileTypeFileUploadActiveSubject('specialBondFile', this.specialBondFileFormGroup);
    this.registerFileTypeFileUploadActiveSubject('courtOrderFile', this.courtOrderFileFormGroup);
    this.registerFileTypeFileUploadActiveSubject('judgmentFile', this.judgmentFileFormGroup);
  }

  clearHearingDate() {
    if (this.hearingScheduled) {
      this.hearingScheduled
        .valueChanges.pipe(distinctUntilChanged())
        .subscribe(b => {
          if (b) {
            this.dateOfNextHearing.setValue('');
          }
        });
    }
  }

  get formArrayMapper() {
    return [];
  }

  get applicationInformation(): FormGroup {
    return this.stepperFormArray.at(0) as FormGroup;
  }

  get termsAndConditions(): FormGroup {
    return this.stepperFormArray.at(1) as FormGroup;
  }

  get courtInformationFormGroup(): FormGroup {
    return this.applicationInformation.get('courtInformation') as FormGroup;
  }

  get attorneyInformationFormGroup(): FormGroup {
    return this.applicationInformation.get('attorneyInformation') as FormGroup;
  }

  get courtOrderFileFormGroup(): FormGroup {
    return this.applicationInformation.get('courtOrderFile') as FormGroup;
  }

  get judgmentFileFormGroup(): FormGroup {
    return this.applicationInformation.get('judgmentFile') as FormGroup;
  }

  // get specialBondFileFormGroup(): FormGroup {
  //   return this.applicationInformation.get('specialBondFile') as FormGroup;
  // }

  // get specialBondForm(): FormControl {
  //   return this.applicationInformation.get('specialBondForm') as FormControl;
  // }

  // get specialBondUpload(): FormControl {
  //   return this.applicationInformation.get('specialBondUpload') as FormControl;
  // }

  get paymentInformationFormGroup(): FormGroup {
    return this.applicationInformation.get(PAYMENT_INFORMATION_FORM_GROUP_NAME) as FormGroup;
  }

  get deliveryInformationFormGroup(): FormGroup {
    return this.applicationInformation.get('deliveryInformation') as FormGroup;
  }

  get applicantInfoFormGroup(): FormGroup {
    return this.applicationInformation.get('applicantInfo') as FormGroup;
  }


  get federalOrState(): FormControl {
    return this.applicationInformation.get('federalOrState') as FormControl;
  }

  get plaintiffs(): FormControl {
    return this.applicationInformation.get('plaintiffs') as FormControl;
  }

  get defendants(): FormControl {
    return this.applicationInformation.get('defendants') as FormControl;
  }

  get appelleeName(): FormControl {
    return this.applicationInformation.get('appelleeName') as FormControl;
  }

  get appellantName(): FormControl {
    return this.applicationInformation.get('appellantName') as FormControl;
  }

  get typeOfCollateral(): FormControl {
    return this.applicationInformation.get('typeOfCollateral') as FormControl;
  }

  get dateOfJudgmentOrOrder(): FormControl {
    return this.applicationInformation.get('dateOfJudgmentOrOrder') as FormControl;
  }

  get judgmentOrOrder(): FormControl {
    return this.applicationInformation.get('judgmentOrOrder') as FormControl;
  }

  // get typeOfOrderAppealed(): FormControl {
  //   return this.applicationInformation.get('typeOfOrderAppealed') as FormControl;
  // }

  get uploadJudgment(): FormControl {
    return this.applicationInformation.get('uploadJudgment') as FormControl;
  }

  get uploadCourtOrder(): FormControl {
    return this.applicationInformation.get('uploadCourtOrder') as FormControl;
  }

  get hearingScheduled(): FormControl {
    return this.applicationInformation.get('hearingScheduled') as FormControl;
  }

  get dateOfNextHearing(): FormControl {
    return this.applicationInformation.get('dateOfNextHearing') as FormControl;
  }

  get deliveryMethod(): FormControl {
    return this.deliveryInformationFormGroup.get('deliveryMethod') as FormControl;
  }

  get deliveryName(): FormControl {
    return this.deliveryInformationFormGroup.get('deliveryName') as FormControl;
  }

  get deliveryPhone(): FormControl {
    return this.deliveryInformationFormGroup.get('deliveryPhone') as FormControl;
  }

  get copyViaEmail(): FormControl {
    return this.deliveryInformationFormGroup.get('copyViaEmail') as FormControl;
  }

  get deliveryAddress(): FormGroup {
    return this.deliveryInformationFormGroup.get('deliveryAddress') as FormGroup;
  }

  get deliveryAddressStreet1(): FormControl {
    return this.deliveryAddress.get('street1') as FormControl;
  }

  get deliveryAddressCity(): FormControl {
    return this.deliveryAddress.get('city') as FormControl;
  }

  get deliveryAddressState(): FormControl {
    return this.deliveryAddress.get('state') as FormControl;
  }

  get deliveryAddressZipCode(): FormControl {
    return this.deliveryAddress.get('zipCode') as FormControl;
  }

  get judgmentOrOrderAmount(): FormControl {
    return this.applicationInformation.get('judgmentOrOrderAmount') as FormControl;
  }

  get termsAndConditionsFormGroup(): FormGroup {
    return this.stepperFormArray.at(1) as FormGroup;
  }

  get termsSignaturesFormGroup(): FormGroup {
    return this.termsAndConditionsFormGroup.get('termsSignatures') as FormGroup;
  }

  get emailSignature(): FormControl {
    return this.termsSignaturesFormGroup.get('emailSignature') as FormControl;
  }


  get signatureName(): FormControl {
    return this.termsSignaturesFormGroup.get('signatureName') as FormControl;
  }

  get applicantEmail(): FormControl {
    return this.applicationInformation.get('applicantEmail') as FormControl;
  }

  userIsSteward(): boolean {
    return this.currentUserIsSteward;
  }

  get isLinear(): boolean {
    return !this.isSteward;
  }

  // PageGtmEvent(event, bondType, bondPremium, userType, quoteId?, bondClass?, applicationID?) {
  //   this.googleTagManagerService.sendEvent(
  //     `${event}`,
  //     `${bondType}`,
  //     `${bondPremium}`,
  //     `${userType}`,
  //     `${quoteId}`,
  //     `${bondClass}`,
  //     `${applicationID}`
  //   );
  // }
  termsAndConditionEvent(event, bondType, bondPremium, userType, lpGroup?, lpBond?, quoteId?, bondClass?, applicationID?, paymentType?) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`,
      `${paymentType}`
    );
  }

}
