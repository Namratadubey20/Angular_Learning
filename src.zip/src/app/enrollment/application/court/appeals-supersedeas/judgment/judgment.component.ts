import { Component, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FileUploadConfig } from '../../../../../common/file-upload/file-upload-config';
import { DocumentUploadComponent } from '../../../../../common/document-upload/document-upload.component';

@Component({
  selector: 'app-judgment',
  templateUrl: './judgment.component.html',
  styleUrls: ['./judgment.component.css'],
})
export class JudgmentComponent extends DocumentUploadComponent {

  @Input()
  judgmentFormGroup: FormGroup;

  // FileUploadConfig for uploading the judgment file.
  fileUploadConfig: FileUploadConfig;

  @Input()
  disableUploadJudgmentButton: boolean;

  constructor() {
    super();
    this.fileUploadConfig = new FileUploadConfig();
    this.fileUploadConfig.acceptsFileTypes = '.pdf,.doc,.docx,.jpg,.jpeg';
  }

  get uploadJudgment(): FormControl {
    return this.judgmentFormGroup.get('uploadJudgment') as FormControl;
  }

  get judgmentFileFormGroup(): FormGroup {
    return this.judgmentFormGroup.get('judgmentFile') as FormGroup;
  }

}
