import { Auditable, AuditableObject } from '../../../../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateStringOnlyConverter } from '../../../../common/utils/date-string-only-converter';
import { ProductType, ProductTypeImpl } from '../../../../product/product-type';


export interface ClientCourtApplicationSummary extends Auditable {
  id: number;
  productType: ProductType;
  status: string;
  productTypeName?: string;
  productTypeCode?: string;
}

@JsonObject('ClientCourtApplicationSummaryImpl')
export class ClientCourtApplicationSummaryImpl extends AuditableObject implements ClientCourtApplicationSummary {

  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('productType', ProductTypeImpl, true)
  productType: ProductType = new ProductTypeImpl();

  @JsonProperty('status', String, true)
  status: string = null;

  @JsonProperty('createdAt', DateStringOnlyConverter, true)
  createdAt: Date = null;

  @JsonProperty('productTypeName', String, true)
  productTypeName: string = null;

  @JsonProperty('productTypeCode', String, true)
  productTypeCode: string = null;
}
