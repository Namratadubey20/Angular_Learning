import { JsonConverter, JsonCustomConvert } from 'json2typescript';
import { ApplicationData } from './application-data';
import { AppealsSupersedeasCourtApplicationImpl } from './appeals-supersedeas-court-application';
import { ConservatorshipGuardianshipApplicationImpl } from './conservatorship-guardianship-application';
import { RefereeReceiverApplicationImpl } from './referee-receiver-application';
import { EstateTrusteeApplicationImpl } from './estate-trustee-application';
import { UtilService } from '../../../../common/utils/util.service';
import { CourtBondType } from '../../common/bond-types';
import { ReplevinApplicationImpl } from './replevin-application';
import { AttachmentApplicationImpl } from './attachment-application';
import { InjunctionCourtApplicationImpl } from './injunction-court-application';
import { PnlApplicationDataImpl } from '../../pnl-application-data';

@JsonConverter
export class ApplicationDataConverter implements JsonCustomConvert<ApplicationData> {
  deserialize(data: any): ApplicationData {
    const jsonConvert = UtilService.getJsonConvert();

    switch (data.bondClassification as CourtBondType) {
      case CourtBondType.Supersedeas:
        return jsonConvert.deserialize(data, AppealsSupersedeasCourtApplicationImpl) as ApplicationData;

      case CourtBondType.Replevin:
        return jsonConvert.deserialize(data, ReplevinApplicationImpl) as ApplicationData;

      case CourtBondType.Attachment:
        return jsonConvert.deserialize(data, AttachmentApplicationImpl) as ApplicationData;

      case CourtBondType.Injunction:
        return jsonConvert.deserialize(data, InjunctionCourtApplicationImpl) as ApplicationData;

      case CourtBondType.Conservatorship:
      case CourtBondType.Guardianship:
        return jsonConvert.deserialize(data, ConservatorshipGuardianshipApplicationImpl) as ApplicationData;

      case CourtBondType.Referee:
      case CourtBondType.Receiver:
        return jsonConvert.deserialize(data, RefereeReceiverApplicationImpl) as ApplicationData;

      case CourtBondType.Estate:
      case CourtBondType.Trustee:
        return jsonConvert.deserialize(data, EstateTrusteeApplicationImpl) as ApplicationData;

      case CourtBondType.pnl:
        return jsonConvert.deserialize(data, PnlApplicationDataImpl) as ApplicationData;

      default:
        throw new Error(`Unrecognized application type in ApplicationDataConverter.deserialize: ${data.bondClassification}`);
    }
  }

  serialize(data: ApplicationData): any {
    const jsonConvert = UtilService.getJsonConvert();

    switch (data.bondClassification as CourtBondType) {
      case CourtBondType.Supersedeas:
      case CourtBondType.Replevin:
      case CourtBondType.Attachment:
      case CourtBondType.Injunction:
      case CourtBondType.Conservatorship:
      case CourtBondType.Guardianship:
      case CourtBondType.Referee:
      case CourtBondType.Receiver:
      case CourtBondType.Estate:
      case CourtBondType.Trustee:
      case CourtBondType.pnl:
        return jsonConvert.serialize(data);

      default:
        throw new Error(`Unrecognized application type in ApplicationDataConverter.serialize: ${data.bondClassification}`);
    }
  }
}
