import { JsonObject, JsonProperty } from 'json2typescript';
import { ApplicationData, ApplicationDataImpl } from './application-data';
import { Address, AddressImpl } from './common/address';
import { ApplicationFile } from './common/application-file';
import { ApplicationFileImpl } from '../../../adjudication/application-file';
import { CurrencyConverter } from '../../../../common/utils/currency-converter';
import { PhoneNumberConverter } from '../../../../common/utils/phone-number-converter';
import { DynamicQuestionImpl, DynamicQuestion } from './common/dynamic-question';


export interface AttachmentApplication extends ApplicationData {
  creditCheckAuthorized: boolean;
  creditCheckSignature: string;
  creditCheckEmail: string;
  creditScoreSatisfactory: boolean;
  applicantSSNum: string;

  companyOrIndividual: string;
  federalOrState: string;
  claimAmount: number;
  exparteProcedure: boolean;
  // exparteProcedureExplanation: string;
  // propertyDescription: string;
  // securedByUcc: boolean;
  // securedByUccExplanation: string;
  // titleAttachedToSomeoneOther: boolean;
  // titleAttachedToSomeoneOtherExplanation: string;
  plaintiffs: string;
  plaintiffAttorney: string;

  // expose plaintiff attorney firm, phone, email as properties,
  // even though the application form doesn't currently collect them
  plaintiffAttorneyFirm: string;
  plaintiffAttorneyPhone: string;
  plaintiffAttorneyEmail: string;

  plaintiffAttorneyAddress: Address;
  defendants: string;
  uploadCourtOrder: boolean;
  courtOrderFile: ApplicationFile;
  knockoutQuestions: Array<DynamicQuestion>;
  // specialBondForm: boolean;
  // specialBondUpload: boolean;
  // specialBondFile: ApplicationFile;
}

@JsonObject('AttachmentApplicationImpl')
export class AttachmentApplicationImpl extends ApplicationDataImpl implements AttachmentApplication {

  @JsonProperty('creditCheckAuthorized', Boolean, true)
  creditCheckAuthorized: boolean = null;

  @JsonProperty('creditCheckEmail', String, true)
  creditCheckEmail: string = null;

  @JsonProperty('creditCheckSignature', String, null)
  creditCheckSignature: string = null;

  @JsonProperty('creditScoreSatisfactory', Boolean, true)
  creditScoreSatisfactory: boolean = null;

  @JsonProperty('applicantSSNum', String, true)
  applicantSSNum: string = null;

  @JsonProperty('claimAmount', CurrencyConverter, true)
  claimAmount: number = null;

  @JsonProperty('companyOrIndividual', String, true)
  companyOrIndividual: string = null;

  @JsonProperty('courtOrderFile', ApplicationFileImpl, true)
  courtOrderFile: ApplicationFile = new ApplicationFileImpl();

  @JsonProperty('defendants', String, true)
  defendants: string = null;

  @JsonProperty('exparteProcedure', Boolean, true)
  exparteProcedure: boolean = null;

  // @JsonProperty('exparteProcedureExplanation', String, true)
  // exparteProcedureExplanation: string = null;

  @JsonProperty('federalOrState', String, true)
  federalOrState: string = null;

  @JsonProperty('plaintiffs', String, true)
  plaintiffs: string = null;

  @JsonProperty('plaintiffAttorney', String, true)
  plaintiffAttorney: string = null;


  // expose plaintiff attorney firm, phone, email as properties,
  // even though the application form doesn't currently collect them
  @JsonProperty('plaintiffAttorneyFirm', String, true)
  plaintiffAttorneyFirm: string = null;

  @JsonProperty('plaintiffAttorneyPhone', PhoneNumberConverter, true)
  plaintiffAttorneyPhone: string = null;

  @JsonProperty('plaintiffAttorneyEmail', String, true)
  plaintiffAttorneyEmail: string = null;


  @JsonProperty('plaintiffAttorneyAddress', AddressImpl, true)
  plaintiffAttorneyAddress: Address = new AddressImpl();

  // @JsonProperty('titleAttachedToSomeoneOther', Boolean, true)
  // titleAttachedToSomeoneOther: boolean = null;

  // @JsonProperty('titleAttachedToSomeoneOtherExplanation', String, true)
  // titleAttachedToSomeoneOtherExplanation: string = null;

  // @JsonProperty('propertyDescription', String, true)
  // propertyDescription: string = null;

  // @JsonProperty('securedByUcc', Boolean, true)
  // securedByUcc: boolean = null;

  // @JsonProperty('securedByUccExplanation', String, true)
  // securedByUccExplanation: string = null;

  // @JsonProperty('specialBondFile', ApplicationFileImpl, true)
  // specialBondFile: ApplicationFile = new ApplicationFileImpl();

  // @JsonProperty('specialBondForm', Boolean, true)
  // specialBondForm: boolean = null;

  // @JsonProperty('specialBondUpload', Boolean, true)
  // specialBondUpload: boolean = null;

  @JsonProperty('uploadCourtOrder', Boolean, true)
  uploadCourtOrder: boolean = null;

  @JsonProperty('knockoutQuestions', [DynamicQuestionImpl], true)
  knockoutQuestions: Array<DynamicQuestion> = [];

  hasKnockoutQuestions(): boolean {
    return true;
  }

  knockoutQuestionFieldName(): string {
    return 'knockoutQuestions';
  }
}
