import { Auditable, AuditableObject } from '../../../../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DollarSignCurrencyConverter } from '../../../../common/utils/dollar-sign-currency-converter';
import { DateStringOnlyConverter } from '../../../../common/utils/date-string-only-converter';


export interface AgentCourtApplicationSummary extends Auditable {
  id: number;
  productTypeName: string;
  productTypeCode: string;
  amount: string;
  premium: string;
  status: string;
  obligeeName: string;
  applicantName: string;
}

@JsonObject('AgentCourtApplicationSummaryImpl')
export class AgentCourtApplicationSummaryImpl extends AuditableObject implements AgentCourtApplicationSummary {

  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('productTypeName', String, true)
  productTypeName: string = null;

  @JsonProperty('productTypeCode', String, true)
  productTypeCode: string = null;

  @JsonProperty('amount', DollarSignCurrencyConverter, true)
  amount: string = null;

  @JsonProperty('premium', DollarSignCurrencyConverter, true)
  premium: string = null;

  @JsonProperty('status', String, true)
  status: string = null;

  @JsonProperty('obligeeName', String, true)
  obligeeName: string = null;

  @JsonProperty('applicantName', String, true)
  applicantName: string = null;

  @JsonProperty('createdAt', DateStringOnlyConverter, true)
  createdAt: Date = null;
}
