import { Address, AddressImpl } from './common/address';
import { DeliveryMethod, DeliveryMethodImpl } from './common/delivery-method';
import { TermsAndConditions, TermsAndConditionsImpl } from './common/terms-and-conditions';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../../../../common/utils/date-converter';
import { PaymentMethod, PaymentMethodImpl } from './common/payment-method';
import { CurrencyConverter } from '../../../../common/utils/currency-converter';
import { PhoneNumberConverter } from '../../../../common/utils/phone-number-converter';
import { CourtInformation, CourtInformationImpl } from './common/court-information';
import { ApplicationPaymentPlan, ApplicationPaymentPlanImpl } from './common/application-payment-plan';

export type KnockoutReason = 'knockedOut' | 'creditScore' | 'both' | 'technicalError';

export interface ApplicationData {
  id: number;
  applicantName: string;
  applicantFirstName: string;
  applicantLastName: string;
  applicantSalutation: string;
  applicantSuffix: string;
  applicantPhone: string;
  applicantEmail: string;
  applicantFax: string;
  applicantWebsite: string;
  applicantOfficePerson: string;
  applicantOfficePersonTitle: string;
  bondClassification: string;
  amount: string;
  premium: string;
  applicationDate: Date;
  applicantId: number;
  applicantAddress: Address;
  knockedOut: boolean;
  knockedOutReason: KnockoutReason;
  paymentMethod: PaymentMethod;
  applicationPaymentPlan: ApplicationPaymentPlan;
  deliveryMethod: DeliveryMethod;
  termsAndConditions: TermsAndConditions;
  plaintiffs: string;
  attorneyName: string;
  attorneyPhone: string;
  attorneyEmail: string;
  attorneyFirm: string;
  court: CourtInformation;
  // specialBondUpload: boolean; // check this (common model)
  uploadPersonal: boolean;
  premiumRateId: number;
  applicantCreditCheckAddress: object;
  creditCheckAddressSameAsApplicant: boolean;
  hasKnockoutQuestions(): boolean;
  knockoutQuestionFieldName(): string;
}

@JsonObject('ApplicationDataImpl')
export class ApplicationDataImpl implements ApplicationData {
  @JsonProperty('id', Number, true)
  id: number = null;

  @JsonProperty('applicantName', String, true)
  applicantName: string = null;

  @JsonProperty('applicantFirstName', String, true)
  applicantFirstName: string = null;

  @JsonProperty('applicantLastName', String, true)
  applicantLastName: string = null;

  @JsonProperty('applicantSalutation', String, true)
  applicantSalutation: string = null;

  @JsonProperty('applicantSuffix', String, true)
  applicantSuffix: string = null;

  @JsonProperty('applicantPhone', PhoneNumberConverter, true)
  applicantPhone: string = null;

  @JsonProperty('applicantFax', PhoneNumberConverter, true)
  applicantFax: string = null;

  @JsonProperty('applicantWebsite', String, true)
  applicantWebsite: string = null;

  @JsonProperty('applicantEmail', String, true)
  applicantEmail: string = null;

  @JsonProperty('applicantOfficePerson', String, true)
  applicantOfficePerson: string = null;

  @JsonProperty('applicantOfficePersonTitle', String, true)
  applicantOfficePersonTitle: string = null;

  @JsonProperty('bondClassification', String, true)
  bondClassification: string = null;

  @JsonProperty('amount', CurrencyConverter, true)
  amount: string = null;

  @JsonProperty('premium', CurrencyConverter, true)
  premium: string = null;

  @JsonProperty('applicationDate', DateConverter, true)
  applicationDate: Date = null;

  @JsonProperty('applicantId', Number, true)
  applicantId: number = null;

  @JsonProperty('applicantAddress', AddressImpl, true)
  applicantAddress: Address = new AddressImpl();

  @JsonProperty('knockedOut', Boolean, true)
  knockedOut: boolean = null;

  @JsonProperty('knockedOutReason', String, true)
  knockedOutReason: KnockoutReason = null;

  @JsonProperty('paymentMethod', PaymentMethodImpl, true)
  paymentMethod: PaymentMethod = new PaymentMethodImpl();

  @JsonProperty('deliveryMethod', DeliveryMethodImpl, true)
  deliveryMethod: DeliveryMethod = new DeliveryMethodImpl();

  @JsonProperty('termsAndConditions', TermsAndConditionsImpl, true)
  termsAndConditions: TermsAndConditions = new TermsAndConditionsImpl();

  @JsonProperty('applicationPaymentPlan', ApplicationPaymentPlanImpl, true)
  applicationPaymentPlan: ApplicationPaymentPlan = null;

  @JsonProperty('plaintiffs', String, true)
  plaintiffs: string = null;

  @JsonProperty('attorneyName', String, true)
  attorneyName: string = null;

  @JsonProperty('attorneyPhone', String, true)
  attorneyPhone: string = null;

  @JsonProperty('attorneyEmail', String, true)
  attorneyEmail: string = null;

  @JsonProperty('attorneyFirm', String, true)
  attorneyFirm: string = null;

  @JsonProperty('court', CourtInformationImpl, true)
  court: CourtInformation = new CourtInformationImpl();

  // @JsonProperty('specialBondUpload', Boolean, true)
  // specialBondUpload: boolean = null;

  @JsonProperty('uploadPersonal', Boolean, true)
  uploadPersonal: boolean = null;

  @JsonProperty('premiumRateId', Number, true)
  premiumRateId: number = null;

  @JsonProperty('applicantCreditCheckAddress', Object, true)
  applicantCreditCheckAddress: object = {};

  @JsonProperty('creditCheckAddressSameAsApplicant', Boolean, true)
  creditCheckAddressSameAsApplicant: boolean = null;

  /**
   * override and return true once you implement dynamic questions for your common type
   */
  hasKnockoutQuestions(): boolean {
    return false;
  }

  knockoutQuestionFieldName(): string {
    return null;
  }
}
