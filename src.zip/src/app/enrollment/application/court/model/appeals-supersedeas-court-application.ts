import { ApplicationData, ApplicationDataImpl } from './application-data';
import { Address, AddressImpl } from './common/address';
import { CourtInformation, CourtInformationImpl } from './common/court-information';
import { JsonObject, JsonProperty } from 'json2typescript';
import { DateConverter } from '../../../../common/utils/date-converter';
import { CurrencyConverter } from '../../../../common/utils/currency-converter';
import { ApplicationFile, ApplicationFileImpl } from './common/application-file';
import { PhoneNumberConverter } from '../../../../common/utils/phone-number-converter';
import { CustomDateConverter } from 'src/app/common/utils/custom-date-converter';

export type CompanyOrIndividual = 'Company' | 'Individual';

export interface AppealsSupersedeasCourtApplication extends ApplicationData {
  federalOrState: string;
  companyOrIndividual: CompanyOrIndividual;
  invoiceId: string;
  plaintiffs: string;
  defendants: string;
  appelleeName: string;
  appellantName: string;
  typeOfCollateral: string;
  dateOfJudgmentOrOrder: Date;
  judgmentOrOrder: string;
  judgmentOrOrderAmount: string;
  // hearingScheduled: boolean;
  dateOfNextHearing: Date;
  // typeOfOrderAppealed: string;
  referralCode: string;
  // specialBondForm: boolean;
  // specialBondUpload: boolean;
  // specialBondFile: ApplicationFile;
  uploadCourtOrder: boolean;
  courtOrderFile: ApplicationFile;
  attorneyName: string;
  attorneyFirm: string;
  attorneyPhone: string;
  attorneyEmail: string;
  attorneyAddress: Address;
  court: CourtInformation;
}

@JsonObject('AppealsSupersedeasCourtApplicationImpl')
export class AppealsSupersedeasCourtApplicationImpl extends ApplicationDataImpl implements AppealsSupersedeasCourtApplication {
  @JsonProperty('federalOrState', String, true)
  federalOrState: string = null;

  @JsonProperty('companyOrIndividual', String, true)
  companyOrIndividual: CompanyOrIndividual = null;

  @JsonProperty('invoiceId', String, true)
  invoiceId: string = null;

  @JsonProperty('plaintiffs', String, true)
  plaintiffs: string = null;

  @JsonProperty('defendants', String, true)
  defendants: string = null;

  @JsonProperty('appelleeName', String, true)
  appelleeName: string = null;

  @JsonProperty('appellantName', String, true)
  appellantName: string = null;

  @JsonProperty('typeOfCollateral', String, true)
  typeOfCollateral: string = null;

  @JsonProperty('dateOfJudgmentOrOrder', CustomDateConverter, true)
  dateOfJudgmentOrOrder: Date = null;

  @JsonProperty('judgmentOrOrder', String, true)
  judgmentOrOrder: string = null;

  @JsonProperty('judgmentOrOrderAmount', CurrencyConverter, true)
  judgmentOrOrderAmount: string = null;

  // @JsonProperty('hearingScheduled', Boolean, true)
  // hearingScheduled: boolean = null;

  @JsonProperty('dateOfNextHearing', CustomDateConverter, true)
  dateOfNextHearing: Date = null;

  // @JsonProperty('typeOfOrderAppealed', String, true)
  // typeOfOrderAppealed: string = null;

  @JsonProperty('referralCode', String, true)
  referralCode: string = null;

  // @JsonProperty('specialBondForm', Boolean, true)
  // specialBondForm: boolean = null;

  // @JsonProperty('specialBondUpload', Boolean, true)
  // specialBondUpload: boolean = null;

  // @JsonProperty('specialBondFile', ApplicationFileImpl, true)
  // specialBondFile: ApplicationFile = new ApplicationFileImpl();

  @JsonProperty('uploadCourtOrder', Boolean, true)
  uploadCourtOrder: boolean = null;

  @JsonProperty('judgmentFile', ApplicationFileImpl, true)
  judgmentFile: ApplicationFile = new ApplicationFileImpl();

  @JsonProperty('uploadJudgment', Boolean, true)
  uploadJudgment: boolean = null;

  @JsonProperty('courtOrderFile', ApplicationFileImpl, true)
  courtOrderFile: ApplicationFile = new ApplicationFileImpl();

  @JsonProperty('attorneyName', String, true)
  attorneyName: string = null;

  @JsonProperty('attorneyFirm', String, true)
  attorneyFirm: string = null;

  @JsonProperty('attorneyPhone', PhoneNumberConverter, true)
  attorneyPhone: string = null;

  @JsonProperty('attorneyEmail', String, true)
  attorneyEmail: string = null;

  @JsonProperty('attorneyAddress', AddressImpl, true)
  attorneyAddress: Address = new AddressImpl();

  @JsonProperty('court', CourtInformationImpl, true)
  court: CourtInformation = new CourtInformationImpl();
}
