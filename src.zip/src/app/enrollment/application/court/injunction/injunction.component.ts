import { ApplicationBaseComponent } from '../../common/application-base-component';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormArrayMapper } from '../../common/form-array-mapper';
import { Component, Inject, ElementRef } from '@angular/core';
import { ApplicationService } from '../../application.service';
import { InjunctionFormArrayMapper } from './injunction-form-array-mapper.service';
import { SecurityService } from '../../../../security/security.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CourtBondType, isFiduciaryBondType } from '../../common/bond-types';
import { ServiceHandler } from '../../../../common/utils/service-handler.service';
import { GoogleTagManagerService } from '../../../../common/services/google-tag-manager.service';
import { ApplicationRoleService } from '../../../../common/services/application-role-service';
import { MatDialog } from '@angular/material';
import { CheckboxValidator } from '../../../../common/validators/checkbox-validator';
import { PatternValidators } from '../../../../common/validators/pattern-validators';
import { ConditionalValidator } from '../../../../common/validators/conditional-validator';
import { PaymentMethodSelectionFormGroup } from '../../../../common/payment-method-selection/payment-method-selection-form-group';
import { ControlValidator } from '../../common/control-validator';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { ValueMatchValidator } from '../../../../common/validators/value-match-validator';
import { PersonService } from '../../../../common/person-service';
import { CommonUtilities } from '../../../../common/utils/common-utilities';
import { PLAINTIFF_CHAR_LIMIT } from '../../../../common/utils/constants';
import { KnockoutQuestionsBaseComponent } from '../../common/knockout-questions-base.component';
import { DOCUMENT } from '@angular/common';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';
@Component({
  selector: 'app-injunction',
  templateUrl: './injunction.component.html',
})
export class InjunctionComponent extends KnockoutQuestionsBaseComponent {
  stepperFormArray: FormArray;
  private creditCheckWasRequired: boolean;
  plaintiff_char_limit = PLAINTIFF_CHAR_LIMIT;
  constructor(
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      new InjunctionFormArrayMapper(),
      applicationService,
      securityService,
      activatedRoute,
      router,
      CourtBondType.Injunction,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      elementRef,
      document,
      spinnerService
    );
  }

  get instanceofFiduciaryBondComponent(): boolean {
    return isFiduciaryBondType(this.bondType);
  }

  fiduciaryObligeeStateSelectorControl(): FormControl {
    return this.stepperFormArray
      .at(2)
      .get('court.address.state') as FormControl;
  }

  protected createNewApplication(): void {
    this.stepperFormArray = new FormArray([
      // Page 1: Qualifications
      new FormGroup(
        {
          applicantInfo: new FormGroup({
            applicantId: new FormControl(null),
            applicantName: new FormControl(null),
            applicantSalutation: new FormControl(null),
            applicantSuffix: new FormControl(null),
            applicantOfficePerson: new FormControl(null),
            applicantPhone: new FormControl(null),
            applicantFax: new FormControl(null),
            applicantEmail: new FormControl(null),
            applicantWebsite: new FormControl(null),
            applicantAddress: this.createApplicantAddressFormGroup(),
          }),
          companyOrIndividual: new FormControl(),
          knockedOut: new FormControl(null),
          knockoutQuestions: new FormGroup({
            exparteProcedure: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          }),
          // applicantSSNum: new FormControl({
          //   value: null,
          //   disabled: this.isSteward,
          // }),
          // creditCheckAuthorized: new FormControl(
          //   { value: false, disabled: this.isSteward },
          //   CheckboxValidator.requireTrue()
          // ),
          // creditScoreSatisfactory: new FormControl(null),
          // creditCheckSignatures: new FormGroup({
          //   signatureName: new FormControl({ disabled: true, value: null }),
          //   emailSignature: new FormControl(
          //     { value: null, disabled: this.isSteward },
          //     [this.requiredIfNotAgent, PatternValidators.email()]
          //   ),
          // }),
        }
        // {
        //   validators: [
        //     ValueMatchValidator.matchingValues(
        //       'applicantInfo.applicantEmail',
        //       'creditCheckSignatures.emailSignature',
        //       false,
        //       true
        //     ),
        //   ],
        // }
      ),
      // Page 2: Bond Details:
      new FormGroup({
        typeOfBond: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        jurisdiction: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        amountOfClaimOrDebt: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // usedInExParteProcedure: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // whyNotUsedInExParteProcedure: new FormControl({ value: null, disabled: this.isEmployee }, [Validators.maxLength(250)]),
        // injunctionDetails: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // injunctionDefersPayment: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // injunctionDeferredPaymentAmount: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // damagesClaimableInCaseOfImproperInjunction: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
      }),
      // Page 3: Bond Details Cont.
      new FormGroup({
        court: new FormGroup({
          caseNumber: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtName: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          presidingJudge: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtDistrict: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtCounty: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtPhone: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          address: this.createApplicationAddressFormGroup(),
        }),
        plaintiffs: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        attorneyName: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        attorneyFirm: new FormControl(),
        attorneyPhone: new FormControl(),
        attorneyEmail: new FormControl(),
        attorneyAddress: this.createRequiredAddressFormGroup(
          this.isEmployee,
          this.requiredIfNotAgent
        ),
        defendants: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        uploadCourtOrder: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        courtOrderFile: new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null),
        }),
        // specialBondForm: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // specialBondUpload: new FormControl({ value: null, disabled: this.isEmployee }),
        // specialBondFile: new FormGroup({
        //   id: new FormControl(null),
        //   name: new FormControl(null),
        // }),
      }),
      // Page 4: Delivery & Payment
      new FormGroup({
        deliveryMethod: this.createDeliveryInformationFormGroup(),
        paymentMethod: this.createPaymentInformationFormGroup(),
      }),
      // Page 5: Terms & Conditions
      new FormGroup({
        readAndAgreeToTerms: new FormControl(
          { value: false, disabled: this.isSteward || this.isEmployee },
          CheckboxValidator.requireTrue()
        ),
        declareTrue: new FormControl({
          value: false,
          disabled: this.isSteward || this.isEmployee,
        }),
        premiumAcknowledged: new FormControl(
          { value: false, disabled: this.isSteward || this.isEmployee },
          CheckboxValidator.requireTrue()
        ),
        agreementDate: new FormControl({ value: null, disabled: true }),
        indemnitor: new FormControl(null),
        indemnitorOfficePerson: new FormControl(null),
        indemnitorOfficePersonTitle: new FormControl(null),

        applicantSSNum: new FormControl({
          value: null,
          disabled: this.isSteward,
        }),
        creditCheckAuthorized: new FormControl(
          { value: false, disabled: this.isSteward }
          // CheckboxValidator.requireTrue()
        ),
        creditScoreSatisfactory: new FormControl(null),
        // creditCheckSignatures: new FormGroup({
        //   signatureName: new FormControl({ disabled: true, value: null }),
        //   emailSignature: new FormControl(
        //     { value: null, disabled: this.isSteward },
        //     [this.requiredIfNotAgent, PatternValidators.email()]
        //   ),
        // }),

        termsSignatures: new FormGroup({
          signatureName: new FormControl({ disabled: true, value: null }),
          emailSignature: new FormControl(
            { value: null, disabled: this.isSteward || this.isEmployee },
            [this.requiredIfNotAgent, PatternValidators.email()]
          ),
          companyEmailSignature: new FormControl(
            { value: null, disabled: this.isSteward || this.isEmployee },
            [this.requiredIfCompanyAndNotAgent, PatternValidators.email()]
          ),
        }),
        applicantCreditCheckAddress: new FormGroup({
          street1: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
          street2: new FormControl({ value: null, disabled: this.isEmployee }),
          city: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
          state: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
          zipCode: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
        }),
        creditCheckAddressSameAsApplicant: new FormControl(
          { value: false, disabled: this.isSteward || this.isEmployee }
        ),
      }),
    ]);

    if (this.isCompany) {
      this.stepperFormArray
        .at(4)
        .setValidators([
          ValueMatchValidator.matchValueToField(
            this.application.data.applicantEmail,
            'termsSignatures.emailSignature',
            false,
            true
          ),
          ValueMatchValidator.matchValueToField(
            this.application.data.applicantEmail,
            'termsSignatures.companyEmailSignature',
            false,
            true
          ),
        ]);
    } else {
      this.stepperFormArray
        .at(4)
        .setValidators([
          ValueMatchValidator.matchValueToField(
            this.application.data.applicantEmail,
            'termsSignatures.emailSignature',
            false,
            true
          ),
        ]);
    }

    this.addConditionalValidation();
  }

  private addConditionalValidation(): void {
    const and = (a, b) => () => a() && b();

    const isClient = () => !(this.isSteward || this.isEmployee);

    // this.setConditionalValidator(this.whyNotUsedInExParteProcedure, [
    //   Validators.maxLength(250),
    //   ConditionalValidator.conditionalRequire(
    //     and(() => !this.usedInExParteProcedure.value, isClient)
    //   )]
    // );

    // this.updateOnChangeEvents(this.usedInExParteProcedure, this.whyNotUsedInExParteProcedure);

    // this.usedInExParteProcedure.valueChanges.subscribe(b => {
    //   if (b) { this.whyNotUsedInExParteProcedure.setValue(null, { onlySelf: true, emitEvent: false }); }
    // });

    // this.setConditionalValidator(this.injunctionDeferredPaymentAmount, ConditionalValidator.conditionalRequire(
    //   and(() => !!this.injunctionDefersPayment.value, isClient)
    // ));

    // this.updateOnChangeEvents(this.injunctionDefersPayment, this.injunctionDeferredPaymentAmount);

    // this.injunctionDefersPayment.valueChanges.subscribe(b => {
    //   if (b) { this.injunctionDeferredPaymentAmount.setValue(null, { onlySelf: true, emitEvent: false }); }
    // });

    // this.registerFileTypeFileUploadActiveSubject('specialBondFile', this.specialBondFile);
    this.registerFileTypeFileUploadActiveSubject(
      'courtOrderFile',
      this.courtOrderFile
    );

    // delivery method conditional validation
    const deliveryMethodSetAndIsNotEmailCondition = this.notStewardAnd(
      this.isSetAndNotEqualTo('Email', this.deliveryMethod)
    );

    this.setConditionalValidators([
      {
        formControl: this.deliveryName,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
        ],
      },
      {
        formControl: this.deliveryPhone,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
        ],
      },
      {
        formControl: this.deliveryAddressStreet1,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
          Validators.maxLength(60),
        ],
      },
      {
        formControl: this.deliveryAddressZipCode,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
          PatternValidators.zipCode(),
        ],
      },
      {
        formControl: this.deliveryAddressCity,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
          Validators.maxLength(30),
        ],
      },
      {
        formControl: this.deliveryAddressState,
        validators: [
          ConditionalValidator.conditionalRequire(
            deliveryMethodSetAndIsNotEmailCondition
          ),
        ],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.deliveryMethod, [
      this.deliveryName,
      this.deliveryPhone,
      this.deliveryAddressStreet1,
      this.deliveryAddressZipCode,
      this.deliveryAddressCity,
      this.deliveryAddressState,
    ]);

    // court order is required if the user selects upload
    const uploadCourtOrderCondition = this.notStewardAnd(
      () => this.uploadCourtOrder.value
    );
    this.setConditionalValidators([
      {
        formControl: this.courtOrderFile.get('id') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(uploadCourtOrderCondition),
        ],
      },
      {
        formControl: this.courtOrderFile.get('name') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(uploadCourtOrderCondition),
        ],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.uploadCourtOrder, [
      this.courtOrderFile.get('id') as FormControl,
      this.courtOrderFile.get('name') as FormControl,
    ]);
  }

  patchValueForSsnAddress() {
    const updatedApplicantForm = this.qualificationsFormGroup.controls['applicantInfo'];
    const ssnAddressUpdate = this.stepperFormArray.controls[4];
    if (!this.applicantInfoFormGroup.value.applicantOfficePerson) {
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.patchValue({
        street1: updatedApplicantForm['controls'].applicantAddress['controls'].street1.value,
        street2: updatedApplicantForm['controls'].applicantAddress['controls'].street2.value,
        city: updatedApplicantForm['controls'].applicantAddress['controls'].city.value,
        state: updatedApplicantForm['controls'].applicantAddress['controls'].state.value,
        zipCode: updatedApplicantForm['controls'].applicantAddress['controls'].zipCode.value,
      });
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street1').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street2').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('city').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('state').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('zipCode').disable();
    }
  }

  patchValueForBillingAddress() {
    const updatedBillingForm = this.qualificationsFormGroup.controls['applicantInfo'];
    const updatedDeliveryAddress: FormGroup = this.stepperFormArray.controls[3]['controls'].deliveryMethod.controls.deliveryAddress;
    const updatedBillingAddress: FormGroup = this.stepperFormArray.controls[3]['controls'].paymentMethod.billingAddressGroup;
    updatedBillingAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
    updatedDeliveryAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
  }

  async stepSelectionChange(event: StepperSelectionEvent) {
    this.validatePage(event.selectedIndex);
    if (event.selectedIndex === 4) {
      this.patchValueForSsnAddress();
    }
    if (event.selectedIndex === 3) {
      this.patchValueForBillingAddress();
    }
    if (event.previouslySelectedIndex === 0 && event.selectedIndex === 1) {
      if (this.qualificationsFormGroup.valid || this.isSteward) {
        if (this.creditCheckWasRequired) {
          await this.saveApplication('Saving Form...');
          this.creditCheckWasRequired = false;
        } else {
          await this.saveApplication('Saving Form...');
        }
        // this.applicantSSNum.clearValidators();
        this.applicantSSNum.updateValueAndValidity();
        this.creditCheckAuthorized.clearValidators();
        this.creditCheckAuthorized.updateValueAndValidity();
      }

      CommonUtilities.markAllTouched(this.qualificationsFormGroup);
    } else {
      await super.stepSelectionChange(event);
    }
    // if (this.isSteward || this.isCreditScoreSatisfactory) {
    //   [
    //     this.applicantSSNum,
    //     this.creditCheckAuthorized,
    //     // this.creditCheckEmailSignature,
    //   ].forEach((c) => {
    //     if (c.value) {
    //       c.disable();
    //     }
    //   });
    // }
    this.determineTypeOfClient();
    // if (event.selectedIndex !== 0) {
    //   this.googleTagManagerService.sendEvent(
    //     `court-bond-app-step-${event.selectedIndex}`,
    //     this.bondType,
    //     this.premium,
    //     this.userType
    //   );
    // }
    const gtmBondType = this.applicationService.setBondType(this.bondType);
    const user = this.securityService.user;
    const userType = user
      ? user.hasAttorneyRole
        ? 'attorney'
        : user.userRoles[0].userRoleRef.role
      : 'anonymous';
    const paymentType = this.application['data'].paymentMethod.paymentChannelCode ?
      this.application['data'].paymentMethod.paymentChannelCode.cardValidatorType : '';
    if (event.selectedIndex === 1) {
      this.PageGtmEvent(
        'court-bond-app-details1',
        gtmBondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    }
    if (event.selectedIndex === 2) {
      this.PageGtmEvent(
        'court-bond-app-details2',
        gtmBondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    }
    if (event.selectedIndex === 3) {
      this.PageGtmEvent(
        'court-bond-app-delivery',
        gtmBondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    }
    if (event.selectedIndex === 4) {
      this.termsAndConditionEvent(
        'court-bond-app-terms',
        gtmBondType,
        this.application.premium,
        userType,
        '',
        '',
        this.application.quoteId,
        'new',
        this.application.id,
        paymentType
      );
    }
  }

  otherPrequalificationPageFormFields(): FormControl[] {
    return [
      // this.creditCheckAuthorized,
      // this.creditCheckEmailSignature,
    ];
  }

  private notStewardAnd(condFn: () => boolean): () => boolean {
    return () => !this.isSteward && condFn();
  }

  private isSetAndNotEqualTo(value: any, control: FormControl): () => boolean {
    return () => !!control.value && control.value !== value;
  }

  disableFormArrayInputs(): void { }

  creditCheckIsRequiredHandler(event: boolean) {
    this.creditCheckWasRequired = event;
  }

  // get pageOneIsValid(): () => boolean {
  //   return () => this.qualificationsFormGroup.valid;
  // }

  get isLinear(): boolean {
    return !this.isSteward && !this.qualificationsFormGroup.valid;
  }

  get qualificationsFormGroup(): FormGroup {
    return this.stepperFormArray.at(0) as FormGroup;
  }

  // get applicantSSNum(): FormControl {
  //   return this.qualificationsFormGroup.get('applicantSSNum') as FormControl;
  // }

  get applicantSSNum(): FormControl {
    return this.termsAndConditionsFormGroup.get('applicantSSNum') as FormControl;
  }

  get creditCheckAuthorized(): FormControl {
    return this.termsAndConditionsFormGroup.get(
      'creditCheckAuthorized'
    ) as FormControl;
  }

  // get creditCheckEmailSignature(): FormControl {
  //   return this.termsAndConditionsFormGroup.get(
  //     'creditCheckSignatures.emailSignature'
  //   ) as FormControl;
  // }

  get knockoutQuestionFormGroup(): FormGroup {
    return this.qualificationsFormGroup.get('knockoutQuestions') as FormGroup;
  }

  get applicantInfoFormGroup(): FormGroup {
    return this.qualificationsFormGroup.get('applicantInfo') as FormGroup;
  }

  get bondDetailsFormGroup(): FormGroup {
    return this.stepperFormArray.at(1) as FormGroup;
  }

  get typeOfBond(): FormControl {
    return this.bondDetailsFormGroup.get('typeOfBond') as FormControl;
  }

  get jurisdiction(): FormControl {
    return this.bondDetailsFormGroup.get('jurisdiction') as FormControl;
  }

  get amountOfClaimOrDebt(): FormControl {
    return this.bondDetailsFormGroup.get('amountOfClaimOrDebt') as FormControl;
  }

  get exparteProcedure(): FormControl {
    return this.knockoutQuestionFormGroup.get('exparteProcedure') as FormControl;
  }

  // get usedInExParteProcedure(): FormControl {
  //   return this.bondDetailsFormGroup.get(
  //     'usedInExParteProcedure'
  //   ) as FormControl;
  // }

  // get whyNotUsedInExParteProcedure(): FormControl {
  //   return this.bondDetailsFormGroup.get('whyNotUsedInExParteProcedure') as FormControl;
  // }

  // get injunctionDetails(): FormControl {
  //   return this.bondDetailsFormGroup.get('injunctionDetails') as FormControl;
  // }

  // get injunctionDefersPayment(): FormControl {
  //   return this.bondDetailsFormGroup.get('injunctionDefersPayment') as FormControl;
  // }

  // get injunctionDeferredPaymentAmount(): FormControl {
  //   return this.bondDetailsFormGroup.get('injunctionDeferredPaymentAmount') as FormControl;
  // }

  // get damagesClaimableInCaseOfImproperInjunction(): FormControl {
  //   return this.bondDetailsFormGroup.get('damagesClaimableInCaseOfImproperInjunction') as FormControl;
  // }

  get bondDetailsContinuedFormGroup(): FormGroup {
    return this.stepperFormArray.at(2) as FormGroup;
  }

  get courtInformationFormGroup(): FormGroup {
    return this.bondDetailsContinuedFormGroup.get('court') as FormGroup;
  }

  get plaintiffs(): FormControl {
    return this.bondDetailsContinuedFormGroup.get('plaintiffs') as FormControl;
  }

  get attorneyName(): FormControl {
    return this.bondDetailsContinuedFormGroup.get(
      'attorneyName'
    ) as FormControl;
  }

  get attorneyAddress(): FormGroup {
    return this.bondDetailsContinuedFormGroup.get(
      'attorneyAddress'
    ) as FormGroup;
  }

  get defendants(): FormControl {
    return this.bondDetailsContinuedFormGroup.get('defendants') as FormControl;
  }

  get courtOrderFormGroup(): FormGroup {
    return this.bondDetailsContinuedFormGroup;
  }

  get courtOrderFile(): FormGroup {
    return this.courtOrderFormGroup.get('courtOrderFile') as FormGroup;
  }

  get uploadCourtOrder(): FormControl {
    return this.bondDetailsContinuedFormGroup.get(
      'uploadCourtOrder'
    ) as FormControl;
  }

  // get specialBondFileFormGroup(): FormGroup {
  //   return this.bondDetailsContinuedFormGroup;
  // }

  // get specialBondFile(): FormGroup {
  //   return this.specialBondFileFormGroup.get('specialBondFile') as FormGroup;
  // }

  get deliveryAndPaymentFormGroup(): FormGroup {
    return this.stepperFormArray.at(3) as FormGroup;
  }

  get deliveryMethodFormGroup(): FormGroup {
    return this.deliveryAndPaymentFormGroup.get('deliveryMethod') as FormGroup;
  }

  get deliveryName(): FormControl {
    return this.deliveryMethodFormGroup.get('deliveryName') as FormControl;
  }

  get deliveryPhone(): FormControl {
    return this.deliveryMethodFormGroup.get('deliveryPhone') as FormControl;
  }

  get deliveryAddressStreet1(): FormControl {
    return this.deliveryMethodFormGroup.get(
      'deliveryAddress.street1'
    ) as FormControl;
  }

  get deliveryAddressZipCode(): FormControl {
    return this.deliveryMethodFormGroup.get(
      'deliveryAddress.zipCode'
    ) as FormControl;
  }

  get deliveryAddressCity(): FormControl {
    return this.deliveryMethodFormGroup.get(
      'deliveryAddress.city'
    ) as FormControl;
  }

  get deliveryAddressState(): FormControl {
    return this.deliveryMethodFormGroup.get(
      'deliveryAddress.state'
    ) as FormControl;
  }

  get deliveryMethod(): FormControl {
    return this.deliveryMethodFormGroup.get('deliveryMethod') as FormControl;
  }

  get paymentMethodFormGroup(): PaymentMethodSelectionFormGroup {
    return this.deliveryAndPaymentFormGroup.get(
      'paymentMethod'
    ) as PaymentMethodSelectionFormGroup;
  }

  get termsAndConditionsFormGroup(): FormGroup {
    return this.stepperFormArray.at(4) as FormGroup;
  }

  get termsSignaturesFormGroup(): FormGroup {
    return this.termsAndConditionsFormGroup.get('termsSignatures') as FormGroup;
  }

  get emailSignature(): FormControl {
    return this.termsSignaturesFormGroup.get('emailSignature') as FormControl;
  }

  protected get formArrayMapper(): FormArrayMapper[] {
    return [];
  }

  protected get paymentInformationFormGroup(): FormGroup {
    return undefined;
  }

  PageGtmEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup,
    lpBond,
    quoteId?,
    bondClass?,
    applicationID?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }

  termsAndConditionEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup,
    lpBond,
    quoteId?,
    bondClass?,
    applicationID?,
    paymentType?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`,
      `${paymentType}`
    );
  }

  validatePage(index) {
    if (index === 0) {
      CommonUtilities.markAllTouched(this.stepperFormArray.at(0));
    }
  }

}
