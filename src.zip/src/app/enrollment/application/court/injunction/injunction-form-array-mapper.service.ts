import { AbstractFormArrayMapper } from '../../common/abstract-form-array-mapper.service';
import { Injectable } from '@angular/core';
import {
  InjunctionCourtApplication,
  InjunctionCourtApplicationImpl,
} from '../model/injunction-court-application';
import { DeliveryMethodImpl } from '../model/common/delivery-method';
import { PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';

@Injectable()
export class InjunctionFormArrayMapper extends AbstractFormArrayMapper {

  constructor() {
    super();
  }

  public formArrayJsonToObject(formArrayJson: any): InjunctionCourtApplication {
    const application: InjunctionCourtApplicationImpl = new InjunctionCourtApplicationImpl();

    const [
      qualificationsQuestions,
      bondDetails1,
      bondDetails2,
      paymentAndDelivery,
      termsAndConditions,
    ] = formArrayJson;

    // Page 1 : Qualifications Questions
    application.applicantId = qualificationsQuestions.applicantInfo.applicantId;
    application.applicantName = qualificationsQuestions.applicantInfo.applicantName;
    application.applicantSalutation = qualificationsQuestions.applicantInfo.applicantSalutation;
    application.applicantSuffix = qualificationsQuestions.applicantInfo.applicantSuffix;
    application.applicantOfficePerson = qualificationsQuestions.applicantInfo.applicantOfficePerson;
    application.applicantPhone = qualificationsQuestions.applicantInfo.applicantPhone;
    application.applicantFax = qualificationsQuestions.applicantInfo.applicantFax;
    application.applicantEmail = qualificationsQuestions.applicantInfo.applicantEmail;
    application.applicantWebsite = qualificationsQuestions.applicantInfo.applicantWebsite;
    application.applicantAddress.street1 =
      qualificationsQuestions.applicantInfo.applicantAddress ? qualificationsQuestions.applicantInfo.applicantAddress.street1 : null;
    application.applicantAddress.street2 =
      qualificationsQuestions.applicantInfo.applicantAddress ? qualificationsQuestions.applicantInfo.applicantAddress.street2 : null;
    application.applicantAddress.city =
      qualificationsQuestions.applicantInfo.applicantAddress ? qualificationsQuestions.applicantInfo.applicantAddress.city : null;
    application.applicantAddress.state =
      qualificationsQuestions.applicantInfo.applicantAddress ? qualificationsQuestions.applicantInfo.applicantAddress.state : null;
    application.applicantAddress.zipCode =
      qualificationsQuestions.applicantInfo.applicantAddress ? qualificationsQuestions.applicantInfo.applicantAddress.zipCode : null;

    application.knockedOut = qualificationsQuestions.knockedOut;
    application.knockoutQuestions.push(
      this.createDynamicQuestionForField('exparteProcedure', qualificationsQuestions.knockoutQuestions.exparteProcedure)
    );
    application.companyOrIndividual = qualificationsQuestions.companyOrIndividual;

    // application.applicantSSNum = qualificationsQuestions.applicantSSNum;
    // application.creditCheckAuthorized = qualificationsQuestions.creditCheckAuthorized;
    // application.creditScoreSatisfactory = qualificationsQuestions.creditScoreSatisfactory;

    // application.creditCheckEmail =
    //   qualificationsQuestions.creditCheckSignatures ? qualificationsQuestions.creditCheckSignatures.emailSignature : null;
    // application.creditCheckSignature =
    //   qualificationsQuestions.applicantInfo.applicantName;

    // Page 2 : Bond Details
    application.typeOfBond = bondDetails1.typeOfBond;
    application.jurisdiction = bondDetails1.jurisdiction;
    application.amountOfClaimOrDebt = bondDetails1.amountOfClaimOrDebt;

    // Page 3 : Bonds Details Contd
    const { court } = bondDetails2;
    application.court.caseNumber = court.caseNumber;
    application.court.courtName = court.courtName;
    application.court.presidingJudge = court.presidingJudge;
    application.court.courtCounty = court.courtCounty;
    application.court.courtPhone = court.courtPhone;
    application.court.address.street1 = court.address ? court.address.street1 : null;
    application.court.address.street2 = court.address ? court.address.street2 : null;
    application.court.address.city = court.address ? court.address.city : null;
    application.court.address.state = court.address ? court.address.state : null;
    application.court.address.zipCode = court.address ? court.address.zipCode : null;
    application.court.courtDistrict = court.courtDistrict;

    application.plaintiffs = bondDetails2.plaintiffs;
    application.attorneyName = bondDetails2.attorneyName;
    application.attorneyFirm = bondDetails2.attorneyFirm;
    application.attorneyPhone = bondDetails2.attorneyPhone;
    application.attorneyEmail = bondDetails2.attorneyEmail;

    application.attorneyAddress.street1 = bondDetails2.attorneyAddress.street1;
    application.attorneyAddress.street2 = bondDetails2.attorneyAddress.street2;
    application.attorneyAddress.zipCode = bondDetails2.attorneyAddress.zipCode;
    application.attorneyAddress.city = bondDetails2.attorneyAddress.city;
    application.attorneyAddress.state = bondDetails2.attorneyAddress.state;

    application.defendants = bondDetails2.defendants;
    application.uploadCourtOrder = bondDetails2.uploadCourtOrder;
    application.courtOrderFile.id = bondDetails2.courtOrderFile ? bondDetails2.courtOrderFile.id : null;
    application.courtOrderFile.name = bondDetails2.courtOrderFile ? bondDetails2.courtOrderFile.name : null;

    // Page 4: Delivery & Payment
    const deliveryMethod = paymentAndDelivery.deliveryMethod;
    application.deliveryMethod = new DeliveryMethodImpl();
    this.populateDeliveryMethod(application.deliveryMethod, deliveryMethod);
    application.paymentMethod = paymentAndDelivery.paymentMethod;

    // Page 5: Terms & Conditions
    application.termsAndConditions.readAndAgreeToTerms = termsAndConditions.readAndAgreeToTerms;
    application.termsAndConditions.declareTrue = termsAndConditions.declareTrue;
    application.termsAndConditions.indemnitor = qualificationsQuestions.applicantInfo.applicantName;
    application.termsAndConditions.agreementDate = new Date();
    application.termsAndConditions.emailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.emailSignature : null;
    application.termsAndConditions.signatureName = termsAndConditions.termsSignatures.signatureName;
    application.termsAndConditions.companyEmailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.companyEmailSignature : null;
    application.termsAndConditions.premiumAcknowledged = termsAndConditions.premiumAcknowledged;
    application.applicantOfficePersonTitle = termsAndConditions.indemnitorOfficePersonTitle;
    application.applicantOfficePerson = termsAndConditions.indemnitorOfficePerson;

    application.applicantSSNum = termsAndConditions.applicantSSNum;
    application.creditCheckAuthorized = termsAndConditions.creditCheckAuthorized;
    application.creditScoreSatisfactory = termsAndConditions.creditScoreSatisfactory;
    application.creditCheckEmail =
      termsAndConditions.creditCheckSignatures ? termsAndConditions.creditCheckSignatures.emailSignature : null;
    application.creditCheckSignature =
      qualificationsQuestions.applicantInfo.applicantName;
    application.applicantCreditCheckAddress = {
      street1: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street1 : null,
      street2: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street2 : null,
      city: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.city : null,
      state: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.state : null,
      zipCode: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.zipCode : null,
    };
    application.creditCheckAddressSameAsApplicant = termsAndConditions.creditCheckAddressSameAsApplicant;

    return application;
  }

  objectToFormArrayJson(application: InjunctionCourtApplication): any {
    return [
      {
        // Page 1: Qualifications
        applicantInfo: {
          applicantId: application.applicantId,
          applicantName: application.applicantName,
          applicantSalutation: application.applicantSalutation,
          applicantSuffix: application.applicantSuffix,
          applicantOfficePerson: application.applicantOfficePerson,
          applicantOfficePersonTitle: application.applicantOfficePersonTitle,
          applicantEmail: application.applicantEmail,
          applicantPhone: application.applicantPhone,
          applicantFax: application.applicantFax,
          applicantWebsite: application.applicantWebsite,
          applicantAddress: {
            street1: application.applicantAddress ? application.applicantAddress.street1 : null,
            street2: application.applicantAddress ? application.applicantAddress.street2 : null,
            zipCode: application.applicantAddress ? application.applicantAddress.zipCode : null,
            city: application.applicantAddress ? application.applicantAddress.city : null,
            state: application.applicantAddress ? application.applicantAddress.state : null,
          },
        },
        companyOrIndividual: application.companyOrIndividual,
        knockedOut: application.knockedOut,
        knockoutQuestions: {
          exparteProcedure: this.getValueFromDynamicQuestions('exparteProcedure', application.knockoutQuestions),
          // exparteProcedure:  application.knockoutQuestions,
        },
      },
      {
        // Page 2: Bond Details
        typeOfBond: application.typeOfBond,
        jurisdiction: application.jurisdiction,
        amountOfClaimOrDebt: application.amountOfClaimOrDebt,
        // usedInExParteProcedure,
        // whyNotUsedInExParteProcedure,
        // injunctionDetails,
        // injunctionDefersPayment,
        // injunctionDeferredPaymentAmount,
        // damagesClaimableInCaseOfImproperInjunction,
      },
      {
        // Page 3: Bond Details Continued
        court: {
          caseNumber: application.court ? application.court.caseNumber : null,
          courtName: application.court ? application.court.courtName : null,
          presidingJudge: application.court ? application.court.presidingJudge : null,
          courtCounty: application.court ? application.court.courtCounty : null,
          courtPhone: application.court ? application.court.courtPhone : null,
          address: {
            street1: application.court ? application.court.address.street1 : null,
            street2: application.court ? application.court.address.street2 : null,
            city: application.court ? application.court.address.city : null,
            state: application.court ? application.court.address.state : null,
            zipCode: application.court ? application.court.address.zipCode : null,
          },
          courtDistrict: application.court ? application.court.courtDistrict : null,
        },
        plaintiffs: application.plaintiffs,
        attorneyName: application.attorneyName,
        attorneyFirm: application.attorneyFirm,
        attorneyPhone: application.attorneyPhone,
        attorneyEmail: application.attorneyEmail,
        attorneyAddress: {
          street1: application.attorneyAddress ? application.attorneyAddress.street1 : null,
          street2: application.attorneyAddress ? application.attorneyAddress.street2 : null,
          zipCode: application.attorneyAddress ? application.attorneyAddress.zipCode : null,
          city: application.attorneyAddress ? application.attorneyAddress.city : null,
          state: application.attorneyAddress ? application.attorneyAddress.state : null,
        },
        defendants: application.defendants,
        uploadCourtOrder: application.uploadCourtOrder,
        courtOrderFile: {
          id: application.courtOrderFile ? application.courtOrderFile.id : null,
          name: application.courtOrderFile ? application.courtOrderFile.name : null,
        },
        // specialBondForm, specialBondUpload,
        // specialBondFile: specialBondFile || new ApplicationFileImpl(),
      },
      {
        // Page 4: Delivery & Payment
        deliveryMethod: this.createDeliveryMethodFormGroupPatchValues(application.deliveryMethod),
        paymentMethod: application.paymentMethod,
      },
      {
        // Page 5: Terms & Conditions
        readAndAgreeToTerms: application.termsAndConditions ? application.termsAndConditions.readAndAgreeToTerms : false,
        declareTrue: application.termsAndConditions ? application.termsAndConditions.declareTrue : false,
        agreementDate: new Date(),
        indemnitor: application.applicantName,
        indemnitorOfficePerson: application.applicantOfficePerson ? application.applicantOfficePerson : null,
        indemnitorOfficePersonTitle: application.applicantOfficePersonTitle ? application.applicantOfficePersonTitle : null,
        premiumAcknowledged: application.termsAndConditions.premiumAcknowledged,
        creditScoreSatisfactory: application.creditScoreSatisfactory,
        applicantSSNum: application.applicantSSNum,
        creditCheckAuthorized: application.creditCheckAuthorized,
        creditCheckSignatures: {
          signatureName: application.applicantName,
          emailSignature: application.creditCheckEmail,
        },
        termsSignatures: {
          companyEmailSignature: application.termsAndConditions.companyEmailSignature,
          signatureName: application.termsAndConditions.signatureName,
          emailSignature: application.termsAndConditions.emailSignature,
        },
        applicantCreditCheckAddress: {
          street1: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['street1'] : null,
          street2: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['street2'] : null,
          city: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['city'] : null,
          state: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['state'] : null,
          zipCode: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['zipCode'] : null,
        },
        creditCheckAddressSameAsApplicant: application.creditCheckAddressSameAsApplicant,
      },
    ];
  }
}
