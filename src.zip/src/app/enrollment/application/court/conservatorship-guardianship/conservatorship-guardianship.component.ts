import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { ApplicationService } from '../../application.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArrayMapper } from '../../common/form-array-mapper';
import { ConservatorshipGuardianshipFormArrayMapper } from './conservatorship-guardianship-form-array-mapper.service';
import { SecurityService } from '../../../../security/security.service';
import { PatternValidators } from '../../../../common/validators/pattern-validators';
import { ValueMatchValidator } from '../../../../common/validators/value-match-validator';
import { CheckboxValidator } from '../../../../common/validators/checkbox-validator';
import { ConditionalValidator } from '../../../../common/validators/conditional-validator';
import { ControlValidator } from '../../common/control-validator';
import { MultipleFieldValidators } from '../../../../common/validators/multiple-field-validators';
import { distinctUntilChanged } from 'rxjs/operators';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { ServiceHandler } from '../../../../common/utils/service-handler.service';
import {
  ApplicationBaseComponent,
  PAYMENT_INFORMATION_FORM_GROUP_NAME,
} from '../../common/application-base-component';
import { GoogleTagManagerService } from '../../../../common/services/google-tag-manager.service';
import { CommonUtilities } from '../../../../common/utils/common-utilities';
import { ApplicationRoleService } from '../../../../common/services/application-role-service';
import { MatDialog } from '@angular/material';
import { FiduciaryBondComponent } from '../../common/fiduciary-bond.component';
import { CourtBondType, isFiduciaryBondType } from '../../common/bond-types';
import { PersonService } from '../../../../common/person-service';
import { DOCUMENT } from '@angular/common';
import { Inject, ElementRef } from '@angular/core';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

export type CgFiduciaryType = 'Conservator' | 'Guardian';

export abstract class ConservatorshipGuardianshipComponent extends ApplicationBaseComponent implements FiduciaryBondComponent {
  stepperFormArray: FormArray;
  creditCheckWasRequired: boolean;
  protected constructor(
    public fiduciaryType: CgFiduciaryType,
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    bondType: CourtBondType,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      new ConservatorshipGuardianshipFormArrayMapper(),
      applicationService,
      securityService,
      activatedRoute,
      router,
      bondType,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      document,
      elementRef,
      spinnerService
    );
  }

  get instanceofFiduciaryBondComponent(): boolean {
    return isFiduciaryBondType(this.bondType);
  }

  fiduciaryObligeeStateSelectorControl(): FormControl {
    return this.stepperFormArray
      .at(1)
      .get('courtInformation.address.state') as FormControl;
  }

  // specialBondFormControl(): FormControl {
  //   return this.stepperFormArray.at(2).get('specialBondForm') as FormControl;
  // }

  createNewApplication() {
    this.stepperFormArray = new FormArray([
      // Page 1: Applicant Info and Knockout questions
      new FormGroup(
        {
          applicantInfo: new FormGroup({
            applicantId: new FormControl(null),
            applicantName: new FormControl(null),
            applicantSalutation: new FormControl(null),
            applicantSuffix: new FormControl(null),
            applicantOfficePerson: new FormControl(null),
            applicantPhone: new FormControl(null),
            applicantFax: new FormControl(null),
            applicantEmail: new FormControl(null),
            applicantWebsite: new FormControl(null),
            applicantAddress: this.createApplicantAddressFormGroup(),
          }),
          knockedOut: new FormControl(null),
          // creditScoreSatisfactory: new FormControl(null),
          // applicantSSNum: new FormControl({
          //   value: null,
          //   disabled: this.isSteward || this.isEmployee,
          // }),
          // creditCheckAuthorized: new FormControl(
          //   { value: false, disabled: this.isSteward || this.isEmployee },
          //   CheckboxValidator.requireTrue()
          // ),
          // creditCheckSignatures: new FormGroup({
          //   signatureName: new FormControl({ disabled: true, value: null }),
          //   emailSignature: new FormControl(
          //     { value: null, disabled: this.isSteward || this.isEmployee },
          //     [this.requiredIfNotAgent, PatternValidators.email()]
          //   ),
          // }),
        }
        // {
        //   validators: [
        //     ValueMatchValidator.matchingValues(
        //       'applicantInfo.applicantEmail',
        //       'creditCheckSignatures.emailSignature',
        //       false,
        //       true
        //     ),
        //   ],
        // }
      ),
      // Page 2: Bond Details
      new FormGroup({
        occupation: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        annualIncome: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        maritalStatus: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        applicantSpouse: new FormControl({
          value: null,
          disabled: this.isEmployee,
        }),
        courtInformation: new FormGroup({
          caseNumber: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtName: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          presidingJudge: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtCounty: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          courtPhone: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          address: this.createApplicationAddressFormGroup(),
        }),
        appointment: new FormGroup(
          {
            appointmentDate: new FormControl({
              value: null,
              disabled: this.isEmployee,
            }),
            futureAppointmentWillNotify: new FormControl({
              value: null,
              disabled: this.isEmployee,
            }),
          },
          {
            validators: [
              ConditionalValidator.conditionalValidator(
                () => !this.isSteward,
                MultipleFieldValidators.exactlyOneRequired([
                  'appointmentDate',
                  'futureAppointmentWillNotify',
                ])
              ),
            ],
          }
        ),
        appointmentType: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        minorIncompetentList: new FormArray([]),
      }),
      // Page 3: Payment and Delivery
      new FormGroup({
        uploadCourtOrder: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        courtOrderFile: new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null),
        }),
        // specialBondForm: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // specialBondUpload: new FormControl({ value: null, disabled: this.isEmployee }),
        // specialBondFile: new FormGroup({
        //   id: new FormControl(null),
        //   name: new FormControl(null),
        // }),
        uploadPersonal: new FormControl(
          { value: null, disabled: this.isEmployee },
          this.requiredIfNotAgent
        ),
        personalFinancialFile: new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null),
        }),
        applicantFinancialInfo: new FormGroup({
          assetsCash: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          // assetsNotes: new FormControl({
          //   value: null,
          //   disabled: this.isEmployee,
          // }),
          assetsBonds: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          assetsRealEstate: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          assetsOther: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          // liabilityNotes: new FormControl({
          //   value: null,
          //   disabled: this.isEmployee,
          // }),
          liabilityCreditBalance: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          liabilityTaxes: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          liabilityMortgage: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          liabilityOther: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          assetsTotal: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          liabilityTotal: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          networth: new FormControl({ value: null, disabled: this.isEmployee }),
        }),
        deliveryInformation: this.createDeliveryInformationFormGroup(),
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: this.createPaymentInformationFormGroup(),
      }),
      // Page 4: Terms and conditions
      new FormGroup(
        {
          readAndAgreeToTerms: new FormControl(
            { value: false, disabled: this.isSteward || this.isEmployee },
            CheckboxValidator.requireTrue()
          ),
          declareTrue: new FormControl({
            value: false,
            disabled: this.isSteward || this.isEmployee,
          }),
          premiumAcknowledged: new FormControl(
            { value: false, disabled: this.isSteward || this.isEmployee },
            CheckboxValidator.requireTrue()
          ),
          agreementDate: new FormControl({ value: null, disabled: true }),
          indemnitor: new FormControl(null),
          creditScoreSatisfactory: new FormControl(null),
          applicantSSNum: new FormControl({
            value: null,
            disabled: this.isSteward || this.isEmployee,
          }),
          creditCheckAuthorized: new FormControl(
            { value: false, disabled: this.isSteward || this.isEmployee }
            // CheckboxValidator.requireTrue()
          ),
          // creditCheckSignatures: new FormGroup({
          //   signatureName: new FormControl({ disabled: true, value: null }),
          //   emailSignature: new FormControl(
          //     { value: null, disabled: this.isSteward || this.isEmployee },
          //     [this.requiredIfNotAgent, PatternValidators.email()]
          //   ),
          // }),
          termsSignatures: new FormGroup({
            signatureName: new FormControl({ disabled: true, value: null }),
            emailSignature: new FormControl(
              { value: null, disabled: this.isSteward || this.isEmployee },
              [this.requiredIfNotAgent, PatternValidators.email()]
            ),
            companyEmailSignature: new FormControl(
              { value: null, disabled: this.isSteward || this.isEmployee },
              [this.requiredIfCompanyAndNotAgent, PatternValidators.email()]
            ),
          }),
          applicantCreditCheckAddress: new FormGroup({
            street1: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
            street2: new FormControl({ value: null, disabled: this.isEmployee }),
            city: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
            state: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
            zipCode: new FormControl({ value: null, disabled: this.isEmployee },
              this.requiredIfNotAgent),
          }),
          creditCheckAddressSameAsApplicant: new FormControl(
            { value: false, disabled: this.isSteward || this.isEmployee }
          ),
        },
        {
          validators: [
            ValueMatchValidator.matchValueToField(
              this.application.data.applicantEmail,
              'termsSignatures.emailSignature',
              false,
              true
            ),
          ],
        }
      ),
    ]);
    this.addConditionalValidation();

    this.registerFileUploadControls();
  }

  protected otherPrequalificationPageFormFields(): FormControl[] {
    return [
      // this.applicantSSNum,
      // this.creditCheckAuthorization,
      // this.creditCheckEmailSignature,
    ];
  }

  get isLinear(): boolean {
    return !this.isSteward && !this.preliminaryQuestionFormGroup.valid;
  }

  // pageOneIsValid(): boolean {
  //   return this.preliminaryQuestionFormGroup.valid;
  // }

  /**
   * Indicate that the various file uploads should be managed wrt/ 'obsolete' uploaded files
   * if the FileUploadMode is no longer fileUpload.
   */
  private registerFileUploadControls() {
    // this.registerFileTypeFileUploadActiveSubject('specialBondFile', this.specialBondFile);
    this.registerFileTypeFileUploadActiveSubject(
      'courtOrderFile',
      this.courtOrderFile
    );
    this.registerFileTypeFileUploadActiveSubject(
      'personalFinancialFile',
      this.personalFinancialFile
    );
  }

  addConditionalValidation(): void {
    // spouse name is required if the person is married
    this.setConditionalValidator(
      this.applicantSpouse,
      ConditionalValidator.conditionalRequire(
        () => !this.isSteward && this.maritalStatus.value === 'Married'
      )
    );
    this.updateOnChangeEvents(this.maritalStatus, this.applicantSpouse);

    // court order is required if the user selects upload
    this.setConditionalValidators([
      {
        formControl: this.courtOrderFile.get('id') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadCourtOrder.value
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.courtOrderFile.get('name') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadCourtOrder.value
          ),
        ],
      } as ControlValidator,
    ]);
    this.updateOnChangeEvents(this.uploadCourtOrder, [
      this.courtOrderFile.get('id') as FormControl,
      this.courtOrderFile.get('name') as FormControl,
    ]);

    // special common upload is required if special common form is true
    // this.setConditionalValidator(this.specialBondUpload,
    //   ConditionalValidator.conditionalRequire(() => !this.isSteward && this.specialBondForm.value));
    // this.updateOnChangeEvents(this.specialBondForm, this.specialBondUpload);

    // this.setConditionalValidators([
    //   {
    //     formControl: this.specialBondFile.get('id') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.specialBondUpload.value)],
    //   } as ControlValidator,
    //   {
    //     formControl: this.specialBondFile.get('name') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(() => !this.isSteward && this.specialBondUpload.value)],
    //   } as ControlValidator,
    // ]);
    // this.updateOnChangeEvents(this.specialBondUpload, [
    //   this.specialBondFile.get('id') as FormControl,
    //   this.specialBondFile.get('name') as FormControl,
    // ]);

    // personal financial file
    this.setConditionalValidators([
      {
        formControl: this.personalFinancialFile.get('id') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.personalFinancialFile.get('name') as FormControl,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value
          ),
        ],
      } as ControlValidator,
    ]);
    this.updateOnChangeEvents(this.uploadPersonal, [
      this.personalFinancialFile.get('id') as FormControl,
      this.personalFinancialFile.get('name') as FormControl,
    ]);

    // fill in personal financial info
    this.setConditionalValidators([
      {
        formControl: this.assetsCash,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
      // {
      //   formControl: this.assetsNotes,
      //   validators: [
      //     ConditionalValidator.conditionalRequire(
      //       () => !this.isSteward && this.uploadPersonal.value === false
      //     ),
      //   ],
      // } as ControlValidator,
      {
        formControl: this.assetsBonds,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.assetsRealEstate,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.assetsOther,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
      // {
      //   formControl: this.liabilityNotes,
      //   validators: [
      //     ConditionalValidator.conditionalRequire(
      //       () => !this.isSteward && this.uploadPersonal.value === false
      //     ),
      //   ],
      // } as ControlValidator,
      {
        formControl: this.liabilityCreditBalance,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.liabilityTaxes,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.liabilityMortgage,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.liabilityOther,
        validators: [
          ConditionalValidator.conditionalRequire(
            () => !this.isSteward && this.uploadPersonal.value === false
          ),
        ],
      } as ControlValidator,
    ]);

    this.updateOnChangeEvents(this.uploadPersonal, [
      this.assetsCash,
      // this.assetsNotes,
      this.assetsBonds,
      this.assetsRealEstate,
      this.assetsOther,
      // this.liabilityNotes,
      this.liabilityCreditBalance,
      this.liabilityTaxes,
      this.liabilityMortgage,
      this.liabilityOther,
    ]);

    // delivery method conditional validation
    this.setConditionalValidators([
      {
        formControl: this.deliveryName,
        validators: [
          ConditionalValidator.conditionalRequire(
            () =>
              !this.isSteward &&
              !!this.deliveryMethod.value &&
              this.deliveryMethod.value !== 'Email'
          ),
        ],
      } as ControlValidator,
      {
        formControl: this.deliveryPhone,
        validators: [
          ConditionalValidator.conditionalRequire(
            () =>
              !this.isSteward &&
              !!this.deliveryMethod.value &&
              this.deliveryMethod.value !== 'Email'
          ),
          PatternValidators.phoneNumber(),
        ],
      } as ControlValidator,
      {
        formControl: this.deliveryAddressStreet1,
        validators: [
          ConditionalValidator.conditionalRequire(
            () =>
              !this.isSteward &&
              !!this.deliveryMethod.value &&
              this.deliveryMethod.value !== 'Email'
          ),
          Validators.maxLength(60),
        ],
      } as ControlValidator,
      {
        formControl: this.deliveryAddressZipCode,
        validators: [
          ConditionalValidator.conditionalRequire(
            () =>
              !this.isSteward &&
              !!this.deliveryMethod.value &&
              this.deliveryMethod.value !== 'Email'
          ),
          PatternValidators.zipCode(),
        ],
      } as ControlValidator,
      {
        formControl: this.deliveryAddressCity,
        validators: [
          ConditionalValidator.conditionalRequire(
            () =>
              !this.isSteward &&
              !!this.deliveryMethod.value &&
              this.deliveryMethod.value !== 'Email'
          ),
          Validators.maxLength(30),
        ],
      } as ControlValidator,
      {
        formControl: this.deliveryAddressState,
        validators: [
          ConditionalValidator.conditionalRequire(
            () =>
              !this.isSteward &&
              !!this.deliveryMethod.value &&
              this.deliveryMethod.value !== 'Email'
          ),
        ],
      } as ControlValidator,
    ]);
    this.updateOnChangeEvents(this.deliveryMethod, [
      this.deliveryName,
      this.deliveryPhone,
      this.deliveryAddressStreet1,
      this.deliveryAddressZipCode,
      this.deliveryAddressCity,
      this.deliveryAddressState,
    ]);
  }

  /**
   * This form array mapper is the mapper for all of the FormArrays in the stepperFormArray (ex. service providers on page 2)
   * Though I may try to think of a simpler way of implementing this... here's how it goes:
   * The array index is to match the pageIndex where the list is.
   * If you have 4 separate lists on page 3, then you'll put all 4 FormArrayMappers in the element at index 2 (for page 3)
   * A FormArrayMapper is just a string (the json variable name) that maps to a FormGroup/FormControl.  The FormGroup should be a single
   * empty FormGroup that makes up the elements of your array.  So in the example below, I have a list of servie providers on the second
   * page.  So I know that it needs to go in the array at index 1 (this is why the first is empty).  I know my FormArray is named
   * "serviceProviders", so I am mapping the name serviceProviders to an instance of a blank service provider that will populate the array.
   */

  get formArrayMapper(): FormArrayMapper[] {
    return [
      {} as FormArrayMapper,
      {
        serviceProviders: new FormGroup({
          name: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          phone: new FormControl({ value: null, disabled: this.isEmployee }, [
            this.requiredIfNotAgent,
            PatternValidators.phoneNumber(),
          ]),
          email: new FormControl({ value: null, disabled: this.isEmployee }, [
            this.requiredIfNotAgent,
            PatternValidators.email(),
          ]),
          address: this.createApplicationAddressFormGroup(),
        }),
        minorIncompetentList: new FormGroup({
          minor: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          birthday: new FormControl({ value: null, disabled: this.isEmployee }),
          dateDeclaredIncompetent: new FormControl({
            value: null,
            disabled: this.isEmployee,
          }),
          minorName: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          relationshipToMinor: new FormControl(
            { value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent
          ),
          // residence: new FormControl(
          //   { value: null, disabled: this.isEmployee },
          //   this.requiredIfNotAgent
          // ),
          // health: new FormControl(
          //   { value: null, disabled: this.isEmployee },
          //   this.requiredIfNotAgent
          // ),
        }),
      } as FormArrayMapper,
    ];
  }

  disableFormArrayInputs() {
    if (this.isEmployee) {
      this.minorIncompetentFormArray.controls.forEach((group: FormGroup) => {
        group.disable();
      });
    }
  }

  resetAttorney() {
    this.bondDetailsFormGroup.get('attorneyInvolved').reset();
    this.bondDetailsFormGroup.get('attorneyName').reset();
    this.bondDetailsFormGroup.get('attorneyFirm').reset();
    this.bondDetailsFormGroup.get('attorneyPhone').reset();
    this.bondDetailsFormGroup.get('attorneyAddress').reset();
  }

  patchValueForSsnAddress() {
    const updatedApplicantForm = this.preliminaryQuestionFormGroup.controls['applicantInfo'];
    const ssnAddressUpdate = this.stepperFormArray.controls[3];
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.patchValue({
      street1: updatedApplicantForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedApplicantForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedApplicantForm['controls'].applicantAddress['controls'].city.value,
      state: updatedApplicantForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedApplicantForm['controls'].applicantAddress['controls'].zipCode.value,
    });
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street1').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street2').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('city').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('state').disable();
    ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('zipCode').disable();
  }

  patchValueForBillingAddress() {
    const updatedBillingForm = this.preliminaryQuestionFormGroup.controls['applicantInfo'];
    const updatedDeliveryAddress: FormGroup = this.stepperFormArray.controls[2]['controls'].deliveryInformation.controls.deliveryAddress;
    const updatedBillingAddress: FormGroup = this.stepperFormArray.controls[2]['controls'].paymentInformation.controls.billingAddressGroup;
    updatedBillingAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
    updatedDeliveryAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
  }

  async stepSelectionChange(event: StepperSelectionEvent) {
    this.validatePage(event.selectedIndex);
    if (event.selectedIndex === 3) {
      this.patchValueForSsnAddress();
    }
    if (event.selectedIndex === 2) {
      this.patchValueForBillingAddress();
    }
    // knockout question page change is different from the rest
    if (event.previouslySelectedIndex === 0 && event.selectedIndex === 1) {
      if (this.preliminaryQuestionFormGroup.valid || this.isSteward) {
        if (this.creditCheckWasRequired) {
          await this.saveApplication('Saving Form...');
          this.creditCheckWasRequired = false;
        } else {
          await this.saveApplication('Saving Form...');
        }
        // this.applicantSSNum.clearValidators();
        this.applicantSSNum.updateValueAndValidity();
        this.creditCheckAuthorization.clearValidators();
        this.creditCheckAuthorization.updateValueAndValidity();
      }

      // ... and mark all of the formControls as touched to 'activate' the validators.
      // Many of the validators are inactive until the controls have been 'touched'.
      CommonUtilities.markAllTouched(this.preliminaryQuestionFormGroup);
    } else {
      await super.stepSelectionChange(event);
    }

    this.sendCourtBondsAppSteptEvent(event);
  }

  sendCourtBondsAppSteptEvent(event: StepperSelectionEvent) {
    this.determineTypeOfClient();
    // if (event.selectedIndex !== 0) {
    //   this.googleTagManagerService.sendEvent(
    //     `court-bond-app-step-${event.selectedIndex}`,
    //     `${this.bondType}`,
    //     `${this.premium}`,
    //     `${this.userType}`
    //   );
    // }
    const user = this.securityService.user;
    const userType = user
      ? user.hasAttorneyRole
        ? 'attorney'
        : user.userRoles[0].userRoleRef.role
      : 'anonymous';
    const paymentType = this.application['data'].paymentMethod.paymentChannelCode ?
      this.application['data'].paymentMethod.paymentChannelCode.cardValidatorType : '';
    if (event.selectedIndex === 1) {
      this.bondDetailsPageGtmEvent(
        'court-bond-app-details1',
        this.bondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    } else if (event.selectedIndex === 2) {
      this.PageGtmEvent(
        'court-bond-app-delivery',
        this.bondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    } else if (event.selectedIndex === 3) {
      this.termsAndConditionEvent(
        'court-bond-app-terms',
        this.bondType,
        this.application.premium,
        userType,
        '',
        '',
        this.application.quoteId,
        'new',
        this.application.id,
        paymentType
      );
    }

  }

  creditCheckIsRequiredHandler(event) {
    this.creditCheckWasRequired = event;
  }

  /**
   * Page 1: KO and Applicant Info
   */

  get preliminaryQuestionFormGroup(): FormGroup {
    return this.stepperFormArray.at(0) as FormGroup;
  }

  get knockoutQuestionFormGroup(): FormGroup {
    return this.preliminaryQuestionFormGroup.get(
      'knockoutQuestions'
    ) as FormGroup;
  }

  get applicantInfoFormGroup(): FormGroup {
    return this.preliminaryQuestionFormGroup.get('applicantInfo') as FormGroup;
  }

  get applicantSSNum(): FormControl {
    return this.termsAndConditionsFormGroup.get(
      'applicantSSNum'
    ) as FormControl;
  }

  // get creditCheckSignatureFormGroup(): FormGroup {
  //   return this.termsAndConditionsFormGroup.get(
  //     'creditCheckSignatures'
  //   ) as FormGroup;
  // }

  get creditCheckAuthorization(): FormControl {
    return this.termsAndConditionsFormGroup.get(
      'creditCheckAuthorized'
    ) as FormControl;
  }

  get creditCheckEmailSignature(): FormControl {
    return this.termsAndConditionsFormGroup.get(
      'emailSignature'
    ) as FormControl;
  }

  /**
   * Page 2: Bond Details
   */

  get bondDetailsFormGroup(): FormGroup {
    return this.stepperFormArray.at(1) as FormGroup;
  }

  get occupation(): FormControl {
    return this.bondDetailsFormGroup.get('occupation') as FormControl;
  }

  get annualIncome(): FormControl {
    return this.bondDetailsFormGroup.get('annualIncome') as FormControl;
  }

  get courtInformationFormGroup(): FormGroup {
    return this.bondDetailsFormGroup.get('courtInformation') as FormGroup;
  }

  get appointmentType(): FormControl {
    return this.bondDetailsFormGroup.get('appointmentType') as FormControl;
  }

  get minorIncompetentFormArray(): FormArray {
    return this.bondDetailsFormGroup.get('minorIncompetentList') as FormArray;
  }

  get appointmentFormGroup(): FormGroup {
    return this.bondDetailsFormGroup.get('appointment') as FormGroup;
  }

  get appointmentDate(): FormControl {
    return this.appointmentFormGroup.get('appointmentDate') as FormControl;
  }

  get futureAppointmentWillNotify(): FormControl {
    return this.appointmentFormGroup.get(
      'futureAppointmentWillNotify'
    ) as FormControl;
  }

  get applicantSpouse(): FormControl {
    return this.bondDetailsFormGroup.get('applicantSpouse') as FormControl;
  }

  get maritalStatus(): FormControl {
    return this.bondDetailsFormGroup.get('maritalStatus') as FormControl;
  }

  /**
   * Page 3: Payment and Delivery Info
   */

  get paymentAndDeliveryFormGroup(): FormGroup {
    return this.stepperFormArray.at(2) as FormGroup;
  }

  get paymentInformationFormGroup(): FormGroup {
    return this.paymentAndDeliveryFormGroup.get(
      PAYMENT_INFORMATION_FORM_GROUP_NAME
    ) as FormGroup;
  }

  get deliveryInformationFormGroup(): FormGroup {
    return this.paymentAndDeliveryFormGroup.get(
      'deliveryInformation'
    ) as FormGroup;
  }

  get deliveryMethod(): FormControl {
    return this.deliveryInformationFormGroup.get(
      'deliveryMethod'
    ) as FormControl;
  }

  get copyViaEmail(): FormControl {
    return this.deliveryInformationFormGroup.get('copyViaEmail') as FormControl;
  }

  get deliveryName(): FormControl {
    return this.deliveryInformationFormGroup.get('deliveryName') as FormControl;
  }

  get deliveryPhone(): FormControl {
    return this.deliveryInformationFormGroup.get(
      'deliveryPhone'
    ) as FormControl;
  }

  get deliveryAddress(): FormGroup {
    return this.deliveryInformationFormGroup.get(
      'deliveryAddress'
    ) as FormGroup;
  }

  get deliveryAddressStreet1(): FormControl {
    return this.deliveryAddress.get('street1') as FormControl;
  }

  get deliveryAddressCity(): FormControl {
    return this.deliveryAddress.get('city') as FormControl;
  }

  get deliveryAddressState(): FormControl {
    return this.deliveryAddress.get('state') as FormControl;
  }

  get deliveryAddressZipCode(): FormControl {
    return this.deliveryAddress.get('zipCode') as FormControl;
  }

  get uploadCourtOrder(): FormControl {
    return this.paymentAndDeliveryFormGroup.get(
      'uploadCourtOrder'
    ) as FormControl;
  }

  get courtOrderFile(): FormGroup {
    return this.paymentAndDeliveryFormGroup.get('courtOrderFile') as FormGroup;
  }

  // get specialBondForm(): FormControl {
  //   return this.paymentAndDeliveryFormGroup.get('specialBondForm') as FormControl;
  // }

  // get specialBondUpload(): FormControl {
  //   return this.paymentAndDeliveryFormGroup.get('specialBondUpload') as FormControl;
  // }

  // get specialBondFile(): FormGroup {
  //   return this.paymentAndDeliveryFormGroup.get('specialBondFile') as FormGroup;
  // }

  get uploadPersonal(): FormControl {
    return this.paymentAndDeliveryFormGroup.get(
      'uploadPersonal'
    ) as FormControl;
  }

  get personalFinancialFile(): FormGroup {
    return this.paymentAndDeliveryFormGroup.get(
      'personalFinancialFile'
    ) as FormGroup;
  }

  get applicantFinancialInfo(): FormGroup {
    return this.paymentAndDeliveryFormGroup.get(
      'applicantFinancialInfo'
    ) as FormGroup;
  }

  get assetsCash(): FormControl {
    return this.applicantFinancialInfo.get('assetsCash') as FormControl;
  }

  // get assetsNotes(): FormControl {
  //   return this.applicantFinancialInfo.get('assetsNotes') as FormControl;
  // }

  get assetsBonds(): FormControl {
    return this.applicantFinancialInfo.get('assetsBonds') as FormControl;
  }

  get assetsRealEstate(): FormControl {
    return this.applicantFinancialInfo.get('assetsRealEstate') as FormControl;
  }

  get assetsOther(): FormControl {
    return this.applicantFinancialInfo.get('assetsOther') as FormControl;
  }

  // get liabilityNotes(): FormControl {
  //   return this.applicantFinancialInfo.get('liabilityNotes') as FormControl;
  // }

  get liabilityCreditBalance(): FormControl {
    return this.applicantFinancialInfo.get(
      'liabilityCreditBalance'
    ) as FormControl;
  }

  get liabilityTaxes(): FormControl {
    return this.applicantFinancialInfo.get('liabilityTaxes') as FormControl;
  }

  get liabilityMortgage(): FormControl {
    return this.applicantFinancialInfo.get('liabilityMortgage') as FormControl;
  }

  get liabilityOther(): FormControl {
    return this.applicantFinancialInfo.get('liabilityOther') as FormControl;
  }

  /**
   * Page 4: Terms and Conditions
   */

  get termsAndConditionsFormGroup(): FormGroup {
    return this.stepperFormArray.at(3) as FormGroup;
  }

  get termsSignaturesFormGroup(): FormGroup {
    return this.termsAndConditionsFormGroup.get('termsSignatures') as FormGroup;
  }

  get emailSignature(): FormControl {
    return this.termsSignaturesFormGroup.get('emailSignature') as FormControl;
  }

  // get signatureName(): FormControl {
  //   return this.creditCheckSignatureFormGroup.get('signatureName') as FormControl;
  // }

  bondDetailsPageGtmEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup?,
    lpBond?,
    quoteId?,
    bondClass?,
    applicationID?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }

  PageGtmEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup?,
    lpBond?,
    quoteId?,
    bondClass?,
    applicationID?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }

  termsAndConditionEvent(
    event,
    bondType,
    bondPremium,
    userType,
    lpGroup?,
    lpBond?,
    quoteId?,
    bondClass?,
    applicationID?,
    paymentType?
  ) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`,
      `${paymentType}`
    );
  }

  validatePage(index) {
    if (index === 0) {
      CommonUtilities.markAllTouched(this.stepperFormArray.at(0));
    }
  }

}
