import { Component, Inject, ElementRef } from '@angular/core';
import { ConservatorshipGuardianshipComponent } from '../conservatorship-guardianship.component';
import { ApplicationService } from '../../../application.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../../../../security/security.service';
import { ServiceHandler } from '../../../../../common/utils/service-handler.service';
import { GoogleTagManagerService } from '../../../../../common/services/google-tag-manager.service';
import { ApplicationRoleService } from '../../../../../common/services/application-role-service';
import { MatDialog } from '@angular/material';
import { PersonService } from '../../../../../common/person-service';
import { CourtBondType } from '../../../common/bond-types';
import { DOCUMENT } from '@angular/common';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

@Component({
  selector: 'app-guardianship',
  templateUrl: '../conservatorship-guardianship.component.html',
  styleUrls: ['../conservatorship-guardianship.component.css'],
  providers: [ApplicationRoleService],
})
export class GuardianshipComponent extends ConservatorshipGuardianshipComponent {
  constructor(
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      'Guardian',
      applicationService,
      securityService,
      activatedRoute,
      router,
      CourtBondType.Guardianship,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      elementRef,
      document,
      spinnerService
    );
  }
}
