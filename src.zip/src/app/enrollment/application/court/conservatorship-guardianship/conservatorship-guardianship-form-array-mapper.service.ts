import { AbstractFormArrayMapper } from '../../common/abstract-form-array-mapper.service';
import { Injectable } from '@angular/core';
import { ConservatorshipGuardianshipApplicationImpl } from '../model/conservatorship-guardianship-application';
import { ServiceProviderImpl } from '../model/common/service-provider';
import { DeliveryMethodImpl } from '../model/common/delivery-method';
import { MinorInfoImpl } from '../model/common/minor-info';
import * as moment from 'moment';
import { PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';

@Injectable()
export class ConservatorshipGuardianshipFormArrayMapper extends AbstractFormArrayMapper {
  constructor() {
    super();
  }

  public formArrayJsonToObject(formArrayJson: any): ConservatorshipGuardianshipApplicationImpl {
    const application: ConservatorshipGuardianshipApplicationImpl = new ConservatorshipGuardianshipApplicationImpl();
    const [preliminaryQuestions, bondDetails, paymentAndDelivery, termsAndConditions] = formArrayJson;
    // Page 1: Knockout questions and Applicant info
    application.applicantEmail = preliminaryQuestions.applicantInfo.applicantEmail;
    application.applicantId = preliminaryQuestions.applicantInfo.applicantId;
    application.applicantPhone = preliminaryQuestions.applicantInfo.applicantPhone;
    application.applicantName = preliminaryQuestions.applicantInfo.applicantName;
    application.applicantSalutation = preliminaryQuestions.applicantInfo.applicantSalutation;
    application.applicantSuffix = preliminaryQuestions.applicantInfo.applicantSuffix;
    application.applicantFax = preliminaryQuestions.applicantInfo.applicantFax;
    application.applicantAddress.street1 =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.street1 : null;
    application.applicantAddress.street2 =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.street2 : null;
    application.applicantAddress.city =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.city : null;
    application.applicantAddress.state =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.state : null;
    application.applicantAddress.zipCode =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.zipCode : null;
    application.premiumRateId = preliminaryQuestions.premiumRateId;
    application.knockedOut = preliminaryQuestions.knockedOut;

    // application.creditScoreSatisfactory = preliminaryQuestions.creditScoreSatisfactory;
    // application.applicantSSNum = preliminaryQuestions.applicantSSNum;
    // application.creditCheckAuthorized = preliminaryQuestions.creditCheckAuthorized;
    // application.creditCheckEmail =
    //   preliminaryQuestions.creditCheckSignatures ? preliminaryQuestions.creditCheckSignatures.emailSignature : null;
    // application.creditCheckSignature =
    //   preliminaryQuestions.applicantInfo.applicantName;

    // Page 2: Bond Details
    for (const minor of bondDetails.minorIncompetentList) {
      const minorIncompetentImpl: MinorInfoImpl = new MinorInfoImpl();
      minorIncompetentImpl.minor = minor.minor;
      minorIncompetentImpl.birthday = minor.birthday;
      minorIncompetentImpl.dateDeclaredIncompetent = minor.dateDeclaredIncompetent;
      minorIncompetentImpl.minorName = minor.minorName;
      minorIncompetentImpl.relationshipToMinor = minor.relationshipToMinor;
      // minorIncompetentImpl.residence = minor.residence;
      // minorIncompetentImpl.health = minor.health;
      application.minors.push(minorIncompetentImpl);
    }
    application.attorneyName = bondDetails.attorneyName;
    application.attorneyFirm = bondDetails.attorneyFirm;
    application.attorneyPhone = bondDetails.attorneyPhone;
    application.attorneyEmail = bondDetails.attorneyEmail;
    application.attorneyAddress.street1 = bondDetails.attorneyAddress ? bondDetails.attorneyAddress.street1 : null;
    application.attorneyAddress.street2 = bondDetails.attorneyAddress ? bondDetails.attorneyAddress.street2 : null;
    application.attorneyAddress.zipCode = bondDetails.attorneyAddress ? bondDetails.attorneyAddress.zipCode : null;
    application.attorneyAddress.city = bondDetails.attorneyAddress ? bondDetails.attorneyAddress.city : null;
    application.attorneyAddress.state = bondDetails.attorneyAddress ? bondDetails.attorneyAddress.state : null;
    application.occupation = bondDetails.occupation;
    application.annualIncome = bondDetails.annualIncome;
    application.maritalStatus = bondDetails.maritalStatus;
    application.applicantSpouse = bondDetails.applicantSpouse;
    const courtInformation = bondDetails.courtInformation;
    application.court.caseNumber = courtInformation.caseNumber;
    application.court.courtName = courtInformation.courtName;
    application.court.presidingJudge = courtInformation.presidingJudge;
    application.court.courtCounty = courtInformation.courtCounty;
    application.court.courtPhone = courtInformation.courtPhone;
    application.court.address.street1 = courtInformation.address ? courtInformation.address.street1 : null;
    application.court.address.street2 = courtInformation.address ? courtInformation.address.street2 : null;
    application.court.address.city = courtInformation.address ? courtInformation.address.city : null;
    application.court.address.state = courtInformation.address ? courtInformation.address.state : null;
    application.court.address.zipCode = courtInformation.address ? courtInformation.address.zipCode : null;
    application.appointmentDate = bondDetails.appointment.appointmentDate;
    application.futureAppointmentWillNotify = bondDetails.appointment.futureAppointmentWillNotify;
    application.appointmentType = bondDetails.appointmentType;

    // Page 3: Payment and Delivery
    application.uploadCourtOrder = paymentAndDelivery.uploadCourtOrder;
    application.courtOrderFile.id = paymentAndDelivery.courtOrderFile.id;
    application.courtOrderFile.name = paymentAndDelivery.courtOrderFile.name;
    // application.specialBondForm = paymentAndDelivery.specialBondForm;
    // application.specialBondUpload = paymentAndDelivery.specialBondUpload;
    // application.specialBondFile.id = paymentAndDelivery.specialBondFile.id;
    // application.specialBondFile.name = paymentAndDelivery.specialBondFile.name;
    // financial info
    application.uploadPersonal = paymentAndDelivery.uploadPersonal;
    application.personalFinancialFile.id = paymentAndDelivery.personalFinancialFile.id;
    application.personalFinancialFile.name = paymentAndDelivery.personalFinancialFile.name;

    application.assetsCash = paymentAndDelivery.applicantFinancialInfo.assetsCash;
    // application.assetsNotes = paymentAndDelivery.applicantFinancialInfo.assetsNotes;
    application.assetsBonds = paymentAndDelivery.applicantFinancialInfo.assetsBonds;
    application.assetsRealEstate = paymentAndDelivery.applicantFinancialInfo.assetsRealEstate;
    application.assetsOther = paymentAndDelivery.applicantFinancialInfo.assetsOther;
    // application.liabilityNotes = paymentAndDelivery.applicantFinancialInfo.liabilityNotes;
    application.liabilityCreditBalance = paymentAndDelivery.applicantFinancialInfo.liabilityCreditBalance;
    application.liabilityTaxes = paymentAndDelivery.applicantFinancialInfo.liabilityTaxes;
    application.liabilityMortgage = paymentAndDelivery.applicantFinancialInfo.liabilityMortgage;
    application.liabilityOther = paymentAndDelivery.applicantFinancialInfo.liabilityOther;
    application.assetsTotal = paymentAndDelivery.applicantFinancialInfo.assetsTotal;
    application.liabilityTotal = paymentAndDelivery.applicantFinancialInfo.liabilityTotal;
    application.networth = paymentAndDelivery.applicantFinancialInfo.networth;

    const deliveryInformation = paymentAndDelivery.deliveryInformation;

    // Delivery Method
    application.deliveryMethod = new DeliveryMethodImpl();
    this.populateDeliveryMethod(application.deliveryMethod, deliveryInformation);

    // Payment Method will already have been converted to an instance of PaymentMethod via PaymentMethodSelectionFormGroup.getRawValue().
    application.paymentMethod = paymentAndDelivery[PAYMENT_INFORMATION_FORM_GROUP_NAME];

    // Page 4: Terms and Conditions
    application.termsAndConditions.readAndAgreeToTerms = termsAndConditions.readAndAgreeToTerms;
    application.termsAndConditions.declareTrue = termsAndConditions.declareTrue;
    application.termsAndConditions.agreementDate = moment().toDate();
    application.termsAndConditions.indemnitor = preliminaryQuestions.applicantInfo.applicantName;
    application.termsAndConditions.emailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.emailSignature : null;
    application.termsAndConditions.signatureName = preliminaryQuestions.applicantInfo.applicantName;
    application.termsAndConditions.companyEmailSignature = termsAndConditions.termsSignatures.companyEmailSignature;
    application.termsAndConditions.premiumAcknowledged = termsAndConditions.premiumAcknowledged;

    application.creditScoreSatisfactory = termsAndConditions.creditScoreSatisfactory;
    application.applicantSSNum = termsAndConditions.applicantSSNum;
    application.creditCheckAuthorized = termsAndConditions.creditCheckAuthorized;
    application.creditCheckEmail =
      termsAndConditions.creditCheckSignatures ? termsAndConditions.creditCheckSignatures.emailSignature : null;
    application.creditCheckSignature =
      preliminaryQuestions.applicantInfo.applicantName;
    application.applicantCreditCheckAddress = {
      street1: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street1 : null,
      street2: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street2 : null,
      city: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.city : null,
      state: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.state : null,
      zipCode: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.zipCode : null,
    };
    application.creditCheckAddressSameAsApplicant = termsAndConditions.creditCheckAddressSameAsApplicant;

    return application;
  }

  public objectToFormArrayJson(object: ConservatorshipGuardianshipApplicationImpl): any {
    return [
      // Page 1: knockout questions and applicant info
      {
        applicantInfo: {
          applicantId: object.applicantId,
          applicantName: object.applicantName,
          applicantSalutation: object.applicantSalutation,
          applicantSuffix: object.applicantSuffix,
          applicantEmail: object.applicantEmail,
          applicantFax: object.applicantFax,
          applicantPhone: object.applicantPhone,
          applicantAddress: {
            street1: object.applicantAddress ? object.applicantAddress.street1 : null,
            street2: object.applicantAddress ? object.applicantAddress.street2 : null,
            zipCode: object.applicantAddress ? object.applicantAddress.zipCode : null,
            city: object.applicantAddress ? object.applicantAddress.city : null,
            state: object.applicantAddress ? object.applicantAddress.state : null,
          },
        },
        premiumRateId: object.premiumRateId,
        knockedOut: object.knockedOut,
        // creditScoreSatisfactory: object.creditScoreSatisfactory,
        // applicantSSNum: object.applicantSSNum,
        // creditCheckAuthorized: object.creditCheckAuthorized,
        // creditCheckSignatures: {
        //   signatureName: object.applicantName,
        //   emailSignature: object.creditCheckEmail,
        // },
      },
      // Page 2: Bond details
      {
        occupation: object.occupation,
        annualIncome: object.annualIncome,
        maritalStatus: object.maritalStatus,
        applicantSpouse: object.applicantSpouse,
        courtInformation: {
          caseNumber: object.court ? object.court.caseNumber : null,
          courtName: object.court ? object.court.courtName : null,
          presidingJudge: object.court ? object.court.presidingJudge : null,
          courtCounty: object.court ? object.court.courtCounty : null,
          courtPhone: object.court ? object.court.courtPhone : null,
          address: {
            street1: object.court && object.court.address ? object.court.address.street1 : null,
            street2: object.court && object.court.address ? object.court.address.street2 : null,
            city: object.court && object.court.address ? object.court.address.city : null,
            state: object.court && object.court.address ? object.court.address.state : null,
            zipCode: object.court && object.court.address ? object.court.address.zipCode : null,
          },
        },
        appointment: {
          appointmentDate: object.appointmentDate,
          futureAppointmentWillNotify: object.futureAppointmentWillNotify,
        },
        appointmentType: object.appointmentType,
        minorIncompetentList: object.minors,
      },
      // Page 3: Payment Method and Delivery Info
      {
        uploadCourtOrder: object.uploadCourtOrder,
        courtOrderFile: {
          id: object.courtOrderFile ? object.courtOrderFile.id : null,
          name: object.courtOrderFile ? object.courtOrderFile.name : null,
        },
        // specialBondForm: object.specialBondForm,
        // specialBondUpload: object.specialBondUpload,
        // specialBondFile: {
        //   id: object.specialBondFile ? object.specialBondFile.id : null,
        //   name: object.specialBondFile ? object.specialBondFile.name : null,
        // },
        uploadPersonal: object.uploadPersonal,
        personalFinancialFile: {
          id: object.personalFinancialFile ? object.personalFinancialFile.id : null,
          name: object.personalFinancialFile ? object.personalFinancialFile.name : null,
        },
        applicantFinancialInfo: {
          assetsCash: object.assetsCash,
          // assetsNotes: object.assetsNotes,
          assetsBonds: object.assetsBonds,
          assetsRealEstate: object.assetsRealEstate,
          assetsOther: object.assetsOther,
          // liabilityNotes: object.liabilityNotes,
          liabilityCreditBalance: object.liabilityCreditBalance,
          liabilityTaxes: object.liabilityTaxes,
          liabilityMortgage: object.liabilityMortgage,
          liabilityOther: object.liabilityOther,
          assetsTotal: object.assetsTotal,
          liabilityTotal: object.liabilityTotal,
          networth: object.networth,
        },
        deliveryInformation: this.createDeliveryMethodFormGroupPatchValues(object.deliveryMethod),

        // The Payment FormGroup will generate the patchValues itself from the paymentMethod.
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: object.paymentMethod,
      },
      // Page 4: Terms and conditions
      {
        readAndAgreeToTerms: object.termsAndConditions ? object.termsAndConditions.readAndAgreeToTerms : false,
        declareTrue: object.termsAndConditions ? object.termsAndConditions.declareTrue : false,
        agreementDate: object.termsAndConditions ? object.termsAndConditions.agreementDate : null,
        indemnitor: object.applicantName,
        premiumAcknowledged: object.termsAndConditions.premiumAcknowledged,
        creditScoreSatisfactory: object.creditScoreSatisfactory,
        applicantSSNum: object.applicantSSNum,
        creditCheckAuthorized: object.creditCheckAuthorized,
        creditCheckSignatures: {
          signatureName: object.applicantName,
          emailSignature: object.creditCheckEmail,
        },
        termsSignatures: {
          companyEmailSignature: object.termsAndConditions.companyEmailSignature,
          signatureName: object.applicantName,
          emailSignature: object.termsAndConditions.emailSignature,
        },
        applicantCreditCheckAddress: {
          street1: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['street1'] : null,
          street2: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['street2'] : null,
          city: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['city'] : null,
          state: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['state'] : null,
          zipCode: object.applicantCreditCheckAddress ? object.applicantCreditCheckAddress['zipCode'] : null,
        },
        creditCheckAddressSameAsApplicant: object.creditCheckAddressSameAsApplicant,
      },
    ];
  }
}
