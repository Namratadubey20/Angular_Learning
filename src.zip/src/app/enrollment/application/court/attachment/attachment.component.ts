import { Component, Inject, ElementRef } from '@angular/core';
import { ApplicationBaseComponent, PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormArrayMapper } from '../../common/form-array-mapper';
import { ApplicationService } from '../../application.service';
import { SecurityService } from '../../../../security/security.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceHandler } from '../../../../common/utils/service-handler.service';
import { GoogleTagManagerService } from '../../../../common/services/google-tag-manager.service';
import { ApplicationRoleService } from '../../../../common/services/application-role-service';
import { MatDialog } from '@angular/material';
import { AttachmentFormArrayMapperService } from './attachment-form-array-mapper.service';
import { CheckboxValidator } from '../../../../common/validators/checkbox-validator';
import { PatternValidators } from '../../../../common/validators/pattern-validators';
import { ValueMatchValidator } from '../../../../common/validators/value-match-validator';
import { ConditionalValidator } from '../../../../common/validators/conditional-validator';
import { ControlValidator } from '../../common/control-validator';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { PersonService } from '../../../../common/person-service';
import { CommonUtilities } from '../../../../common/utils/common-utilities';
import { CourtBondType } from '../../common/bond-types';
import { PLAINTIFF_CHAR_LIMIT } from '../../../../common/utils/constants';
import { KnockoutQuestionsBaseComponent } from '../../common/knockout-questions-base.component';
import { DOCUMENT } from '@angular/common';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

@Component({
  selector: 'app-attachment',
  templateUrl: './attachment.component.html',
  styleUrls: ['./attachment.component.css'],
})
export class AttachmentComponent extends KnockoutQuestionsBaseComponent {
  stepperFormArray: FormArray;
  creditCheckWasRequired: boolean;
  plaintiff_char_limit = PLAINTIFF_CHAR_LIMIT;
  constructor(
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      new AttachmentFormArrayMapperService(),
      applicationService,
      securityService,
      activatedRoute,
      router,
      CourtBondType.Attachment,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      document,
      elementRef,
      spinnerService
    );
  }

  protected createNewApplication(): void {
    this.stepperFormArray = new FormArray([
      // page 1
      new FormGroup({
        applicantInfo: new FormGroup({
          applicantId: new FormControl(null),
          applicantName: new FormControl(null),
          applicantSalutation: new FormControl(null),
          applicantSuffix: new FormControl(null),
          applicantOfficePerson: new FormControl(null),
          applicantPhone: new FormControl(null),
          applicantFax: new FormControl(null),
          applicantEmail: new FormControl(null),
          applicantWebsite: new FormControl(null),
          applicantAddress: this.createApplicantAddressFormGroup(),
        }),
        companyOrIndividual: new FormControl(null),
        premiumRateId: new FormControl(),
        knockedOut: new FormControl(null),
        knockoutQuestions: new FormGroup({
          exparteProcedure: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        }),
        // creditScoreSatisfactory: new FormControl(null),
        // applicantSSNum: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }),
        // creditCheckAuthorized: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) },
        //   CheckboxValidator.requireTrue()),
        // creditCheckSignatures: new FormGroup({
        //   signatureName: new FormControl({ disabled: true, value: null }),
        //   emailSignature: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
        //     [this.requiredIfNotAgent, PatternValidators.email()]),
        // }),
      }
        // {
        //   validators: [ValueMatchValidator.matchingValues('applicantInfo.applicantEmail', 'creditCheckSignatures.emailSignature', false,
        //     true)],
        // }
      ),

      // page 2
      new FormGroup({
        federalOrState: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        claimAmount: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // exparteProcedure: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // exparteProcedureExplanation: new FormControl({ value: null, disabled: this.isEmployee }),
        // propertyDescription: new FormControl({ value: null, disabled: this.isEmployee }, [this.requiredIfNotAgent,
        // Validators.maxLength(250)]),
        // securedByUcc: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // securedByUccExplanation: new FormControl({ value: null, disabled: this.isEmployee }),
        // titleAttachedToSomeoneOther: new FormControl({ value: null, disabled: this.isEmployee },
        //   [this.requiredIfNotAgent, Validators.maxLength(250)]),
        // titleAttachedToSomeoneOtherExplanation: new FormControl({ value: null, disabled: this.isEmployee },
        //   [this.requiredIfNotAgent, Validators.maxLength(250)]),
      }),

      // page 3
      new FormGroup({
        courtInformation: new FormGroup({
          caseNumber: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          courtName: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          presidingJudge: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          courtCounty: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          courtPhone: new FormControl({ value: null, disabled: this.isEmployee }),
          courtDistrict: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
          address: this.createApplicationAddressFormGroup(),
        }),
        plaintiffs: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        plaintiffAttorney: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),

        // expose plaintiff attorney firm, phone, email as properties,
        // even though the application form doesn't currently collect them
        plaintiffAttorneyFirm: new FormControl(),
        plaintiffAttorneyPhone: new FormControl(),
        plaintiffAttorneyEmail: new FormControl(),

        plaintiffAttorneyAddress: this.createApplicationAddressFormGroup(),
        defendants: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        uploadCourtOrder: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        courtOrderFile: new FormGroup({
          id: new FormControl(null),
          name: new FormControl(null),
        }),
        // specialBondForm: new FormControl({ value: null, disabled: this.isEmployee }, this.requiredIfNotAgent),
        // specialBondUpload: new FormControl({ value: null, disabled: this.isEmployee }),
        // specialBondFile: new FormGroup({
        //   id: new FormControl(null),
        //   name: new FormControl(null),
        // }),
      }),

      // page 4
      new FormGroup({
        deliveryInformation: this.createDeliveryInformationFormGroup(),
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: this.createPaymentInformationFormGroup(),
      }),

      // page 5
      new FormGroup({
        readAndAgreeToTerms: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) },
          CheckboxValidator.requireTrue()),
        declareTrue: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) }),
        agreementDate: new FormControl({ value: null }),
        premiumAcknowledged: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) },
          CheckboxValidator.requireTrue()),
        indemnitor: new FormControl(null),
        indemnitorOfficePerson: new FormControl(null),
        indemnitorOfficePersonTitle: new FormControl(null),

        creditScoreSatisfactory: new FormControl(null),
        applicantSSNum: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) }),
        creditCheckAuthorized: new FormControl({ value: false, disabled: (this.isSteward || this.isEmployee) }
          // CheckboxValidator.requireTrue()
        ),
        // creditCheckSignatures: new FormGroup({
        //   signatureName: new FormControl({ disabled: true, value: null }),
        //   emailSignature: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
        //     [this.requiredIfNotAgent, PatternValidators.email()]),
        // }),

        termsSignatures: new FormGroup({
          signatureName: new FormControl({ disabled: true, value: null }),
          emailSignature: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
            [this.requiredIfNotAgent, PatternValidators.email()]),
          companyEmailSignature: new FormControl({ value: null, disabled: (this.isSteward || this.isEmployee) },
            [this.requiredIfCompanyAndNotAgent, PatternValidators.email()]),
        }),
        applicantCreditCheckAddress: new FormGroup({
          street1: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
          street2: new FormControl({ value: null, disabled: this.isEmployee }),
          city: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
          state: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
          zipCode: new FormControl({ value: null, disabled: this.isEmployee },
            this.requiredIfNotAgent),
        }),
        creditCheckAddressSameAsApplicant: new FormControl(
          { value: false, disabled: this.isSteward || this.isEmployee }
        ),
      }),
    ]);

    if (this.isCompany) {
      this.stepperFormArray.at(4)
        .setValidators([ValueMatchValidator.matchValueToField(this.application.data.applicantEmail, 'termsSignatures.emailSignature',
          false, true),
        ValueMatchValidator.matchValueToField(this.application.data.applicantEmail, 'termsSignatures.companyEmailSignature',
          false, true)]);
    } else {
      this.stepperFormArray.at(4)
        .setValidators([ValueMatchValidator.matchValueToField(this.application.data.applicantEmail, 'termsSignatures.emailSignature',
          false, true)]);
    }

    this.addConditionalValidation();
    this.registerFileUploadControls();
  }

  addConditionalValidation(): void {

    // const exparteProcedureExplanationCondition = this.notStewardAnd(() => this.exparteProcedure.value === false);
    // this.setConditionalValidator(this.exparteProcedureExplanation, [
    //   ConditionalValidator.conditionalRequire(exparteProcedureExplanationCondition), Validators.maxLength(250)]);
    // this.updateOnChangeEvents(this.exparteProcedure, this.exparteProcedureExplanation);

    // const securedByUccExplanationCondition = this.notStewardAnd(() => this.securedByUcc.value === false);
    // this.setConditionalValidator(this.securedByUccExplanation, [
    //   ConditionalValidator.conditionalRequire(securedByUccExplanationCondition), Validators.maxLength(250)]);
    // this.updateOnChangeEvents(this.securedByUcc, this.securedByUccExplanation);

    // const titleAttachedToSomeoneOtherExplanationCondition = this.notStewardAnd(() => this.titleAttachedToSomeoneOther.value === true);
    // this.setConditionalValidator(this.titleAttachedToSomeoneOtherExplanation, [
    //   ConditionalValidator.conditionalRequire(titleAttachedToSomeoneOtherExplanationCondition), Validators.maxLength(250)]);
    // this.updateOnChangeEvents(this.titleAttachedToSomeoneOther, this.titleAttachedToSomeoneOtherExplanation);

    const uploadCourtOrderCondition = this.notStewardAnd(() => this.uploadCourtOrder.value);
    this.setConditionalValidators([
      {
        formControl: this.courtOrderFileFormGroup.get('id') as FormControl,
        validators: [ConditionalValidator.conditionalRequire(uploadCourtOrderCondition)],
      },
      {
        formControl: this.courtOrderFileFormGroup.get('name') as FormControl,
        validators: [ConditionalValidator.conditionalRequire(uploadCourtOrderCondition)],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.uploadCourtOrder, [
      this.courtOrderFileFormGroup.get('id') as FormControl,
      this.courtOrderFileFormGroup.get('name') as FormControl,
    ]);

    // const specialBondUploadCondition = this.notStewardAnd(() => this.specialBondForm.value);
    // this.setConditionalValidator(this.specialBondUpload, ConditionalValidator.conditionalRequire(specialBondUploadCondition));
    // this.updateOnChangeEvents(this.specialBondForm, this.specialBondUpload);
    // this.setConditionalValidators([
    //   {
    //     formControl: this.specialBondFileFormGroup.get('id') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(this.notStewardAnd(() => this.specialBondUpload.value))],
    //   },
    //   {
    //     formControl: this.specialBondFileFormGroup.get('name') as FormControl,
    //     validators: [ConditionalValidator.conditionalRequire(this.notStewardAnd(() => this.specialBondUpload.value))],
    //   },
    // ] as ControlValidator[]);
    // this.updateOnChangeEvents(this.specialBondUpload, [
    //   this.specialBondFileFormGroup.get('id') as FormControl,
    //   this.specialBondFileFormGroup.get('name') as FormControl,
    // ]);

    // delivery method conditional validation
    const deliveryMethodSetAndIsNotEmailCondition =
      this.notStewardAnd(this.isSetAndNotEqualTo('Email', this.deliveryMethod));

    this.setConditionalValidators([
      {
        formControl: this.deliveryName,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition)],
      },
      {
        formControl: this.deliveryPhone,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition)],
      },
      {
        formControl: this.deliveryAddressStreet1,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition), Validators.maxLength(60)],
      },
      {
        formControl: this.deliveryAddressZipCode,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition), PatternValidators.zipCode()],
      },
      {
        formControl: this.deliveryAddressCity,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition), Validators.maxLength(30)],
      },
      {
        formControl: this.deliveryAddressState,
        validators: [ConditionalValidator.conditionalRequire(deliveryMethodSetAndIsNotEmailCondition)],
      },
    ] as ControlValidator[]);
    this.updateOnChangeEvents(this.deliveryMethod, [
      this.deliveryName,
      this.deliveryPhone,
      this.deliveryAddressStreet1,
      this.deliveryAddressZipCode,
      this.deliveryAddressCity,
      this.deliveryAddressState,
    ]);
  }

  private registerFileUploadControls() {
    // this.registerFileTypeFileUploadActiveSubject('specialBondFile', this.specialBondFileFormGroup);
    this.registerFileTypeFileUploadActiveSubject('courtOrderFile', this.courtOrderFileFormGroup);
  }

  patchValueForSsnAddress() {
    const updatedApplicantForm = this.preliminaryQuestionsFormGroup.controls['applicantInfo'];
    const ssnAddressUpdate = this.stepperFormArray.controls[4];
    if (!this.applicantInfoFormGroup.value.applicantOfficePerson) {
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.patchValue({
        street1: updatedApplicantForm['controls'].applicantAddress['controls'].street1.value,
        street2: updatedApplicantForm['controls'].applicantAddress['controls'].street2.value,
        city: updatedApplicantForm['controls'].applicantAddress['controls'].city.value,
        state: updatedApplicantForm['controls'].applicantAddress['controls'].state.value,
        zipCode: updatedApplicantForm['controls'].applicantAddress['controls'].zipCode.value,
      });
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street1').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('street2').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('city').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('state').disable();
      ssnAddressUpdate['controls'].applicantCreditCheckAddress.get('zipCode').disable();
    }
  }

  patchValueForBillingAddress() {
    const updatedBillingForm = this.preliminaryQuestionsFormGroup.controls['applicantInfo'];
    const updatedDeliveryAddress: FormGroup = this.stepperFormArray.controls[3]['controls'].deliveryInformation.controls.deliveryAddress;
    const updatedBillingAddress: FormGroup = this.stepperFormArray.controls[3]['controls'].paymentInformation.controls.billingAddressGroup;
    updatedBillingAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
    updatedDeliveryAddress.patchValue({
      street1: updatedBillingForm['controls'].applicantAddress['controls'].street1.value,
      street2: updatedBillingForm['controls'].applicantAddress['controls'].street2.value,
      city: updatedBillingForm['controls'].applicantAddress['controls'].city.value,
      state: updatedBillingForm['controls'].applicantAddress['controls'].state.value,
      zipCode: updatedBillingForm['controls'].applicantAddress['controls'].zipCode.value,
    });
  }

  async stepSelectionChange(event: StepperSelectionEvent) {
    this.validatePage(event.selectedIndex);

    if (event.selectedIndex === 4) {
      this.patchValueForSsnAddress();
    }
    if (event.selectedIndex === 3) {
      this.patchValueForBillingAddress();
    }
    if (event.previouslySelectedIndex === 0 && event.selectedIndex === 1) {

      if (this.preliminaryQuestionsFormGroup.valid || this.isSteward) {
        if (this.creditCheckWasRequired) {
          await this.saveApplication('Saving Form...'); // was checking credit earlier
          this.creditCheckWasRequired = false;
        } else {
          await this.saveApplication('Saving Form...');
        }
        this.creditCheckAuthorization.clearValidators();
        this.creditCheckAuthorization.updateValueAndValidity();
        // this.applicantSSNum.clearValidators();
        this.applicantSSNum.updateValueAndValidity();
      }

      // ... and mark all of the formControls as touched to 'activate' the validators.
      // Many of the validators are inactive until the controls have been 'touched'.
      CommonUtilities.markAllTouched(this.preliminaryQuestionsFormGroup);
    } else {
      await super.stepSelectionChange(event);
    }
    this.determineTypeOfClient();
    // if (event.selectedIndex !== 0) {
    //   this.googleTagManagerService.sendEvent(
    //     `court-bond-app-step-${event.selectedIndex}`,
    //     `${this.bondType}`,
    //     `${this.premium}`,
    //     `${this.userType}`
    //   );
    // }
    const gtmBondType = this.applicationService.setBondType(this.bondType);
    const user = this.securityService.user;
    const userType = user ? (user.hasAttorneyRole ? 'attorney' : user.userRoles[0].userRoleRef.role) : 'anonymous';
    const paymentType = this.application['data'].paymentMethod.paymentChannelCode ?
      this.application['data'].paymentMethod.paymentChannelCode.cardValidatorType : '';
    if (event.selectedIndex === 1) {
      this.bondDetailsPageGtmEvent(
        'court-bond-app-details1',
        gtmBondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    } else if (event.selectedIndex === 2) {
      this.bondDetailsPageGtmEvent(
        'court-bond-app-details2',
        gtmBondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    } else if (event.selectedIndex === 3) {
      this.PageGtmEvent(
        'court-bond-app-delivery',
        gtmBondType,
        this.premium,
        userType,
        '',
        '',
        `${this.application['quoteId']}`,
        'new',
        this.id
      );
    } else if (event.selectedIndex === 4) {
      this.termsAndConditionEvent(
        'court-bond-app-terms',
        gtmBondType,
        this.application.premium,
        userType,
        '',
        '',
        this.application.quoteId,
        'new',
        this.application.id,
        paymentType
      );
    }
  }

  creditCheckIsRequiredHandler(event) {
    this.creditCheckWasRequired = event;
  }

  otherPrequalificationPageFormFields(): FormControl[] {
    return [
      // this.creditCheckAuthorization,
      // this.creditCheckEmailSignature,
    ];
  }


  private notSteward(): () => boolean {
    return () => !this.isSteward;
  }

  private notStewardAnd(condFn: () => boolean): () => boolean {
    return () => !this.isSteward && condFn();
  }

  private isSetAndNotEqualTo(value: any, control: FormControl): () => boolean {
    return () => !!control.value && control.value !== value;
  }

  disableFormArrayInputs(): void {
  }

  get formArrayMapper(): FormArrayMapper[] {
    return [];
  }

  get paymentInformationFormGroup(): FormGroup {
    return this.paymentAndDeliveryFormGroup.get(PAYMENT_INFORMATION_FORM_GROUP_NAME) as FormGroup;
  }

  get preliminaryQuestionsFormGroup(): FormGroup {
    return this.stepperFormArray.at(0) as FormGroup;
  }

  get bondDetails1FormGroup(): FormGroup {
    return this.stepperFormArray.at(1) as FormGroup;
  }

  get bondDetails2FormGroup(): FormGroup {
    return this.stepperFormArray.at(2) as FormGroup;
  }

  get paymentAndDeliveryFormGroup(): FormGroup {
    return this.stepperFormArray.at(3) as FormGroup;
  }

  get termsAndConditionsFormGroup(): FormGroup {
    return this.stepperFormArray.at(4) as FormGroup;
  }

  get knockoutQuestionFormGroup(): FormGroup {
    return this.preliminaryQuestionsFormGroup.get('knockoutQuestions') as FormGroup;
  }

  get applicantInfoFormGroup(): FormGroup {
    return this.preliminaryQuestionsFormGroup.get('applicantInfo') as FormGroup;
  }

  // get applicantSSNum(): FormControl {
  //   return this.preliminaryQuestionsFormGroup.get('applicantSSNum') as FormControl;
  // }
  get applicantSSNum(): FormControl {
    return this.termsAndConditionsFormGroup.get('applicantSSNum') as FormControl;
  }

  // get creditCheckSignatureFormGroup(): FormGroup {
  //   return this.termsAndConditionsFormGroup.get('creditCheckSignatures') as FormGroup;
  // }

  get creditCheckAuthorization(): FormControl {
    return this.termsAndConditionsFormGroup.get('creditCheckAuthorized') as FormControl;
  }

  get creditCheckEmailSignature(): FormControl {
    return this.termsAndConditionsFormGroup.get('emailSignature') as FormControl;
  }

  get federalOrState(): FormControl {
    return this.bondDetails1FormGroup.get('federalOrState') as FormControl;
  }

  get claimAmount(): FormControl {
    return this.bondDetails1FormGroup.get('claimAmount') as FormControl;
  }

  get exparteProcedure(): FormControl {
    return this.knockoutQuestionFormGroup.get('exparteProcedure') as FormControl;
  }

  // get exparteProcedure(): FormControl {
  //   return this.bondDetails1FormGroup.get('exparteProcedure') as FormControl;
  // }

  // get exparteProcedureExplanation(): FormControl {
  //   return this.bondDetails1FormGroup.get('exparteProcedureExplanation') as FormControl;
  // }

  // get propertyDescription(): FormControl {
  //   return this.bondDetails1FormGroup.get('propertyDescription') as FormControl;
  // }

  // get securedByUcc(): FormControl {
  //   return this.bondDetails1FormGroup.get('securedByUcc') as FormControl;
  // }

  // get securedByUccExplanation(): FormControl {
  //   return this.bondDetails1FormGroup.get('securedByUccExplanation') as FormControl;
  // }

  // get titleAttachedToSomeoneOther(): FormControl {
  //   return this.bondDetails1FormGroup.get('titleAttachedToSomeoneOther') as FormControl;
  // }

  get courtInformationFormGroup(): FormGroup {
    return this.bondDetails2FormGroup.get('courtInformation') as FormGroup;
  }

  get plaintiffAttorney(): FormControl {
    return this.bondDetails2FormGroup.get('plaintiffAttorney') as FormControl;
  }

  get plaintiffs(): FormControl {
    return this.bondDetails2FormGroup.get('plaintiffs') as FormControl;
  }

  get plaintiffAttorneyAddressFormGroup(): FormGroup {
    return this.bondDetails2FormGroup.get('plaintiffAttorneyAddress') as FormGroup;
  }

  get defendants(): FormControl {
    return this.bondDetails2FormGroup.get('defendants') as FormControl;
  }

  get uploadCourtOrder(): FormControl {
    return this.bondDetails2FormGroup.get('uploadCourtOrder') as FormControl;
  }

  get courtOrderFileFormGroup(): FormGroup {
    return this.bondDetails2FormGroup.get('courtOrderFile') as FormGroup;
  }

  // get specialBondForm(): FormControl {
  //   return this.bondDetails2FormGroup.get('specialBondForm') as FormControl;
  // }

  // get specialBondUpload(): FormControl {
  //   return this.bondDetails2FormGroup.get('specialBondUpload') as FormControl;
  // }

  // get specialBondFileFormGroup(): FormGroup {
  //   return this.bondDetails2FormGroup.get('specialBondFile') as FormGroup;
  // }

  get deliveryInformationFormGroup(): FormGroup {
    return this.paymentAndDeliveryFormGroup.get('deliveryInformation') as FormGroup;
  }

  get termsSignaturesFormGroup(): FormGroup {
    return this.termsAndConditionsFormGroup.get('termsSignatures') as FormGroup;
  }

  get emailSignature(): FormControl {
    return this.termsSignaturesFormGroup.get('emailSignature') as FormControl;
  }

  // get signatureName(): FormControl {
  //   return this.creditCheckSignatureFormGroup.get('signatureName') as FormControl;
  // }

  get applicantEmail(): FormControl {
    return this.applicantInfoFormGroup.get('applicantEmail') as FormControl;
  }

  get deliveryMethod(): FormControl {
    return this.deliveryInformationFormGroup.get('deliveryMethod') as FormControl;
  }

  get deliveryName(): FormControl {
    return this.deliveryInformationFormGroup.get('deliveryName') as FormControl;
  }

  get deliveryPhone(): FormControl {
    return this.deliveryInformationFormGroup.get('deliveryPhone') as FormControl;
  }

  get copyViaEmail(): FormControl {
    return this.deliveryInformationFormGroup.get('copyViaEmail') as FormControl;
  }

  get deliveryAddress(): FormGroup {
    return this.deliveryInformationFormGroup.get('deliveryAddress') as FormGroup;
  }

  get deliveryAddressStreet1(): FormControl {
    return this.deliveryAddress.get('street1') as FormControl;
  }

  get deliveryAddressCity(): FormControl {
    return this.deliveryAddress.get('city') as FormControl;
  }

  get deliveryAddressState(): FormControl {
    return this.deliveryAddress.get('state') as FormControl;
  }

  get deliveryAddressZipCode(): FormControl {
    return this.deliveryAddress.get('zipCode') as FormControl;
  }

  get isLinear(): boolean {
    return !this.isSteward && !this.preliminaryQuestionsFormGroup.valid;
  }

  // get titleAttachedToSomeoneOtherExplanation(): FormControl {
  //   return this.bondDetails1FormGroup.get('titleAttachedToSomeoneOtherExplanation') as FormControl;
  // }

  shouldScroll = () => this.preliminaryQuestionsFormGroup.valid;

  bondDetailsPageGtmEvent(event, bondType, bondPremium, userType, lpGroup?, lpBond?, quoteId?, bondClass?, applicationID?) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }

  PageGtmEvent(event, bondType, bondPremium, userType, lpGroup?, lpBond?, quoteId?, bondClass?, applicationID?) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`
    );
  }

  termsAndConditionEvent(event, bondType, bondPremium, userType, lpGroup?, lpBond?, quoteId?, bondClass?, applicationID?, paymentType?) {
    this.googleTagManagerService.sendEvent(
      `${event}`,
      `${bondType}`,
      `${bondPremium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`,
      `${paymentType}`
    );
  }

  validatePage(index) {
    if (index === 0) {
      CommonUtilities.markAllTouched(this.stepperFormArray.at(0));
    }
  }

}


