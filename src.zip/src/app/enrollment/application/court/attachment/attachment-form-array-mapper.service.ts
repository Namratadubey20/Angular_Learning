import { Injectable } from '@angular/core';
import { AbstractFormArrayMapper } from '../../common/abstract-form-array-mapper.service';
import { DeliveryMethodImpl } from '../model/common/delivery-method';
import { PAYMENT_INFORMATION_FORM_GROUP_NAME } from '../../common/application-base-component';
import { AttachmentApplication, AttachmentApplicationImpl } from '../model/attachment-application';


@Injectable()
export class AttachmentFormArrayMapperService extends AbstractFormArrayMapper {

  constructor() {
    super();
  }

  formArrayJsonToObject(formArrayJson: any): AttachmentApplication {
    const application: AttachmentApplication = new AttachmentApplicationImpl();
    const [preliminaryQuestions, bondDetails1, bondDetails2, paymentAndDelivery, termsAndConditions] =
      formArrayJson;

    // Page 1
    application.applicantEmail = preliminaryQuestions.applicantInfo.applicantEmail;
    application.applicantOfficePerson = preliminaryQuestions.applicantInfo.applicantOfficePerson;
    application.applicantId = preliminaryQuestions.applicantInfo.applicantId;
    application.applicantPhone = preliminaryQuestions.applicantInfo.applicantPhone;
    application.applicantFax = preliminaryQuestions.applicantInfo.applicantFax;
    application.applicantWebsite = preliminaryQuestions.applicantInfo.applicantWebsite;
    application.applicantName = preliminaryQuestions.applicantInfo.applicantName;
    application.applicantSalutation = preliminaryQuestions.applicantInfo.applicantSalutation;
    application.applicantSuffix = preliminaryQuestions.applicantInfo.applicantSuffix;
    application.companyOrIndividual = preliminaryQuestions.companyOrIndividual;
    application.premiumRateId = preliminaryQuestions.premiumRateId;
    application.applicantAddress.street1 =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.street1 : null;
    application.applicantAddress.street2 =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.street2 : null;
    application.applicantAddress.city =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.city : null;
    application.applicantAddress.state =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.state : null;
    application.applicantAddress.zipCode =
      preliminaryQuestions.applicantInfo.applicantAddress ? preliminaryQuestions.applicantInfo.applicantAddress.zipCode : null;
    // application.creditScoreSatisfactory = preliminaryQuestions.creditScoreSatisfactory;
    // application.applicantSSNum = preliminaryQuestions.applicantSSNum;
    // application.creditCheckAuthorized = preliminaryQuestions.creditCheckAuthorized;
    // application.creditCheckEmail =
    //   preliminaryQuestions.creditCheckSignatures ? preliminaryQuestions.creditCheckSignatures.emailSignature : null;
    // application.creditCheckSignature =
    //   preliminaryQuestions.applicantInfo.applicantName;

    application.knockedOut = preliminaryQuestions.knockedOut;
    application.knockoutQuestions.push(
      this.createDynamicQuestionForField('exparteProcedure', preliminaryQuestions.knockoutQuestions.exparteProcedure)
    );

    // page 2
    application.federalOrState = bondDetails1.federalOrState;
    application.claimAmount = bondDetails1.claimAmount;
    // application.exparteProcedure = bondDetails1.exparteProcedure;
    // application.exparteProcedureExplanation = bondDetails1.exparteProcedureExplanation;
    // application.propertyDescription = bondDetails1.propertyDescription;
    // application.securedByUcc = bondDetails1.securedByUcc;
    // application.securedByUccExplanation = bondDetails1.securedByUccExplanation;
    // application.titleAttachedToSomeoneOther = bondDetails1.titleAttachedToSomeoneOther;
    // application.titleAttachedToSomeoneOtherExplanation = bondDetails1.titleAttachedToSomeoneOtherExplanation;

    // Page 3
    const { courtInformation } = bondDetails2;
    application.court.caseNumber = courtInformation.caseNumber;
    application.court.courtName = courtInformation.courtName;
    application.court.presidingJudge = courtInformation.presidingJudge;
    application.court.courtCounty = courtInformation.courtCounty;
    application.court.courtPhone = courtInformation.courtPhone;
    application.court.address.street1 = courtInformation.address ? courtInformation.address.street1 : null;
    application.court.address.street2 = courtInformation.address ? courtInformation.address.street2 : null;
    application.court.address.city = courtInformation.address ? courtInformation.address.city : null;
    application.court.address.state = courtInformation.address ? courtInformation.address.state : null;
    application.court.address.zipCode = courtInformation.address ? courtInformation.address.zipCode : null;
    application.court.courtDistrict = courtInformation.courtDistrict;
    application.plaintiffs = bondDetails2.plaintiffs;
    application.plaintiffAttorney = bondDetails2.plaintiffAttorney;

    // map plaintiff attorney firm, phone, email as properties,
    // even though the application form doesn't currently collect them
    application.plaintiffAttorneyFirm = bondDetails2.plaintiffAttorneyFirm;
    application.plaintiffAttorneyPhone = bondDetails2.plaintiffAttorneyPhone;
    application.plaintiffAttorneyEmail = bondDetails2.plaintiffAttorneyEmail;

    application.plaintiffAttorneyAddress.street1 = bondDetails2.plaintiffAttorneyAddress.street1;
    application.plaintiffAttorneyAddress.street2 = bondDetails2.plaintiffAttorneyAddress.street2;
    application.plaintiffAttorneyAddress.zipCode = bondDetails2.plaintiffAttorneyAddress.zipCode;
    application.plaintiffAttorneyAddress.city = bondDetails2.plaintiffAttorneyAddress.city;
    application.plaintiffAttorneyAddress.state = bondDetails2.plaintiffAttorneyAddress.state;

    application.defendants = bondDetails2.defendants;
    application.uploadCourtOrder = bondDetails2.uploadCourtOrder;
    application.courtOrderFile.id = bondDetails2.courtOrderFile ? bondDetails2.courtOrderFile.id : null;
    application.courtOrderFile.name = bondDetails2.courtOrderFile ? bondDetails2.courtOrderFile.name : null;
    // application.specialBondForm = bondDetails2.specialBondForm;
    // application.specialBondUpload = bondDetails2.specialBondUpload;
    // application.specialBondFile.id = bondDetails2.specialBondFile ? bondDetails2.specialBondFile.id : null;
    // application.specialBondFile.name = bondDetails2.specialBondFile ? bondDetails2.specialBondFile.name : null;

    // Page 4
    const deliveryInformation = paymentAndDelivery.deliveryInformation;
    application.deliveryMethod = new DeliveryMethodImpl();
    this.populateDeliveryMethod(application.deliveryMethod, deliveryInformation);
    application.paymentMethod = paymentAndDelivery[PAYMENT_INFORMATION_FORM_GROUP_NAME];

    application.termsAndConditions.readAndAgreeToTerms = termsAndConditions.readAndAgreeToTerms;
    application.termsAndConditions.declareTrue = termsAndConditions.declareTrue;
    application.termsAndConditions.indemnitor = preliminaryQuestions.applicantInfo.applicantName;
    application.termsAndConditions.agreementDate = new Date();
    application.termsAndConditions.emailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.emailSignature : null;
    application.termsAndConditions.signatureName = termsAndConditions.termsSignatures.signatureName;
    application.termsAndConditions.companyEmailSignature =
      termsAndConditions.termsSignatures ? termsAndConditions.termsSignatures.companyEmailSignature : null;
    application.termsAndConditions.premiumAcknowledged = termsAndConditions.premiumAcknowledged;
    application.applicantOfficePersonTitle = termsAndConditions.indemnitorOfficePersonTitle;
    application.applicantOfficePerson = termsAndConditions.indemnitorOfficePerson;

    application.creditScoreSatisfactory = termsAndConditions.creditScoreSatisfactory;
    application.applicantSSNum = termsAndConditions.applicantSSNum;
    application.creditCheckAuthorized = termsAndConditions.creditCheckAuthorized;
    application.creditCheckEmail =
      termsAndConditions.creditCheckSignatures ? termsAndConditions.creditCheckSignatures.emailSignature : null;
    application.creditCheckSignature =
      preliminaryQuestions.applicantInfo.applicantName;
    application.applicantCreditCheckAddress = {
      street1: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street1 : null,
      street2: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.street2 : null,
      city: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.city : null,
      state: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.state : null,
      zipCode: termsAndConditions.applicantCreditCheckAddress ? termsAndConditions.applicantCreditCheckAddress.zipCode : null,
    };
    application.creditCheckAddressSameAsApplicant = termsAndConditions.creditCheckAddressSameAsApplicant;

    return application;
  }

  objectToFormArrayJson(application: AttachmentApplication): any {
    return [
      // Page 1
      {
        applicantInfo: {
          applicantId: application.applicantId,
          applicantName: application.applicantName,
          applicantSalutation: application.applicantSalutation,
          applicantSuffix: application.applicantSuffix,
          applicantOfficePerson: application.applicantOfficePerson,
          applicantEmail: application.applicantEmail,
          applicantPhone: application.applicantPhone,
          applicantFax: application.applicantFax,
          applicantWebsite: application.applicantWebsite,
          applicantAddress: {
            street1: application.applicantAddress ? application.applicantAddress.street1 : null,
            street2: application.applicantAddress ? application.applicantAddress.street2 : null,
            zipCode: application.applicantAddress ? application.applicantAddress.zipCode : null,
            city: application.applicantAddress ? application.applicantAddress.city : null,
            state: application.applicantAddress ? application.applicantAddress.state : null,
          },
        },
        companyOrIndividual: application.companyOrIndividual,
        premiumRateId: application.premiumRateId,
        creditScoreSatisfactory: application.creditScoreSatisfactory,
        knockedOut: application.knockedOut,
        knockoutQuestions: {
          exparteProcedure: this.getValueFromDynamicQuestions('exparteProcedure', application.knockoutQuestions),
          // exparteProcedure:  application.knockoutQuestions,
        },
        // creditScoreSatisfactory: application.creditScoreSatisfactory,
        // applicantSSNum: application.applicantSSNum,
        // creditCheckAuthorized: application.creditCheckAuthorized,
        // creditCheckSignatures: {
        //   signatureName: application.applicantName,
        //   emailSignature: application.creditCheckEmail,
        // },
      },
      // Page 2
      {
        federalOrState: application.federalOrState,
        claimAmount: application.claimAmount,
        // exparteProcedure: application.exparteProcedure,
        // exparteProcedureExplanation: application.exparteProcedureExplanation,
        // propertyDescription: application.propertyDescription,
        // securedByUcc: application.securedByUcc,
        // securedByUccExplanation: application.securedByUccExplanation,
        // titleAttachedToSomeoneOther: application.titleAttachedToSomeoneOther,
        // titleAttachedToSomeoneOtherExplanation: application.titleAttachedToSomeoneOtherExplanation,
      },
      // Page 3
      {
        courtInformation: {
          caseNumber: application.court ? application.court.caseNumber : null,
          courtName: application.court ? application.court.courtName : null,
          presidingJudge: application.court ? application.court.presidingJudge : null,
          courtCounty: application.court ? application.court.courtCounty : null,
          courtPhone: application.court ? application.court.courtPhone : null,
          address: {
            street1: application.court ? application.court.address.street1 : null,
            street2: application.court ? application.court.address.street2 : null,
            city: application.court ? application.court.address.city : null,
            state: application.court ? application.court.address.state : null,
            zipCode: application.court ? application.court.address.zipCode : null,
          },
          courtDistrict: application.court ? application.court.courtDistrict : null,
        },
        plaintiffs: application.plaintiffs,
        plaintiffAttorney: application.plaintiffAttorney,

        // map plaintiff attorney firm, phone, email as properties,
        // even though the application form doesn't currently collect them
        plaintiffAttorneyFirm: application.plaintiffAttorneyFirm,
        plaintiffAttorneyPhone: application.plaintiffAttorneyPhone,
        plaintiffAttorneyEmail: application.plaintiffAttorneyEmail,

        plaintiffAttorneyAddress: {
          street1: application.plaintiffAttorneyAddress ? application.plaintiffAttorneyAddress.street1 : null,
          street2: application.plaintiffAttorneyAddress ? application.plaintiffAttorneyAddress.street2 : null,
          zipCode: application.plaintiffAttorneyAddress ? application.plaintiffAttorneyAddress.zipCode : null,
          city: application.plaintiffAttorneyAddress ? application.plaintiffAttorneyAddress.city : null,
          state: application.plaintiffAttorneyAddress ? application.plaintiffAttorneyAddress.state : null,
        },
        defendants: application.defendants,
        uploadCourtOrder: application.uploadCourtOrder,
        courtOrderFile: {
          id: application.courtOrderFile ? application.courtOrderFile.id : null,
          name: application.courtOrderFile ? application.courtOrderFile.name : null,
        },
        // specialBondForm: application.specialBondForm,
        // specialBondUpload: application.specialBondUpload,
        // specialBondFile: {
        //   id: application.specialBondFile ? application.specialBondFile.id : null,
        //   name: application.specialBondFile ? application.specialBondFile.name : null,
        // },
      },
      // Page 4
      {
        deliveryInformation: this.createDeliveryMethodFormGroupPatchValues(application.deliveryMethod),
        [PAYMENT_INFORMATION_FORM_GROUP_NAME]: application.paymentMethod,
      },
      // Page 5
      {
        readAndAgreeToTerms: application.termsAndConditions ? application.termsAndConditions.readAndAgreeToTerms : false,
        declareTrue: application.termsAndConditions ? application.termsAndConditions.declareTrue : false,
        agreementDate: new Date(),
        indemnitor: application.applicantName,
        indemnitorOfficePerson: application.applicantOfficePerson ? application.applicantOfficePerson : null,
        indemnitorOfficePersonTitle: application.applicantOfficePersonTitle ? application.applicantOfficePersonTitle : null,
        premiumAcknowledged: application.termsAndConditions.premiumAcknowledged,
        creditScoreSatisfactory: application.creditScoreSatisfactory,
        applicantSSNum: application.applicantSSNum,
        creditCheckAuthorized: application.creditCheckAuthorized,
        creditCheckSignatures: {
          signatureName: application.applicantName,
          emailSignature: application.creditCheckEmail,
        },
        termsSignatures: {
          companyEmailSignature: application.termsAndConditions.companyEmailSignature,
          signatureName: application.termsAndConditions.signatureName,
          emailSignature: application.termsAndConditions.emailSignature,
        },
        applicantCreditCheckAddress: {
          street1: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['street1'] : null,
          street2: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['street2'] : null,
          city: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['city'] : null,
          state: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['state'] : null,
          zipCode: application.applicantCreditCheckAddress ? application.applicantCreditCheckAddress['zipCode'] : null,
        },
        creditCheckAddressSameAsApplicant: application.creditCheckAddressSameAsApplicant,
      },
    ];
  }
}
