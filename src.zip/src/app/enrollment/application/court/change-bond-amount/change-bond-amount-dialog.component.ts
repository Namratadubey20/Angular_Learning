import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { PreCourtApplicationFormGroup } from '../../pre-application/pre-court-application/pre-court-application-form-group';
import { CourtBondType } from '../../common/bond-types';
import { CurrencyFormatter } from '../../../../common/utils/currency-formatter';
import { PremiumCalculationService } from '../../pre-application/premium-calculation/premium-calculation.service';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-change-bond-amount-dialog',
  templateUrl: './change-bond-amount-dialog.component.html',
  styleUrls: ['./change-bond-amount-dialog.component.scss'],
})
export class ChangeBondAmountDialogComponent {
  amountAndPremium: PreCourtApplicationFormGroup;
  showQuoteBox: boolean;
  currencyFormattedAmount: string;

  private readonly bondType: CourtBondType;

  constructor(
    public dialogRef: MatDialogRef<ChangeBondAmountDialogComponent>,
    private premiumCalculationService: PremiumCalculationService,
    @Inject(MAT_DIALOG_DATA) private data: ChangeBondAmountData
  ) {
    this.amountAndPremium = new PreCourtApplicationFormGroup(data.bondType);
    this.bondType = data.bondType;
    this.showQuoteBox = false;
    this.amountAndPremium.amount.valueChanges.subscribe(() => {
      this.premium.setValue('');
      this.currencyFormattedAmount = '';
      this.showQuoteBox = false;
    });
  }

  get amount(): FormControl {
    return this.amountAndPremium.amount;
  }

  get premium(): FormControl {
    return this.amountAndPremium.premium;
  }

  cancel() {
    this.dialogRef.close();
  }

  changeBondAmount() {
    const { amount, premium } = this.amountAndPremium.getRawValue();
    this.data.change(CurrencyFormatter.toRawNumber(amount), CurrencyFormatter.toRawNumber(premium));
    this.dialogRef.close();
  }

  async getPremium() {
    this.currencyFormattedAmount = CurrencyFormatter.formatMoney(this.amount.value);
    this.amount.disable({ onlySelf: true, emitEvent: false });
    this.premium.setValue('');

    try {
      const { premium: { amount, premium } } = await this.premiumCalculationService.getPremium(
        this.bondType,
        CurrencyFormatter.toRawNumber(this.amount.value).toString()
      );

      this.amount.setValue(amount, { onlySelf: true, emitEvent: false });
      this.premium.setValue(CurrencyFormatter.formatMoney(premium));
    } finally {
      this.amount.enable({ onlySelf: true, emitEvent: false });
    }
    this.showQuoteBox = true;
  }
}

export interface ChangeBondAmountData {
  bondType: CourtBondType;
  change(newAmount: number, newPremium: number): any;
}
