import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-company-name-dialog',
  templateUrl: './add-company-name-dialog.component.html',
  styleUrls: ['./add-company-name-dialog.component.scss'],
})

export class AddCompanyNameDialogComponent implements OnInit {

  companyNameForm: FormGroup;
  applicantName: string;
  constructor(
    public fb: FormBuilder,
    public dialogRef: MatDialogRef<AddCompanyNameDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }
  ngOnInit() {
    this.companyNameForm = this.fb.group({
      companyName: this.fb.control('', [Validators.required]),
    });
    this.applicantName = this.dialogRef.componentInstance ? this.dialogRef.componentInstance.data.clientDetails.fullName : '';
  }
  cancel(): void {
    this.dialogRef.close();
  }

  saveCompanyName() {
    this.dialogRef.close();
    this.data = this.companyNameForm.value;
  }
}

