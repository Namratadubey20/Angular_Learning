import { Injectable } from '@angular/core';
import { ApplicationDataImpl } from './court/model/application-data';
import { HttpClient } from '@angular/common/http';
import { JsonConvert } from 'json2typescript';
import { UtilService } from '../../common/utils/util.service';
import { Application, ApplicationImpl } from './application';
import { PersonImpl } from '../../common/person';
import { CompanyOfficeImpl } from '../../common/company-office';
import { AgentImpl } from '../../common/agent';
import { SecurityService } from '../../security/security.service';
import { UserImpl } from '../../security/user';
import { Observable } from 'rxjs/Observable';
import { ServiceHandler } from '../../common/utils/service-handler.service';
import { FileService } from '../../common/file-upload/file.service';
import { Page, Pageable, PageableConverter, PageImpl } from '../../common/pagination';
import { FileModel } from '../../common/file-upload/file-model';
import { throwError, BehaviorSubject } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { CourtBondFacilitationService } from '../facilitation/court-bond-facilitation.service';
import { EmployeeCourtApplicationSummary, EmployeeCourtApplicationSummaryImpl } from './court/model/employee-court-application-summary';
import { AgentCourtApplicationSummary, AgentCourtApplicationSummaryImpl } from './court/model/agent-court-application-summary';
import { ClientCourtApplicationSummaryImpl } from './court/model/client-court-application-summary';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';
import { ClientData } from '../../user/client/client-data';

export interface BondApplicantIds {
  personId?: number;
  companyOfficeId?: number;
  agentId?: number;
}

@Injectable({
  providedIn: 'root',
})
export class ApplicationService {
  private requestURL = 'api/application';
  private requestEmployeeURL = 'api/colonial';
  private jsonConvert: JsonConvert;
  private searchByStatusSubject = new BehaviorSubject<string>('');
  searchByStatus = this.searchByStatusSubject.asObservable();
  private clearSearchSubject = new BehaviorSubject<boolean>(false);
  clearSearch = this.clearSearchSubject.asObservable();
  companyName: string;
  applicationDetails;
  constructor(
    private http: HttpClient,
    private securityService: SecurityService,
    private fileService: FileService,
    private serviceHandler: ServiceHandler,
    private courtBondFacilitationService: CourtBondFacilitationService,
    private googleTagManagerService: GoogleTagManagerService
  ) {
    this.jsonConvert = UtilService.getJsonConvert();
  }

  async create(bondType: string, data: ApplicationDataImpl, applicantIds: BondApplicantIds): Promise<ApplicationImpl> {
    return this.createAsObservable(bondType, data, applicantIds).toPromise();
  }

  createAsObservable(bondType: string, data: ApplicationDataImpl, applicantIds: BondApplicantIds): Observable<ApplicationImpl> {
    const { personId, companyOfficeId, agentId } = applicantIds;
    if (!personId && !companyOfficeId) {
      throw new Error('User or Company Office is required');
    }
    if (personId && companyOfficeId) {
      throw new Error('Cannot create application for user and company office.');
    }
    data.bondClassification = bondType;
    const requestBody: ApplicationImpl = new ApplicationImpl();
    requestBody.amount = data.amount;
    requestBody.premium = data.premium;
    requestBody.quoteId = this.courtBondFacilitationService.getQuoteId() || null;
    requestBody.data = data;
    requestBody.quoteId = this.courtBondFacilitationService.getQuoteId() || null;


    if (personId) {
      const person = new PersonImpl();
      person.id = personId;
      requestBody.person = person;
    }
    if (companyOfficeId) {
      const companyOffice = new CompanyOfficeImpl();
      companyOffice.id = companyOfficeId;
      requestBody.companyOffice = companyOffice;
    }
    if (agentId) {
      const agent = new AgentImpl();
      agent.id = agentId;
      requestBody.agent = agent;
    }
    return this.http.post<ApplicationImpl>(`${this.requestURL}/${bondType}`, this.jsonConvert.serialize(requestBody)).pipe(
      tap(a => {
        this.courtBondFacilitationService.applicationCreated(a);
        this.sendCourtBondsAppStartEvent(a, bondType);
      }),
      map(a => this.jsonConvert.deserialize(a, ApplicationImpl) as ApplicationImpl)
    );
  }

  async saveForLater(id: number, bondType: string, application: ApplicationImpl, processPaymentMethod: boolean): Promise<ApplicationImpl> {
    return this.putApplication(bondType, application, `${this.requestURL}/${bondType}/save-for-later/${id}`, processPaymentMethod);
  }

  async update(id: number, bondType: string, application: ApplicationImpl, processPaymentMethod: boolean): Promise<ApplicationImpl> {
    return this.putApplication(bondType, application, `${this.requestURL}/${bondType}/${id}`, processPaymentMethod);
  }

  private async putApplication(bondType: string, application: ApplicationImpl, url: string,
    processPaymentMethod: boolean): Promise<ApplicationImpl> {
    let returnData: any;

    application.data.bondClassification = bondType;
    const formattedData = this.jsonConvert.serialize(application);

    const applicationUrl = url + (processPaymentMethod ? '?processPaymentMethod=true' : '');
    returnData = await this.http.put(applicationUrl, formattedData).toPromise();

    return this.jsonConvert.deserialize(returnData, ApplicationImpl) as ApplicationImpl;
  }

  async getById(id: number): Promise<ApplicationImpl> {
    const application: any = await this.http.get(`${this.requestURL}/${id}`).toPromise();
    return this.jsonConvert.deserialize(application, ApplicationImpl) as ApplicationImpl;
  }

  async getApplicationListForPerson(pageable: Pageable = { page: 0, size: 5, sort: null }, searchParams) {
    const user: UserImpl = this.securityService.user;
    const pageableParams = PageableConverter.toPageableRequest(pageable);
    // let apiUrl = 'api/application/user/list?page=0&size=500&sort=id,asc';
    for (const searchParam of Object.keys(searchParams)) {
      if (searchParams[searchParam]) {
        pageableParams.params[searchParam] = searchParams[searchParam];
      }
    }
    const applicationList = await this.http.get(`${this.requestURL}/user/list`, pageableParams).toPromise();
    // applicationList['content'] = applicationList['content'].filter(list => list.status !== 'Completed');
    const page = this.jsonConvert.deserialize(applicationList, PageImpl) as PageImpl<ClientCourtApplicationSummaryImpl>;
    page.content =
      this.jsonConvert.deserializeArray(page.content, ClientCourtApplicationSummaryImpl) as Array<ClientCourtApplicationSummaryImpl>;
    return page;
  }

  searchApplication(staus) {
    this.searchByStatusSubject.next(staus);
  }

  clearApplicationSearch(staus) {
    this.clearSearchSubject.next(staus);
  }

  async getListForUser(pageable: Pageable = { page: 0, size: 20, sort: null }): Promise<Page<Application>> {
    const user: UserImpl = this.securityService.user;
    const pageableParams = PageableConverter.toPageableRequest(pageable);
    let applicationList: any;

    if (this.securityService.user.hasEmployeePermissions) { // Colonial superuser gets all applications
      applicationList = await this.http.get(`${this.requestEmployeeURL}/adjudicate/list`, pageableParams).toPromise();
    } else if (this.securityService.user.isSteward) { // Agent gets applications of her clients
      applicationList = await this.http.get(`${this.requestURL}/list/agent/${user.agent.id}`, pageableParams).toPromise();
    }
    return this.jsonConvert.deserialize(applicationList, PageImpl) as PageImpl<ApplicationImpl>;
  }

  async getCourtApplicationsForEmployee(pageable: Pageable = { page: 0, size: 20, sort: null }, searchParams: any):
    Promise<Page<EmployeeCourtApplicationSummary>> {

    const pageableParams = PageableConverter.toPageableRequest(pageable);
    for (const searchParam of Object.keys(searchParams)) {
      if (searchParams[searchParam]) {
        pageableParams.params[searchParam] = searchParams[searchParam];
      }
    }
    const response = await this.http.get(`${this.requestEmployeeURL}/adjudicate/list/court`, pageableParams).toPromise();
    const page = this.jsonConvert.deserialize(response, PageImpl) as PageImpl<EmployeeCourtApplicationSummaryImpl>;

    // had to do it this way so it would deserialize the array properly
    page.content =
      this.jsonConvert.deserializeArray(page.content, EmployeeCourtApplicationSummaryImpl) as Array<EmployeeCourtApplicationSummaryImpl>;
    return page;
  }

  async getCourtApplicationsForAgent(pageable: Pageable = { page: 0, size: 20, sort: null }, searchParams: any):
    Promise<Page<AgentCourtApplicationSummary>> {

    const pageableParams = PageableConverter.toPageableRequest(pageable);
    for (const searchParam of Object.keys(searchParams)) {
      if (searchParams[searchParam]) {
        pageableParams.params[searchParam] = searchParams[searchParam];
      }
    }
    const response = await this.http.get(`${this.requestURL}/agent/list/court`, pageableParams).toPromise();
    const page = this.jsonConvert.deserialize(response, PageImpl) as PageImpl<AgentCourtApplicationSummaryImpl>;

    // had to do it this way so it would deserialize the array properly
    page.content =
      this.jsonConvert.deserializeArray(page.content, AgentCourtApplicationSummaryImpl) as Array<AgentCourtApplicationSummaryImpl>;
    return page;
  }

  getFileListForApplication(applicationId: number): Observable<FileModel[]> {
    return this.fileService.getFileList(applicationId.toString(10), 'Application');
  }

  submit(id: number, bondType: string, application: ApplicationImpl, processPaymentMethod?: boolean): Observable<ApplicationImpl> {
    application.data.bondClassification = bondType;
    const formattedData = this.jsonConvert.serialize(application);

    const submitUrl = `${this.requestURL}/submit/${bondType}/${id}` + (processPaymentMethod ? '?processPaymentMethod=true' : '');

    return this.http.put(submitUrl, formattedData).pipe(
      catchError((error) => this.serviceHandler.handleError(error)),
      map((app: ApplicationImpl) => this.jsonConvert.deserialize(app, ApplicationImpl) as ApplicationImpl)
    );
  }

  getBondOverview(id: number): Observable<ApplicationImpl> {
    return this.http.get(`${this.requestURL}/overview/${id}`).pipe(
      catchError((error) => this.serviceHandler.handleError(error)),
      map((application: ApplicationImpl) => this.jsonConvert.deserialize(application, ApplicationImpl) as ApplicationImpl)
    );
  }

  getAdjudicationOverview(id: number): Observable<ApplicationImpl> {
    return this.http.get(`${this.requestURL}/adjudication/${id}`).pipe(
      catchError((error) => this.serviceHandler.handleError(error)),
      map((application: ApplicationImpl) => this.jsonConvert.deserialize(application, ApplicationImpl) as ApplicationImpl)
    );
  }

  adjudicate(id: number, decision: string): Observable<ApplicationImpl> {
    return this.http.put(`${this.requestEmployeeURL}/adjudicate/decision/${decision}/${id}/`, null).pipe(
      catchError((error) => throwError(this.serviceHandler.showErrorMessage('An error occurred on application submission'))),
      map((app: ApplicationImpl) => this.jsonConvert.deserialize(app, ApplicationImpl) as ApplicationImpl)
    );
  }

  /**
   * Delete the uploaded file associated with the application.
   * @param applicationId
   * @param fileId
   */
  async deleteApplicationFileUpload(applicationId: number, fileId: number) {
    const isHistoryNeeded = false;
    await this.fileService.deleteFileById(fileId, isHistoryNeeded).subscribe();
  }

  getPendingApplicationList(status, appId) {
    let apiUrl = 'api/application/user/list?page=0&size=500&sort=id,asc';
    if (status) {
      apiUrl = apiUrl + '&status=' + status;
    }
    if (appId) {
      apiUrl = apiUrl + '&applicationId=' + appId;
    }
    return this.http.get(apiUrl).toPromise();
  }

  getActiveProductList(status, appId) {
    let apiUrl = 'api/product/list/person?page=0&size=500&sort=id,asc';
    if (status) {
      apiUrl = apiUrl + '&status=' + status;
    }
    if (appId) {
      apiUrl = apiUrl + '&productNo=' + appId;
    }
    return this.http.get(apiUrl).toPromise();
  }
  setBondType(bondType) {
    let gtmBondType: string;
    if (bondType === 'injunction') {
      gtmBondType = 'TRO Injunction';
    } else {
      gtmBondType = bondType;
    }
    return gtmBondType;
  }
  sendCourtBondsAppStartEvent(compiledData: ApplicationImpl, bondType: string) {
    const user = this.securityService.user;
    const userType = user ? (user.hasAttorneyRole ? 'attorney' : user.userRoles[0].userRoleRef.role) : 'anonymous';
    const gtmBondType = this.setBondType(bondType);
    const lpGroup = '';
    const lpBond = '';
    this.googleTagManagerService.sendEvent(
      'court-bond-app-start',
      `${gtmBondType}`,
      `${compiledData.premium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${compiledData.quoteId}`,
      'new',
      `${compiledData.id}`
    );
  }
  getZipCode(zipCode) {
    return this.http.get('api/util/usps/zip/' + zipCode);
  }
  createCompanyProfile(data, id) {
    return this.http.post(`api/person/${id}/company`, data);
  }
  setApplicant(applicant) {
    if (applicant) {
      this.applicationDetails = applicant;
    }
  }
  getApplicationDetails() {
    return this.applicationDetails;
  }
}
