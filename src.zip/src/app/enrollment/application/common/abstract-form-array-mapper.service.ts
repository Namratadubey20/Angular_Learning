import { Injectable } from '@angular/core';
import { ApplicationData } from '../court/model/application-data';
import { DynamicQuestion, DynamicQuestionImpl } from '../court/model/common/dynamic-question';
import { QuestionImpl } from '../question';
import { DeliveryMethod } from '../court/model/common/delivery-method';
import { Address } from '../court/model/common/address';
import { FormGroup } from '@angular/forms';
import { DeliveryMethodSelectionMapper } from '../../../common/delivery-method-selection/delivery-method-selection-mapper';
import { AddressMapper } from '../../../common/address/address-mapper';

@Injectable()
export abstract class AbstractFormArrayMapper {

  /**
   * Constructs an ApplicationData instance from a FormControl hierarchy's 'rawValues'.
   * @param formArrayJson raw values of the FormControl hierarchy.
   */
  abstract formArrayJsonToObject(formArrayJson: any): ApplicationData;

  /**
   * Constructs an object from ApplicationData to support populating a FormControl hierarchy's via 'patchValue'.
   * @param applicationData source of information to populate the FormControl hierarchy's patchValues.
   */
  abstract objectToFormArrayJson(applicationData: ApplicationData): any;

  // noinspection JSMethodCanBeStatic
  protected getValueFromDynamicQuestions(name: string, dynamicQuestions: Array<DynamicQuestion>): string {
    let value = null;
    if (dynamicQuestions && dynamicQuestions.length > 0) {
      for (const dynamicQuestion of dynamicQuestions) {
        if (dynamicQuestion.question.name === name) {
          value = dynamicQuestion.value;
        }
      }
    }
    return value;
  }

  // noinspection JSMethodCanBeStatic
  protected createDynamicQuestionForField(fieldName: string, value: string): DynamicQuestionImpl {
    const question: QuestionImpl = new QuestionImpl();
    question.name = fieldName;

    const dynamicQuestion: DynamicQuestionImpl = new DynamicQuestionImpl();
    dynamicQuestion.value = value;
    dynamicQuestion.question = question;

    return dynamicQuestion;
  }

  /**
   * Populate a DeliveryMethod instance from an deliveryMethod FormGroup's rawValues.
   * @param deliveryMethod instance to be populated from 'rawValues'.
   * @param deliveryMethodRawValues  'rawValues' to populate instance.
   */
  protected populateDeliveryMethod(deliveryMethod: DeliveryMethod, deliveryMethodRawValues: any | null): DeliveryMethod {
    DeliveryMethodSelectionMapper.populateDeliveryMethod(deliveryMethod, deliveryMethodRawValues);
    return deliveryMethod;
  }

  // noinspection JSMethodCanBeStatic
  /**
   * Create an object of values to be 'patched' into a DeliveryMethod FormGroup.
   * @param deliveryMethod source of values to be patched.
   */
  protected createDeliveryMethodFormGroupPatchValues(deliveryMethod: DeliveryMethod | null): any {
    const patchValues = DeliveryMethodSelectionMapper.createDeliveryMethodFormGroupPatchValues(deliveryMethod);
    return patchValues;
  }

  /**
   * Populate an Address instance from an address FormGroup's rawValues.
   * @param address instance to be populated from 'rawValues'.
   * @param addressRawValues 'rawValues' to populate instance.
   */
  protected populateAddress(address: Address, addressRawValues: any | null): Address {
    AddressMapper.populateAddress(address, addressRawValues);
    return address;
  }

  /**
   * Create an object of values to be 'oatched' into an Address FormGroup.
   * @param address source of values to be patched.
   */
  protected createAddressFormGroupPatchValues(address: Address | null): any {
    const patchValues = AddressMapper.createAddressFormGroupPatchValues(address);
    return patchValues;
  }
}
