export enum CourtBondType {
  Supersedeas = 'supersedeas',
  Replevin = 'replevin',
  Attachment = 'attachment',
  Injunction = 'injunction',
  Guardianship = 'guardianship',
  Conservatorship = 'conservatorship',
  Estate = 'estate',
  Trustee = 'trustee',
  Receiver = 'receiver',
  Referee = 'referee',
  pnl = 'pnl',
}

export const CourtBondTypeDisplayNames = {
  [CourtBondType.Supersedeas]: 'Appeal / Supersedeas',
  [CourtBondType.Replevin]: 'Replevin',
  [CourtBondType.Attachment]: 'Attachment',
  [CourtBondType.Injunction]: 'TRO / Injunction',
  [CourtBondType.Guardianship]: 'Guardianship',
  [CourtBondType.Conservatorship]: 'Conservatorship',
  [CourtBondType.Estate]: 'Estate',
  [CourtBondType.Trustee]: 'Trustee',
  [CourtBondType.Receiver]: 'Receiver',
  [CourtBondType.Referee]: 'Referee',
  [CourtBondType.pnl]: 'pnl',
};

export const CourtBondTypesPurchasableByCompanies = [
  CourtBondType.Supersedeas,
  CourtBondType.Replevin,
  CourtBondType.Attachment,
  CourtBondType.Injunction,
];

export enum ProfessionalLiabilityBondType {
  Pnl = 'pnl',
}

export function isFiduciaryBondType(bondType: CourtBondType | string): boolean {
  const fiduciaryBondTypes: Array<CourtBondType | string> = [
    CourtBondType.Conservatorship,
    CourtBondType.Estate,
    CourtBondType.Guardianship,
    CourtBondType.Receiver,
    CourtBondType.Referee,
    CourtBondType.Trustee,
    CourtBondType.Injunction,
  ];

  return fiduciaryBondTypes.includes(bondType);
}
