import { Question } from '../question';


export interface QuestionMap {
  [key: string]: Question;
}
