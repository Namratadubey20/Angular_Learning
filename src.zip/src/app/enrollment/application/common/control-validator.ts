import { FormControl, ValidatorFn } from '@angular/forms';


export interface ControlValidator {
  formControl: FormControl;
  validators: ValidatorFn | ValidatorFn[] | null;
}
