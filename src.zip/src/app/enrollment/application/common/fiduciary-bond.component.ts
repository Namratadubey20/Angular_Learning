import { FormControl } from '@angular/forms';

export interface FiduciaryBondComponent {
  // Poor man's TypeScript ”instanceof Interface” type check…
  instanceofFiduciaryBondComponent: boolean;

  fiduciaryObligeeStateSelectorControl(): FormControl;

  // specialBondFormControl(): FormControl;
}
