import { ApplicationBaseComponent } from './application-base-component';
import { FormControl, FormGroup } from '@angular/forms';
import { OnInit, ElementRef, Inject } from '@angular/core';
import { AbstractFormArrayMapper } from './abstract-form-array-mapper.service';
import { ServiceHandler } from '../../../common/utils/service-handler.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicationService } from '../application.service';
import { SecurityService } from '../../../security/security.service';
import { GoogleTagManagerService } from '../../../common/services/google-tag-manager.service';
import { ApplicationRoleService } from '../../../common/services/application-role-service';
import { MatDialog } from '@angular/material';
import { PersonService } from '../../../common/person-service';
import { CourtBondType } from './bond-types';
import { DOCUMENT } from '@angular/common';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';

export abstract class KnockoutQuestionsBaseComponent extends ApplicationBaseComponent implements OnInit {
  protected abstract get knockoutQuestionFormGroup(): FormGroup;

  protected constructor(
    abstractFormArrayMapper: AbstractFormArrayMapper,
    applicationService: ApplicationService,
    securityService: SecurityService,
    activatedRoute: ActivatedRoute,
    router: Router,
    bondType: CourtBondType,
    serviceHandler: ServiceHandler,
    googleTagManagerService: GoogleTagManagerService,
    applicationRoleService: ApplicationRoleService,
    personService: PersonService,
    dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    elementRef: ElementRef,
    spinnerService: SpinnerService
  ) {
    super(
      abstractFormArrayMapper,
      applicationService,
      securityService,
      activatedRoute,
      router,
      bondType,
      serviceHandler,
      googleTagManagerService,
      applicationRoleService,
      personService,
      dialog,
      document,
      elementRef,
      spinnerService
    );
  }

  async ngOnInit() {
    await super.ngOnInit();
    this.disableKnockoutQuestions();
  }

  disableKnockoutQuestions(): void {
    if (this.isSteward || (this.isKnockoutAnswered && this.isCreditScoreSatisfactory)) {

      if (this.application.data.knockedOut !== null) {
        Object.keys(this.knockoutQuestionFormGroup.controls).forEach(key => {
          this.knockoutQuestionFormGroup.get(key).disable();
        });

        this.otherPrequalificationPageFormFields().forEach(c => { if (c.value) { c.disable(); } });
      }
    }
  }

  protected abstract otherPrequalificationPageFormFields(): FormControl[];

  get isLinear(): boolean {
    return !this.isSteward && !this.pageOneIsValid();
  }

  pageOneIsValid(): boolean {
    return this.isKnockoutAnswered && this.stepperFormArray.at(0).valid;
  }

  get isKnockoutAnswered(): boolean {
    if (this.application.data.hasKnockoutQuestions()) {
      const knockoutQuestions = this.application.data[this.application.data.knockoutQuestionFieldName()];
      for (const kq of knockoutQuestions) {
        if (kq.value === null) {
          return false;
        }
      }
      return true;
    } else {
      return false;
    }
  }

  async saveApplication(savedMessage: string = 'Saving Form...'): Promise<void> {
    await super.saveApplication(savedMessage);
    this.disableKnockoutQuestions();
  }
}
