import { AbstractControl } from '@angular/forms';


export interface FormArrayMapper {
  [key: string]: AbstractControl;
}
