import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ApplicationService } from '../application.service';
import { HostListener, Input, OnDestroy, OnInit, Inject, ElementRef } from '@angular/core';
import { FormArray, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Subject, Subscription } from 'rxjs';
import { FormArrayMapper } from './form-array-mapper';
import { AbstractFormArrayMapper } from './abstract-form-array-mapper.service';
import { ApplicationData, ApplicationDataImpl } from '../court/model/application-data';
import { SecurityService } from '../../../security/security.service';
import { Client } from '../../../common/client';
import { CurrencyFormatter } from '../../../common/utils/currency-formatter';
import { Question, QuestionImpl } from '../question';
import { DynamicQuestion, DynamicQuestionImpl } from '../court/model/common/dynamic-question';
import { QuestionMap } from './question-map';
import { ConditionalValidator } from '../../../common/validators/conditional-validator';
import { Agent } from '../../../common/agent';
import { ControlValidator } from './control-validator';
import { ApplicationImpl } from '../application';
import { ServiceHandler } from '../../../common/utils/service-handler.service';
import { DisplayQuestion } from '../display-question';
import { CommonUtilities } from '../../../common/utils/common-utilities';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { UserImpl } from '../../../security/user';
import { GoogleTagManagerService } from '../../../common/services/google-tag-manager.service';
import { ApplicationRoleService } from '../../../common/services/application-role-service';
import {
  PaymentMethodSelectionFormGroup,
  PaymentMethodSelectionFormGroupConfig,
} from '../../../common/payment-method-selection/payment-method-selection-form-group';
import { ApplicationInitializationData } from '../application-initialization/application-initialization-data';
import { PatternValidators } from '../../../common/validators/pattern-validators';
import {
  ChangeBondAmountData,
  ChangeBondAmountDialogComponent,
} from '../court/change-bond-amount/change-bond-amount-dialog.component';
import { MatDialog } from '@angular/material';
import { CourtBondType, CourtBondTypeDisplayNames, isFiduciaryBondType } from './bond-types';
import { FiduciaryBondComponent } from './fiduciary-bond.component';
import { ConfirmationDialogComponent } from '../../../common/confirmation-dialog/confirmation-dialog.component';
import { McdCopyPlaceholders } from './mcd-copy-placeholders';
import { PersonService } from '../../../common/person-service';
import { ApplicationFileImpl } from '../court/model/common/application-file';
import { DOCUMENT } from '@angular/common';
import { SpinnerService } from 'src/app/ibond/service/spinner.service';
import { NoopScrollStrategy } from '@angular/cdk/overlay';

export const PAYMENT_INFORMATION_FORM_GROUP_NAME = 'paymentInformation';

export abstract class ApplicationBaseComponent implements OnInit, OnDestroy {

  @Input()
  public id: number;

  @Input()
  public currentUserIsSteward: boolean;

  @Input()
  public agentAsApplicant: boolean;

  @Input()
  public applicant: Client;

  @Input()
  public agent: Agent;

  @Input()
  public application: ApplicationImpl;

  @Input()
  applicationInitialization: ApplicationInitializationData;

  public pageIndex: number;

  public user: UserImpl;

  public responsiblePersonId: number;

  public displayName: string;

  protected abstract stepperFormArray: FormArray;
  public premium: string;
  public amount: string;
  public questionMap: QuestionMap = {};
  returnUrl: string;
  disableSubmit = false;
  userType: string;
  pendingStatus: string;
  // a subscription whose sole purpose is to support cleanup of subscriptions.
  private _rootCleanupSubscription: Subscription = new Subscription();

  private fileTypeToFileUploadActiveSubject: Map<String, Subject<boolean>> = new Map();

  protected constructor(public abstractFormArrayMapper: AbstractFormArrayMapper,
    public applicationService: ApplicationService,
    public securityService: SecurityService,
    public activatedRoute: ActivatedRoute,
    public router: Router,
    public bondType: CourtBondType,
    public serviceHandler: ServiceHandler,
    public googleTagManagerService: GoogleTagManagerService,
    public applicationRoleService: ApplicationRoleService,
    public personService: PersonService,
    protected dialog: MatDialog,
    @Inject(DOCUMENT) public document,
    public elementRef: ElementRef,
    public spinnerService: SpinnerService
  ) { this.displayName = CourtBondTypeDisplayNames[this.bondType]; }

  protected abstract createNewApplication(): void;

  disableFormArrayInputs?(): void;

  protected abstract get formArrayMapper(): FormArrayMapper[];

  protected abstract get paymentInformationFormGroup(): FormGroup;

  abstract get isLinear(): boolean

  async ngOnInit() {
    this.pageIndex = 0;

    this.initializeApplication();

    // send to the page after the quote page.
    // possibly in the future well want to send them to the page that is not done
    // which should be easy enough to do
    // this.pageIndex = findTheFirstInvalidPage;
    this.user = this.securityService.user;

    if (this.isCompany) {
      const person = await this.personService.getCompanyOfficeResponsiblePersonByCompanyOfficeId(this.application.companyOffice.id);
      this.responsiblePersonId = person.id;
    } else {
      this.responsiblePersonId = this.application.person.id;
    }
  }

  ngOnDestroy(): void {
    this.unregisterFileTypeFileUploadActiveSubjects();
    this._rootCleanupSubscription.unsubscribe();
  }

  @HostListener('window:beforeunload', ['$event'])
  refresh($event) {
    return (this.isEmployee);
  }
  // Bing Code Snippet-add GTM script configuration
  bingSnippetConfig() {
    const bingSnippet = this.document.createElement('script');
    bingSnippet.type = 'text/javascript';
    bingSnippet.innerHTML = `
      (function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function()
        {var o={ti:"15215878"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},
        n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function()
        {var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},
        i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})
        (window,document,"script","//bat.bing.com/bat.js","uetq");
      `;
    this.elementRef.nativeElement.appendChild(bingSnippet);
  }
  async saveApplication(savedMessage: string = 'Saving Form...') {
    // this.serviceHandler.handleConfirm(savedMessage);
    const rawFormArrayData = this.stepperFormArray.getRawValue();
    const applicationData: ApplicationDataImpl = this.abstractFormArrayMapper.formArrayJsonToObject(rawFormArrayData);
    if (this.amount && this.premium) {
      applicationData.amount = this.amount;
      applicationData.premium = this.premium;
    }

    if (applicationData.hasKnockoutQuestions()) {
      applicationData[applicationData.knockoutQuestionFieldName()] = this.populateQuestionInDynamicQuestions(this.questionMap,
        applicationData[applicationData.knockoutQuestionFieldName()]);
    }

    this.application.data = applicationData;
    this.spinnerService.show();
    this.application = await this.applicationService.update(this.id, this.bondType, this.application, this.isProcessPaymentInformation);
    this.spinnerService.hide();
    if (this.application.amount && this.application.premium) {
      this.amount = this.application.amount;
      this.premium = this.application.premium;
    }
    if (this.application.data.hasKnockoutQuestions()) {
      this.questionMap =
        this.extractQuestionDataFromDynamicQuestions(this.application.data[this.application.data.knockoutQuestionFieldName()]);
    }
    const formArrayData = this.abstractFormArrayMapper.objectToFormArrayJson(this.application.data);
    this.handleFormArrays(formArrayData);
    this.stepperFormArray.patchValue(formArrayData);
    this.checkoutKnockedOut(this.application.data); // this point is important for navigation to knockout page

    if (savedMessage) {
      this.serviceHandler.handleConfirm(savedMessage);
    }
  }

  /**
   * Save the application, optionally bypassing validation, then route back to home
   *
   * The knockout pages of court bonds (C/G, E/T, R/R) want to bypass validation on the client and
   * avoid side effects on the server
   *
   * @returns {Promise<void>}
   */
  async saveForLater(shouldValidate: boolean = true) {
    const message = 'Saving For Later...';

    if (this.currentUserIsTheApplicantOfTheApplication() || this.currentUserIsTheAgentOfTheApplication()) {
      if (shouldValidate) {
        await this.saveApplication(message);
      } else {
        this.serviceHandler.handleConfirm(message);
        const rawFormArrayData = this.stepperFormArray.getRawValue();
        const applicationData: ApplicationDataImpl = this.abstractFormArrayMapper.formArrayJsonToObject(rawFormArrayData);
        if (this.amount && this.premium) {
          applicationData.amount = this.amount;
          applicationData.premium = this.premium;
        }

        if (applicationData.hasKnockoutQuestions()) {
          applicationData[applicationData.knockoutQuestionFieldName()] = this.populateQuestionInDynamicQuestions(this.questionMap,
            applicationData[applicationData.knockoutQuestionFieldName()]);
        }

        this.application.data = applicationData;
        this.application = await this.applicationService.saveForLater(this.id, this.bondType, this.application
          , this.isProcessPaymentInformation);
      }
    }

    await this.router.navigateByUrl('/');
  }

  async submit() {
    this.spinnerService.show();
    if (this.stepperFormArray.valid) {
      this.disableSubmitButton();
      const rawFormArrayData = this.stepperFormArray.getRawValue();
      const applicationData: ApplicationDataImpl = this.abstractFormArrayMapper.formArrayJsonToObject(rawFormArrayData);

      if (this.amount && this.premium) {
        applicationData.amount = this.amount;
        applicationData.premium = this.premium;
      }

      if (applicationData.hasKnockoutQuestions()) {
        applicationData[applicationData.knockoutQuestionFieldName()] = this.populateQuestionInDynamicQuestions(this.questionMap,
          applicationData[applicationData.knockoutQuestionFieldName()]);
      }
      this.application.data = applicationData;
      try {
        this.application = await this.applicationService.submit(this.id, this.bondType, this.application).toPromise();
        this.serviceHandler.handleConfirm('This application\'s status has been changed to Submitted.');
        this.checkoutKnockedOut(this.application.data);

        if (this.application.data.hasKnockoutQuestions()) {
          this.questionMap =
            this.extractQuestionDataFromDynamicQuestions(this.application.data[this.application.data.knockoutQuestionFieldName()]);
        }
        const confirmationMessage = this.determineConfirmationMessage();
        localStorage.setItem('confirmationMessage', confirmationMessage);
        await this.router.navigateByUrl('/');
        if (this.application.status === 'Completed') {
          this.pendingStatus = this.application.status;
        } else if (this.application.status === 'Declined') {
          this.pendingStatus = this.application.status;
        } else {
          this.pendingStatus = 'pending';
        }
        this.sendCourtBondAppCompleteStep(
          `${this.application['quoteId']}`,
          'new',
          this.id,
          this.application['data'].paymentMethod.paymentChannelCode.cardValidatorType,
          this.pendingStatus
        );
        this.bingSnippetConfig();
        this.spinnerService.hide();
      } catch (err) {
        this.enableSubmitButton();
        this.serviceHandler.setErrorBlock(err.error['message']);
        this.spinnerService.hide();
      }
    } else {
      this.validatePage(this.stepperFormArray.length - 1); // validate the last page.
      this.serviceHandler.showErrorMessage('There are errors in your application, please fix them before submitting');
      this.goToFirstInvalidPage();
      this.spinnerService.hide();
    }
  }

  private determineConfirmationMessage(): string {
    let confirmationMessage = 'Thank you. Your application is being processed. We will email you when it is ready.';
    if (this.application.status === 'Completed') {
      confirmationMessage = 'Thank you for your purchase from Colonial Surety Company. Your bond is ready for download.';
    }
    if (this.application.status === 'Declined') {
      if (isFiduciaryBondType(this.bondType)) {
        if (this.bondIsForAnObligeeInVirginia()) {
          confirmationMessage = JSON.stringify({
            type: 'warn',
            message: McdCopyPlaceholders.VirginiaObligeeFiduciaryApplicationAutoDeclinedMessage,
          });
        }
      }
    }
    return confirmationMessage;
  }

  private bondIsForAnObligeeInVirginia() {
    return this.application.data
      && this.application.data.court
      && this.application.data.court.address
      && this.application.data.court.address.state === 'VA';
  }

  determineTypeOfClient() {
    if (this.securityService.user.hasAgentRole) {
      this.userType = 'Agent';
    }

    if (this.securityService.user.hasAttorneyRole) {
      this.userType = 'Attorney';
    }

    if (!this.securityService.user.hasAttorneyRole
      && !this.securityService.user.hasAgentRole
      && !this.securityService.user.hasSuperuserRole) {
      if (this.securityService.user && this.securityService.user.isCompany) {
        this.userType = 'Company';
      } else {
        this.userType = 'Individual';
      }
    }
  }

  sendCourtBondAppCompleteStep(quoteId?, bondClass?, applicationID?, paymentType?, status?) {
    this.determineTypeOfClient();
    const gtmBondType = this.applicationService.setBondType(this.bondType);
    const user = this.securityService.user;
    const userType = user ? (user.hasAttorneyRole ? 'attorney' : user.userRoles[0].userRoleRef.role) : 'anonymous';
    const lpGroup = '';
    const lpBond = '';
    this.googleTagManagerService.sendEvent(
      'court-bond-app-complete',
      `${gtmBondType}`,
      `${this.premium}`,
      `${userType}`,
      `${lpGroup}`,
      `${lpBond}`,
      `${quoteId}`,
      `${bondClass}`,
      `${applicationID}`,
      `${paymentType}`,
      `${status}`
    );
  }

  extractQuestionDataFromDynamicQuestions(dynamicQuestions: Array<DynamicQuestion>): QuestionMap {
    const map: QuestionMap = {};
    for (const dynamicQuestion of dynamicQuestions) {
      const question = dynamicQuestion.question;
      map[question.name] = question;
    }
    return map;
  }

  populateQuestionInDynamicQuestions(questionMap: QuestionMap, dynamicQuestions: Array<DynamicQuestionImpl>): Array<DynamicQuestionImpl> {
    const populatedDynamicQuestions: Array<DynamicQuestionImpl> = new Array<DynamicQuestionImpl>();
    // for each dynamic question...
    for (const dynamicQuestion of dynamicQuestions) {
      // look up the question impl in the question map based on the name
      const question: QuestionImpl = questionMap[dynamicQuestion.question.name];
      // create and populate the question of the dynamic question with the question you just got from the map
      const freshDynamicQuestion: DynamicQuestionImpl = new DynamicQuestionImpl();
      // add the value from the "old" dynamic question
      freshDynamicQuestion.value = dynamicQuestion.value;
      freshDynamicQuestion.question = question;
      populatedDynamicQuestions.push(freshDynamicQuestion);
    }
    return populatedDynamicQuestions;
  }

  async gotoHandOffScreen() {
    if (this.stepperFormArray.valid) {
      await this.saveApplication();
      this.returnUrl = `/`;
      await this.router.navigate([`/enrollment/agent-handoff/${this.application.id}`],
        { queryParams: { returnUrl: this.router.url } } as NavigationExtras);
    } else {
      CommonUtilities.markAllTouched(this.stepperFormArray); // We don't know which page has an error so touch them all.
      this.serviceHandler.showErrorMessage('There are errors in your application, please fix them before sending to client.');
      this.goToFirstInvalidPage();
    }
  }

  get isCreditScoreSatisfactory(): boolean {
    const rawFormArrayData = this.stepperFormArray.getRawValue();
    const applicationData: any = this.abstractFormArrayMapper.formArrayJsonToObject(rawFormArrayData);

    if (applicationData.creditScoreSatisfactory === undefined ||
      applicationData.creditScoreSatisfactory === null) {
      return true;
    }
    return !!applicationData.creditScoreSatisfactory;
  }

  checkoutKnockedOut(applicationData: ApplicationData) {
    const { knockedOut, knockedOutReason } = applicationData;

    if (knockedOut) {
      if (this.application.status === 'Completed') {
        this.pendingStatus = this.application.status;
      } else if (this.application.status === 'Declined') {
        this.pendingStatus = this.application.status;
      } else {
        this.pendingStatus = 'pending';
      }
      this.router.navigate(['/com/knockout-dialog'], { queryParams: { reason: knockedOutReason } } as NavigationExtras).then(() => {
        this.sendCourtBondAppCompleteStep(
          `${this.application['quoteId']}`,
          'new',
          this.id,
          // this.application['data'].paymentMethod.paymentChannelCode.cardValidatorType,
          '',
          this.pendingStatus
        );
      });
    }
  }

  setConditionalValidators(controlValidators: ControlValidator[]) {
    controlValidators.forEach((cv) => this.setConditionalValidator(cv.formControl, cv.validators));
  }

  setConditionalValidator(formControl: FormControl, validators: ValidatorFn | ValidatorFn[] | null) {
    formControl.setValidators(validators);
  }

  setControlValidator(controlValidator: ControlValidator) {
    this.setConditionalValidator(controlValidator.formControl, controlValidator.validators);
  }

  updateOnChangeEvents(changingFormControl: FormControl, updateFormControls: FormControl | FormControl[]) {
    changingFormControl.valueChanges.subscribe((val) => {
      if (updateFormControls instanceof Array) {
        updateFormControls.forEach((control) => control.updateValueAndValidity());
      } else {
        updateFormControls.updateValueAndValidity();
      }
    });
  }

  validatePage(i: number) {
    if (!this.stepperFormArray.at(i).valid) {
      CommonUtilities.markAllTouched(this.stepperFormArray.at(i));
    }
  }

  /**
   * This is the event handler for when a step changes.
   *
   * Note this should be treated as the default functionality.  Feel free to implement your own if you need to check certain things on
   * specific page transitions (event.selectedIndex and event.previouslySelectedIndex will be what you want to check in those cases)
   *
   * @param event
   */

  stepSelectionChange(event: StepperSelectionEvent) {
    if (event.previouslySelectedIndex < event.selectedIndex) {
      if (this.currentUserIsTheApplicantOfTheApplication() || this.currentUserIsTheAgentOfTheApplication()) {
        this.saveApplication();
      }

      // make sure previous pages shows field errors
      for (let i = event.previouslySelectedIndex; i < event.selectedIndex; i++) {
        this.validatePage(i);
      }
    }
    if (event.previouslySelectedIndex === this.stepperFormArray.length - 1 && event.selectedIndex < this.stepperFormArray.length - 1) {
      this.validatePage(this.stepperFormArray.length - 1); // validate the last page.
    }

    this.pageIndex = event.selectedIndex;
  }

  currentUserIsTheApplicantOfTheApplication(): boolean {
    return this.responsiblePersonId === this.securityService.user.person.id;
  }

  currentUserIsTheAgentOfTheApplication(): boolean {
    const maybeAgentIdOfApplication = this.application.agent && this.application.agent.id;
    const maybeAgentIdOfUser = this.securityService.user.agent && this.securityService.user.agent.id;
    return !!maybeAgentIdOfApplication && !!maybeAgentIdOfUser && maybeAgentIdOfApplication === maybeAgentIdOfUser;
  }

  goToFirstInvalidPage() {
    for (let i = 0; i < this.stepperFormArray.length; i++) {
      if (!this.stepperFormArray.at(i).valid) {
        this.pageIndex = i;
        break;
      }
    }
  }

  getPaymentInformationFormGroupControl(formControlPath: string): FormControl | null {
    let paymentInformationFormGroupControl: FormControl;
    paymentInformationFormGroupControl = this.paymentInformationFormGroup.get(formControlPath) as FormControl;
    return paymentInformationFormGroupControl;
  }

  createPaymentInformationFormGroup(): PaymentMethodSelectionFormGroup {
    let paymentMethodSelectionFormGroup: PaymentMethodSelectionFormGroup;
    const paymentMethodSelectionFormGroupConfig: PaymentMethodSelectionFormGroupConfig = {
      isRequired: !this.isSteward,
      isDisabled: this.isEmployee,
    };
    paymentMethodSelectionFormGroup = new PaymentMethodSelectionFormGroup(this._rootCleanupSubscription
      , paymentMethodSelectionFormGroupConfig);
    return paymentMethodSelectionFormGroup;
  }

  protected createDeliveryInformationFormGroup(): FormGroup {
    let deliveryInformationFormGroup: FormGroup;
    const staticIsDisabled = this.isEmployee;
    const staticIsRequired = this.requiredIfNotAgent;
    deliveryInformationFormGroup = new FormGroup({
      deliveryMethod: new FormControl({ value: null, disabled: staticIsDisabled }, [staticIsRequired]),
      copyViaEmail: new FormControl({ value: null, disabled: staticIsDisabled }, []),
      deliveryName: new FormControl({ value: null, disabled: staticIsDisabled }, []),
      deliveryPhone: new FormControl({ value: null, disabled: staticIsDisabled }, [PatternValidators.phoneNumber()]),
      deliveryAddress: this.createRequiredAddressFormGroup(staticIsDisabled, staticIsRequired),
    });
    return deliveryInformationFormGroup;
  }

  /**
   * Create the 'most common' configuration of an Applicant's Address FormGroup used in an Application.
   */
  protected createApplicantAddressFormGroup(): FormGroup {
    return this.createOptionalAddressFormGroup(false);
  }

  /**
   * Create the 'most common' configuration of a generic Address FormGroup used in an Application.
   */
  protected createApplicationAddressFormGroup(): FormGroup {
    const staticIsDisabled = this.isEmployee;
    const staticIsRequired = this.requiredIfNotAgent;
    return this.createRequiredAddressFormGroup(staticIsDisabled, staticIsRequired);
  }

  /**
   * Create an address FormGroup.
   * @param staticIsDisabled value to be assigned to the 'disabled' FormControl property.
   * @param staticIsRequired static, but possibly conditional,'isRequired' ValidatorFn
   * to be registered with the address FormGroup's FormControls.
   */
  protected createRequiredAddressFormGroup(staticIsDisabled: boolean, staticIsRequired: ValidatorFn): FormGroup {
    return new FormGroup({
      street1: new FormControl({ value: null, disabled: staticIsDisabled }, [staticIsRequired, Validators.maxLength(60)]),
      // street2 is currently never required.
      street2: new FormControl({ value: null, disabled: staticIsDisabled }, [Validators.maxLength(60)]),
      city: new FormControl({ value: null, disabled: staticIsDisabled }, [staticIsRequired, Validators.maxLength(30)]),
      state: new FormControl({ value: null, disabled: staticIsDisabled }, [staticIsRequired]),
      zipCode: new FormControl({ value: null, disabled: staticIsDisabled }, [staticIsRequired, PatternValidators.zipCode()]),
    });
  }

  /**
   * Create an address FormGroup.
   * @param staticIsDisabled value to be assigned to the 'disabled' FormControl property.
   * to be registered with the address FormGroup's FormControls.
   */
  protected createOptionalAddressFormGroup(staticIsDisabled: boolean): FormGroup {
    return new FormGroup({
      street1: new FormControl({ value: null, disabled: staticIsDisabled }, [Validators.maxLength(60)]),
      street2: new FormControl({ value: null, disabled: staticIsDisabled }, [Validators.maxLength(60)]),
      city: new FormControl({ value: null, disabled: staticIsDisabled }, [Validators.maxLength(30)]),
      state: new FormControl({ value: null, disabled: staticIsDisabled }, []),
      zipCode: new FormControl({ value: null, disabled: staticIsDisabled }, [PatternValidators.zipCode()]),
    });
  }

  /**
   * Manage the fileType's fileUpload and FormGroup wrt/ 'obsolete' uploaded files if the FileUploadMode is no longer fileUpload.
   * @param fileType of fileUpload
   * @param fileUploadFormGroup that manages uploaded file's id and name.
   * @return Subject which can be injected in file-upload components.
   */
  registerFileTypeFileUploadActiveSubject(fileType: string, fileUploadFormGroup: FormGroup) {
    const fileUploadActiveSubject = this.getOrCreateFileUploadActiveSubject(fileType);
    fileUploadActiveSubject.subscribe(async (fileUploadMode: boolean) => {
      if (fileUploadMode) {
        // File Upload mode is selected. Nothing to do.
      } else {
        // File Upload mode is not selected ...
        const fileIdControl = fileUploadFormGroup.get('id');
        const fileNameControl = fileUploadFormGroup.get('name');
        const fileId = fileIdControl.value;
        if (fileId !== null) {
          // ... and we have a fileUpload. The file upload is therefore now 'obsolete'.
          // Request file deletion and clear formControls of uploaded file info.
          await this.applicationService.deleteApplicationFileUpload(this.id, fileId);
          fileIdControl.setValue(null);
          fileNameControl.setValue(null);
          await this.saveApplication();
        }
      }
    });
  }

  private unregisterFileTypeFileUploadActiveSubjects() {
    this.fileTypeToFileUploadActiveSubject.forEach((subject, fileType, map) => {
      subject.unsubscribe();
    });
  }

  /**
   * Get or create a FileUploadActive Subject for the given upload fileType.
   * @param fileType of fileUpload
   */
  getOrCreateFileUploadActiveSubject(fileType: string): Subject<boolean> {
    let fileUploadActiveSubject;
    if (this.fileTypeToFileUploadActiveSubject.has(fileType)) {
      fileUploadActiveSubject = this.fileTypeToFileUploadActiveSubject.get(fileType);
    } else {
      fileUploadActiveSubject = new Subject<boolean>();
      this.fileTypeToFileUploadActiveSubject.set(fileType, fileUploadActiveSubject);
    }
    return fileUploadActiveSubject;
  }

  /**
   * A boolean Subject that 'fires' when specialBond document submission mode changes on or off of the file upload option.
   * Subject value indicates whether the fileUpload option is active.
   */
  // get specialBondFileUploadActive() {
  //   return this.getOrCreateFileUploadActiveSubject('specialBondFile');
  // }

  /**
   * A boolean Subject that 'fires' when courtOrder document submission mode changes on or off of the file upload option.
   * Subject value indicates whether the fileUpload option is active.
   */
  get courtOrderFileUploadActive() {
    return this.getOrCreateFileUploadActiveSubject('courtOrderFile');
  }

  /**
   * A boolean Subject that 'fires' when personalFinancial document submission mode changes on or off of the file upload option.
   * Subject value indicates whether the fileUpload option is active.
   */
  get personalFinancialFileUploadActive() {
    return this.getOrCreateFileUploadActiveSubject('personalFinancialFile');
  }

  /**
   * A boolean Subject that 'fires' when judgment document submission mode changes on or off of the file upload option.
   * Subject value indicates whether the fileUpload option is active.
   */
  get judgmentFileUploadActive() {
    return this.getOrCreateFileUploadActiveSubject('judgmentFile');
  }

  async fileUploadSuccessHandler(val) {
    this.spinnerService.show();
    if (val) {
      await this.saveApplication();
      this.spinnerService.hide();
    }
  }

  get questionMapKeys(): string[] {
    const keys = Object.keys(this.questionMap);
    const mappingKeysToQuestions = (keyToQuestionFn) => (compareFn) => (a, b) => compareFn(keyToQuestionFn(a), keyToQuestionFn(b));
    const sortAscendingBy = (sortByFn) => (a, b) => sortByFn(a) - sortByFn(b);
    keys.sort(mappingKeysToQuestions(k => this.questionMap[k])(sortAscendingBy(q => q.displayOrder)));
    return keys;
  }

  get requiredIfNotAgent(): ValidatorFn {
    return ConditionalValidator.conditionalRequire((() => !this.isSteward));
  }

  get requiredIfCompanyAndNotAgent(): ValidatorFn {
    return ConditionalValidator.conditionalRequire((() => !this.isSteward && this.isCompany));
  }

  get isSteward(): boolean {
    return this.currentUserIsSteward && !this.agentAsApplicant;
  }

  get isCompany(): boolean {
    return !!(this.application.companyOffice && this.application.companyOffice.id);
  }

  createNewDisplayQuestion(question: Question): DisplayQuestion {
    return new DisplayQuestion(question, {});
  }

  get isEmployee(): boolean {
    return this.applicationRoleService.hasEmployeePermissions();
  }

  get isProcessPaymentInformation(): boolean {
    let isProcessPaymentInformation = false;
    // See if payment info is filled in and dirty, then instruct server to validate payment by passing in "processPaymentMethod" param
    if (!!this.applicationInitialization) {
      if (!!this.applicationInitialization.paymentMethodInitializationData) {
        isProcessPaymentInformation = this.applicationInitialization.paymentMethodInitializationData.isProcessPaymentInformation();
      }
    }
    return isProcessPaymentInformation;
  }

  handleFormArrays(courtBondFormArrayRawData: any) {
    for (let i = 0; i < this.formArrayMapper.length; i++) {
      const formArraysForPage = this.formArrayMapper[i];
      if (Object.keys(formArraysForPage)) {
        for (const key in formArraysForPage) {
          if (formArraysForPage[key]) {
            const formArray: FormArray = this.stepperFormArray.at(i).get(key) as FormArray;
            const rawFormArrayData = courtBondFormArrayRawData[i][key];
            if (rawFormArrayData) {
              for (const formGroupIndexString in rawFormArrayData) {
                if (rawFormArrayData.hasOwnProperty(formGroupIndexString)) {
                  const formGroupIndex = (+formGroupIndexString); // String -> Number.
                  if (formArray.length < (formGroupIndex + 1)) {
                    // Controls hierarchy has fewer controls then is present in the data hierarchy for this 'key'.
                    let emptyFormGroup;
                    const firstEmptyFormGroup = formArraysForPage[key];
                    if (formGroupIndex === 0) {
                      // This is the first element of raw data. We simply use the first/existing control from the formArray.
                      emptyFormGroup = firstEmptyFormGroup;
                    } else {
                      // This is the not first element of raw data.
                      // We therefore need a new control since the first control has already been allocated.
                      // Make a clone the initial/pre-existing control from the formArray.
                      emptyFormGroup = CommonUtilities.cloneAbstractControl(firstEmptyFormGroup);
                    }
                    formArray.push(emptyFormGroup);
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  trackByQuestionKey(index: number, questionKey: string): string {
    return questionKey;
  }

  disableSubmitButton() {
    this.disableSubmit = true;
  }

  enableSubmitButton() {
    this.disableSubmit = false;
  }

  changeBondAmount(): void {
    const data: ChangeBondAmountData = {
      bondType: this.bondType as CourtBondType,
      change: async (newAmount, newPremium) => {
        await this.saveApplication('Updating Bond Amount and Premium...');

        const [amount, premium] = [newAmount, newPremium].map(_ => _.toString());
        this.application.amount = amount;
        this.application.premium = premium;

        this.application.data.amount = amount;
        this.application.data.premium = premium;

        this.application = await this.applicationService.update(
          this.application.id,
          this.bondType,
          this.application,
          false
        );
        // this.initializeApplication();
        if (this.application.amount && this.application.premium) {
          this.amount = CurrencyFormatter.formatMoney(this.application.amount);
          this.premium = CurrencyFormatter.formatMoney(this.application.premium);
        }
        const rawFormArrayData = this.abstractFormArrayMapper.objectToFormArrayJson(this.application.data);
        this.handleFormArrays(rawFormArrayData);
        this.stepperFormArray.patchValue(rawFormArrayData);
      },
    };
    const width = '800px';
    this.dialog.open(ChangeBondAmountDialogComponent, {
      width, data, panelClass: 'vertical-scroll',
      scrollStrategy: new NoopScrollStrategy(),
    });
  }

  private initializeApplication(): void {
    this.createNewApplication();

    // set this to true if its an agent of some sort filling out an application for not him/herself
    if (this.application.amount && this.application.premium) {
      this.amount = CurrencyFormatter.formatMoney(this.application.amount);
      this.premium = CurrencyFormatter.formatMoney(this.application.premium);
    }

    const rawFormArrayData = this.abstractFormArrayMapper.objectToFormArrayJson(this.application.data);
    this.handleFormArrays(rawFormArrayData);
    this.stepperFormArray.patchValue(rawFormArrayData);

    if (this.application.data.hasKnockoutQuestions()) {
      this.checkoutKnockedOut(this.application.data);
      this.questionMap =
        this.extractQuestionDataFromDynamicQuestions(this.application.data[this.application.data.knockoutQuestionFieldName()]);
    }

    if (this.disableFormArrayInputs) {
      this.disableFormArrayInputs();
    }

    // Poor man's TypeScript ”instanceof Interface” type check…
    if (this['instanceofFiduciaryBondComponent']) {
      const thisFiduciaryBondComponent = <FiduciaryBondComponent><unknown>this;
      thisFiduciaryBondComponent
        .fiduciaryObligeeStateSelectorControl()
        .valueChanges
        .subscribe(state => {
          // FRO-350 - Virginia Fiduciary Exceptions
          if (state === 'VA') {
            this.dialog.open(ConfirmationDialogComponent, {
              data: {
                title: McdCopyPlaceholders.VirginiaFiduciaryObligeeStateSelectorModalTitleText,
                detailsText: McdCopyPlaceholders.VirginiaFiduciaryObligeeStateSelectorModalBodyText,
                acceptLabel: 'OK',
              },
              width: '550px',
            });
          }

          // const specialBondFormControl = thisFiduciaryBondComponent.specialBondFormControl();

          // FRO-351 - Michigan Fiduciary Exceptions - Michigan has a state-wide special bond form, so default to “Yes”
          // if (state === 'MI') {
          //   specialBondFormControl.setValue(true);
          // }

          // FRO-351 - New Jersey Fiduciary Exceptions - special bond form is not required, since it's the same as the court order
          /* let specialBondFormValidators = null;
          if (state === 'NJ') {
            specialBondFormControl.setValue(false);
            specialBondFormValidators = this.requiredIfNotAgent;
            // Also delete any existing special bond files!
            this.applicationService.getFileListForApplication(this.application.id).subscribe(fs => {
              const specialBondFiles = fs.filter(({ fileTypeName }) => fileTypeName === 'specialBondFile');

              // If there was at least one special bond file, then we also delete it/them
              // and clear out the other special bond form related questions
              if (specialBondFiles.length > 0) {
                specialBondFiles.forEach(({ id }) => this.applicationService.deleteApplicationFileUpload(this.application.id, id));

                // Clear out the special bond form data, but which page is it on? Roll up our sleeves and search, I guess…
                for (let i = 0; i < this.stepperFormArray.length; i++) {
                  const currentPage = this.stepperFormArray.at(i);
                  // Try to destructure the values we're interested in out of the current page
                  const { specialBondFile, specialBondForm, specialBondUpload } = currentPage.value;
                  // If they don't exist on that page, they will be set to undefined; explicitly test for that value
                  if (!(specialBondFile === undefined || specialBondForm === undefined || specialBondUpload === undefined)) {
                    // Ok, we found the page that has the special bond form data! Blow it away, and save!
                    currentPage.patchValue({
                      specialBondFile: new ApplicationFileImpl(),
                      specialBondForm: false,
                      specialBondUpload: false,
                    });
                    this.saveApplication();
                  }
                }
              }
            });
          }

          specialBondFormControl.setValidators(specialBondFormValidators);
          specialBondFormControl.updateValueAndValidity();
        });
    } */
        });
    }
  }
}
