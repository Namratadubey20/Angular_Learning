// Replace these strings with the actual copy content from Colonial / MCD
export enum McdCopyPlaceholders {
  VirginiaFiduciaryObligeeQuotePageWarning
  = 'Colonial Surety Company does not sell this bond type for scenarios with the obligee in the state of Virginia.',

  VirginiaFiduciaryObligeeStateSelectorModalTitleText
  = 'Unable to buy bond for Obligees in Virginia',

  // VirginiaFiduciaryObligeeStateSelectorModalBodyText
  // = 'Colonial Surety Company does not sell this bond type for obligees in the state of Virginia.',

  VirginiaFiduciaryObligeeStateSelectorModalBodyText
  = 'Sorry at this time we are not able to write this bond in your state.',

  VirginiaObligeeFiduciaryApplicationAutoDeclinedMessage
  = 'Sorry, your application has been declined due to obligee state. Please call us at 800-221-3662 for questions',
}
