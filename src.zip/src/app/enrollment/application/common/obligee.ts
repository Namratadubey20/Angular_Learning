import { Address, AddressImpl } from '../court/model/common/address';
import { JsonObject, JsonProperty } from 'json2typescript';


export interface Obligee {
  name: string;
  address: Address;
}

@JsonObject('ObligeeImpl')
export class ObligeeImpl implements Obligee {

  @JsonProperty('name', String, true)
  name: string = null;

  @JsonProperty('address', AddressImpl, true)
  address: Address = new AddressImpl();

}
