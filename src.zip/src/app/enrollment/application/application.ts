import { Agent, AgentImpl } from '../../common/agent';
import { CompanyOffice, CompanyOfficeImpl } from '../../common/company-office';
import { Person, PersonImpl } from '../../common/person';
import { ProductType, ProductTypeImpl } from '../../product/product-type';
import { JsonObject, JsonProperty } from 'json2typescript';
import { ApplicationData, ApplicationDataImpl } from './court/model/application-data';
import { CurrencyConverter } from '../../common/utils/currency-converter';
import { Auditable, AuditableProfile } from '../../common/auditable-object';
import { ApplicationDataConverter } from './court/model/application-data-converter';
import { CourtInformationImpl } from './court/model/common/court-information';
import { PersonSummary } from '../../common/person-summary';

export interface Application extends Auditable {
  id: number;
  amount: string;
  premium: string;
  data: ApplicationData;
  status: string;
  productType: ProductType;
  agent: Agent;
  companyOffice: CompanyOffice;
  person: Person;
  readonly applicationResponsiblePerson: PersonSummary;
  toDate: Date;
  fromDate: Date;
  creditScoreOverride;
  koqOverride: boolean;
  quoteId: number;
}

@JsonObject('ApplicationImpl')
export class ApplicationImpl extends AuditableProfile implements Application {

  @JsonProperty('amount', CurrencyConverter, true)
  amount: string = null;

  @JsonProperty('premium', CurrencyConverter, true)
  premium: string = null;

  @JsonProperty('data', ApplicationDataConverter, true)
  data: ApplicationDataImpl = new ApplicationDataImpl();

  @JsonProperty('status', String, true)
  status: string = null;

  @JsonProperty('productType', ProductTypeImpl, true)
  productType: ProductType = new ProductTypeImpl();

  @JsonProperty('agent', AgentImpl, true)
  agent: Agent = new AgentImpl();

  @JsonProperty('companyOffice', CompanyOfficeImpl, true)
  companyOffice: CompanyOffice = new CompanyOfficeImpl();

  @JsonProperty('person', PersonImpl, true)
  person: Person = new PersonImpl();

  @JsonProperty('court', CourtInformationImpl, true)
  court: CourtInformationImpl = new CourtInformationImpl();

  @JsonProperty('creditScoreOverride', Boolean, true)
  creditScoreOverride: boolean = null;

  @JsonProperty('koqOverride', Boolean, true)
  koqOverride = false;

  @JsonProperty('quoteId', Number, true)
  quoteId: number = null;

  get isKnockedOut(): boolean {
    return this.data.hasKnockoutQuestions() && this.data.knockedOut;
  }

  get applicationResponsiblePerson(): PersonSummary {
    let responsiblePerson: PersonSummary;
    if (!!this.person) {
      responsiblePerson = this.person;
    } else if (!!this.companyOffice) {
      responsiblePerson = this.companyOffice.responsiblePerson;
    }
    return responsiblePerson;
  }
}
