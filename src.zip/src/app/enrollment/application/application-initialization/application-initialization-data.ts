import { PaymentMethodInitializationData } from '../../../common/payment-method-selection/payment-method-initialization-data';

/**
 * Groups read-only 'reference' data used while completing an application.
 */
export class ApplicationInitializationData {
  /**
   *
   * @param paymentMethodInitializationData Used to initialize PaymentMethodSelection.
   */
  constructor(readonly paymentMethodInitializationData: PaymentMethodInitializationData) {
  }
}
