import { Component, OnDestroy, OnInit } from '@angular/core';
import { CompanyOfficeImpl } from '../../../common/company-office';
import { PersonImpl } from '../../../common/person';
import { Subscription } from 'rxjs';
import { Application, ApplicationImpl } from '../application';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicationService } from '../application.service';
import { Client, ClientImpl } from '../../../common/client';
import { Agent, AgentImpl } from '../../../common/agent';
import { SecurityService } from '../../../security/security.service';
import { ApplicationInitializationData } from './application-initialization-data';
import { PersonService } from '../../../common/person-service';
import {
  BillingPersonImpl,
  RolePaymentDefinition,
} from '../../../common/payment-method-selection/billing-person';
import { PaymentMethodInitializationData } from '../../../common/payment-method-selection/payment-method-initialization-data';
import { ServiceHandler } from 'src/app/common/utils/service-handler.service';
import { GoogleTagManagerService } from 'src/app/common/services/google-tag-manager.service';

@Component({
  selector: 'app-application-initialization',
  templateUrl: './application-initialization.component.html',
  styleUrls: ['./application-initialization.component.css'],
})
export class ApplicationInitializationComponent implements OnInit, OnDestroy {

  applicationInitialized = false;

  id: number;
  bondType: string;

  application: Application = new ApplicationImpl();
  applicant: Client = new ClientImpl();
  agent: Agent = new AgentImpl();
  currentUserIsSteward: boolean;
  agentAsApplicant: boolean;
  applicationInitialization: ApplicationInitializationData; // Groups data common to applications to reduce number of 'inputs'.

  paramsSubscription: Subscription;

  errorMessage: string;
  errorClass = 'errorClass';

  constructor(private activatedRoute: ActivatedRoute, private applicationService: ApplicationService,
    private securityService: SecurityService, private router: Router,
    private serviceHandler: ServiceHandler, private personService: PersonService, public gtmService: GoogleTagManagerService) {
  }

  ngOnInit() {
    this.paramsSubscription = this.activatedRoute.params.subscribe(
      async (params) => {
        if (params.id && params.bondType) {
          // the + converts it to a number
          this.id = +params.id;
          this.bondType = params.bondType;

          this.application = await this.applicationService.getById(this.id);
          const bondArray = ['estate', 'conservatorship', 'trustee', 'guardianship', 'receiver', 'referee'];
          let notAppealBond = false;
          if (bondArray.indexOf(this.bondType) > -1) {
            notAppealBond = true;
          } else {
            notAppealBond = false;
          }
          if (notAppealBond) {
            localStorage.setItem('compOrInd', 'false');
          } else {
            // localStorage.setItem('compOrInd', this.companyOrIndividual ? 'true' : 'false');
            localStorage.setItem('compOrInd', this.application['data']['companyOrIndividual'] === 'Company' ? 'true' : 'false');
          }
          if (this.application.status !== 'In Progress') {
            return this.router.navigateByUrl(`/enrollment/application-overview?formId=${this.application.id}`);
          }
          if (this.application.companyOffice) {
            this.applicant.companyOffice = new CompanyOfficeImpl();
            this.applicant.companyOffice.id = this.application.companyOffice.id;
          } else if (this.application.person) {
            this.applicant.person = new PersonImpl();
            this.applicant.person.id = this.application.person.id;
          }

          this.currentUserIsSteward = this.securityService.user && this.securityService.user.isSteward;
          // see if the application has an agent associated
          let agentIsApplicant = false;
          if (this.application.agent && this.application.agent.id) {
            this.agent = this.application.agent;
          }
          if (this.applicantIsPersonOfAgent() || this.applicantIsCompanyOfficeOfAgent()) {
            agentIsApplicant = true;
          }
          this.agentAsApplicant = agentIsApplicant;

          // paymentMethodToBeUsedImmediately for Application if user is a client or user is an agent but acting on their own behalf.
          const paymentMethodToBeUsedImmediately = !this.currentUserIsSteward || (this.currentUserIsSteward && agentIsApplicant);
          const paymentMethodInitializationData = new PaymentMethodInitializationData(agentIsApplicant
            , this.currentUserIsSteward
            , true // Don't allow agent to select existing client BPs.
            , paymentMethodToBeUsedImmediately
          );
          this.applicationInitialization = new ApplicationInitializationData(paymentMethodInitializationData);

          // IMPORTANT: 'applicationInitialized' is used as a 'master' switch to control display of applications in template.
          // Any 'data' that needs to be immediately available to sub-components needs to be available prior to switching it to true.
          this.applicationInitialized = true;

          this.populatePaymentMethodInitializationData();

        }
      }
    );
    this.serviceHandler.getErrorBlock().subscribe(err => {
      this.errorMessage = err;
    });
  }

  ngOnDestroy(): void {
    this.paramsSubscription.unsubscribe();
    this.applicationInitialized = false;
    localStorage.removeItem('compOrInd');
  }

  private applicantIsPersonOfAgent(): boolean {
    return this.currentUserIsSteward &&
      this.applicant.person &&
      this.applicant.person.id &&
      this.applicant.person.id === this.securityService.user.person.id;
  }

  private applicantIsCompanyOfficeOfAgent(): boolean {
    return this.currentUserIsSteward &&
      this.applicant.companyOffice &&
      this.applicant.companyOffice.id &&
      this.securityService.user.person.companyOfficePersons.some(
        cop => cop.responsiblePerson && cop.companyOffice.id === this.applicant.companyOffice.id
      );
  }

  /**
   * Populate initialization data for Application Payment data collection.
   */
  private populatePaymentMethodInitializationData() {
    const paymentMethodInitializationData = this.applicationInitialization.paymentMethodInitializationData;
    {
      // ApplicantBillingPerson
      if (!!this.application.person) {
        // Application-responsible-party is an individual person or agent.
        const personSummary = this.application.person;
        const overrideAddress = undefined;
        const rolePaymentDefinition = RolePaymentDefinition.clientRolePaymentDefinition;
        const billingPerson = BillingPersonImpl
          .createBillingPersonFromPersonSummary(personSummary, rolePaymentDefinition, overrideAddress);
        paymentMethodInitializationData.applicantBillingPerson$.next(billingPerson);
      } else if (!!this.application.companyOffice) {
        // Application-responsible-party is the company office responsible person. We need to fetch their personSummary.
        // Can't rely on this.applicant.companyOffice  because it is not fully populated.
        this.personService.getCompanyOfficeResponsiblePersonByCompanyOfficeId(this.application.companyOffice.id)
          .then((personSummary) => {
            // Use the company-office address instead of the company-office-responsible-person's address.
            const overrideAddress = this.application.companyOffice.address;
            const rolePaymentDefinition = RolePaymentDefinition.clientRolePaymentDefinition;
            const billingPerson = BillingPersonImpl
              .createBillingPersonFromPersonSummary(personSummary, rolePaymentDefinition, overrideAddress);
            paymentMethodInitializationData.applicantBillingPerson$.next(billingPerson);
          });
      } else {
        paymentMethodInitializationData.applicantBillingPerson$.next(null);
      }
    }
    {
      // Secondary Billing Person
      if (!!this.application.agent && this.application.agent.id) {
        // The application has an agent. The agent is therefore the secondary BillingPerson if:
        // - The agent is not the applicant.
        // - The agent is the logged-in user.
        // Note that we're actually settling for logged-in user is a steward
        // and not checking if the logged-in user is the application's agent.
        if (!paymentMethodInitializationData.agentIsApplicant
          && paymentMethodInitializationData.currentUserIsSteward) {
          // We have a Secondary Billing Person.
          // Agent is acting on somebody else's behalf, billing address should be the agent's company's address.
          const loggedInUser = this.securityService.user;
          const overrideAddress = loggedInUser.person.companyOfficePersons[0].companyOffice.address;
          const billingPerson = BillingPersonImpl.createBillingPersonFromUser(loggedInUser, overrideAddress);
          paymentMethodInitializationData.secondaryBillingPerson$.next(billingPerson);
        } else {
          // No Secondary Billing Person
          paymentMethodInitializationData.secondaryBillingPerson$.next(null);
        }
      } else {
        paymentMethodInitializationData.secondaryBillingPerson$.next(null);
      }
    }
  }



  displayError(): boolean {
    return !!this.errorMessage && this.errorMessage.length > 1;
  }

  removeErrorMessage() {
    this.errorMessage = '';
  }
}
