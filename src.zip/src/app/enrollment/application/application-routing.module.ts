import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../security/app.auth.guard';
import { PreApplicationComponent } from './pre-application/pre-application.component';
import { ApplicationInitializationComponent } from './application-initialization/application-initialization.component';
import { LoggedInResolver } from './providers/logged-in.resolver';

const routes: Routes = [
  { path: ':bondType/select-applicant', component: PreApplicationComponent, data: { displayState: 'SELECTING' } },
  { path: ':bondType/add-applicant', component: PreApplicationComponent, data: { displayState: 'ADDING' } },
  { path: ':bondType/add-company-info', component: PreApplicationComponent, data: { displayState: 'BUSINESS_INFO' } },
  { path: ':bondType/:id', component: ApplicationInitializationComponent, canActivate: [AuthGuard] },
  { path: ':bondType', component: PreApplicationComponent, resolve: { loggedIn: LoggedInResolver } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ApplicationRoutingModule { }
