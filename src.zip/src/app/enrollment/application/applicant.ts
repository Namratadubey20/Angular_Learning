export interface Applicant {
  person?: any;
  company?: string;
  applicantType?: string;
}
