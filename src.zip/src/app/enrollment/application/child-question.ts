import { Auditable, AuditableObject } from '../../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';

export interface ChildQuestion extends Auditable {
  id: number;
  questionId: number;
  answerId: number;
}

@JsonObject('ChildQuestionImpl')
export class ChildQuestionImpl extends AuditableObject implements ChildQuestion {
  @JsonProperty('questionId', Number, true)
  questionId: number = null;

  @JsonProperty('answerId', Number, true)
  answerId: number = null;
}
