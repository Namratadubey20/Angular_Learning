import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApplicationRoutingModule } from './application-routing.module';
import { PremiumCalculationComponent } from './pre-application/premium-calculation/premium-calculation.component';
import { AppealsSupersedeasComponent } from './court/appeals-supersedeas/appeals-supersedeas.component';
import { ReplevinComponent } from './court/replevin/replevin.component';
import { AttachmentComponent } from './court/attachment/attachment.component';
import { InjunctionComponent } from './court/injunction/injunction.component';
import { JudgmentComponent } from './court/appeals-supersedeas/judgment/judgment.component';
import {
  MatButtonModule,
  MatCardModule,
  MatDividerModule,
  MatFormFieldModule,
  MatGridListModule,
  MatInputModule,
  MatSelectModule,
  MatToolbarModule,
  MatTooltipModule,
} from '@angular/material';
import { MatRadioModule } from '@angular/material/radio';
import { MatStepperModule } from '@angular/material/stepper';
import {
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import { PremiumCalculationService } from './pre-application/premium-calculation/premium-calculation.service';
import { ConservatorshipComponent } from './court/conservatorship-guardianship/conservatorship/conservatorship.component';
import { GuardianshipComponent } from './court/conservatorship-guardianship/guardianship/guardianship.component';
import { RefereeComponent } from './court/referee-receiver/referee/referee.component';
import { ReceiverComponent } from './court/referee-receiver/receiver/receiver.component';
import { ToolbarComponent } from './court/toolbar/toolbar.component';
import { EstateComponent } from './court/estate-trustee/estate/estate.component';
import { TrusteeComponent } from './court/estate-trustee/trustee/trustee.component';
import { ApplicationService } from './application.service';
import { AppealsSupersedeasFormArrayMapper } from './court/appeals-supersedeas/appeals-supersedeas-form-array-mapper.service';
import {
  CalendarModule,
  CheckboxModule
} from 'primeng/primeng';
import { ConservatorshipGuardianshipFormArrayMapper } from './court/conservatorship-guardianship/conservatorship-guardianship-form-array-mapper.service';
import { EstateTrusteeFormArrayMapper } from './court/estate-trustee/estate-trustee-form-array-mapper.service';
import { RefereeReceiverFormArrayMapper } from './court/referee-receiver/referee-receiver-form-array-mapper.service';
import { EnrollmentModule } from '../enrollment.module';
import { PreApplicationComponent } from './pre-application/pre-application.component';
import { DeceasedInfoComponent } from './court/estate-trustee/deceased-info/deceased-info.component';
import { EstateInfoComponent } from './court/estate-trustee/estate-info/estate-info.component';
import { PnlApplicationComponent } from './pnl-application/pnl-application.component';
import { PnlApplicationQuoteComponent } from './pnl-application/pnl-application-quote/pnl-application-quote.component';
import { CurrencyQuestionComponent } from './question/currency-question/currency-question.component';
import { DateQuestionComponent } from './question/date-question/date-question.component';
import { EditQuestionComponent } from './question/edit-question/edit-question.component';
import { InputQuestionComponent } from './question/input-question/input-question.component';
import { QuestionComponent } from './question/question.component';
import { RadioQuestionComponent } from './question/radio-question/radio-question.component';
import { TextThenChildrenQuestionComponent } from './question/text-then-children-question/text-then-children-question.component';
import { SelectQuestionComponent } from './question/select-question/select-question.component';
import { EmailQuestionComponent } from './question/email-question/email-question.component';
import { PhoneQuestionComponent } from './question/phone-question/phone-question.component';
import { CheckboxQuestionComponent } from './question/checkbox-question/checkbox-question.component';
import { UploadFileQuestionComponent } from './question/upload-file-question/upload-file-question.component';
import { DynamicQuestionComponent } from './dynamic-question/dynamic-question.component';
import { ChildQuestionComponent } from './question/child-question/child-question.component';
import { CurrencyChildQuestionComponent } from './question/child-question/currency-child-question/currency-child-question.component';
import { DateChildQuestionComponent } from './question/child-question/date-child-question/date-child-question.component';
import { InputChildQuestionComponent } from './question/child-question/input-child-question/input-child-question.component';
import { RadioChildQuestionComponent } from './question/child-question/radio-child-question/radio-child-question.component';
import { SelectChildQuestionComponent } from './question/child-question/select-child-question/select-child-question.component';
import { EmailChildQuestionComponent } from './question/child-question/email-child-question/email-child-question.component';
import { PhoneChildQuestionComponent } from './question/child-question/phone-child-question/phone-child-question.component';
import { CheckboxChildQuestionComponent } from './question/child-question/checkbox-child-question/checkbox-child-question.component';
import { ApplicationInitializationComponent } from './application-initialization/application-initialization.component';
import { PnlApplicationService } from './pnl-application.service';
import { PnlApplicationQuoteService } from './pnl-application/pnl-application-quote/pnl-application-quote.service';
import { StepperFormArrayMapper } from './pnl-application/pnl-form-array-mapper.service';
import { CommonComponentsModule } from '../../common/common-components.module';
import { NumberQuestionComponent } from './question/number-question/number-question.component';
import { NumberChildQuestionComponent } from './question/child-question/number-child-question/number-child-question.component';
import { PreCourtApplicationComponent } from './pre-application/pre-court-application/pre-court-application.component';
import { SelectStateAndPrimaryServiceComponent } from './pre-application/pre-pnl-application/select-state-and-primary-service/select-state-and-primary-service.component';
import { PrePnlApplicationComponent } from './pre-application/pre-pnl-application/pre-pnl-application.component';
import { SelectApplicantComponent } from '../select-applicant/select-applicant.component';
import { DataListModule } from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { AgentHandoffComponent } from '../agent-handoff/agent-handoff.component';
import { PercentageQuestionComponent } from './question/percentage-question/percentage-question.component';
import { PercentageChildQuestionComponent } from './question/child-question/percentage-child-question/percentage-child-question.component';
import { UserModule } from '../../user/user.module';
import { FormComponentsModule } from '../../form-components/form-components.module';
import { LoggedInResolver } from './providers/logged-in.resolver';
import { ChangeBondAmountDialogComponent } from './court/change-bond-amount/change-bond-amount-dialog.component';
import { AddCompanyNameDialogComponent } from './court/add-company-name/add-company-name-dialog.component';

@NgModule({
  imports: [
    CommonModule,
    EnrollmentModule,
    ReactiveFormsModule,
    FormsModule,
    DataListModule,
    TableModule,
    ApplicationRoutingModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    MatStepperModule,
    MatDividerModule,
    MatToolbarModule,
    MatRadioModule,
    MatSelectModule,
    MatGridListModule,
    MatTooltipModule,
    CalendarModule,
    CheckboxModule,
    CommonComponentsModule,
    UserModule,
    FormComponentsModule,
  ],
  declarations: [
    CurrencyQuestionComponent,
    DateQuestionComponent,
    EditQuestionComponent,
    InputQuestionComponent,
    QuestionComponent,
    RadioQuestionComponent,
    TextThenChildrenQuestionComponent,
    SelectQuestionComponent,
    PremiumCalculationComponent,
    JudgmentComponent,
    AppealsSupersedeasComponent,
    ReplevinComponent,
    AttachmentComponent,
    InjunctionComponent,
    ConservatorshipComponent,
    GuardianshipComponent,
    RefereeComponent,
    ReceiverComponent,
    EstateComponent,
    TrusteeComponent,
    ToolbarComponent,
    ChangeBondAmountDialogComponent,
    PreApplicationComponent,
    DeceasedInfoComponent,
    EstateInfoComponent,
    PnlApplicationComponent,
    PnlApplicationQuoteComponent,
    EmailQuestionComponent,
    PhoneQuestionComponent,
    CheckboxQuestionComponent,
    UploadFileQuestionComponent,
    DynamicQuestionComponent,
    ChildQuestionComponent,
    CurrencyChildQuestionComponent,
    DateChildQuestionComponent,
    InputChildQuestionComponent,
    RadioChildQuestionComponent,
    SelectChildQuestionComponent,
    EmailChildQuestionComponent,
    PhoneChildQuestionComponent,
    CheckboxChildQuestionComponent,
    ApplicationInitializationComponent,
    NumberQuestionComponent,
    NumberChildQuestionComponent,
    AgentHandoffComponent,
    PreCourtApplicationComponent,
    PrePnlApplicationComponent,
    SelectApplicantComponent,
    SelectStateAndPrimaryServiceComponent,
    PercentageQuestionComponent,
    PercentageChildQuestionComponent,
    AddCompanyNameDialogComponent,
  ],
  providers: [
    AppealsSupersedeasFormArrayMapper,
    ConservatorshipGuardianshipFormArrayMapper,
    EstateTrusteeFormArrayMapper,
    RefereeReceiverFormArrayMapper,
    PremiumCalculationService,
    ApplicationService,
    PnlApplicationService,
    PnlApplicationQuoteService,
    StepperFormArrayMapper,
    LoggedInResolver,
  ],
  exports: [
    JudgmentComponent,
  ],
  entryComponents: [
    ChangeBondAmountDialogComponent,
    AddCompanyNameDialogComponent,
  ],
})
export class ApplicationModule {
}
