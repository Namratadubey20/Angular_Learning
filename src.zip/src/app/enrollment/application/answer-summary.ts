import { Auditable, AuditableObject } from '../../common/auditable-object';
import { JsonObject, JsonProperty } from 'json2typescript';

export interface AnswerSummary extends Auditable {
  id: number;
  answer: string;
}

@JsonObject('AnswerSummaryImpl')
export class AnswerSummaryImpl extends AuditableObject implements AnswerSummary {
  @JsonProperty('answer', String, true)
  answer: string = null;
}
