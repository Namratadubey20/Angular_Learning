import {
  Component,
  Input, OnInit
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  Validators
} from '@angular/forms';
import { ApplicationService } from '../application/application.service';
import { states } from '../../common/utils/constants';
import { SecurityService } from 'src/app/security/security.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-applicant-info',
  templateUrl: './applicant-info.component.html',
  styleUrls: ['./applicant-info.component.css'],
})

export class ApplicantInfoComponent implements OnInit {

  @Input()
  applicantInfoFormGroup: FormGroup;
  applicantData: any;
  zipCodeData: object;
  states = states;
  bondType;
  isAppealBond;
  disableApplicantName: boolean;
  isCompanySelected;
  constructor(
    private applicationService: ApplicationService,
    private securityService: SecurityService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.initializeForm();
    this.populateApplicantForm();
  }

  trackByStateAbbrev(index: number, stateAbbreviation: string): string {
    return stateAbbreviation;
  }
  getZipCode(zipCode) {
    if (zipCode.target.value) {
      this.applicationService.getZipCode(zipCode.target.value).subscribe((response) => {
        this.zipCodeData = response;
        this.applicantInfoFormGroup.get('applicantAddress.city').setValue(this.zipCodeData['city']);
        this.applicantInfoFormGroup.get('applicantAddress.state').setValue(this.zipCodeData['state']);
        this.applicantInfoFormGroup.get('applicantAddress').updateValueAndValidity();
      });
    }
  }
  initializeForm() {
    this.applicantInfoFormGroup.get('applicantEmail').disable();
    // this.applicantInfoFormGroup.get('applicantName').disable();
    this.applicantInfoFormGroup.get('applicantAddress.street1').setValidators([Validators.required]);
    this.applicantInfoFormGroup.get('applicantAddress.city').setValidators([Validators.required]);
    this.applicantInfoFormGroup.get('applicantAddress.state').setValidators([Validators.required]);
    this.applicantInfoFormGroup.get('applicantAddress.zipCode').setValidators([Validators.required]);
    this.applicantInfoFormGroup.get('applicantPhone').setValidators([Validators.required]);
    this.applicantInfoFormGroup.get('applicantName').setValidators([Validators.required]);
  }
  populateApplicantForm() {
    if (localStorage.getItem('compOrInd')) {
      this.isCompanySelected = localStorage.getItem('compOrInd') === 'true' ? true : false;
    } else {
      this.isCompanySelected = false;
    }
    if (this.applicantInfoFormGroup.value.applicantName) {
      this.applicantInfoFormGroup.get('applicantName').disable();
    } else {
      this.applicantInfoFormGroup.get('applicantName').enable();
    }
  }
}
