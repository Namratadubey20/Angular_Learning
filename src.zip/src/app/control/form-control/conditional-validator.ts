import { AbstractControl, ValidatorFn, Validators } from '@angular/forms';

export class ConditionalValidator {
  static required(condition: (() => boolean)): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!condition()) {
        return null;
      } else {
        return Validators.required(control);
      }
    };
  }
}

