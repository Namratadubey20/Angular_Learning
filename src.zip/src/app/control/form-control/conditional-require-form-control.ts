import { AsyncValidatorFn, FormControl, ValidatorFn } from '@angular/forms';
import { ConditionalValidator } from './conditional-validator';


export class ConditionalRequireFormControl extends FormControl {
  constructor(formState: any, condition?: () => boolean, validatorOrOpts?: ValidatorFn | ValidatorFn[] | null,
    asyncValidator?: AsyncValidatorFn | AsyncValidatorFn[] | null) {
    // add required validator, after checking what the type of validatorOrOpts
    if (validatorOrOpts !== null && validatorOrOpts !== undefined) {
      if (validatorOrOpts instanceof Array) {
        (validatorOrOpts as Array<ValidatorFn>).push(ConditionalValidator.required(condition));
      } else {
        validatorOrOpts = [validatorOrOpts, ConditionalValidator.required(condition)];
      }
    } else {
      validatorOrOpts = ConditionalValidator.required(condition);
    }
    super(formState, validatorOrOpts, asyncValidator);
  }
}
